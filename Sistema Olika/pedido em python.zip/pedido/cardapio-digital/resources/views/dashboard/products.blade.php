@extends('dashboard.layout-complete')

@section('title', 'Gestão de Produtos - Cardápio Digital Olika')
@section('page-title', 'Gestão de Produtos')

@section('content')
<div class="space-y-6">
    <!-- Header com Ações -->
    <div class="bg-white rounded-xl p-6 shadow-lg">
        <div class="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
            <div>
                <h2 class="text-2xl font-bold text-gray-900">Produtos</h2>
                <p class="text-gray-600">Gerencie o catálogo de produtos do seu restaurante</p>
            </div>
            
            <div class="flex flex-col sm:flex-row gap-4">
                <!-- Busca -->
                <div class="relative">
                    <input 
                        type="text" 
                        id="search-products"
                        placeholder="Buscar produtos..."
                        class="w-full sm:w-64 pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                    <svg class="absolute left-3 top-2.5 w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                    </svg>
                </div>
                
                <!-- Categoria -->
                <select id="category-filter" class="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <option value="">Todas as categorias</option>
                    <option value="1">Pratos Principais</option>
                    <option value="2">Bebidas</option>
                    <option value="3">Sobremesas</option>
                </select>
                
                <!-- Botão Adicionar -->
                <button id="add-product-btn" class="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition flex items-center space-x-2">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
                    </svg>
                    <span>Adicionar Produto</span>
                </button>
            </div>
        </div>
    </div>

    <!-- Stats Cards -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div class="bg-white rounded-xl p-6 shadow-lg">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-gray-600">Total de Produtos</p>
                    <p class="text-2xl font-bold text-gray-900">45</p>
                </div>
                <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <svg class="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"></path>
                    </svg>
                </div>
            </div>
        </div>
        
        <div class="bg-white rounded-xl p-6 shadow-lg">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-gray-600">Disponíveis</p>
                    <p class="text-2xl font-bold text-green-600">42</p>
                </div>
                <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                    <svg class="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                    </svg>
                </div>
            </div>
        </div>
        
        <div class="bg-white rounded-xl p-6 shadow-lg">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-gray-600">Indisponíveis</p>
                    <p class="text-2xl font-bold text-red-600">3</p>
                </div>
                <div class="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                    <svg class="w-6 h-6 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                </div>
            </div>
        </div>
        
        <div class="bg-white rounded-xl p-6 shadow-lg">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-gray-600">Em Destaque</p>
                    <p class="text-2xl font-bold text-yellow-600">8</p>
                </div>
                <div class="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                    <svg class="w-6 h-6 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"></path>
                    </svg>
                </div>
            </div>
        </div>
    </div>

    <!-- Lista de Produtos -->
    <div class="bg-white rounded-xl shadow-lg">
        <div class="p-6 border-b border-gray-200">
            <h3 class="text-lg font-semibold text-gray-900">Lista de Produtos</h3>
        </div>
        
        <div class="overflow-x-auto">
            <table class="w-full">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Produto</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Categoria</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Preço</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Destaque</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ações</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200" id="products-table-body">
                    <!-- Produto 1 -->
                    <tr class="hover:bg-gray-50">
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="flex items-center space-x-4">
                                <img src="/placeholder.svg" alt="Pizza Margherita" class="w-12 h-12 object-cover rounded-lg">
                                <div>
                                    <div class="text-sm font-medium text-gray-900">Pizza Margherita</div>
                                    <div class="text-sm text-gray-500">Molho de tomate, mussarela, manjericão</div>
                                </div>
                            </div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">Pratos Principais</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">R$ 45,00</td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                Disponível
                            </span>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <label class="relative inline-flex items-center cursor-pointer">
                                <input type="checkbox" class="sr-only peer" checked>
                                <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                            </label>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                            <button class="text-blue-600 hover:text-blue-900 edit-product" data-product-id="1">Editar</button>
                            <button class="text-green-600 hover:text-green-900 toggle-status" data-product-id="1">Desativar</button>
                            <button class="text-red-600 hover:text-red-900 delete-product" data-product-id="1">Excluir</button>
                        </td>
                    </tr>
                    
                    <!-- Produto 2 -->
                    <tr class="hover:bg-gray-50">
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="flex items-center space-x-4">
                                <img src="/placeholder.svg" alt="Hambúrguer Clássico" class="w-12 h-12 object-cover rounded-lg">
                                <div>
                                    <div class="text-sm font-medium text-gray-900">Hambúrguer Clássico</div>
                                    <div class="text-sm text-gray-500">Pão, carne, queijo, alface, tomate</div>
                                </div>
                            </div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">Pratos Principais</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">R$ 25,00</td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                Disponível
                            </span>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <label class="relative inline-flex items-center cursor-pointer">
                                <input type="checkbox" class="sr-only peer">
                                <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                            </label>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                            <button class="text-blue-600 hover:text-blue-900 edit-product" data-product-id="2">Editar</button>
                            <button class="text-green-600 hover:text-green-900 toggle-status" data-product-id="2">Desativar</button>
                            <button class="text-red-600 hover:text-red-900 delete-product" data-product-id="2">Excluir</button>
                        </td>
                    </tr>
                    
                    <!-- Produto 3 -->
                    <tr class="hover:bg-gray-50">
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="flex items-center space-x-4">
                                <img src="/placeholder.svg" alt="Refrigerante" class="w-12 h-12 object-cover rounded-lg">
                                <div>
                                    <div class="text-sm font-medium text-gray-900">Refrigerante</div>
                                    <div class="text-sm text-gray-500">Coca-Cola, Pepsi, Guaraná</div>
                                </div>
                            </div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">Bebidas</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">R$ 8,00</td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">
                                Indisponível
                            </span>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <label class="relative inline-flex items-center cursor-pointer">
                                <input type="checkbox" class="sr-only peer">
                                <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                            </label>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                            <button class="text-blue-600 hover:text-blue-900 edit-product" data-product-id="3">Editar</button>
                            <button class="text-green-600 hover:text-green-900 toggle-status" data-product-id="3">Ativar</button>
                            <button class="text-red-600 hover:text-red-900 delete-product" data-product-id="3">Excluir</button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal de Adicionar/Editar Produto -->
<div id="product-modal" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden flex items-center justify-center p-4">
    <div class="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div class="p-6 border-b border-gray-200">
            <div class="flex items-center justify-between">
                <h3 class="text-xl font-bold text-gray-900" id="modal-title">Adicionar Produto</h3>
                <button id="close-product-modal" class="text-gray-500 hover:text-gray-700">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                </button>
            </div>
        </div>
        
        <form id="product-form" class="p-6 space-y-6">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- Nome -->
                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Nome do Produto *</label>
                    <input type="text" name="name" required class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
                
                <!-- Descrição -->
                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Descrição</label>
                    <textarea name="description" rows="3" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"></textarea>
                </div>
                
                <!-- Preço -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Preço (R$) *</label>
                    <input type="number" name="price" step="0.01" required class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
                
                <!-- Categoria -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Categoria *</label>
                    <select name="category_id" required class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="">Selecione uma categoria</option>
                        <option value="1">Pratos Principais</option>
                        <option value="2">Bebidas</option>
                        <option value="3">Sobremesas</option>
                    </select>
                </div>
                
                <!-- Tempo de Preparo -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Tempo de Preparo (min)</label>
                    <input type="number" name="preparation_time" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
                
                <!-- Ingredientes -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Ingredientes</label>
                    <input type="text" name="ingredients" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
            </div>
            
            <!-- Imagem -->
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Imagem do Produto</label>
                <input type="file" name="image" accept="image/*" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>
            
            <!-- Status e Destaque -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div class="flex items-center">
                    <input type="checkbox" name="available" id="available" class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500">
                    <label for="available" class="ml-2 text-sm font-medium text-gray-700">Disponível</label>
                </div>
                
                <div class="flex items-center">
                    <input type="checkbox" name="featured" id="featured" class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500">
                    <label for="featured" class="ml-2 text-sm font-medium text-gray-700">Produto em Destaque</label>
                </div>
            </div>
            
            <!-- Botões -->
            <div class="flex space-x-3 pt-6">
                <button type="button" id="cancel-product" class="flex-1 bg-gray-300 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-400 transition">
                    Cancelar
                </button>
                <button type="submit" class="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition">
                    Salvar Produto
                </button>
            </div>
        </form>
    </div>
</div>

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    const modal = document.getElementById('product-modal');
    const form = document.getElementById('product-form');
    const modalTitle = document.getElementById('modal-title');
    
    // Abrir modal para adicionar produto
    document.getElementById('add-product-btn').addEventListener('click', function() {
        modalTitle.textContent = 'Adicionar Produto';
        form.reset();
        modal.classList.remove('hidden');
    });
    
    // Fechar modal
    document.getElementById('close-product-modal').addEventListener('click', function() {
        modal.classList.add('hidden');
    });
    
    document.getElementById('cancel-product').addEventListener('click', function() {
        modal.classList.add('hidden');
    });
    
    // Editar produto
    document.querySelectorAll('.edit-product').forEach(button => {
        button.addEventListener('click', function() {
            const productId = this.dataset.productId;
            modalTitle.textContent = 'Editar Produto';
            // Aqui você carregaria os dados do produto
            modal.classList.remove('hidden');
        });
    });
    
    // Toggle status do produto
    document.querySelectorAll('.toggle-status').forEach(button => {
        button.addEventListener('click', function() {
            const productId = this.dataset.productId;
            const currentText = this.textContent;
            const newText = currentText === 'Ativar' ? 'Desativar' : 'Ativar';
            
            if (confirm(`Tem certeza que deseja ${newText.toLowerCase()} este produto?`)) {
                this.textContent = newText;
                showToast(`Produto ${newText.toLowerCase()}do com sucesso!`, 'success');
                // Aqui você faria a chamada para a API
            }
        });
    });
    
    // Excluir produto
    document.querySelectorAll('.delete-product').forEach(button => {
        button.addEventListener('click', function() {
            const productId = this.dataset.productId;
            
            if (confirm('Tem certeza que deseja excluir este produto? Esta ação não pode ser desfeita.')) {
                showToast('Produto excluído com sucesso!', 'success');
                // Aqui você faria a chamada para a API
                // this.closest('tr').remove();
            }
        });
    });
    
    // Salvar produto
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        
        // Simular salvamento
        showToast('Produto salvo com sucesso!', 'success');
        modal.classList.add('hidden');
        
        // Aqui você faria a chamada para a API
        // saveProduct(formData);
    });
    
    // Filtros
    const searchInput = document.getElementById('search-products');
    const categoryFilter = document.getElementById('category-filter');
    
    function applyFilters() {
        const searchTerm = searchInput.value.toLowerCase();
        const selectedCategory = categoryFilter.value;
        
        const rows = document.querySelectorAll('#products-table-body tr');
        
        rows.forEach(row => {
            const productName = row.querySelector('td:first-child .text-sm').textContent.toLowerCase();
            const category = row.querySelector('td:nth-child(2)').textContent;
            
            const matchesSearch = productName.includes(searchTerm);
            const matchesCategory = !selectedCategory || category.includes(selectedCategory);
            
            if (matchesSearch && matchesCategory) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    }
    
    searchInput.addEventListener('input', applyFilters);
    categoryFilter.addEventListener('change', applyFilters);
    
    // Toggle destaque
    document.querySelectorAll('input[type="checkbox"]').forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            const productId = this.closest('tr').querySelector('.edit-product').dataset.productId;
            const isFeatured = this.checked;
            
            showToast(`Produto ${isFeatured ? 'adicionado' : 'removido'} dos destaques!`, 'success');
            // Aqui você faria a chamada para a API
        });
    });
});
</script>
@endpush
@endsection
