@extends('client.layout')

@section('title', ($settings->business_name ?? 'Cardápio Digital') . ' - Menu')

@section('content')
<div x-data="menuData()" x-init="init()" class="min-h-screen bg-gray-50">
    <!-- Header -->
    <header class="gradient-primary text-white py-6">
        <div class="container mx-auto px-4">
            <div class="flex items-center justify-between">
                <div>
                    <h1 class="text-2xl font-bold">{{ $settings->business_name ?? 'Cardápio Digital' }}</h1>
                    @if($settings->business_description)
                        <p class="text-white/90 mt-1">{{ $settings->business_description }}</p>
                    @endif
                </div>
                <div class="flex items-center gap-4">
                    <!-- Search -->
                    <div class="relative">
                        <input 
                            x-model="searchTerm" 
                            @input="filterProducts()"
                            type="text" 
                            placeholder="Buscar produtos..."
                            class="bg-white/20 border border-white/30 rounded-lg px-4 py-2 text-white placeholder-white/70 focus:outline-none focus:ring-2 focus:ring-white/50"
                        >
                        <i data-lucide="search" class="absolute right-3 top-2.5 w-4 h-4 text-white/70"></i>
                    </div>
                    
                    <!-- Cart -->
                    <a href="/cart" class="relative bg-white/20 hover:bg-white/30 rounded-lg p-2 transition-colors">
                        <i data-lucide="shopping-cart" class="w-6 h-6 text-white"></i>
                        <span id="cart-count" class="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center hidden">0</span>
                    </a>
                </div>
            </div>
        </div>
    </header>

    <main class="container mx-auto px-4 py-6">
        <!-- Category Tabs -->
        <div class="flex items-center justify-between mb-6 gap-4">
            <div class="flex-1 overflow-x-auto">
                <div class="flex gap-2 pb-2">
                    <button 
                        @click="selectCategory('all')"
                        :class="selectedCategory === 'all' ? 'bg-blue-600 text-white' : 'bg-white text-gray-700 hover:bg-gray-50'"
                        class="px-4 py-2 rounded-lg font-medium whitespace-nowrap transition-colors"
                    >
                        Todos
                    </button>
                    <template x-for="category in categories" :key="category.id">
                        <button 
                            @click="selectCategory(category.id)"
                            :class="selectedCategory === category.id ? 'bg-blue-600 text-white' : 'bg-white text-gray-700 hover:bg-gray-50'"
                            class="px-4 py-2 rounded-lg font-medium whitespace-nowrap transition-colors"
                            x-text="category.name"
                        ></button>
                    </template>
                </div>
            </div>
            
            <!-- Display Mode -->
            <div class="flex bg-white rounded-lg p-1">
                <button 
                    @click="displayMode = 'grid'"
                    :class="displayMode === 'grid' ? 'bg-blue-600 text-white' : 'text-gray-600'"
                    class="px-3 py-1 rounded-md transition-colors"
                    title="Grade"
                >
                    <i data-lucide="grid-3x3" class="w-4 h-4"></i>
                </button>
                <button 
                    @click="displayMode = 'list'"
                    :class="displayMode === 'list' ? 'bg-blue-600 text-white' : 'text-gray-600'"
                    class="px-3 py-1 rounded-md transition-colors"
                    title="Lista"
                >
                    <i data-lucide="list" class="w-4 h-4"></i>
                </button>
                <button 
                    @click="displayMode = 'compact'"
                    :class="displayMode === 'compact' ? 'bg-blue-600 text-white' : 'text-gray-600'"
                    class="px-3 py-1 rounded-md transition-colors"
                    title="Compacto"
                >
                    <i data-lucide="grid-2x2" class="w-4 h-4"></i>
                </button>
            </div>
        </div>

        <!-- Featured Products -->
        <div x-show="featuredProducts.length > 0 && selectedCategory === 'all'" class="mb-8">
            <h2 class="text-2xl font-bold mb-4 flex items-center gap-2">
                <i data-lucide="star" class="w-6 h-6 text-yellow-500 fill-current"></i>
                Produtos em Destaque
            </h2>
            <div :class="getGridClass()">
                <template x-for="product in featuredProducts" :key="product.id">
                    @include('client.components.product-card')
                </template>
            </div>
        </div>

        <!-- Products -->
        <div :class="getGridClass()">
            <template x-for="product in filteredProducts" :key="product.id">
                @include('client.components.product-card')
            </template>
        </div>

        <!-- Empty State -->
        <div x-show="filteredProducts.length === 0" class="text-center py-12 text-gray-500">
            <i data-lucide="search-x" class="w-16 h-16 mx-auto mb-4 text-gray-300"></i>
            <p class="text-lg">Nenhum produto encontrado</p>
            <p class="text-sm">Tente ajustar os filtros ou buscar por outro termo</p>
        </div>
    </main>

    <!-- Product Detail Modal -->
    <div x-show="selectedProduct" x-cloak class="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
        <div x-show="selectedProduct" class="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div class="sticky top-0 bg-white border-b p-4 flex items-center justify-between">
                <h3 class="text-xl font-bold" x-text="selectedProduct?.name"></h3>
                <button @click="selectedProduct = null" class="text-gray-500 hover:text-gray-700">
                    <i data-lucide="x" class="w-6 h-6"></i>
                </button>
            </div>
            
            <div class="p-6">
                <template x-if="selectedProduct">
                    <div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <!-- Product Image -->
                            <div class="aspect-square bg-gray-100 rounded-lg overflow-hidden">
                                <img 
                                    :src="selectedProduct.image || '/images/placeholder-product.jpg'" 
                                    :alt="selectedProduct.name"
                                    class="w-full h-full object-cover"
                                >
                            </div>
                            
                            <!-- Product Info -->
                            <div class="space-y-4">
                                <div>
                                    <h4 class="text-2xl font-bold" x-text="selectedProduct.name"></h4>
                                    <p class="text-gray-600" x-text="selectedProduct.description"></p>
                                </div>
                                
                                <div class="text-3xl font-bold text-blue-600" x-text="formatCurrency(selectedProduct.price)"></div>
                                
                                <div class="space-y-3">
                                    <div class="flex items-center gap-2">
                                        <span class="text-sm font-medium">Quantidade:</span>
                                        <div class="flex items-center border rounded-lg">
                                            <button @click="quantity = Math.max(1, quantity - 1)" class="px-3 py-1 hover:bg-gray-100">-</button>
                                            <span class="px-4 py-1" x-text="quantity"></span>
                                            <button @click="quantity++" class="px-3 py-1 hover:bg-gray-100">+</button>
                                        </div>
                                    </div>
                                    
                                    <button 
                                        @click="addToCart(selectedProduct.id, quantity)"
                                        class="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg font-medium transition-colors"
                                    >
                                        Adicionar ao Carrinho
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </template>
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script>
function menuData() {
    return {
        products: @json($products),
        categories: @json($categories),
        settings: @json($settings),
        selectedCategory: 'all',
        displayMode: 'grid',
        searchTerm: '',
        filteredProducts: [],
        featuredProducts: [],
        selectedProduct: null,
        quantity: 1,
        
        init() {
            this.filterProducts();
            this.featuredProducts = this.products.filter(p => p.featured && p.available);
            lucide.createIcons();
        },
        
        selectCategory(categoryId) {
            this.selectedCategory = categoryId;
            this.filterProducts();
        },
        
        filterProducts() {
            let filtered = this.products.filter(p => p.available);
            
            if (this.selectedCategory !== 'all') {
                filtered = filtered.filter(p => p.category_id == this.selectedCategory);
            }
            
            if (this.searchTerm) {
                const term = this.searchTerm.toLowerCase();
                filtered = filtered.filter(p => 
                    p.name.toLowerCase().includes(term) || 
                    p.description.toLowerCase().includes(term)
                );
            }
            
            this.filteredProducts = filtered;
        },
        
        getGridClass() {
            switch(this.displayMode) {
                case 'list':
                    return 'space-y-4';
                case 'compact':
                    return 'grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4';
                default:
                    return 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6';
            }
        },
        
        formatCurrency(value) {
            return new Intl.NumberFormat('pt-BR', {
                style: 'currency',
                currency: 'BRL'
            }).format(value);
        }
    }
}
</script>
@endpush
@endsection
