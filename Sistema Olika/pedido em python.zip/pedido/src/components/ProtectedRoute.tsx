import { Navigate } from "react-router-dom";

interface ProtectedRouteProps {
  children: React.ReactNode;
}

export const ProtectedRoute = ({ children }: ProtectedRouteProps) => {
  const isAuthenticated = sessionStorage.getItem("dashboardAuth") === "true";
  
  if (!isAuthenticated) {
    return <Navigate to="/dashboard-login" replace />;
  }
  
  return <>{children}</>;
};