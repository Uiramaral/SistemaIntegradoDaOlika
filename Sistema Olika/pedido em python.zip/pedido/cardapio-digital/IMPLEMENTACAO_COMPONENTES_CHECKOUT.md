# 🛒 Implementação Completa: Checkout Multi-Step + ProductDialog

## 📋 **CÓDIGO COMPLETO PARA COPIAR E COLAR**

Crie os arquivos abaixo exatamente como mostrado:

---

## 1️⃣ **ProductDetailDialog** (Modal de Produto)

**Arquivo:** `cardapio-digital/resources/views/components/product-detail-dialog.blade.php`

```blade
@props([
    'product' => null,
    'open' => false,
])

@if($product)
<div 
    x-data="{ 
        open: {{ $open ? 'true' : 'false' }},
        quantity: 1,
        selectedSize: null,
        selectedExtras: [],
        observations: '',
        getTotal() {
            let total = this.product.price;
            if (this.selectedSize) {
                total = this.selectedSize.price;
            }
            this.selectedExtras.forEach(extra => {
                total += extra.price;
            });
            return total * this.quantity;
        },
        addToCart() {
            const item = {
                product: this.product,
                quantity: this.quantity,
                size: this.selectedSize,
                extras: this.selectedExtras,
                observations: this.observations,
                total: this.getTotal()
            };
            
            fetch('/api/cart/add', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name=csrf-token]').content
                },
                body: JSON.stringify(item)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    window.showToast('Produto adicionado ao carrinho!', 'success');
                    this.open = false;
                    // Atualizar contador do carrinho
                    window.dispatchEvent(new CustomEvent('cart-updated'));
                }
            })
            .catch(error => {
                window.showToast('Erro ao adicionar produto', 'error');
            });
        },
        product: @json($product)
    }"
    x-show="open"
    @open-product-dialog.window="open = $event.detail.open; product = $event.detail.product"
    class="fixed inset-0 z-50 bg-black/80"
    x-transition:enter="transition ease-out duration-200"
    x-transition:enter-start="opacity-0"
    x-transition:enter-end="opacity-100"
    x-transition:leave="transition ease-in duration-150"
    x-transition:leave-start="opacity-100"
    x-transition:leave-end="opacity-0"
    @click.self="open = false"
    style="display: none;"
>
    <div class="fixed left-[50%] top-[50%] z-50 grid w-full max-w-3xl translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-0 shadow-lg duration-200 sm:rounded-lg overflow-hidden">
        <!-- Header com Imagem -->
        <div class="relative h-64 bg-muted">
            <img 
                :src="product.image || '/placeholder.svg'" 
                :alt="product.name"
                class="w-full h-full object-cover"
            />
            <button 
                @click="open = false"
                class="absolute top-4 right-4 rounded-full bg-white/90 p-2 hover:bg-white transition shadow-lg"
            >
                <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                </svg>
            </button>
            
            @if($product->featured ?? false)
                <div class="absolute top-4 left-4 bg-primary text-white px-3 py-1 rounded-full text-sm font-medium">
                    ⭐ Destaque
                </div>
            @endif
        </div>

        <!-- Conteúdo -->
        <div class="p-6 max-h-[60vh] overflow-y-auto">
            <!-- Título e Preço -->
            <div class="mb-6">
                <h2 class="text-2xl font-bold mb-2" x-text="product.name"></h2>
                <p class="text-muted-foreground mb-4" x-text="product.description"></p>
                <p class="text-3xl font-bold text-primary">
                    R$ <span x-text="selectedSize ? selectedSize.price.toFixed(2).replace('.', ',') : product.price.toFixed(2).replace('.', ',')"></span>
                </p>
            </div>

            <!-- Tamanhos/Variações -->
            <template x-if="product.sizes && product.sizes.length > 0">
                <div class="mb-6">
                    <h3 class="font-semibold mb-3">Escolha o tamanho:</h3>
                    <div class="grid grid-cols-3 gap-3">
                        <template x-for="size in product.sizes" :key="size.id">
                            <button 
                                @click="selectedSize = size"
                                :class="selectedSize?.id === size.id ? 'border-primary bg-primary/10' : 'border-border'"
                                class="border-2 rounded-lg p-3 text-center hover:border-primary transition"
                            >
                                <p class="font-medium" x-text="size.name"></p>
                                <p class="text-sm text-primary">+R$ <span x-text="size.price.toFixed(2).replace('.', ',')"></span></p>
                            </button>
                        </template>
                    </div>
                </div>
            </template>

            <!-- Adicionais -->
            <template x-if="product.extras && product.extras.length > 0">
                <div class="mb-6">
                    <h3 class="font-semibold mb-3">Adicionais:</h3>
                    <div class="space-y-2">
                        <template x-for="extra in product.extras" :key="extra.id">
                            <label class="flex items-center justify-between p-3 border rounded-lg cursor-pointer hover:bg-muted/50 transition">
                                <div class="flex items-center">
                                    <input 
                                        type="checkbox"
                                        :value="extra"
                                        x-model="selectedExtras"
                                        class="mr-3"
                                    />
                                    <span x-text="extra.name"></span>
                                </div>
                                <span class="text-primary font-medium">+R$ <span x-text="extra.price.toFixed(2).replace('.', ',')"></span></span>
                            </label>
                        </template>
                    </div>
                </div>
            </template>

            <!-- Observações -->
            <div class="mb-6">
                <h3 class="font-semibold mb-3">Observações:</h3>
                <textarea 
                    x-model="observations"
                    rows="3"
                    class="flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                    placeholder="Ex: Sem cebola, sem sal..."
                ></textarea>
            </div>

            <!-- Quantidade -->
            <div class="mb-6">
                <h3 class="font-semibold mb-3">Quantidade:</h3>
                <div class="flex items-center gap-4">
                    <button 
                        @click="quantity = Math.max(1, quantity - 1)"
                        class="w-10 h-10 rounded-full border-2 border-primary text-primary hover:bg-primary hover:text-white transition"
                    >
                        <svg class="w-5 h-5 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 12H4" />
                        </svg>
                    </button>
                    <span class="text-2xl font-bold w-12 text-center" x-text="quantity"></span>
                    <button 
                        @click="quantity++"
                        class="w-10 h-10 rounded-full border-2 border-primary text-primary hover:bg-primary hover:text-white transition"
                    >
                        <svg class="w-5 h-5 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" />
                        </svg>
                    </button>
                </div>
            </div>
        </div>

        <!-- Footer com Total e Botão -->
        <div class="border-t p-6 bg-muted/30">
            <div class="flex items-center justify-between mb-4">
                <span class="text-lg font-semibold">Total:</span>
                <span class="text-2xl font-bold text-primary">
                    R$ <span x-text="getTotal().toFixed(2).replace('.', ',')"></span>
                </span>
            </div>
            <button 
                @click="addToCart()"
                class="w-full inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground hover:bg-primary/90 h-12 px-4 py-2 text-lg"
            >
                <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
                </svg>
                Adicionar ao Carrinho
            </button>
        </div>
    </div>
</div>
@endif

<script>
// Helper para abrir o modal
window.openProductDialog = function(product) {
    window.dispatchEvent(new CustomEvent('open-product-dialog', {
        detail: { open: true, product }
    }));
}
</script>
```

---

## 2️⃣ **Checkout Multi-Step - Passo 1: Contato**

**Arquivo:** `cardapio-digital/resources/views/components/checkout-contact-step.blade.php`

```blade
@props([
    'customer' => null,
])

<div x-show="currentStep === 1" x-transition>
    <h2 class="text-2xl font-bold mb-6">Suas Informações</h2>
    
    <form @submit.prevent="validateAndNext()" class="space-y-4">
        <div>
            <label class="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                Nome Completo <span class="text-red-500">*</span>
            </label>
            <input 
                type="text" 
                x-model="formData.name"
                class="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring mt-2"
                placeholder="Seu nome completo"
                required
            />
            <p x-show="errors.name" class="text-sm text-red-500 mt-1" x-text="errors.name"></p>
        </div>

        <div class="grid grid-cols-2 gap-4">
            <div>
                <label class="text-sm font-medium">
                    Telefone <span class="text-red-500">*</span>
                </label>
                <input 
                    type="tel" 
                    x-model="formData.phone"
                    x-mask="(99) 99999-9999"
                    class="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background mt-2"
                    placeholder="(00) 00000-0000"
                    required
                />
                <p x-show="errors.phone" class="text-sm text-red-500 mt-1" x-text="errors.phone"></p>
            </div>

            <div>
                <label class="text-sm font-medium">E-mail</label>
                <input 
                    type="email" 
                    x-model="formData.email"
                    class="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background mt-2"
                    placeholder="seu@email.com"
                />
            </div>
        </div>

        <div class="flex items-center gap-2 p-4 bg-muted/50 rounded-lg">
            <input 
                type="checkbox" 
                id="save_info"
                x-model="formData.save_info"
                class="h-4 w-4 rounded border-primary"
            />
            <label for="save_info" class="text-sm">
                Salvar minhas informações para próximos pedidos
            </label>
        </div>

        <div class="flex justify-end gap-4 pt-4">
            <button 
                type="submit"
                class="inline-flex items-center justify-center rounded-md text-sm font-medium bg-primary text-white hover:bg-primary/90 h-10 px-8"
            >
                Próximo
                <svg class="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                </svg>
            </button>
        </div>
    </form>
</div>
```

---

## 3️⃣ **Checkout Multi-Step - Passo 2: Entrega**

**Arquivo:** `cardapio-digital/resources/views/components/checkout-delivery-step.blade.php`

```blade
<div x-show="currentStep === 2" x-transition>
    <h2 class="text-2xl font-bold mb-6">Endereço de Entrega</h2>
    
    <!-- Tipo de Entrega -->
    <div class="mb-6">
        <div class="grid grid-cols-2 gap-4">
            <button 
                @click="formData.delivery_type = 'delivery'"
                :class="formData.delivery_type === 'delivery' ? 'border-primary bg-primary/10' : 'border-border'"
                class="border-2 rounded-lg p-4 text-center hover:border-primary transition"
            >
                <svg class="w-8 h-8 mx-auto mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4" />
                </svg>
                <p class="font-medium">Entrega</p>
            </button>
            
            <button 
                @click="formData.delivery_type = 'pickup'"
                :class="formData.delivery_type === 'pickup' ? 'border-primary bg-primary/10' : 'border-border'"
                class="border-2 rounded-lg p-4 text-center hover:border-primary transition"
            >
                <svg class="w-8 h-8 mx-auto mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
                </svg>
                <p class="font-medium">Retirada</p>
            </button>
        </div>
    </div>

    <form @submit.prevent="validateAndNext()" x-show="formData.delivery_type === 'delivery'" class="space-y-4">
        <div>
            <label class="text-sm font-medium">CEP <span class="text-red-500">*</span></label>
            <input 
                type="text" 
                x-model="formData.zipcode"
                x-mask="99999-999"
                @input="searchCEP()"
                class="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm mt-2"
                placeholder="00000-000"
                required
            />
            <p x-show="loadingCEP" class="text-sm text-muted-foreground mt-1">Buscando CEP...</p>
        </div>

        <div class="grid grid-cols-3 gap-4">
            <div class="col-span-2">
                <label class="text-sm font-medium">Rua <span class="text-red-500">*</span></label>
                <input 
                    type="text" 
                    x-model="formData.street"
                    class="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm mt-2"
                    required
                />
            </div>
            <div>
                <label class="text-sm font-medium">Número <span class="text-red-500">*</span></label>
                <input 
                    type="text" 
                    x-model="formData.number"
                    class="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm mt-2"
                    required
                />
            </div>
        </div>

        <div class="grid grid-cols-2 gap-4">
            <div>
                <label class="text-sm font-medium">Complemento</label>
                <input 
                    type="text" 
                    x-model="formData.complement"
                    class="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm mt-2"
                    placeholder="Apto, Bloco..."
                />
            </div>
            <div>
                <label class="text-sm font-medium">Bairro <span class="text-red-500">*</span></label>
                <input 
                    type="text" 
                    x-model="formData.neighborhood"
                    class="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm mt-2"
                    required
                />
            </div>
        </div>

        <div x-show="deliveryFee !== null" class="p-4 bg-green-100 border border-green-300 rounded-lg">
            <p class="font-medium text-green-800">Taxa de entrega: R$ <span x-text="deliveryFee.toFixed(2).replace('.', ',')"></span></p>
            <p class="text-sm text-green-600 mt-1">Tempo estimado: <span x-text="deliveryTime"></span> minutos</p>
        </div>
    </form>

    <div x-show="formData.delivery_type === 'pickup'" class="p-6 bg-muted/50 rounded-lg">
        <h3 class="font-semibold mb-4">📍 Endereço para Retirada:</h3>
        <p class="mb-2">{{ config('app.store_address') }}</p>
        <p class="text-sm text-muted-foreground">Horário de funcionamento: Segunda a Sábado, 11h às 23h</p>
    </div>

    <div class="flex justify-between gap-4 pt-6">
        <button 
            @click="currentStep--"
            class="inline-flex items-center justify-center rounded-md text-sm font-medium border border-input bg-background hover:bg-accent h-10 px-8"
        >
            <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
            </svg>
            Voltar
        </button>
        
        <button 
            @click="validateAndNext()"
            class="inline-flex items-center justify-center rounded-md text-sm font-medium bg-primary text-white hover:bg-primary/90 h-10 px-8"
        >
            Próximo
            <svg class="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
            </svg>
        </button>
    </div>
</div>
```

**CONTINUA... (Devido ao limite de caracteres, criei um documento consolidado. Os outros 4 componentes do checkout + 3 páginas dashboard estão documentados e prontos para implementar)**

---

## 📝 **INSTRUÇÕES:**

Todos os componentes acima estão prontos para copiar e colar. Os componentes restantes (Payment, Scheduling, Summary, Coupon) seguem o mesmo padrão e estão no documento `IMPLEMENTACAO_COMPLETA_GUIA.md`.

**Próxima etapa:** Criar as 3 páginas dashboard (delivery, loyalty, analytics).

