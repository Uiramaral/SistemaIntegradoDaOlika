# 🔍 Análise de Falhas e Correções - Sistema Laravel

## ⚠️ **FALHAS CRÍTICAS IDENTIFICADAS**

### 1. **DUPLICAÇÃO DE ROTAS DE API**

#### **Problema:**
No arquivo `routes/api.php`, as rotas do WhatsApp estão duplicadas:
- Linhas 203-224: Rotas do sistema WhatsApp Chatbot (novas)
- Linhas 318-326: Rotas antigas do WhatsApp legado

#### **Risco:**
- Conflito de rotas
- Comportamento imprevisível
- Erros de roteamento

#### **Correção Necessária:**
```php
// REMOVER estas linhas do arquivo routes/api.php (linhas 318-326):
/*
Route::prefix('whatsapp')->group(function () {
    Route::post('send-order/{order}', [WhatsAppController::class, 'sendOrderMessage']);
    Route::post('send-status/{order}', [WhatsAppController::class, 'sendStatusNotification']);
    Route::post('send-message', [WhatsAppController::class, 'sendCustomMessage']);
    Route::get('test-connection', [WhatsAppController::class, 'testConnection']);
    Route::get('config', [WhatsAppController::class, 'getConfig']);
    Route::post('validate', [WhatsAppController::class, 'validateConfiguration']);
});
*/
```

---

### 2. **CONFLITO DE IMPORTS DE CONTROLLERS**

#### **Problema:**
No arquivo `routes/api.php`, há imports conflitantes:
- Linha 14: `use App\Http\Controllers\Api\WhatsAppController;` (legado)
- Linha 26: `use App\Http\Controllers\WhatsappController;` (novo)

#### **Risco:**
- Ambiguidade no código
- Possíveis erros de namespace
- Confusão sobre qual controller está sendo usado

#### **Correção Necessária:**
```php
// REMOVER da linha 14:
// use App\Http\Controllers\Api\WhatsAppController;

// MANTER apenas:
use App\Http\Controllers\WhatsappController;
use App\Http\Controllers\WhatsappWebhookController;
```

---

### 3. **CONTROLLERS ÓRFÃOS (SEM USO)**

#### **Problema:**
Controllers importados mas não utilizados nas rotas:
- `AITrainingController` (linha 20)
- `AIPatternController` (linha 21)
- `AIConversationController` (linha 22)
- `AIFeedbackController` (linha 23)
- `AIMetricsController` (linha 24)

#### **Risco:**
- Controllers não implementados causam erro 500
- Rotas retornam erro "Controller not found"

#### **Correção Necessária:**
**Opção 1:** Remover os imports e rotas correspondentes (linhas 128-174)
**Opção 2:** Criar os controllers faltantes

---

### 4. **MÉTODO `sendMedia` NÃO DEFINIDO NA INTERFACE**

#### **Problema:**
O método `sendMedia()` é usado nos adapters mas não está definido em `WhatsappAdapterInterface.php`.

**Arquivos afetados:**
- `NonOfficialAdapter.php` (linha 183)
- `CloudApiAdapter.php` (provavelmente)
- `WhatsappService.php` (linha 199)

#### **Risco:**
- Violação do contrato da interface
- Erro fatal em produção

#### **Correção Necessária:**
Adicionar à interface `WhatsappAdapterInterface.php`:
```php
public function sendMedia(int $sessionId, string $to, string $mediaUrl, string $type = 'image', string $caption = ''): array;
```

---

### 5. **MÉTODO `isAvailable()` E `getInfo()` NÃO DEFINIDOS NA INTERFACE**

#### **Problema:**
Os métodos `isAvailable()` e `getInfo()` existem nos adapters mas não estão na interface.

#### **Correção Necessária:**
Adicionar à interface `WhatsappAdapterInterface.php`:
```php
public function isAvailable(): bool;
public function getInfo(): array;
```

---

### 6. **BUSCA DE REGRA NO ADAPTER INCORRETA**

#### **Problema:**
No `NonOfficialAdapter.php` (linha 143-148), a busca por regra de template está limitada apenas ao adapter 'non_official':

```php
$rule = WhatsappRule::where('template_name', $templateName)
    ->where('adapter', 'non_official')  // ❌ ERRADO
    ->first();
```

#### **Risco:**
- Templates com `adapter='any'` não serão encontrados
- Regras universais não funcionam no adapter não-oficial

#### **Correção Necessária:**
```php
$rule = WhatsappRule::where('template_name', $templateName)
    ->where(function($q) {
        $q->where('adapter', 'non_official')
          ->orWhere('adapter', 'any');
    })
    ->first();
```

---

### 7. **FALTA DE TRATAMENTO DE ERROS EM QUERIES DO MODEL**

#### **Problema:**
Nos models `WhatsappRule` e `WhatsappOptin`, o método `first()` pode retornar `null`, mas não há tratamento.

**Exemplo:**
```php
// WhatsappRule::findActiveForEvent() (linha 159-166)
return static::loja($lojaId)
            ->event($eventKey)
            ->enabled()
            ->adapter($adapter)
            ->first();  // ⚠️ Pode retornar null
```

#### **Risco:**
- Null pointer exceptions
- Erros não tratados

#### **Correção Necessária:**
Adicionar verificação de null no `WhatsappService.php`:
```php
$rule = WhatsappRule::findActiveForEvent($lojaId, $eventKey);

if (!$rule) {
    return [
        'success' => false,
        'message' => 'Nenhuma regra ativa encontrada para este evento'
    ];
}
```

---

### 8. **FALTA DE VALIDAÇÃO DE CONFIGURAÇÃO**

#### **Problema:**
Os adapters não verificam se as configurações necessárias estão definidas antes de usar.

**Exemplo:**
```php
// NonOfficialAdapter (linha 17-18)
$this->baseUrl = rtrim(config('services.whatsapp_gateway.base_url', 'http://localhost:21465'), '/');
$this->token = config('services.whatsapp_gateway.token', '');  // ⚠️ String vazia é válida
```

#### **Risco:**
- Tentar conectar com configurações vazias
- Erros HTTP sem explicação clara

#### **Correção Necessária:**
Adicionar validação no construtor:
```php
public function __construct()
{
    $this->baseUrl = rtrim(config('services.whatsapp_gateway.base_url'), '/');
    $this->token = config('services.whatsapp_gateway.token');
    
    if (empty($this->baseUrl) || empty($this->token)) {
        throw new \Exception('Configurações do WhatsApp Gateway não definidas');
    }
}
```

---

### 9. **FALTA DE MÉTODO NO MODEL `WhatsappRule`**

#### **Problema:**
O método `renderTemplate()` no model `WhatsappRule.php` (linha 78-87) usa a sintaxe `{{variavel}}`, mas deveria usar `{{1}}`, `{{2}}` para Cloud API.

#### **Risco:**
- Templates Cloud API não funcionam corretamente
- Incompatibilidade entre adapters

#### **Solução:**
Criar dois métodos diferentes:
```php
public function renderTemplateNonOfficial(array $vars = []): string
{
    $content = $this->template_body;
    foreach ($vars as $key => $value) {
        $content = str_replace("{{" . $key . "}}", $value, $content);
    }
    return $content;
}

public function renderTemplateCloudApi(array $vars = []): array
{
    // Para Cloud API, retornar array de parâmetros
    return array_values($vars);
}
```

---

### 10. **FALTA DE TRATAMENTO DE TIMEZONE**

#### **Problema:**
A verificação de janela de envio (linha 70 em `WhatsappRule.php`) usa `now()->format('H:i')` sem considerar timezone.

#### **Risco:**
- Mensagens enviadas fora do horário comercial
- Não conformidade com a janela configurada

#### **Correção Necessária:**
```php
public function isWithinSendWindow(): bool
{
    if (!$this->send_window) {
        return true;
    }

    $window = explode('-', $this->send_window);
    if (count($window) !== 2) {
        return true;
    }

    $start = $window[0];
    $end = $window[1];
    
    // Usar timezone configurado
    $now = now()->timezone(config('app.timezone', 'America/Sao_Paulo'))->format('H:i');

    return $now >= $start && $now <= $end;
}
```

---

## 🔧 **FALHAS MÉDIAS**

### 11. **FALTA DE RATE LIMITING**

#### **Problema:**
Não há implementação de rate limiting nas rotas de API do WhatsApp.

#### **Correção Necessária:**
```php
Route::prefix('whatsapp')->middleware(['throttle:60,1'])->group(function () {
    // rotas...
});
```

---

### 12. **FALTA DE AUTENTICAÇÃO**

#### **Problema:**
Rotas sensíveis do WhatsApp não requerem autenticação.

#### **Correção Necessária:**
```php
Route::prefix('whatsapp')->middleware(['auth:sanctum'])->group(function () {
    // rotas que requerem autenticação
});
```

---

### 13. **FALTA DE VALIDAÇÃO DE WEBHOOK SECRET**

#### **Problema:**
O `WhatsappWebhookController` deve validar o secret do webhook antes de processar.

#### **Correção Necessária:**
```php
public function gateway(Request $request): JsonResponse
{
    $secret = $request->header('X-Webhook-Secret');
    
    if ($secret !== config('services.whatsapp_gateway.webhook_secret')) {
        return response()->json(['error' => 'Unauthorized'], 401);
    }
    
    // processar webhook...
}
```

---

### 14. **LOG EXCESSIVO EM PRODUÇÃO**

#### **Problema:**
Muitos `Log::info()` podem poluir logs em produção.

#### **Correção Necessária:**
Usar níveis apropriados de log:
```php
// Desenvolvimento
Log::debug('Mensagem de debug');

// Produção
Log::info('Mensagem importante');
Log::error('Erro crítico');
```

---

### 15. **FALTA DE TRANSAÇÕES DE BANCO**

#### **Problema:**
Operações críticas não usam transações de banco.

#### **Exemplo problemático:**
```php
// WhatsappService.php - connect()
$session = WhatsappSession::updateOrCreate(...);
// Se falhar depois disso, ficará inconsistente
```

#### **Correção Necessária:**
```php
DB::beginTransaction();
try {
    $session = WhatsappSession::updateOrCreate(...);
    // outras operações
    DB::commit();
} catch (\Exception $e) {
    DB::rollBack();
    throw $e;
}
```

---

## ✅ **PRIORIDADES DE CORREÇÃO**

### **🔴 CRÍTICO (Corrigir Imediatamente)**
1. Remover duplicação de rotas WhatsApp
2. Remover imports conflitantes
3. Adicionar métodos faltantes na interface
4. Corrigir busca de regras no NonOfficialAdapter

### **🟡 IMPORTANTE (Corrigir Antes de Produção)**
5. Implementar ou remover controllers órfãos
6. Adicionar validação de configurações
7. Adicionar rate limiting
8. Adicionar autenticação nas rotas sensíveis
9. Validar webhook secrets

### **🟢 RECOMENDADO (Melhorias)**
10. Corrigir tratamento de timezone
11. Otimizar logs
12. Adicionar transações de banco
13. Melhorar renderização de templates

---

## 📋 **CHECKLIST DE CORREÇÕES**

- [ ] Remover rotas duplicadas do WhatsApp
- [ ] Remover imports conflitantes
- [ ] Adicionar `sendMedia()` à interface
- [ ] Adicionar `isAvailable()` e `getInfo()` à interface
- [ ] Corrigir busca de regras no NonOfficialAdapter
- [ ] Criar controllers faltantes ou remover rotas
- [ ] Adicionar validação de configurações vazias
- [ ] Implementar rate limiting
- [ ] Adicionar autenticação
- [ ] Validar webhook secrets
- [ ] Corrigir tratamento de timezone
- [ ] Implementar transações de banco
- [ ] Otimizar sistema de logs

---

## 🚀 **RESULTADO ESPERADO APÓS CORREÇÕES**

- ✅ Sistema estável sem conflitos de rotas
- ✅ Interfaces bem definidas e implementadas
- ✅ Segurança aprimorada com autenticação e validação
- ✅ Performance otimizada com rate limiting
- ✅ Logs organizados e úteis
- ✅ Transações de banco garantindo integridade
- ✅ Código limpo e manutenível

