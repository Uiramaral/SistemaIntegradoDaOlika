@props([
    'variant' => 'default',
])

@php
$baseClasses = 'relative w-full rounded-lg border p-4';

$variants = [
    'default' => 'bg-background text-foreground',
    'destructive' => 'border-red-500/50 text-red-600 dark:border-red-500 [&>svg]:text-red-600',
    'success' => 'border-green-500/50 text-green-600 dark:border-green-500 [&>svg]:text-green-600',
    'warning' => 'border-yellow-500/50 text-yellow-600 dark:border-yellow-500 [&>svg]:text-yellow-600',
];

$classes = $baseClasses . ' ' . ($variants[$variant] ?? $variants['default']);
@endphp

<div {{ $attributes->merge(['class' => $classes]) }} role="alert">
    {{ $slot }}
</div>

