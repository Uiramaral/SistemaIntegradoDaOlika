<?php

namespace App\Services;

use App\Models\Settings;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class GoogleMapsService
{
    private $apiKey;

    public function __construct()
    {
        $settings = Settings::getSettings();
        $this->apiKey = $settings->google_maps_api_key;
    }

    /**
     * Verificar se Google Maps está configurado
     */
    public function isConfigured(): bool
    {
        return !empty($this->apiKey);
    }

    /**
     * Buscar endereço por CEP
     */
    public function getAddressByCep(string $cep): array
    {
        if (!$this->isConfigured()) {
            throw new \Exception('Google Maps não está configurado');
        }

        try {
            $cleanCep = preg_replace('/\D/', '', $cep);
            
            if (strlen($cleanCep) !== 8) {
                return [
                    'success' => false,
                    'message' => 'CEP inválido'
                ];
            }

            $response = Http::get('https://maps.googleapis.com/maps/api/geocode/json', [
                'address' => $cleanCep,
                'key' => $this->apiKey,
                'region' => 'br'
            ]);

            if (!$response->successful()) {
                throw new \Exception('Erro na API do Google Maps');
            }

            $data = $response->json();

            if ($data['status'] !== 'OK' || empty($data['results'])) {
                return [
                    'success' => false,
                    'message' => 'CEP não encontrado'
                ];
            }

            $result = $data['results'][0];
            $addressComponents = $result['address_components'];
            
            $address = $this->parseAddressComponents($addressComponents);
            $address['formatted_address'] = $result['formatted_address'];
            $address['cep'] = $cleanCep;

            return [
                'success' => true,
                'data' => $address
            ];

        } catch (\Exception $e) {
            Log::error('Erro ao buscar endereço por CEP: ' . $e->getMessage());
            
            return [
                'success' => false,
                'message' => 'Erro ao buscar endereço: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Buscar CEP por endereço
     */
    public function getCepByAddress(string $address): array
    {
        if (!$this->isConfigured()) {
            throw new \Exception('Google Maps não está configurado');
        }

        try {
            $response = Http::get('https://maps.googleapis.com/maps/api/geocode/json', [
                'address' => $address . ', Brasil',
                'key' => $this->apiKey,
                'region' => 'br'
            ]);

            if (!$response->successful()) {
                throw new \Exception('Erro na API do Google Maps');
            }

            $data = $response->json();

            if ($data['status'] !== 'OK' || empty($data['results'])) {
                return [
                    'success' => false,
                    'message' => 'Endereço não encontrado'
                ];
            }

            $result = $data['results'][0];
            $addressComponents = $result['address_components'];
            
            $parsedAddress = $this->parseAddressComponents($addressComponents);

            return [
                'success' => true,
                'data' => $parsedAddress
            ];

        } catch (\Exception $e) {
            Log::error('Erro ao buscar CEP por endereço: ' . $e->getMessage());
            
            return [
                'success' => false,
                'message' => 'Erro ao buscar CEP: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Calcular distância entre dois pontos
     */
    public function calculateDistance(string $origin, string $destination): array
    {
        if (!$this->isConfigured()) {
            throw new \Exception('Google Maps não está configurado');
        }

        try {
            $response = Http::get('https://maps.googleapis.com/maps/api/distancematrix/json', [
                'origins' => $origin,
                'destinations' => $destination,
                'key' => $this->apiKey,
                'units' => 'metric'
            ]);

            if (!$response->successful()) {
                throw new \Exception('Erro na API do Google Maps');
            }

            $data = $response->json();

            if ($data['status'] !== 'OK' || empty($data['rows'])) {
                return [
                    'success' => false,
                    'message' => 'Não foi possível calcular a distância'
                ];
            }

            $element = $data['rows'][0]['elements'][0];

            if ($element['status'] !== 'OK') {
                return [
                    'success' => false,
                    'message' => 'Não foi possível calcular a distância'
                ];
            }

            return [
                'success' => true,
                'data' => [
                    'distance' => $element['distance']['value'], // em metros
                    'distance_text' => $element['distance']['text'],
                    'duration' => $element['duration']['value'], // em segundos
                    'duration_text' => $element['duration']['text']
                ]
            ];

        } catch (\Exception $e) {
            Log::error('Erro ao calcular distância: ' . $e->getMessage());
            
            return [
                'success' => false,
                'message' => 'Erro ao calcular distância: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Verificar se endereço está na área de entrega
     */
    public function isInDeliveryArea(string $cep): array
    {
        try {
            // Primeiro, buscar o endereço do CEP
            $addressResult = $this->getAddressByCep($cep);
            
            if (!$addressResult['success']) {
                return $addressResult;
            }

            $address = $addressResult['data'];
            
            // Aqui você pode implementar lógica específica para verificar
            // se o endereço está na área de entrega
            // Por exemplo, verificar se o bairro/cidade está na lista de áreas atendidas
            
            $deliveryAreas = [
                // Exemplo de áreas atendidas
                'São Paulo' => ['Centro', 'Vila Madalena', 'Pinheiros', 'Jardins'],
                // Adicione outras cidades e bairros conforme necessário
            ];

            $city = $address['city'] ?? '';
            $neighborhood = $address['neighborhood'] ?? '';

            $isInArea = false;
            
            if (isset($deliveryAreas[$city])) {
                $isInArea = in_array($neighborhood, $deliveryAreas[$city]);
            }

            return [
                'success' => true,
                'data' => [
                    'is_in_delivery_area' => $isInArea,
                    'address' => $address,
                    'delivery_areas' => $deliveryAreas[$city] ?? []
                ]
            ];

        } catch (\Exception $e) {
            Log::error('Erro ao verificar área de entrega: ' . $e->getMessage());
            
            return [
                'success' => false,
                'message' => 'Erro ao verificar área de entrega: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Obter coordenadas de um endereço
     */
    public function getCoordinates(string $address): array
    {
        if (!$this->isConfigured()) {
            throw new \Exception('Google Maps não está configurado');
        }

        try {
            $response = Http::get('https://maps.googleapis.com/maps/api/geocode/json', [
                'address' => $address . ', Brasil',
                'key' => $this->apiKey,
                'region' => 'br'
            ]);

            if (!$response->successful()) {
                throw new \Exception('Erro na API do Google Maps');
            }

            $data = $response->json();

            if ($data['status'] !== 'OK' || empty($data['results'])) {
                return [
                    'success' => false,
                    'message' => 'Endereço não encontrado'
                ];
            }

            $result = $data['results'][0];
            $location = $result['geometry']['location'];

            return [
                'success' => true,
                'data' => [
                    'latitude' => $location['lat'],
                    'longitude' => $location['lng'],
                    'formatted_address' => $result['formatted_address']
                ]
            ];

        } catch (\Exception $e) {
            Log::error('Erro ao obter coordenadas: ' . $e->getMessage());
            
            return [
                'success' => false,
                'message' => 'Erro ao obter coordenadas: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Validar configuração
     */
    public function validateConfiguration(): array
    {
        if (!$this->isConfigured()) {
            return [
                'success' => false,
                'message' => 'Google Maps não está configurado'
            ];
        }

        try {
            // Testar com um CEP conhecido
            $testResult = $this->getAddressByCep('01310-100');
            
            if ($testResult['success']) {
                return [
                    'success' => true,
                    'message' => 'Configuração válida'
                ];
            }

            return [
                'success' => false,
                'message' => 'Configuração inválida'
            ];

        } catch (\Exception $e) {
            Log::error('Erro ao validar configuração Google Maps: ' . $e->getMessage());
            
            return [
                'success' => false,
                'message' => 'Configuração inválida: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Obter configuração pública
     */
    public function getPublicConfig(): array
    {
        return [
            'configured' => $this->isConfigured(),
            'api_key' => $this->isConfigured() ? substr($this->apiKey, 0, 10) . '...' : null
        ];
    }

    /**
     * Parse dos componentes de endereço do Google Maps
     */
    private function parseAddressComponents(array $components): array
    {
        $address = [
            'street' => '',
            'neighborhood' => '',
            'city' => '',
            'state' => '',
            'cep' => ''
        ];

        foreach ($components as $component) {
            $types = $component['types'];
            
            if (in_array('route', $types)) {
                $address['street'] = $component['long_name'];
            } elseif (in_array('sublocality_level_1', $types) || in_array('sublocality', $types)) {
                $address['neighborhood'] = $component['long_name'];
            } elseif (in_array('locality', $types)) {
                $address['city'] = $component['long_name'];
            } elseif (in_array('administrative_area_level_1', $types)) {
                $address['state'] = $component['short_name'];
            } elseif (in_array('postal_code', $types)) {
                $address['cep'] = $component['long_name'];
            }
        }

        return $address;
    }
}
