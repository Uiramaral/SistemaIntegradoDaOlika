import { ArrowLeft, Minus, Plus, Trash2 } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useMenu } from "@/contexts/MenuContext";
import { toast } from "sonner";

const Cart = () => {
  const { cart, updateQuantity, removeFromCart, clearCart, config } = useMenu();

  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const hasMinimumValue = config.minDeliveryValue ? total >= config.minDeliveryValue : true;

  const handleFinishOrder = () => {
    if (!hasMinimumValue) {
      toast.error(`Valor mínimo para entrega: R$ ${config.minDeliveryValue?.toFixed(2)}`);
      return;
    }

    const message = `Olá! Gostaria de fazer um pedido:\n\n${cart
      .map((item) => `${item.quantity}x ${item.name} - R$ ${(item.price * item.quantity).toFixed(2)}`)
      .join("\n")}\n\nTotal: R$ ${total.toFixed(2)}`;

    const phone = config.phone?.replace(/\D/g, "") || "";
    const whatsappUrl = `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, "_blank");
    
    clearCart();
    toast.success("Pedido enviado com sucesso!");
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 bg-background border-b">
        <div className="container mx-auto px-4">
          <div className="flex items-center gap-4 h-16">
            <Button variant="ghost" size="icon" asChild>
              <Link to="/">
                <ArrowLeft className="h-5 w-5" />
              </Link>
            </Button>
            <h1 className="text-xl font-bold">Carrinho</h1>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6 pb-32">
        {cart.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground mb-4">Seu carrinho está vazio</p>
            <Button asChild>
              <Link to="/">Ver Produtos</Link>
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            {cart.map((item) => (
              <Card key={item.id}>
                <CardContent className="p-4">
                  <div className="flex gap-4">
                    <div className="w-20 h-20 rounded-lg overflow-hidden bg-muted shrink-0">
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold line-clamp-1">{item.name}</h3>
                      <p className="text-sm text-muted-foreground mt-1">
                        R$ {item.price.toFixed(2).replace(".", ",")}
                      </p>
                      <div className="flex items-center gap-3 mt-3">
                        <div className="flex items-center gap-2">
                          <Button
                            size="icon"
                            variant="outline"
                            className="h-8 w-8"
                            onClick={() => updateQuantity(item.id, item.quantity - 1)}
                          >
                            <Minus className="h-3 w-3" />
                          </Button>
                          <span className="w-8 text-center font-semibold">{item.quantity}</span>
                          <Button
                            size="icon"
                            variant="outline"
                            className="h-8 w-8"
                            onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          >
                            <Plus className="h-3 w-3" />
                          </Button>
                        </div>
                        <Button
                          size="icon"
                          variant="ghost"
                          className="h-8 w-8 text-destructive"
                          onClick={() => removeFromCart(item.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    <div className="font-bold text-primary">
                      R$ {(item.price * item.quantity).toFixed(2).replace(".", ",")}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </main>

      {cart.length > 0 && (
        <div className="fixed bottom-0 left-0 right-0 bg-background border-t p-4">
          <div className="container mx-auto">
            <div className="flex items-center justify-between mb-3">
              <span className="text-lg font-semibold">Total:</span>
              <span className="text-2xl font-bold text-primary">
                R$ {total.toFixed(2).replace(".", ",")}
              </span>
            </div>
            {!hasMinimumValue && config.minDeliveryValue && (
              <p className="text-sm text-destructive mb-2">
                Valor mínimo para entrega: R$ {config.minDeliveryValue.toFixed(2)}
              </p>
            )}
            <Button
              className="w-full"
              size="lg"
              onClick={() => window.location.href = '/checkout'}
              disabled={!hasMinimumValue}
            >
              Continuar para Pagamento
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Cart;
