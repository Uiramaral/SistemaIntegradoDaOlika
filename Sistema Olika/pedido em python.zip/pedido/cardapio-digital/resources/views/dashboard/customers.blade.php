@extends('dashboard.layout-complete')

@section('title', 'Gestão de Clientes - Cardápio Digital Olika')
@section('page-title', 'Gestão de Clientes')

@section('content')
<div class="space-y-6">
    <!-- Header com Filtros -->
    <div class="bg-white rounded-xl p-6 shadow-lg">
        <div class="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
            <div>
                <h2 class="text-2xl font-bold text-gray-900">Clientes</h2>
                <p class="text-gray-600">Gerencie o cadastro de clientes do seu restaurante</p>
            </div>
            
            <div class="flex flex-col sm:flex-row gap-4">
                <!-- Busca -->
                <div class="relative">
                    <input 
                        type="text" 
                        id="search-customers"
                        placeholder="Buscar clientes..."
                        class="w-full sm:w-64 pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                    <svg class="absolute left-3 top-2.5 w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                    </svg>
                </div>
                
                <!-- Status -->
                <select id="status-filter" class="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <option value="">Todos os clientes</option>
                    <option value="active">Ativos</option>
                    <option value="inactive">Inativos</option>
                    <option value="vip">VIP</option>
                </select>
                
                <!-- Botão Adicionar -->
                <button id="add-customer-btn" class="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition flex items-center space-x-2">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
                    </svg>
                    <span>Adicionar Cliente</span>
                </button>
            </div>
        </div>
    </div>

    <!-- Stats Cards -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div class="bg-white rounded-xl p-6 shadow-lg">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-gray-600">Total de Clientes</p>
                    <p class="text-2xl font-bold text-gray-900">567</p>
                </div>
                <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <svg class="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-9a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0z"></path>
                    </svg>
                </div>
            </div>
        </div>
        
        <div class="bg-white rounded-xl p-6 shadow-lg">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-gray-600">Novos Hoje</p>
                    <p class="text-2xl font-bold text-green-600">12</p>
                </div>
                <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                    <svg class="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z"></path>
                    </svg>
                </div>
            </div>
        </div>
        
        <div class="bg-white rounded-xl p-6 shadow-lg">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-gray-600">Clientes VIP</p>
                    <p class="text-2xl font-bold text-yellow-600">45</p>
                </div>
                <div class="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                    <svg class="w-6 h-6 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"></path>
                    </svg>
                </div>
            </div>
        </div>
        
        <div class="bg-white rounded-xl p-6 shadow-lg">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-gray-600">Ticket Médio</p>
                    <p class="text-2xl font-bold text-purple-600">R$ 45</p>
                </div>
                <div class="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                    <svg class="w-6 h-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1"></path>
                    </svg>
                </div>
            </div>
        </div>
    </div>

    <!-- Lista de Clientes -->
    <div class="bg-white rounded-xl shadow-lg">
        <div class="p-6 border-b border-gray-200">
            <h3 class="text-lg font-semibold text-gray-900">Lista de Clientes</h3>
        </div>
        
        <div class="overflow-x-auto">
            <table class="w-full">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Cliente</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Contato</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Pedidos</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total Gasto</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Última Visita</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ações</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200" id="customers-table-body">
                    <!-- Cliente 1 -->
                    <tr class="hover:bg-gray-50">
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="flex items-center space-x-4">
                                <div class="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center">
                                    <span class="text-white font-medium text-sm">JS</span>
                                </div>
                                <div>
                                    <div class="text-sm font-medium text-gray-900">João Silva</div>
                                    <div class="text-sm text-gray-500">ID: #1234</div>
                                </div>
                            </div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm text-gray-900">joao@email.com</div>
                            <div class="text-sm text-gray-500">(11) 99999-9999</div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">15 pedidos</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">R$ 675,00</td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                Ativo
                            </span>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">2 dias atrás</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                            <button class="text-blue-600 hover:text-blue-900 view-customer" data-customer-id="1">Ver</button>
                            <button class="text-green-600 hover:text-green-900 edit-customer" data-customer-id="1">Editar</button>
                            <button class="text-purple-600 hover:text-purple-900 toggle-vip" data-customer-id="1">VIP</button>
                        </td>
                    </tr>
                    
                    <!-- Cliente 2 -->
                    <tr class="hover:bg-gray-50">
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="flex items-center space-x-4">
                                <div class="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center">
                                    <span class="text-white font-medium text-sm">MS</span>
                                </div>
                                <div>
                                    <div class="text-sm font-medium text-gray-900">Maria Santos</div>
                                    <div class="text-sm text-gray-500">ID: #1235</div>
                                </div>
                            </div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm text-gray-900">maria@email.com</div>
                            <div class="text-sm text-gray-500">(11) 88888-8888</div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">8 pedidos</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">R$ 320,00</td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">
                                VIP
                            </span>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">1 semana atrás</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                            <button class="text-blue-600 hover:text-blue-900 view-customer" data-customer-id="2">Ver</button>
                            <button class="text-green-600 hover:text-green-900 edit-customer" data-customer-id="2">Editar</button>
                            <button class="text-red-600 hover:text-red-900 remove-vip" data-customer-id="2">Remover VIP</button>
                        </td>
                    </tr>
                    
                    <!-- Cliente 3 -->
                    <tr class="hover:bg-gray-50">
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="flex items-center space-x-4">
                                <div class="w-10 h-10 bg-gray-500 rounded-full flex items-center justify-center">
                                    <span class="text-white font-medium text-sm">PC</span>
                                </div>
                                <div>
                                    <div class="text-sm font-medium text-gray-900">Pedro Costa</div>
                                    <div class="text-sm text-gray-500">ID: #1236</div>
                                </div>
                            </div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm text-gray-900">pedro@email.com</div>
                            <div class="text-sm text-gray-500">(11) 77777-7777</div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">3 pedidos</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">R$ 120,00</td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">
                                Inativo
                            </span>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">1 mês atrás</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                            <button class="text-blue-600 hover:text-blue-900 view-customer" data-customer-id="3">Ver</button>
                            <button class="text-green-600 hover:text-green-900 edit-customer" data-customer-id="3">Editar</button>
                            <button class="text-blue-600 hover:text-blue-900 activate-customer" data-customer-id="3">Ativar</button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal de Detalhes do Cliente -->
<div id="customer-modal" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden flex items-center justify-center p-4">
    <div class="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div class="p-6 border-b border-gray-200">
            <div class="flex items-center justify-between">
                <h3 class="text-xl font-bold text-gray-900">Detalhes do Cliente</h3>
                <button id="close-customer-modal" class="text-gray-500 hover:text-gray-700">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                </button>
            </div>
        </div>
        
        <div class="p-6 space-y-6">
            <!-- Informações Pessoais -->
            <div>
                <h4 class="font-semibold text-gray-900 mb-3">Informações Pessoais</h4>
                <div class="bg-gray-50 rounded-lg p-4">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <p class="text-sm text-gray-600">Nome</p>
                            <p class="font-medium">João Silva</p>
                        </div>
                        <div>
                            <p class="text-sm text-gray-600">E-mail</p>
                            <p class="font-medium">joao@email.com</p>
                        </div>
                        <div>
                            <p class="text-sm text-gray-600">Telefone</p>
                            <p class="font-medium">(11) 99999-9999</p>
                        </div>
                        <div>
                            <p class="text-sm text-gray-600">Data de Nascimento</p>
                            <p class="font-medium">15/03/1985</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Endereço -->
            <div>
                <h4 class="font-semibold text-gray-900 mb-3">Endereço</h4>
                <div class="bg-gray-50 rounded-lg p-4">
                    <p class="font-medium">Rua das Flores, 123</p>
                    <p class="text-gray-600">Centro - São Paulo/SP</p>
                    <p class="text-gray-600">CEP: 01234-567</p>
                </div>
            </div>
            
            <!-- Estatísticas -->
            <div>
                <h4 class="font-semibold text-gray-900 mb-3">Estatísticas</h4>
                <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div class="text-center p-3 bg-blue-50 rounded-lg">
                        <p class="text-2xl font-bold text-blue-600">15</p>
                        <p class="text-sm text-gray-600">Pedidos</p>
                    </div>
                    <div class="text-center p-3 bg-green-50 rounded-lg">
                        <p class="text-2xl font-bold text-green-600">R$ 675</p>
                        <p class="text-sm text-gray-600">Total Gasto</p>
                    </div>
                    <div class="text-center p-3 bg-yellow-50 rounded-lg">
                        <p class="text-2xl font-bold text-yellow-600">45</p>
                        <p class="text-sm text-gray-600">Ticket Médio</p>
                    </div>
                    <div class="text-center p-3 bg-purple-50 rounded-lg">
                        <p class="text-2xl font-bold text-purple-600">2</p>
                        <p class="text-sm text-gray-600">Dias</p>
                    </div>
                </div>
            </div>
            
            <!-- Histórico de Pessos -->
            <div>
                <h4 class="font-semibold text-gray-900 mb-3">Últimos Pedidos</h4>
                <div class="space-y-2">
                    <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div>
                            <p class="font-medium">Pedido #1234</p>
                            <p class="text-sm text-gray-500">15/12/2024 - 15:30</p>
                        </div>
                        <span class="font-medium text-green-600">R$ 45,00</span>
                    </div>
                    <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div>
                            <p class="font-medium">Pedido #1233</p>
                            <p class="text-sm text-gray-500">13/12/2024 - 14:20</p>
                        </div>
                        <span class="font-medium text-green-600">R$ 32,50</span>
                    </div>
                </div>
            </div>
            
            <!-- Ações -->
            <div class="flex space-x-3 pt-4">
                <button class="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition">
                    Enviar Mensagem
                </button>
                <button class="flex-1 bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition">
                    Criar Pedido
                </button>
                <button class="flex-1 bg-purple-600 text-white py-2 px-4 rounded-lg hover:bg-purple-700 transition">
                    Tornar VIP
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Modal de Adicionar/Editar Cliente -->
<div id="customer-form-modal" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden flex items-center justify-center p-4">
    <div class="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div class="p-6 border-b border-gray-200">
            <div class="flex items-center justify-between">
                <h3 class="text-xl font-bold text-gray-900" id="customer-modal-title">Adicionar Cliente</h3>
                <button id="close-customer-form-modal" class="text-gray-500 hover:text-gray-700">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                </button>
            </div>
        </div>
        
        <form id="customer-form" class="p-6 space-y-6">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- Nome -->
                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Nome Completo *</label>
                    <input type="text" name="name" required class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
                
                <!-- E-mail -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">E-mail *</label>
                    <input type="email" name="email" required class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
                
                <!-- Telefone -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Telefone *</label>
                    <input type="tel" name="phone" required class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
                
                <!-- Data de Nascimento -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Data de Nascimento</label>
                    <input type="date" name="birthday" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
                
                <!-- CEP -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">CEP</label>
                    <input type="text" name="cep" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
                
                <!-- Endereço -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Endereço</label>
                    <input type="text" name="address" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
                
                <!-- Cidade -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Cidade</label>
                    <input type="text" name="city" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
                
                <!-- Estado -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Estado</label>
                    <input type="text" name="state" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
            </div>
            
            <!-- Botões -->
            <div class="flex space-x-3 pt-6">
                <button type="button" id="cancel-customer" class="flex-1 bg-gray-300 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-400 transition">
                    Cancelar
                </button>
                <button type="submit" class="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition">
                    Salvar Cliente
                </button>
            </div>
        </form>
    </div>
</div>

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    const customerModal = document.getElementById('customer-modal');
    const customerFormModal = document.getElementById('customer-form-modal');
    const customerForm = document.getElementById('customer-form');
    const modalTitle = document.getElementById('customer-modal-title');
    
    // Abrir modal para adicionar cliente
    document.getElementById('add-customer-btn').addEventListener('click', function() {
        modalTitle.textContent = 'Adicionar Cliente';
        customerForm.reset();
        customerFormModal.classList.remove('hidden');
    });
    
    // Fechar modais
    document.getElementById('close-customer-modal').addEventListener('click', function() {
        customerModal.classList.add('hidden');
    });
    
    document.getElementById('close-customer-form-modal').addEventListener('click', function() {
        customerFormModal.classList.add('hidden');
    });
    
    document.getElementById('cancel-customer').addEventListener('click', function() {
        customerFormModal.classList.add('hidden');
    });
    
    // Ver detalhes do cliente
    document.querySelectorAll('.view-customer').forEach(button => {
        button.addEventListener('click', function() {
            customerModal.classList.remove('hidden');
        });
    });
    
    // Editar cliente
    document.querySelectorAll('.edit-customer').forEach(button => {
        button.addEventListener('click', function() {
            modalTitle.textContent = 'Editar Cliente';
            // Aqui você carregaria os dados do cliente
            customerFormModal.classList.remove('hidden');
        });
    });
    
    // Toggle VIP
    document.querySelectorAll('.toggle-vip').forEach(button => {
        button.addEventListener('click', function() {
            const customerId = this.dataset.customerId;
            if (confirm('Tem certeza que deseja tornar este cliente VIP?')) {
                this.textContent = 'Remover VIP';
                this.classList.remove('toggle-vip');
                this.classList.add('remove-vip');
                showToast('Cliente promovido a VIP!', 'success');
            }
        });
    });
    
    // Remover VIP
    document.querySelectorAll('.remove-vip').forEach(button => {
        button.addEventListener('click', function() {
            const customerId = this.dataset.customerId;
            if (confirm('Tem certeza que deseja remover o status VIP deste cliente?')) {
                this.textContent = 'VIP';
                this.classList.remove('remove-vip');
                this.classList.add('toggle-vip');
                showToast('Status VIP removido!', 'success');
            }
        });
    });
    
    // Ativar cliente
    document.querySelectorAll('.activate-customer').forEach(button => {
        button.addEventListener('click', function() {
            const customerId = this.dataset.customerId;
            if (confirm('Tem certeza que deseja ativar este cliente?')) {
                showToast('Cliente ativado com sucesso!', 'success');
                // Aqui você faria a chamada para a API
            }
        });
    });
    
    // Salvar cliente
    customerForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        
        // Simular salvamento
        showToast('Cliente salvo com sucesso!', 'success');
        customerFormModal.classList.add('hidden');
        
        // Aqui você faria a chamada para a API
        // saveCustomer(formData);
    });
    
    // Filtros
    const searchInput = document.getElementById('search-customers');
    const statusFilter = document.getElementById('status-filter');
    
    function applyFilters() {
        const searchTerm = searchInput.value.toLowerCase();
        const selectedStatus = statusFilter.value;
        
        const rows = document.querySelectorAll('#customers-table-body tr');
        
        rows.forEach(row => {
            const customerName = row.querySelector('td:first-child .text-sm').textContent.toLowerCase();
            const status = row.querySelector('td:nth-child(5) span').textContent;
            
            const matchesSearch = customerName.includes(searchTerm);
            const matchesStatus = !selectedStatus || status.toLowerCase().includes(selectedStatus);
            
            if (matchesSearch && matchesStatus) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    }
    
    searchInput.addEventListener('input', applyFilters);
    statusFilter.addEventListener('change', applyFilters);
});
</script>
@endpush
@endsection
