<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Validator;

class CategoryController extends Controller
{
    /**
     * Listar categorias
     */
    public function index(Request $request): JsonResponse
    {
        $availableOnly = $request->boolean('available_only', true);
        $visibleOnly = $request->boolean('visible_only', false);
        $withProducts = $request->boolean('with_products', false);

        $categories = Category::ordered();

        if ($availableOnly) {
            $categories->available();
        }

        if ($visibleOnly) {
            $categories->visible();
        }

        $categories = $categories->get();

        if ($withProducts) {
            $categories->load(['products' => function ($query) use ($availableOnly, $visibleOnly) {
                if ($availableOnly) {
                    $query->available();
                }
                if ($visibleOnly) {
                    $query->visible();
                }
            }]);
        }

        return response()->json([
            'success' => true,
            'data' => $categories
        ]);
    }

    /**
     * Obter categoria específica
     */
    public function show(Category $category): JsonResponse
    {
        $category->load('products');

        return response()->json([
            'success' => true,
            'data' => $category
        ]);
    }

    /**
     * Criar nova categoria
     */
    public function store(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'icon' => 'nullable|string|max:255',
            'visible' => 'boolean',
            'available' => 'boolean',
            'sort_order' => 'integer|min:0',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Dados inválidos',
                'errors' => $validator->errors()
            ], 422);
        }

        $category = Category::create($request->all());

        return response()->json([
            'success' => true,
            'message' => 'Categoria criada com sucesso',
            'data' => $category
        ], 201);
    }

    /**
     * Atualizar categoria
     */
    public function update(Request $request, Category $category): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'name' => 'sometimes|required|string|max:255',
            'icon' => 'nullable|string|max:255',
            'visible' => 'boolean',
            'available' => 'boolean',
            'sort_order' => 'integer|min:0',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Dados inválidos',
                'errors' => $validator->errors()
            ], 422);
        }

        $category->update($request->all());

        return response()->json([
            'success' => true,
            'message' => 'Categoria atualizada com sucesso',
            'data' => $category
        ]);
    }

    /**
     * Deletar categoria
     */
    public function destroy(Category $category): JsonResponse
    {
        // Verificar se há produtos na categoria
        if ($category->products()->count() > 0) {
            return response()->json([
                'success' => false,
                'message' => 'Não é possível deletar categoria com produtos'
            ], 422);
        }

        $category->delete();

        return response()->json([
            'success' => true,
            'message' => 'Categoria deletada com sucesso'
        ]);
    }

    /**
     * Toggle visibilidade
     */
    public function toggleVisibility(Category $category): JsonResponse
    {
        $category->toggleVisibility();

        return response()->json([
            'success' => true,
            'message' => 'Visibilidade atualizada',
            'data' => $category
        ]);
    }

    /**
     * Toggle disponibilidade
     */
    public function toggleAvailability(Category $category): JsonResponse
    {
        $category->toggleAvailability();

        return response()->json([
            'success' => true,
            'message' => 'Disponibilidade atualizada',
            'data' => $category
        ]);
    }

    /**
     * Obter produtos da categoria
     */
    public function products(Request $request, Category $category): JsonResponse
    {
        $availableOnly = $request->boolean('available_only', true);
        $visibleOnly = $request->boolean('visible_only', false);

        $products = $category->getProducts($availableOnly, $visibleOnly);

        return response()->json([
            'success' => true,
            'data' => $products
        ]);
    }

    /**
     * Obter categorias com produtos
     */
    public function withProducts(Request $request): JsonResponse
    {
        $availableOnly = $request->boolean('available_only', true);
        $visibleOnly = $request->boolean('visible_only', false);

        $categories = Category::withProducts($availableOnly, $visibleOnly);

        return response()->json([
            'success' => true,
            'data' => $categories
        ]);
    }

    /**
     * Buscar categoria por nome
     */
    public function findByName(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Nome é obrigatório',
                'errors' => $validator->errors()
            ], 422);
        }

        $category = Category::findByName($request->name);

        if (!$category) {
            return response()->json([
                'success' => false,
                'message' => 'Categoria não encontrada'
            ], 404);
        }

        return response()->json([
            'success' => true,
            'data' => $category
        ]);
    }

    /**
     * Reordenar categorias
     */
    public function reorder(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'categories' => 'required|array',
            'categories.*.id' => 'required|exists:categories,id',
            'categories.*.sort_order' => 'required|integer|min:0',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Dados inválidos',
                'errors' => $validator->errors()
            ], 422);
        }

        foreach ($request->categories as $categoryData) {
            Category::where('id', $categoryData['id'])
                ->update(['sort_order' => $categoryData['sort_order']]);
        }

        return response()->json([
            'success' => true,
            'message' => 'Ordem das categorias atualizada'
        ]);
    }
}
