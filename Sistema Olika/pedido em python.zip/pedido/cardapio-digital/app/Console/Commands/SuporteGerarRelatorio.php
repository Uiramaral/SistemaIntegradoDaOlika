<?php

namespace App\Console\Commands;

use App\Models\ConversaSuporte;
use App\Models\MensagemSuporte;
use Illuminate\Console\Command;
use Carbon\Carbon;
use Illuminate\Support\Facades\Storage;

class SuporteGerarRelatorio extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'suporte:gerar-relatorio 
                            {--periodo=hoje : Período para o relatório (hoje, ontem, semana, mes)}
                            {--formato=json : Formato do relatório (json, csv, html)}
                            {--arquivo= : Nome do arquivo de saída (opcional)}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Gera relatório detalhado do sistema de suporte IA';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $periodo = $this->option('periodo');
        $formato = $this->option('formato');
        $arquivo = $this->option('arquivo');

        $this->info("📊 Gerando relatório do sistema de suporte IA");
        $this->info("Período: {$periodo} | Formato: {$formato}");

        $dataInicio = $this->obterDataInicio($periodo);
        $dataFim = Carbon::now();

        // Gerar dados do relatório
        $relatorio = $this->gerarDadosRelatorio($dataInicio, $dataFim);

        // Gerar arquivo
        $conteudo = $this->gerarConteudoRelatorio($relatorio, $formato);
        $nomeArquivo = $this->gerarNomeArquivo($arquivo, $periodo, $formato);

        // Salvar arquivo
        $caminho = Storage::put("relatorios/suporte/{$nomeArquivo}", $conteudo);

        $this->info("✅ Relatório gerado com sucesso!");
        $this->info("📁 Arquivo salvo em: storage/app/relatorios/suporte/{$nomeArquivo}");
        $this->info("🔗 Caminho completo: " . storage_path("app/relatorios/suporte/{$nomeArquivo}"));

        // Exibir resumo
        $this->exibirResumoRelatorio($relatorio);
    }

    private function obterDataInicio(string $periodo): Carbon
    {
        switch ($periodo) {
            case 'hoje':
                return Carbon::today();
            case 'ontem':
                return Carbon::yesterday();
            case 'semana':
                return Carbon::now()->subWeek();
            case 'mes':
                return Carbon::now()->subMonth();
            default:
                return Carbon::today();
        }
    }

    private function gerarDadosRelatorio(Carbon $dataInicio, Carbon $dataFim): array
    {
        return [
            'metadados' => [
                'periodo' => $dataInicio->format('d/m/Y H:i') . ' - ' . $dataFim->format('d/m/Y H:i'),
                'gerado_em' => now()->toISOString(),
                'versao_sistema' => '1.0.0'
            ],
            'estatisticas_gerais' => $this->obterEstatisticasGerais($dataInicio, $dataFim),
            'conversas' => $this->obterDadosConversas($dataInicio, $dataFim),
            'mensagens' => $this->obterDadosMensagens($dataInicio, $dataFim),
            'tokens_custos' => $this->obterDadosTokensCustos($dataInicio, $dataFim),
            'performance' => $this->obterDadosPerformance($dataInicio, $dataFim),
            'analise_sentimentos' => $this->obterAnaliseSentimentos($dataInicio, $dataFim),
            'top_assuntos' => $this->obterTopAssuntos($dataInicio, $dataFim),
            'top_intencoes' => $this->obterTopIntencoes($dataInicio, $dataFim),
        ];
    }

    private function obterEstatisticasGerais(Carbon $dataInicio, Carbon $dataFim): array
    {
        $conversas = ConversaSuporte::whereBetween('created_at', [$dataInicio, $dataFim]);
        $mensagens = MensagemSuporte::whereBetween('created_at', [$dataInicio, $dataFim]);

        return [
            'conversas_criadas' => $conversas->count(),
            'conversas_ativas' => $conversas->where('status', 'ativa')->count(),
            'conversas_encerradas' => $conversas->where('status', 'encerrada')->count(),
            'total_mensagens' => $mensagens->count(),
            'mensagens_usuario' => $mensagens->where('role', 'user')->count(),
            'mensagens_assistant' => $mensagens->where('role', 'assistant')->count(),
            'mensagens_sistema' => $mensagens->where('role', 'system')->count(),
        ];
    }

    private function obterDadosConversas(Carbon $dataInicio, Carbon $dataFim): array
    {
        $conversas = ConversaSuporte::whereBetween('created_at', [$dataInicio, $dataFim])
            ->with(['cliente', 'mensagens'])
            ->get()
            ->map(function ($conversa) {
                return [
                    'id' => $conversa->id,
                    'subscriber_id' => $conversa->subscriber_id,
                    'telefone' => $conversa->telefone,
                    'nome' => $conversa->nome,
                    'status' => $conversa->status,
                    'assunto' => $conversa->assunto,
                    'total_mensagens' => $conversa->mensagens->count(),
                    'total_tokens' => $conversa->mensagens->sum('tokens_total'),
                    'custo_total' => $conversa->mensagens->sum('custo_estimado'),
                    'inicio' => $conversa->created_at->toISOString(),
                    'ultima_atividade' => $conversa->updated_at->toISOString(),
                    'duracao_minutos' => $conversa->created_at->diffInMinutes($conversa->updated_at),
                ];
            });

        return [
            'total' => $conversas->count(),
            'detalhes' => $conversas->toArray()
        ];
    }

    private function obterDadosMensagens(Carbon $dataInicio, Carbon $dataFim): array
    {
        $mensagens = MensagemSuporte::whereBetween('created_at', [$dataInicio, $dataFim])
            ->with('conversa')
            ->get()
            ->map(function ($mensagem) {
                return [
                    'id' => $mensagem->id,
                    'conversa_id' => $mensagem->conversa_id,
                    'role' => $mensagem->role,
                    'conteudo' => $mensagem->conteudo,
                    'classificacao' => $mensagem->classificacao,
                    'tokens_total' => $mensagem->tokens_total,
                    'custo_estimado' => $mensagem->custo_estimado,
                    'model_usado' => $mensagem->model_usado,
                    'created_at' => $mensagem->created_at->toISOString(),
                ];
            });

        return [
            'total' => $mensagens->count(),
            'detalhes' => $mensagens->toArray()
        ];
    }

    private function obterDadosTokensCustos(Carbon $dataInicio, Carbon $dataFim): array
    {
        $tokens = MensagemSuporte::whereBetween('created_at', [$dataInicio, $dataFim])
            ->where('role', 'assistant')
            ->selectRaw('
                SUM(tokens_prompt) as total_prompt,
                SUM(tokens_completion) as total_completion,
                SUM(tokens_total) as total_tokens,
                SUM(custo_estimado) as custo_total,
                AVG(tokens_total) as media_tokens,
                AVG(custo_estimado) as media_custo,
                MIN(tokens_total) as min_tokens,
                MAX(tokens_total) as max_tokens
            ')
            ->first();

        return [
            'tokens_prompt' => $tokens->total_prompt ?? 0,
            'tokens_completion' => $tokens->total_completion ?? 0,
            'tokens_total' => $tokens->total_tokens ?? 0,
            'custo_total_usd' => $tokens->custo_total ?? 0,
            'media_tokens_por_mensagem' => $tokens->media_tokens ?? 0,
            'media_custo_por_mensagem' => $tokens->media_custo ?? 0,
            'min_tokens_por_mensagem' => $tokens->min_tokens ?? 0,
            'max_tokens_por_mensagem' => $tokens->max_tokens ?? 0,
        ];
    }

    private function obterDadosPerformance(Carbon $dataInicio, Carbon $dataFim): array
    {
        $performance = MensagemSuporte::whereBetween('created_at', [$dataInicio, $dataFim])
            ->where('role', 'assistant')
            ->whereNotNull('classificacao')
            ->selectRaw('
                AVG(JSON_EXTRACT(classificacao, "$.confianca")) as media_confianca,
                COUNT(CASE WHEN JSON_EXTRACT(classificacao, "$.confianca") >= 0.8 THEN 1 END) as alta_confianca,
                COUNT(CASE WHEN JSON_EXTRACT(classificacao, "$.confianca") < 0.8 THEN 1 END) as baixa_confianca,
                COUNT(*) as total_mensagens
            ')
            ->first();

        $taxaSucesso = $performance->total_mensagens > 0 
            ? ($performance->alta_confianca / $performance->total_mensagens) * 100 
            : 0;

        return [
            'media_confianca' => $performance->media_confianca ?? 0,
            'mensagens_alta_confianca' => $performance->alta_confianca ?? 0,
            'mensagens_baixa_confianca' => $performance->baixa_confianca ?? 0,
            'taxa_sucesso_percentual' => $taxaSucesso,
            'total_mensagens_analisadas' => $performance->total_mensagens ?? 0,
        ];
    }

    private function obterAnaliseSentimentos(Carbon $dataInicio, Carbon $dataFim): array
    {
        $sentimentos = MensagemSuporte::whereBetween('created_at', [$dataInicio, $dataFim])
            ->where('role', 'user')
            ->whereNotNull('classificacao')
            ->selectRaw('
                JSON_EXTRACT(classificacao, "$.sentimento") as sentimento,
                JSON_EXTRACT(classificacao, "$.urgencia") as urgencia,
                COUNT(*) as total,
                AVG(JSON_EXTRACT(classificacao, "$.confianca")) as media_confianca
            ')
            ->groupBy('sentimento', 'urgencia')
            ->orderBy('total', 'desc')
            ->get();

        return $sentimentos->map(function ($item) {
            return [
                'sentimento' => $item->sentimento,
                'urgencia' => $item->urgencia,
                'total' => $item->total,
                'media_confianca' => $item->media_confianca,
            ];
        })->toArray();
    }

    private function obterTopAssuntos(Carbon $dataInicio, Carbon $dataFim): array
    {
        return ConversaSuporte::whereBetween('created_at', [$dataInicio, $dataFim])
            ->whereNotNull('assunto')
            ->selectRaw('assunto, COUNT(*) as total')
            ->groupBy('assunto')
            ->orderBy('total', 'desc')
            ->limit(10)
            ->get()
            ->map(function ($item) {
                return [
                    'assunto' => $item->assunto,
                    'total' => $item->total,
                ];
            })
            ->toArray();
    }

    private function obterTopIntencoes(Carbon $dataInicio, Carbon $dataFim): array
    {
        return MensagemSuporte::whereBetween('created_at', [$dataInicio, $dataFim])
            ->where('role', 'user')
            ->whereNotNull('classificacao')
            ->selectRaw('JSON_EXTRACT(classificacao, "$.intencao") as intencao, COUNT(*) as total')
            ->groupBy('intencao')
            ->orderBy('total', 'desc')
            ->limit(10)
            ->get()
            ->map(function ($item) {
                return [
                    'intencao' => $item->intencao,
                    'total' => $item->total,
                ];
            })
            ->toArray();
    }

    private function gerarConteudoRelatorio(array $relatorio, string $formato): string
    {
        switch ($formato) {
            case 'json':
                return json_encode($relatorio, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
            case 'csv':
                return $this->gerarCSV($relatorio);
            case 'html':
                return $this->gerarHTML($relatorio);
            default:
                return json_encode($relatorio, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        }
    }

    private function gerarCSV(array $relatorio): string
    {
        $csv = "Métrica,Valor\n";
        $csv .= "Período,{$relatorio['metadados']['periodo']}\n";
        $csv .= "Gerado em,{$relatorio['metadados']['gerado_em']}\n";
        $csv .= "Conversas criadas,{$relatorio['estatisticas_gerais']['conversas_criadas']}\n";
        $csv .= "Conversas ativas,{$relatorio['estatisticas_gerais']['conversas_ativas']}\n";
        $csv .= "Total mensagens,{$relatorio['estatisticas_gerais']['total_mensagens']}\n";
        $csv .= "Total tokens,{$relatorio['tokens_custos']['tokens_total']}\n";
        $csv .= "Custo total (USD),{$relatorio['tokens_custos']['custo_total_usd']}\n";
        $csv .= "Taxa de sucesso,{$relatorio['performance']['taxa_sucesso_percentual']}%\n";
        
        return $csv;
    }

    private function gerarHTML(array $relatorio): string
    {
        $html = "<!DOCTYPE html>
<html lang='pt-BR'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Relatório Sistema de Suporte IA</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .header { background: #f8f9fa; padding: 20px; border-radius: 5px; margin-bottom: 20px; }
        .section { margin-bottom: 30px; }
        .metric { display: inline-block; margin: 10px; padding: 15px; background: #e9ecef; border-radius: 5px; }
        .metric-value { font-size: 24px; font-weight: bold; color: #007bff; }
        .metric-label { font-size: 14px; color: #6c757d; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { padding: 10px; text-align: left; border-bottom: 1px solid #dee2e6; }
        th { background-color: #f8f9fa; }
    </style>
</head>
<body>
    <div class='header'>
        <h1>📊 Relatório Sistema de Suporte IA</h1>
        <p><strong>Período:</strong> {$relatorio['metadados']['periodo']}</p>
        <p><strong>Gerado em:</strong> {$relatorio['metadados']['gerado_em']}</p>
    </div>

    <div class='section'>
        <h2>📈 Estatísticas Gerais</h2>
        <div class='metric'>
            <div class='metric-value'>{$relatorio['estatisticas_gerais']['conversas_criadas']}</div>
            <div class='metric-label'>Conversas Criadas</div>
        </div>
        <div class='metric'>
            <div class='metric-value'>{$relatorio['estatisticas_gerais']['conversas_ativas']}</div>
            <div class='metric-label'>Conversas Ativas</div>
        </div>
        <div class='metric'>
            <div class='metric-value'>{$relatorio['estatisticas_gerais']['total_mensagens']}</div>
            <div class='metric-label'>Total Mensagens</div>
        </div>
        <div class='metric'>
            <div class='metric-value'>{$relatorio['tokens_custos']['tokens_total']}</div>
            <div class='metric-label'>Total Tokens</div>
        </div>
        <div class='metric'>
            <div class='metric-value'>$" . number_format($relatorio['tokens_custos']['custo_total_usd'], 4) . "</div>
            <div class='metric-label'>Custo Total (USD)</div>
        </div>
        <div class='metric'>
            <div class='metric-value'>" . number_format($relatorio['performance']['taxa_sucesso_percentual'], 2) . "%</div>
            <div class='metric-label'>Taxa de Sucesso</div>
        </div>
    </div>
</body>
</html>";

        return $html;
    }

    private function gerarNomeArquivo(?string $arquivo, string $periodo, string $formato): string
    {
        if ($arquivo) {
            return $arquivo . '.' . $formato;
        }

        $timestamp = now()->format('Y-m-d_H-i-s');
        return "relatorio_suporte_ia_{$periodo}_{$timestamp}.{$formato}";
    }

    private function exibirResumoRelatorio(array $relatorio): void
    {
        $this->newLine();
        $this->info("📋 RESUMO DO RELATÓRIO:");
        $this->info("   - Conversas: {$relatorio['estatisticas_gerais']['conversas_criadas']} criadas, {$relatorio['estatisticas_gerais']['conversas_ativas']} ativas");
        $this->info("   - Mensagens: {$relatorio['estatisticas_gerais']['total_mensagens']} total");
        $this->info("   - Tokens: " . number_format($relatorio['tokens_custos']['tokens_total']) . " total");
        $this->info("   - Custo: $" . number_format($relatorio['tokens_custos']['custo_total_usd'], 4) . " USD");
        $this->info("   - Performance: " . number_format($relatorio['performance']['taxa_sucesso_percentual'], 2) . "% de sucesso");
    }
}
