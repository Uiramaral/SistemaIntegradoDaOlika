@extends('client.layout')

@section('title', 'Minhas Configurações')

@section('content')
<div class="min-h-screen bg-background py-8">
    <div class="container mx-auto px-4 max-w-4xl">
        <h1 class="text-3xl font-bold mb-8">Minhas Configurações</h1>

        <div class="space-y-6">
            <!-- Informações Pessoais -->
            <div class="rounded-lg border bg-card text-card-foreground shadow-sm">
                <div class="flex flex-col space-y-1.5 p-6">
                    <h3 class="text-2xl font-semibold leading-none tracking-tight">Informações Pessoais</h3>
                    <p class="text-sm text-muted-foreground">Atualize suas informações de contato</p>
                </div>
                <div class="p-6 pt-0">
                    <form method="POST" action="/settings/profile" class="space-y-4">
                        @csrf
                        
                        <div>
                            <label class="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                                Nome Completo <span class="text-red-500">*</span>
                            </label>
                            <input 
                                type="text" 
                                name="name" 
                                value="{{ old('name', $user->name ?? '') }}"
                                class="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 mt-2"
                                required
                            />
                            @error('name')
                                <p class="text-sm text-red-500 mt-1">{{ $message }}</p>
                            @enderror
                        </div>

                        <div>
                            <label class="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                                E-mail <span class="text-red-500">*</span>
                            </label>
                            <input 
                                type="email" 
                                name="email" 
                                value="{{ old('email', $user->email ?? '') }}"
                                class="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 mt-2"
                                required
                            />
                            @error('email')
                                <p class="text-sm text-red-500 mt-1">{{ $message }}</p>
                            @enderror
                        </div>

                        <div>
                            <label class="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                                Telefone <span class="text-red-500">*</span>
                            </label>
                            <input 
                                type="tel" 
                                name="phone" 
                                value="{{ old('phone', $user->phone ?? '') }}"
                                class="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 mt-2"
                                placeholder="(00) 00000-0000"
                                required
                            />
                            @error('phone')
                                <p class="text-sm text-red-500 mt-1">{{ $message }}</p>
                            @enderror
                        </div>

                        <button type="submit" class="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground hover:bg-primary/90 h-10 px-4 py-2">
                            Salvar Alterações
                        </button>
                    </form>
                </div>
            </div>

            <!-- Endereços de Entrega -->
            <div class="rounded-lg border bg-card text-card-foreground shadow-sm">
                <div class="flex flex-col space-y-1.5 p-6">
                    <h3 class="text-2xl font-semibold leading-none tracking-tight">Endereços de Entrega</h3>
                    <p class="text-sm text-muted-foreground">Gerencie seus endereços salvos</p>
                </div>
                <div class="p-6 pt-0">
                    @forelse($addresses ?? [] as $address)
                        <div class="border rounded-lg p-4 mb-4 hover:shadow-md transition">
                            <div class="flex justify-between items-start">
                                <div class="flex-1">
                                    <div class="flex items-center gap-2 mb-2">
                                        <p class="font-medium text-lg">{{ $address->label }}</p>
                                        @if($address->is_default)
                                            <span class="inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus-visible:ring-offset-2 border-transparent bg-green-500 text-white">Padrão</span>
                                        @endif
                                    </div>
                                    <p class="text-sm text-muted-foreground">
                                        {{ $address->street }}, {{ $address->number }}
                                        @if($address->complement), {{ $address->complement }}@endif<br>
                                        {{ $address->neighborhood }} - {{ $address->city }}/{{ $address->state }}<br>
                                        CEP: {{ $address->zipcode }}
                                    </p>
                                </div>
                                <div class="flex gap-2 ml-4">
                                    <button onclick="editAddress({{ $address->id }})" class="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 border border-input bg-background hover:bg-accent hover:text-accent-foreground h-9 px-3">
                                        Editar
                                    </button>
                                    <button onclick="deleteAddress({{ $address->id }})" class="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-red-500 text-white hover:bg-red-600 h-9 px-3">
                                        Remover
                                    </button>
                                </div>
                            </div>
                        </div>
                    @empty
                        <div class="text-center py-8">
                            <svg class="mx-auto h-12 w-12 text-muted-foreground mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                            </svg>
                            <p class="text-muted-foreground">Nenhum endereço cadastrado</p>
                        </div>
                    @endforelse
                    
                    <button onclick="addAddress()" class="w-full inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 border border-input bg-background hover:bg-accent hover:text-accent-foreground h-10 px-4 py-2">
                        <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" />
                        </svg>
                        Adicionar Endereço
                    </button>
                </div>
            </div>

            <!-- Preferências -->
            <div class="rounded-lg border bg-card text-card-foreground shadow-sm">
                <div class="flex flex-col space-y-1.5 p-6">
                    <h3 class="text-2xl font-semibold leading-none tracking-tight">Preferências</h3>
                    <p class="text-sm text-muted-foreground">Configure como deseja receber notificações</p>
                </div>
                <div class="p-6 pt-0 space-y-4">
                    <div class="flex items-center justify-between py-3 border-b">
                        <div class="flex-1">
                            <p class="font-medium">Notificações por E-mail</p>
                            <p class="text-sm text-muted-foreground">Receba atualizações de pedidos por e-mail</p>
                        </div>
                        <label for="email_notifications" class="inline-flex items-center cursor-pointer">
                            <input type="checkbox" id="email_notifications" checked class="sr-only peer" onchange="updatePreference('email_notifications', this.checked)" />
                            <div class="relative w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                        </label>
                    </div>

                    <div class="flex items-center justify-between py-3 border-b">
                        <div class="flex-1">
                            <p class="font-medium">Notificações por WhatsApp</p>
                            <p class="text-sm text-muted-foreground">Receba atualizações de pedidos por WhatsApp</p>
                        </div>
                        <label for="whatsapp_notifications" class="inline-flex items-center cursor-pointer">
                            <input type="checkbox" id="whatsapp_notifications" checked class="sr-only peer" onchange="updatePreference('whatsapp_notifications', this.checked)" />
                            <div class="relative w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                        </label>
                    </div>

                    <div class="flex items-center justify-between py-3">
                        <div class="flex-1">
                            <p class="font-medium">Ofertas e Promoções</p>
                            <p class="text-sm text-muted-foreground">Receba cupons e ofertas exclusivas</p>
                        </div>
                        <label for="promotions" class="inline-flex items-center cursor-pointer">
                            <input type="checkbox" id="promotions" class="sr-only peer" onchange="updatePreference('promotions', this.checked)" />
                            <div class="relative w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                        </label>
                    </div>
                </div>
            </div>

            <!-- Histórico de Pedidos -->
            <div class="rounded-lg border bg-card text-card-foreground shadow-sm">
                <div class="flex flex-col space-y-1.5 p-6">
                    <h3 class="text-2xl font-semibold leading-none tracking-tight">Histórico de Pedidos</h3>
                    <p class="text-sm text-muted-foreground">Seus últimos pedidos</p>
                </div>
                <div class="p-6 pt-0">
                    @forelse($orders ?? [] as $order)
                        <div class="border-b last:border-0 py-4">
                            <div class="flex justify-between items-start">
                                <div class="flex-1">
                                    <p class="font-medium text-lg">Pedido #{{ $order->id }}</p>
                                    <p class="text-sm text-muted-foreground">{{ $order->created_at->format('d/m/Y H:i') }}</p>
                                    <div class="mt-2">
                                        @php
                                            $statusVariants = [
                                                'pending' => 'warning',
                                                'confirmed' => 'default',
                                                'preparing' => 'default',
                                                'ready' => 'success',
                                                'delivering' => 'default',
                                                'delivered' => 'success',
                                                'cancelled' => 'destructive',
                                            ];
                                            $variant = $statusVariants[$order->status] ?? 'default';
                                        @endphp
                                        <span class="inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 
                                        @if($variant === 'success') border-transparent bg-green-500 text-white
                                        @elseif($variant === 'warning') border-transparent bg-yellow-500 text-white
                                        @elseif($variant === 'destructive') border-transparent bg-red-500 text-white
                                        @else border-transparent bg-primary text-primary-foreground
                                        @endif">
                                            {{ $order->status_label }}
                                        </span>
                                    </div>
                                </div>
                                <div class="text-right ml-4">
                                    <p class="font-bold text-lg text-primary">R$ {{ number_format($order->total, 2, ',', '.') }}</p>
                                    <a href="/orders/{{ $order->id }}" class="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 border border-input bg-background hover:bg-accent hover:text-accent-foreground h-9 px-3 mt-2">
                                        Ver Detalhes
                                    </a>
                                </div>
                            </div>
                        </div>
                    @empty
                        <div class="text-center py-8">
                            <svg class="mx-auto h-12 w-12 text-muted-foreground mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
                            </svg>
                            <p class="text-muted-foreground">Nenhum pedido ainda</p>
                            <a href="/" class="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground hover:bg-primary/90 h-10 px-4 py-2 mt-4">
                                Fazer Primeiro Pedido
                            </a>
                        </div>
                    @endforelse
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function updatePreference(preference, value) {
    fetch('/api/settings/preferences', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
        },
        body: JSON.stringify({ [preference]: value })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            window.showToast('Preferência atualizada!', 'success');
        }
    })
    .catch(error => {
        console.error('Erro:', error);
        window.showToast('Erro ao atualizar preferência', 'error');
    });
}

function addAddress() {
    // Implementar modal de adicionar endereço
    window.location.href = '/settings/addresses/create';
}

function editAddress(id) {
    window.location.href = `/settings/addresses/${id}/edit`;
}

function deleteAddress(id) {
    if (confirm('Tem certeza que deseja remover este endereço?')) {
        fetch(`/api/addresses/${id}`, {
            method: 'DELETE',
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                window.location.reload();
            }
        })
        .catch(error => {
            console.error('Erro:', error);
            window.showToast('Erro ao remover endereço', 'error');
        });
    }
}
</script>
@endsection

