<?php

namespace App\Services;

use Illuminate\Support\Facades\Log;

class IntentRecognitionService
{
    private $intentPatterns;
    private $entityPatterns;

    public function __construct()
    {
        $this->intentPatterns = $this->loadIntentPatterns();
        $this->entityPatterns = $this->loadEntityPatterns();
    }

    /**
     * Reconhecer intenção da mensagem
     */
    public function recognize(string $message, array $context = []): array
    {
        $message = strtolower(trim($message));
        $intent = $this->matchIntent($message);
        $entities = $this->extractEntities($message);

        // Ajustar intenção baseada no contexto
        $intent = $this->adjustIntentByContext($intent, $context, $entities);

        return [
            'type' => $intent['type'],
            'confidence' => $intent['confidence'],
            'entities' => $entities,
            'context' => $context,
            'original_message' => $message
        ];
    }

    /**
     * Carregar padrões de intenções
     */
    private function loadIntentPatterns(): array
    {
        return [
            'greeting' => [
                'patterns' => [
                    '/\b(ola|oi|eai|e aí|hey|hi|hello|bom dia|boa tarde|boa noite)\b/',
                    '/\b(tudo bem|td bem|como vai|como está)\b/'
                ],
                'confidence' => 0.9,
                'context_required' => false
            ],
            'menu_request' => [
                'patterns' => [
                    '/\b(cardapio|menu|cardápio|comida|pratos|o que vocês têm|o que tem)\b/',
                    '/\b(ver cardapio|mostrar cardapio|listar pratos)\b/',
                    '/\b(quais são os pratos|que pratos vocês têm)\b/'
                ],
                'confidence' => 0.95,
                'context_required' => false
            ],
            'product_inquiry' => [
                'patterns' => [
                    '/\b(quanto custa|preço|valor|quanto é)\b/',
                    '/\b(o que é|tem|existe)\b/',
                    '/\b(ingredientes|tem gluten|tem lactose|é vegano)\b/',
                    '/\b(tempo de preparo|quanto demora)\b/'
                ],
                'confidence' => 0.8,
                'context_required' => false,
                'requires_entity' => 'product'
            ],
            'order_start' => [
                'patterns' => [
                    '/\b(quero pedir|fazer pedido|pedir|comprar|encomendar)\b/',
                    '/\b(quero|gostaria|vou querer|preciso)\b/',
                    '/\b(fazer um pedido|novo pedido|começar pedido)\b/'
                ],
                'confidence' => 0.9,
                'context_required' => false
            ],
            'add_to_cart' => [
                'patterns' => [
                    '/\b(quero|gostaria|vou querer|preciso|adicionar|colocar)\b/',
                    '/\b(me dá|me manda|me envia)\b/',
                    '/\b(uma|duas|três|quatro|cinco|1|2|3|4|5)\b.*\b(prato|bebida|sobremesa)\b/'
                ],
                'confidence' => 0.85,
                'context_required' => ['order_started'],
                'requires_entity' => 'product'
            ],
            'order_complete' => [
                'patterns' => [
                    '/\b(finalizar|concluir|terminar|fechar pedido)\b/',
                    '/\b(é isso|só isso|acabou|pronto)\b/',
                    '/\b(quero pagar|como pagar|forma de pagamento)\b/',
                    '/\b(endereço|onde entregar|entrega)\b/'
                ],
                'confidence' => 0.9,
                'context_required' => ['order_started', 'cart_not_empty']
            ],
            'order_status' => [
                'patterns' => [
                    '/\b(status|situação|onde está|pedido)\b/',
                    '/\b(quando chega|quando entrega|tempo)\b/',
                    '/\b(último pedido|meu pedido|pedido número)\b/'
                ],
                'confidence' => 0.8,
                'context_required' => false
            ],
            'delivery_info' => [
                'patterns' => [
                    '/\b(entrega|delivery|frete|taxa)\b/',
                    '/\b(onde entregam|área de entrega|cep)\b/',
                    '/\b(tempo de entrega|quando chega|demora quanto)\b/'
                ],
                'confidence' => 0.85,
                'context_required' => false
            ],
            'payment_info' => [
                'patterns' => [
                    '/\b(pagamento|pagar|forma de pagamento)\b/',
                    '/\b(pix|cartão|dinheiro|boleto)\b/',
                    '/\b(mercado pago|whatsapp|transferência)\b/'
                ],
                'confidence' => 0.9,
                'context_required' => false
            ],
            'complaint' => [
                'patterns' => [
                    '/\b(reclamação|reclamar|problema|erro)\b/',
                    '/\b(ruim|péssimo|horrível|demorou|atrasou)\b/',
                    '/\b(não gostei|não recomendo|muito ruim)\b/',
                    '/\b(cancelar|devolver|trocar)\b/'
                ],
                'confidence' => 0.9,
                'context_required' => false
            ],
            'compliment' => [
                'patterns' => [
                    '/\b(parabéns|muito bom|excelente|ótimo|delicioso)\b/',
                    '/\b(amei|adorei|perfeito|maravilhoso)\b/',
                    '/\b(recomendo|indico|volto sempre)\b/',
                    '/\b(obrigado|obrigada|valeu|show)\b/'
                ],
                'confidence' => 0.8,
                'context_required' => false
            ],
            'help' => [
                'patterns' => [
                    '/\b(ajuda|help|socorro|não sei|como funciona)\b/',
                    '/\b(o que posso|quais opções|menu|comandos)\b/',
                    '/\b(atendente|falar com|humano|pessoa)\b/'
                ],
                'confidence' => 0.9,
                'context_required' => false
            ]
        ];
    }

    /**
     * Carregar padrões de entidades
     */
    private function loadEntityPatterns(): array
    {
        return [
            'product' => [
                'patterns' => [
                    // Pratos principais
                    '/\b(prato do dia|prato especial|prato principal)\b/',
                    '/\b(frango grelhado|frango|grelhado)\b/',
                    '/\b(bife à parmegiana|parmegiana|bife)\b/',
                    '/\b(peixe|salmão|tilápia|bacalhau)\b/',
                    '/\b(macarrão|espaguete|penne|lasanha)\b/',
                    '/\b(risotto|arroz|arroz integral)\b/',
                    
                    // Bebidas
                    '/\b(coca|refrigerante|soda)\b/',
                    '/\b(suco|suco de laranja|laranja)\b/',
                    '/\b(água|água mineral)\b/',
                    '/\b(cerveja|chopp|cervejinha)\b/',
                    '/\b(vinho|vinho tinto|vinho branco)\b/',
                    
                    // Sobremesas
                    '/\b(pudim|pudim de leite)\b/',
                    '/\b(brigadeiro|brigadeiros)\b/',
                    '/\b(sorvete|açaí|gelato)\b/',
                    '/\b(brownie|torta|cheesecake)\b/',
                    
                    // Aperitivos
                    '/\b(batata frita|batatas|fritas)\b/',
                    '/\b(coxinha|coxinhas)\b/',
                    '/\b(pastel|pastéis)\b/',
                    '/\b(petiscos|aperitivos)\b/'
                ],
                'confidence' => 0.8
            ],
            'quantity' => [
                'patterns' => [
                    '/\b(uma|um|1)\b/',
                    '/\b(duas|dois|2)\b/',
                    '/\b(três|3)\b/',
                    '/\b(quatro|4)\b/',
                    '/\b(cinco|5)\b/',
                    '/\b(seis|6)\b/',
                    '/\b(sete|7)\b/',
                    '/\b(oito|8)\b/',
                    '/\b(nove|9)\b/',
                    '/\b(dez|10)\b/'
                ],
                'confidence' => 0.9
            ],
            'complaint' => [
                'patterns' => [
                    '/\b(comida fria|prato frio|chegou frio)\b/',
                    '/\b(atrasou|demorou muito|tarde)\b/',
                    '/\b(errado|não é isso|pedido errado)\b/',
                    '/\b(qualidade ruim|gosto ruim|não gostei)\b/',
                    '/\b(embalagem|pacote|sacola)\b/'
                ],
                'confidence' => 0.8
            ]
        ];
    }

    /**
     * Fazer match da intenção
     */
    private function matchIntent(string $message): array
    {
        $bestMatch = [
            'type' => 'unknown',
            'confidence' => 0
        ];

        foreach ($this->intentPatterns as $intentType => $intentData) {
            foreach ($intentData['patterns'] as $pattern) {
                if (preg_match($pattern, $message)) {
                    if ($intentData['confidence'] > $bestMatch['confidence']) {
                        $bestMatch = [
                            'type' => $intentType,
                            'confidence' => $intentData['confidence']
                        ];
                    }
                }
            }
        }

        return $bestMatch;
    }

    /**
     * Extrair entidades da mensagem
     */
    private function extractEntities(string $message): array
    {
        $entities = [];

        foreach ($this->entityPatterns as $entityType => $entityData) {
            foreach ($entityData['patterns'] as $pattern) {
                if (preg_match($pattern, $message, $matches)) {
                    $entities[$entityType] = $matches[0];
                    break;
                }
            }
        }

        // Extrair quantidade numérica
        if (preg_match('/\b(\d+)\b/', $message, $matches)) {
            $entities['quantity'] = (int)$matches[1];
        }

        // Extrair CEP
        if (preg_match('/\b(\d{5}-?\d{3})\b/', $message, $matches)) {
            $entities['cep'] = $matches[1];
        }

        // Extrair telefone
        if (preg_match('/\b(\(\d{2}\)\s?\d{4,5}-?\d{4})\b/', $message, $matches)) {
            $entities['phone'] = $matches[1];
        }

        return $entities;
    }

    /**
     * Ajustar intenção baseada no contexto
     */
    private function adjustIntentByContext(array $intent, array $context, array $entities): array
    {
        // Se está em processo de pedido e menciona produto, é add_to_cart
        if (isset($context['order_started']) && 
            $context['order_started'] && 
            isset($entities['product'])) {
            
            return [
                'type' => 'add_to_cart',
                'confidence' => 0.95
            ];
        }

        // Se menciona produto sem contexto de pedido, é product_inquiry
        if ($intent['type'] === 'unknown' && isset($entities['product'])) {
            return [
                'type' => 'product_inquiry',
                'confidence' => 0.85
            ];
        }

        // Se está coletando informações e menciona endereço
        if (isset($context['step']) && 
            $context['step'] === 'collecting_info' && 
            (isset($entities['cep']) || strpos($intent['original_message'], 'endereço') !== false)) {
            
            return [
                'type' => 'delivery_info',
                'confidence' => 0.9
            ];
        }

        // Se menciona pagamento em contexto de pedido
        if (isset($context['order_started']) && 
            $context['order_started'] && 
            in_array($intent['type'], ['payment_info', 'order_complete'])) {
            
            return [
                'type' => 'order_complete',
                'confidence' => 0.9
            ];
        }

        return $intent;
    }

    /**
     * Validar se intenção atende requisitos
     */
    private function validateIntentRequirements(array $intent, array $context, array $entities): bool
    {
        $intentData = $this->intentPatterns[$intent['type']] ?? null;
        
        if (!$intentData) {
            return false;
        }

        // Verificar se requer entidade específica
        if (isset($intentData['requires_entity'])) {
            $requiredEntity = $intentData['requires_entity'];
            if (!isset($entities[$requiredEntity])) {
                return false;
            }
        }

        // Verificar se requer contexto específico
        if (isset($intentData['context_required'])) {
            $requiredContext = $intentData['context_required'];
            
            if (is_array($requiredContext)) {
                foreach ($requiredContext as $contextKey) {
                    if (!isset($context[$contextKey])) {
                        return false;
                    }
                }
            } else {
                if (!isset($context[$requiredContext])) {
                    return false;
                }
            }
        }

        return true;
    }

    /**
     * Obter sugestões baseadas na intenção
     */
    public function getIntentSuggestions(array $intent): array
    {
        $suggestions = [
            'greeting' => ['Ver cardápio', 'Fazer pedido', 'Informações'],
            'menu_request' => ['Fazer pedido', 'Ver produtos', 'Preços'],
            'product_inquiry' => ['Adicionar ao pedido', 'Ver similares', 'Cardápio'],
            'order_start' => ['Ver cardápio', 'Produtos em destaque'],
            'add_to_cart' => ['Continuar pedido', 'Ver carrinho', 'Finalizar'],
            'order_complete' => ['Confirmar pedido', 'Forma de pagamento'],
            'order_status' => ['Ver detalhes', 'Fazer novo pedido'],
            'delivery_info' => ['Fazer pedido', 'Calcular frete'],
            'payment_info' => ['Finalizar pedido', 'Ver formas'],
            'complaint' => ['Falar com atendente', 'Cancelar pedido'],
            'compliment' => ['Fazer novo pedido', 'Indicar amigos'],
            'help' => ['Ver comandos', 'Falar com atendente'],
            'unknown' => ['Ver cardápio', 'Fazer pedido', 'Ajuda']
        ];

        return $suggestions[$intent['type']] ?? [];
    }

    /**
     * Treinar modelo com nova conversa
     */
    public function trainWithConversation(array $conversationData): void
    {
        // TODO: Implementar aprendizado contínuo
        // Salvar padrões que funcionaram bem
        // Ajustar confiança dos padrões existentes
        
        Log::info('Treinamento de IA com conversa', $conversationData);
    }

    /**
     * Obter estatísticas de reconhecimento
     */
    public function getRecognitionStats(): array
    {
        // TODO: Implementar métricas de performance
        return [
            'total_messages_processed' => 0,
            'successful_recognitions' => 0,
            'accuracy_rate' => 0.0,
            'most_common_intents' => [],
            'improvement_suggestions' => []
        ];
    }
}
