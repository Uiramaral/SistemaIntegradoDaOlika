<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Services\AIService;
use App\Services\WhatsAppService;
use App\Models\Customer;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class WhatsAppAIController extends Controller
{
    private $aiService;
    private $whatsAppService;

    public function __construct()
    {
        $this->aiService = new AIService();
        $this->whatsAppService = new WhatsAppService();
    }

    /**
     * Webhook para receber mensagens do WhatsApp
     */
    public function webhook(Request $request): JsonResponse
    {
        try {
            Log::info('Webhook WhatsApp recebido', $request->all());

            // Verificar se é uma mensagem válida
            if (!$this->isValidMessage($request)) {
                return response()->json(['status' => 'ignored'], 200);
            }

            // Extrair dados da mensagem
            $messageData = $this->extractMessageData($request);
            
            if (!$messageData) {
                return response()->json(['status' => 'invalid'], 200);
            }

            // Processar mensagem com IA
            $response = $this->aiService->processMessage(
                $messageData['text'],
                $messageData['phone'],
                $messageData['context']
            );

            // Salvar contexto da conversa
            if ($response['success']) {
                $this->aiService->saveConversationContext(
                    $messageData['phone'],
                    $response['context'] ?? []
                );
            }

            // Enviar resposta via WhatsApp
            $this->sendWhatsAppResponse($messageData['phone'], $response);

            // Processar ações específicas
            if (isset($response['actions'])) {
                $this->processActions($messageData['phone'], $response['actions'], $response);
            }

            return response()->json([
                'success' => true,
                'message' => 'Mensagem processada com sucesso'
            ]);

        } catch (\Exception $e) {
            Log::error('Erro no webhook WhatsApp IA', [
                'error' => $e->getMessage(),
                'request' => $request->all()
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Erro interno do servidor'
            ], 500);
        }
    }

    /**
     * Verificar se mensagem é válida
     */
    private function isValidMessage(Request $request): bool
    {
        // Verificar se é uma entrada de webhook válida
        $entry = $request->input('entry.0');
        
        if (!$entry || !isset($entry['changes'])) {
            return false;
        }

        $change = $entry['changes'][0] ?? null;
        
        if (!$change || $change['field'] !== 'messages') {
            return false;
        }

        $value = $change['value'] ?? null;
        
        if (!$value || !isset($value['messages'])) {
            return false;
        }

        return true;
    }

    /**
     * Extrair dados da mensagem
     */
    private function extractMessageData(Request $request): ?array
    {
        try {
            $entry = $request->input('entry.0');
            $change = $entry['changes'][0];
            $value = $change['value'];
            $message = $value['messages'][0];

            // Verificar se é mensagem de texto
            if ($message['type'] !== 'text') {
                return null;
            }

            $phone = $message['from'];
            $text = $message['text']['body'] ?? '';
            $messageId = $message['id'];

            // Obter contexto da conversa
            $context = $this->aiService->getConversationContext($phone);

            return [
                'phone' => $phone,
                'text' => $text,
                'message_id' => $messageId,
                'context' => $context,
                'timestamp' => now()->toISOString()
            ];

        } catch (\Exception $e) {
            Log::error('Erro ao extrair dados da mensagem', [
                'error' => $e->getMessage(),
                'request' => $request->all()
            ]);

            return null;
        }
    }

    /**
     * Enviar resposta via WhatsApp
     */
    private function sendWhatsAppResponse(string $phone, array $response): void
    {
        try {
            $message = $response['response'] ?? 'Desculpe, não consegui processar sua mensagem.';

            $this->whatsAppService->sendMessage($phone, $message);

            Log::info('Resposta enviada via WhatsApp', [
                'phone' => $phone,
                'message_length' => strlen($message),
                'intent' => $response['intent'] ?? 'unknown'
            ]);

        } catch (\Exception $e) {
            Log::error('Erro ao enviar resposta WhatsApp', [
                'phone' => $phone,
                'error' => $e->getMessage()
            ]);
        }
    }

    /**
     * Processar ações específicas
     */
    private function processActions(string $phone, array $actions, array $response): void
    {
        foreach ($actions as $action) {
            try {
                switch ($action) {
                    case 'show_menu_options':
                        $this->sendMenuOptions($phone);
                        break;

                    case 'show_full_menu':
                        $this->sendFullMenu($phone);
                        break;

                    case 'start_order_session':
                        $this->startOrderSession($phone);
                        break;

                    case 'show_cart':
                        $this->showCart($phone);
                        break;

                    case 'send_order_confirmation':
                        $this->sendOrderConfirmation($phone, $response['order_data'] ?? []);
                        break;

                    case 'create_complaint_ticket':
                        $this->createComplaintTicket($phone, $response);
                        break;

                    case 'show_similar_products':
                        $this->showSimilarProducts($phone, $response['context']['product_id'] ?? null);
                        break;

                    default:
                        Log::info('Ação não implementada', ['action' => $action]);
                }
            } catch (\Exception $e) {
                Log::error('Erro ao processar ação', [
                    'action' => $action,
                    'phone' => $phone,
                    'error' => $e->getMessage()
                ]);
            }
        }
    }

    /**
     * Enviar opções do menu
     */
    private function sendMenuOptions(string $phone): void
    {
        $message = "🍽️ *O que você gostaria de fazer?*\n\n";
        $message .= "📋 Ver cardápio\n";
        $message .= "🛒 Fazer pedido\n";
        $message .= "📦 Status do pedido\n";
        $message .= "🚚 Informações de entrega\n";
        $message .= "💳 Formas de pagamento\n";
        $message .= "❓ Ajuda\n\n";
        $message .= "💡 *Digite uma das opções acima!*";

        $this->whatsAppService->sendMessage($phone, $message);
    }

    /**
     * Enviar cardápio completo
     */
    private function sendFullMenu(string $phone): void
    {
        $categories = \App\Models\Category::with(['products' => function($query) {
            $query->where('available', true)->where('visible', true);
        }])
        ->where('available', true)
        ->where('visible', true)
        ->orderBy('sort_order')
        ->get();

        $message = "📋 *CARDÁPIO COMPLETO*\n\n";

        foreach ($categories as $category) {
            $message .= "🍽️ *{$category->name}*\n";
            
            foreach ($category->products as $product) {
                $price = number_format($product->price, 2, ',', '.');
                $message .= "• {$product->name} - R$ {$price}\n";
                
                if ($product->description) {
                    $message .= "  _{$product->description}_\n";
                }
            }
            
            $message .= "\n";
        }

        $message .= "🛒 *Para pedir:* \"Quero [nome do produto]\"\n";
        $message .= "ℹ️ *Para mais info:* \"Produto [nome]\"\n";
        $message .= "📞 *Dúvidas?* Digite \"ajuda\"";

        $this->whatsAppService->sendMessage($phone, $message);
    }

    /**
     * Iniciar sessão de pedido
     */
    private function startOrderSession(string $phone): void
    {
        $customer = Customer::findByPhone($phone);
        
        if (!$customer) {
            $message = "👋 Para fazer seu primeiro pedido, preciso de algumas informações:\n\n";
            $message .= "📝 *Seu nome completo:*\n";
            $message .= "🏠 *Endereço completo:*\n";
            $message .= "📱 *Telefone:* (já tenho: {$phone})\n\n";
            $message .= "💡 *Digite seu nome primeiro!*";

            $this->whatsAppService->sendMessage($phone, $message);
        } else {
            $message = "🍽️ Perfeito, {$customer->name}! Vamos fazer seu pedido!\n\n";
            $message .= "📋 *Como pedir:*\n";
            $message .= "• \"Quero [produto]\" - Para adicionar\n";
            $message .= "• \"Ver pedido\" - Para revisar\n";
            $message .= "• \"Finalizar\" - Para concluir\n\n";
            $message .= "✨ *Exemplo:* \"Quero 2 Prato do Dia\"";

            $this->whatsAppService->sendMessage($phone, $message);
        }
    }

    /**
     * Mostrar carrinho
     */
    private function showCart(string $phone): void
    {
        $cartService = new \App\Services\AICartService();
        $cart = $cartService->getCart($phone);

        if (empty($cart['items'])) {
            $message = "🛒 *Seu carrinho está vazio*\n\n";
            $message .= "🍽️ Que tal ver nosso cardápio?\n";
            $message .= "💡 Digite \"cardápio\" para ver as opções!";
        } else {
            $message = "🛒 *SEU PEDIDO*\n\n";
            $total = 0;

            foreach ($cart['items'] as $item) {
                $itemTotal = $item['product_price'] * $item['quantity'];
                $total += $itemTotal;
                
                $message .= "🍽️ *{$item['product_name']}*\n";
                $message .= "📦 Qtd: {$item['quantity']}\n";
                $message .= "💰 R$ " . number_format($itemTotal, 2, ',', '.') . "\n\n";
            }

            $message .= "💵 *Total: R$ " . number_format($total, 2, ',', '.') . "*\n\n";
            $message .= "✨ *Para continuar:*\n";
            $message .= "• Adicione mais produtos\n";
            $message .= "• \"Finalizar pedido\"\n";
            $message .= "• \"Remover [produto]\"";
        }

        $this->whatsAppService->sendMessage($phone, $message);
    }

    /**
     * Enviar confirmação do pedido
     */
    private function sendOrderConfirmation(string $phone, array $orderData): void
    {
        if (empty($orderData)) {
            return;
        }

        $message = "🎉 *PEDIDO CONFIRMADO!*\n\n";
        $message .= "🆔 *Pedido:* #{$orderData['order_number']}\n";
        $message .= "💰 *Total:* R$ " . number_format($orderData['total'], 2, ',', '.') . "\n";
        $message .= "📅 *Entrega:* {$orderData['delivery_date']}\n";
        $message .= "🕒 *Horário:* {$orderData['delivery_time_slot']}\n";
        $message .= "💳 *Pagamento:* " . ucfirst($orderData['payment_method']) . "\n\n";
        
        $message .= "📱 *Acompanhe seu pedido:*\n";
        $message .= "• Status será enviado por aqui\n";
        $message .= "• Tempo estimado: 30-60 minutos\n\n";
        $message .= "🙏 *Obrigado por escolher a Olika!*";

        $this->whatsAppService->sendMessage($phone, $message);

        // Enviar notificação para administradores
        $this->notifyAdminNewOrder($orderData);
    }

    /**
     * Criar ticket de reclamação
     */
    private function createComplaintTicket(string $phone, array $response): void
    {
        // TODO: Implementar sistema de tickets
        Log::info('Ticket de reclamação criado', [
            'phone' => $phone,
            'context' => $response['context'] ?? []
        ]);

        $message = "📝 *Reclamação registrada!*\n\n";
        $message .= "✅ Nossa equipe foi notificada\n";
        $message .= "📞 Retornaremos em até 2 horas\n";
        $message .= "🔧 Vamos resolver isso juntos!\n\n";
        $message .= "🙏 Obrigado pela paciência!";

        $this->whatsAppService->sendMessage($phone, $message);
    }

    /**
     * Mostrar produtos similares
     */
    private function showSimilarProducts(string $phone, ?int $productId): void
    {
        if (!$productId) {
            return;
        }

        $product = \App\Models\Product::find($productId);
        if (!$product) {
            return;
        }

        $similarProducts = \App\Models\Product::where('category_id', $product->category_id)
            ->where('id', '!=', $productId)
            ->where('available', true)
            ->where('visible', true)
            ->limit(3)
            ->get();

        if ($similarProducts->isEmpty()) {
            return;
        }

        $message = "🍽️ *PRODUTOS SIMILARES*\n\n";
        $message .= "Que tal tentar estes outros produtos da categoria *{$product->category->name}*?\n\n";

        foreach ($similarProducts as $similarProduct) {
            $price = number_format($similarProduct->price, 2, ',', '.');
            $message .= "• {$similarProduct->name} - R$ {$price}\n";
        }

        $message .= "\n💡 *Para pedir:* \"Quero [nome do produto]\"";

        $this->whatsAppService->sendMessage($phone, $message);
    }

    /**
     * Notificar administradores sobre novo pedido
     */
    private function notifyAdminNewOrder(array $orderData): void
    {
        try {
            $adminMessage = "🆕 *NOVO PEDIDO VIA WHATSAPP IA!*\n\n";
            $adminMessage .= "🆔 *Pedido:* #{$orderData['order_number']}\n";
            $adminMessage .= "👤 *Cliente:* {$orderData['customer_name']}\n";
            $adminMessage .= "📱 *Telefone:* {$orderData['customer_phone']}\n";
            $adminMessage .= "💰 *Total:* R$ " . number_format($orderData['total'], 2, ',', '.') . "\n";
            $adminMessage .= "💳 *Pagamento:* " . ucfirst($orderData['payment_method']) . "\n";
            $adminMessage .= "📅 *Entrega:* {$orderData['delivery_date']} - {$orderData['delivery_time_slot']}\n\n";
            $adminMessage .= "🤖 *Pedido realizado via IA WhatsApp*";

            // TODO: Enviar para número do administrador
            // $this->whatsAppService->sendMessage($adminPhone, $adminMessage);

            Log::info('Notificação de novo pedido enviada', $orderData);

        } catch (\Exception $e) {
            Log::error('Erro ao notificar admin sobre novo pedido', [
                'error' => $e->getMessage(),
                'order_data' => $orderData
            ]);
        }
    }

    /**
     * Endpoint para testar IA (desenvolvimento)
     */
    public function testAI(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'message' => 'required|string',
            'phone' => 'required|string'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Dados inválidos',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $response = $this->aiService->processMessage(
                $request->message,
                $request->phone,
                $request->context ?? []
            );

            return response()->json([
                'success' => true,
                'response' => $response
            ]);

        } catch (\Exception $e) {
            Log::error('Erro no teste de IA', [
                'message' => $request->message,
                'phone' => $request->phone,
                'error' => $e->getMessage()
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Erro interno do servidor'
            ], 500);
        }
    }

    /**
     * Obter estatísticas da IA
     */
    public function getAIStats(): JsonResponse
    {
        try {
            // TODO: Implementar métricas da IA
            $stats = [
                'total_messages_processed' => 0,
                'successful_recognitions' => 0,
                'orders_via_ai' => 0,
                'most_common_intents' => [],
                'accuracy_rate' => 0.0
            ];

            return response()->json([
                'success' => true,
                'stats' => $stats
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Erro ao obter estatísticas'
            ], 500);
        }
    }
}
