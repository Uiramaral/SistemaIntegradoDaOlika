<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\DeliveryFee;
use App\Models\DeliverySchedule;
use App\Models\Settings;
use App\Services\GoogleMapsService;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;

class DeliveryController extends Controller
{
    /**
     * Calcular taxa de entrega por CEP
     */
    public function calculateFee(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'cep' => 'required|string|max:10',
            'subtotal' => 'nullable|numeric|min:0',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'CEP é obrigatório',
                'errors' => $validator->errors()
            ], 422);
        }

        $cep = preg_replace('/\D/', '', $request->cep);
        $subtotal = $request->subtotal ?? 0;

        if (strlen($cep) !== 8) {
            return response()->json([
                'success' => false,
                'message' => 'CEP deve ter 8 dígitos'
            ], 422);
        }

        // Buscar taxa de entrega
        $deliveryFee = DeliveryFee::getFeeByCep($cep);

        // Verificar entrega grátis
        $settings = Settings::getSettings();
        $freeDeliveryThreshold = $settings->free_delivery_threshold ?? 100;

        if ($subtotal >= $freeDeliveryThreshold) {
            $deliveryFee = 0;
            $isFreeDelivery = true;
            $message = 'Entrega grátis!';
        } else {
            $isFreeDelivery = false;
            $remainingAmount = $freeDeliveryThreshold - $subtotal;
            $message = $deliveryFee > 0 ? 'Taxa de entrega calculada' : 'Entrega não disponível';
        }

        return response()->json([
            'success' => true,
            'message' => $message,
            'data' => [
                'cep' => $request->cep,
                'delivery_fee' => $deliveryFee,
                'formatted_delivery_fee' => $deliveryFee > 0 ? 'R$ ' . number_format($deliveryFee, 2, ',', '.') : 'Grátis',
                'is_free_delivery' => $isFreeDelivery,
                'free_delivery_threshold' => $freeDeliveryThreshold,
                'formatted_free_delivery_threshold' => 'R$ ' . number_format($freeDeliveryThreshold, 2, ',', '.'),
                'remaining_for_free_delivery' => $isFreeDelivery ? 0 : $remainingAmount,
                'formatted_remaining_for_free_delivery' => $isFreeDelivery ? 'R$ 0,00' : 'R$ ' . number_format($remainingAmount, 2, ',', '.'),
                'delivery_available' => $deliveryFee !== false,
                'estimated_delivery_time' => $this->getEstimatedDeliveryTime($cep)
            ]
        ]);
    }

    /**
     * Buscar endereço por CEP
     */
    public function getAddressByCep(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'cep' => 'required|string|max:10',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'CEP é obrigatório',
                'errors' => $validator->errors()
            ], 422);
        }

        $cep = preg_replace('/\D/', '', $request->cep);

        if (strlen($cep) !== 8) {
            return response()->json([
                'success' => false,
                'message' => 'CEP deve ter 8 dígitos'
            ], 422);
        }

        try {
            $googleMapsService = new GoogleMapsService();
            
            if (!$googleMapsService->isConfigured()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Serviço de geolocalização não configurado'
                ], 503);
            }

            $address = $googleMapsService->getAddressByCep($cep);

            if (!$address) {
                return response()->json([
                    'success' => false,
                    'message' => 'CEP não encontrado'
                ], 404);
            }

            // Calcular taxa de entrega para o endereço encontrado
            $deliveryFee = DeliveryFee::getFeeByCep($cep);

            return response()->json([
                'success' => true,
                'data' => [
                    'cep' => $request->cep,
                    'street' => $address['street'] ?? '',
                    'neighborhood' => $address['neighborhood'] ?? '',
                    'city' => $address['city'] ?? '',
                    'state' => $address['state'] ?? '',
                    'delivery_fee' => $deliveryFee,
                    'formatted_delivery_fee' => $deliveryFee > 0 ? 'R$ ' . number_format($deliveryFee, 2, ',', '.') : 'Grátis',
                    'delivery_available' => $deliveryFee !== false,
                    'estimated_delivery_time' => $this->getEstimatedDeliveryTime($cep)
                ]
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Erro ao buscar endereço: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Obter datas disponíveis para entrega
     */
    public function getAvailableDates(): JsonResponse
    {
        try {
            $availableDates = DeliverySchedule::getNextAvailableDates(14);

            return response()->json([
                'success' => true,
                'data' => $availableDates
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Erro ao buscar datas disponíveis: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Obter horários disponíveis para uma data
     */
    public function getAvailableTimeSlots(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'date' => 'required|date|after:today',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Data inválida',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $date = Carbon::parse($request->date);
            $availableSlots = DeliverySchedule::getAvailableSlotsForDate($date);

            return response()->json([
                'success' => true,
                'data' => [
                    'date' => $date->format('Y-m-d'),
                    'formatted_date' => $date->format('d/m/Y'),
                    'available_slots' => $availableSlots,
                    'has_delivery' => !empty($availableSlots)
                ]
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Erro ao buscar horários disponíveis: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Verificar disponibilidade de entrega para uma data/hora
     */
    public function checkAvailability(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'date' => 'required|date|after:today',
            'time_slot' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Data e horário são obrigatórios',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $date = Carbon::parse($request->date);
            $timeSlot = $request->time_slot;

            $isAvailable = DeliverySchedule::isSlotAvailable($date, $timeSlot);

            return response()->json([
                'success' => true,
                'data' => [
                    'date' => $date->format('Y-m-d'),
                    'time_slot' => $timeSlot,
                    'is_available' => $isAvailable,
                    'message' => $isAvailable ? 'Horário disponível' : 'Horário não disponível'
                ]
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Erro ao verificar disponibilidade: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Obter configurações de entrega
     */
    public function getDeliverySettings(): JsonResponse
    {
        try {
            $settings = Settings::getSettings();

            return response()->json([
                'success' => true,
                'data' => [
                    'free_delivery_threshold' => $settings->free_delivery_threshold ?? 100,
                    'formatted_free_delivery_threshold' => 'R$ ' . number_format($settings->free_delivery_threshold ?? 100, 2, ',', '.'),
                    'delivery_radius' => $settings->delivery_radius ?? 10,
                    'delivery_preparation_time' => $settings->delivery_preparation_time ?? 30,
                    'delivery_zones' => DeliveryFee::getAllZones(),
                    'business_hours' => [
                        'monday' => $settings->business_hours_monday ?? '08:00-18:00',
                        'tuesday' => $settings->business_hours_tuesday ?? '08:00-18:00',
                        'wednesday' => $settings->business_hours_wednesday ?? '08:00-18:00',
                        'thursday' => $settings->business_hours_thursday ?? '08:00-18:00',
                        'friday' => $settings->business_hours_friday ?? '08:00-18:00',
                        'saturday' => $settings->business_hours_saturday ?? '08:00-16:00',
                        'sunday' => $settings->business_hours_sunday ?? 'Fechado'
                    ]
                ]
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Erro ao buscar configurações: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Calcular tempo estimado de entrega
     */
    public function calculateDeliveryTime(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'cep' => 'required|string|max:10',
            'order_time' => 'nullable|date',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'CEP é obrigatório',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $cep = preg_replace('/\D/', '', $request->cep);
            $orderTime = $request->order_time ? Carbon::parse($request->order_time) : Carbon::now();

            $settings = Settings::getSettings();
            $preparationTime = $settings->delivery_preparation_time ?? 30; // minutos
            
            $estimatedDeliveryTime = $this->getEstimatedDeliveryTime($cep);
            $totalTime = $preparationTime + $estimatedDeliveryTime;

            $deliveryDateTime = $orderTime->copy()->addMinutes($totalTime);

            return response()->json([
                'success' => true,
                'data' => [
                    'cep' => $request->cep,
                    'preparation_time' => $preparationTime,
                    'delivery_time' => $estimatedDeliveryTime,
                    'total_time' => $totalTime,
                    'estimated_delivery_datetime' => $deliveryDateTime->format('Y-m-d H:i:s'),
                    'formatted_delivery_datetime' => $deliveryDateTime->format('d/m/Y H:i'),
                    'delivery_available_today' => $deliveryDateTime->isToday()
                ]
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Erro ao calcular tempo de entrega: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Obter tempo estimado de entrega por CEP
     */
    private function getEstimatedDeliveryTime(string $cep): int
    {
        // Lógica baseada na distância/região do CEP
        $firstDigit = substr($cep, 0, 1);
        
        switch ($firstDigit) {
            case '0':
            case '1':
                return 60; // Centro - 1 hora
            case '2':
            case '3':
                return 75; // Zona Sul - 1h15
            case '4':
            case '5':
                return 90; // Zona Oeste - 1h30
            case '6':
            case '7':
                return 105; // Zona Norte - 1h45
            case '8':
            case '9':
                return 120; // Região Metropolitana - 2 horas
            default:
                return 90; // Padrão - 1h30
        }
    }
}
