@extends('client.layout')

@section('title', 'Carrinho - ' . ($settings->business_name ?? 'Cardápio Digital'))

@section('content')
<div x-data="cartData()" x-init="loadCart()" class="min-h-screen bg-gray-50">
    <!-- Header -->
    <header class="gradient-primary text-white py-6">
        <div class="container mx-auto px-4">
            <div class="flex items-center justify-between">
                <div class="flex items-center gap-4">
                    <a href="/" class="text-white hover:text-white/80">
                        <i data-lucide="arrow-left" class="w-6 h-6"></i>
                    </a>
                    <h1 class="text-2xl font-bold">Carrinho</h1>
                </div>
                <div class="text-white/80">
                    <span id="cart-count" class="bg-white/20 px-3 py-1 rounded-full text-sm">0 itens</span>
                </div>
            </div>
        </div>
    </header>

    <main class="container mx-auto px-4 py-6">
        <div class="max-w-4xl mx-auto">
            <!-- Cart Items -->
            <div x-show="cartItems.length > 0" class="space-y-4 mb-6">
                <template x-for="item in cartItems" :key="item.id">
                    <div class="bg-white rounded-lg shadow-sm border p-4">
                        <div class="flex items-center gap-4">
                            <div class="w-16 h-16 bg-gray-100 rounded-lg overflow-hidden flex-shrink-0">
                                <img 
                                    :src="item.image || '/images/placeholder-product.jpg'" 
                                    :alt="item.name"
                                    class="w-full h-full object-cover"
                                >
                            </div>
                            
                            <div class="flex-1">
                                <h3 class="font-semibold text-gray-900" x-text="item.name"></h3>
                                <p class="text-sm text-gray-600" x-text="item.description"></p>
                                <p class="text-lg font-bold text-blue-600" x-text="formatCurrency(item.price)"></p>
                            </div>
                            
                            <div class="flex items-center gap-3">
                                <div class="flex items-center border rounded-lg">
                                    <button @click="updateQuantity(item.id, item.quantity - 1)" class="px-3 py-1 hover:bg-gray-100">-</button>
                                    <span class="px-4 py-1" x-text="item.quantity"></span>
                                    <button @click="updateQuantity(item.id, item.quantity + 1)" class="px-3 py-1 hover:bg-gray-100">+</button>
                                </div>
                                
                                <button @click="removeItem(item.id)" class="text-red-500 hover:text-red-700">
                                    <i data-lucide="trash-2" class="w-5 h-5"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </template>
            </div>

            <!-- Empty Cart -->
            <div x-show="cartItems.length === 0" class="text-center py-12">
                <i data-lucide="shopping-cart" class="w-16 h-16 mx-auto mb-4 text-gray-300"></i>
                <h2 class="text-xl font-semibold text-gray-900 mb-2">Seu carrinho está vazio</h2>
                <p class="text-gray-600 mb-6">Adicione alguns produtos para começar seu pedido</p>
                <a href="/" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-medium transition-colors">
                    Ver Cardápio
                </a>
            </div>

            <!-- Coupon Section -->
            <div x-show="cartItems.length > 0" class="bg-white rounded-lg shadow-sm border p-4 mb-6">
                <h3 class="font-semibold text-gray-900 mb-3">Cupom de Desconto</h3>
                <div class="flex gap-2">
                    <input 
                        x-model="couponCode" 
                        type="text" 
                        placeholder="Digite o código do cupom"
                        class="flex-1 border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                    <button 
                        @click="applyCoupon()"
                        :disabled="!couponCode || isApplyingCoupon"
                        class="bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white px-4 py-2 rounded-lg font-medium transition-colors"
                    >
                        <span x-show="!isApplyingCoupon">Aplicar</span>
                        <span x-show="isApplyingCoupon">Aplicando...</span>
                    </button>
                </div>
                
                <div x-show="appliedCoupon" class="mt-3 p-3 bg-green-50 border border-green-200 rounded-lg">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm font-medium text-green-800">
                                Cupom aplicado: <span x-text="appliedCoupon.code"></span>
                            </p>
                            <p class="text-sm text-green-600">
                                Desconto: <span x-text="formatCurrency(appliedCoupon.discount)"></span>
                            </p>
                        </div>
                        <button @click="removeCoupon()" class="text-green-600 hover:text-green-800">
                            <i data-lucide="x" class="w-4 h-4"></i>
                        </button>
                    </div>
                </div>
            </div>

            <!-- Order Summary -->
            <div x-show="cartItems.length > 0" class="bg-white rounded-lg shadow-sm border p-6">
                <h3 class="text-lg font-semibold text-gray-900 mb-4">Resumo do Pedido</h3>
                
                <div class="space-y-2 mb-4">
                    <div class="flex justify-between">
                        <span class="text-gray-600">Subtotal</span>
                        <span x-text="formatCurrency(subtotal)"></span>
                    </div>
                    
                    <div x-show="appliedCoupon" class="flex justify-between text-green-600">
                        <span>Desconto</span>
                        <span x-text="'-' + formatCurrency(appliedCoupon.discount)"></span>
                    </div>
                    
                    <div class="border-t pt-2">
                        <div class="flex justify-between text-lg font-bold">
                            <span>Total</span>
                            <span class="text-blue-600" x-text="formatCurrency(total)"></span>
                        </div>
                    </div>
                </div>
                
                <div class="space-y-3">
                    <a 
                        href="/checkout"
                        class="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg font-medium transition-colors text-center block"
                    >
                        Finalizar Pedido
                    </a>
                    
                    <a 
                        href="/"
                        class="w-full border border-gray-300 hover:bg-gray-50 text-gray-700 py-3 rounded-lg font-medium transition-colors text-center block"
                    >
                        Continuar Comprando
                    </a>
                </div>
            </div>
        </div>
    </main>
</div>

@push('scripts')
<script>
function cartData() {
    return {
        cartItems: [],
        couponCode: '',
        appliedCoupon: null,
        isApplyingCoupon: false,
        subtotal: 0,
        total: 0,
        
        async loadCart() {
            try {
                const response = await axios.get('/api/client/cart/');
                if (response.data.success) {
                    this.cartItems = response.data.data.items;
                    this.subtotal = response.data.data.subtotal;
                    this.total = this.subtotal - (this.appliedCoupon?.discount || 0);
                    this.updateCartCount();
                }
            } catch (error) {
                console.error('Erro ao carregar carrinho:', error);
            }
            
            lucide.createIcons();
        },
        
        async updateQuantity(productId, newQuantity) {
            if (newQuantity < 1) return;
            
            try {
                const response = await axios.put('/api/client/cart/update', {
                    product_id: productId,
                    quantity: newQuantity
                });
                
                if (response.data.success) {
                    const item = this.cartItems.find(i => i.id === productId);
                    if (item) {
                        item.quantity = newQuantity;
                    }
                    this.calculateTotals();
                }
            } catch (error) {
                showToast('Erro ao atualizar quantidade', 'error');
            }
        },
        
        async removeItem(productId) {
            try {
                const response = await axios.delete('/api/client/cart/remove', {
                    data: { product_id: productId }
                });
                
                if (response.data.success) {
                    this.cartItems = this.cartItems.filter(i => i.id !== productId);
                    this.calculateTotals();
                    showToast('Produto removido do carrinho', 'success');
                }
            } catch (error) {
                showToast('Erro ao remover produto', 'error');
            }
        },
        
        async applyCoupon() {
            if (!this.couponCode) return;
            
            this.isApplyingCoupon = true;
            
            try {
                const response = await axios.post('/api/client/cart/apply-coupon', {
                    coupon_code: this.couponCode
                });
                
                if (response.data.success) {
                    this.appliedCoupon = response.data.data.coupon;
                    this.appliedCoupon.discount = response.data.data.discount;
                    this.calculateTotals();
                    showToast('Cupom aplicado com sucesso!', 'success');
                    this.couponCode = '';
                } else {
                    showToast(response.data.message, 'error');
                }
            } catch (error) {
                showToast('Erro ao aplicar cupom', 'error');
            } finally {
                this.isApplyingCoupon = false;
            }
        },
        
        async removeCoupon() {
            try {
                const response = await axios.delete('/api/client/cart/remove-coupon');
                
                if (response.data.success) {
                    this.appliedCoupon = null;
                    this.calculateTotals();
                    showToast('Cupom removido', 'success');
                }
            } catch (error) {
                showToast('Erro ao remover cupom', 'error');
            }
        },
        
        calculateTotals() {
            this.subtotal = this.cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
            this.total = this.subtotal - (this.appliedCoupon?.discount || 0);
            this.updateCartCount();
        },
        
        updateCartCount() {
            const count = this.cartItems.reduce((sum, item) => sum + item.quantity, 0);
            const cartCountElement = document.getElementById('cart-count');
            if (cartCountElement) {
                cartCountElement.textContent = `${count} ${count === 1 ? 'item' : 'itens'}`;
            }
        },
        
        formatCurrency(value) {
            return new Intl.NumberFormat('pt-BR', {
                style: 'currency',
                currency: 'BRL'
            }).format(value);
        }
    }
}
</script>
@endpush
@endsection
