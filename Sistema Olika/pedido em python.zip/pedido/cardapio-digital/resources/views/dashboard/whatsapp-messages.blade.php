@extends('dashboard.layout-complete')

@section('title', 'Mensagens WhatsApp - Cardápio Digital Olika')

@section('content')
<div class="min-h-screen bg-gray-50">
    <!-- Header -->
    <div class="bg-white shadow-sm border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-6">
                <div>
                    <h1 class="text-2xl font-bold text-gray-900">Mensagens WhatsApp</h1>
                    <p class="text-sm text-gray-600">Visualize e gerencie mensagens enviadas e recebidas</p>
                </div>
                <div class="flex space-x-3">
                    <button id="sendMessageBtn" class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                        <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"></path>
                        </svg>
                        Enviar Mensagem
                    </button>
                    <button id="refreshMessages" class="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                        <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path>
                        </svg>
                        Atualizar
                    </button>
                </div>
            </div>
        </div>
    </div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <!-- Estatísticas -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div class="bg-white rounded-lg shadow p-6">
                <div class="flex items-center">
                    <div class="flex-shrink-0">
                        <div class="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                            <svg class="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"></path>
                            </svg>
                        </div>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm font-medium text-gray-500">Enviadas</p>
                        <p id="messagesSent" class="text-2xl font-semibold text-gray-900">0</p>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow p-6">
                <div class="flex items-center">
                    <div class="flex-shrink-0">
                        <div class="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                            <svg class="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"></path>
                            </svg>
                        </div>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm font-medium text-gray-500">Recebidas</p>
                        <p id="messagesReceived" class="text-2xl font-semibold text-gray-900">0</p>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow p-6">
                <div class="flex items-center">
                    <div class="flex-shrink-0">
                        <div class="w-8 h-8 bg-yellow-100 rounded-full flex items-center justify-center">
                            <svg class="w-5 h-5 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                            </svg>
                        </div>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm font-medium text-gray-500">Na Fila</p>
                        <p id="messagesQueued" class="text-2xl font-semibold text-gray-900">0</p>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow p-6">
                <div class="flex items-center">
                    <div class="flex-shrink-0">
                        <div class="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center">
                            <svg class="w-5 h-5 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z"></path>
                            </svg>
                        </div>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm font-medium text-gray-500">Falharam</p>
                        <p id="messagesFailed" class="text-2xl font-semibold text-gray-900">0</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Filtros -->
        <div class="bg-white rounded-lg shadow mb-6">
            <div class="px-6 py-4 border-b border-gray-200">
                <h3 class="text-lg font-medium text-gray-900">Filtros</h3>
            </div>
            <div class="p-6">
                <div class="grid grid-cols-1 md:grid-cols-6 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Direção</label>
                        <select id="directionFilter" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                            <option value="">Todas</option>
                            <option value="IN">Recebidas</option>
                            <option value="OUT">Enviadas</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Status</label>
                        <select id="statusFilter" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                            <option value="">Todos</option>
                            <option value="queued">Na Fila</option>
                            <option value="sent">Enviado</option>
                            <option value="delivered">Entregue</option>
                            <option value="read">Lido</option>
                            <option value="failed">Falhou</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Tipo</label>
                        <select id="typeFilter" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                            <option value="">Todos</option>
                            <option value="text">Texto</option>
                            <option value="image">Imagem</option>
                            <option value="file">Arquivo</option>
                            <option value="template">Template</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Período</label>
                        <select id="periodFilter" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                            <option value="">Todos</option>
                            <option value="today">Hoje</option>
                            <option value="week">Esta semana</option>
                            <option value="month">Este mês</option>
                            <option value="custom">Personalizado</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Buscar</label>
                        <input type="text" id="searchFilter" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" placeholder="Número ou conteúdo...">
                    </div>
                    <div class="flex items-end">
                        <button id="applyFilters" class="w-full inline-flex justify-center items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                            Aplicar
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Lista de Mensagens -->
        <div class="bg-white rounded-lg shadow">
            <div class="px-6 py-4 border-b border-gray-200">
                <div class="flex justify-between items-center">
                    <h3 class="text-lg font-medium text-gray-900">Mensagens</h3>
                    <div class="flex items-center space-x-2">
                        <span id="messagesCount" class="text-sm text-gray-500">0 mensagens</span>
                        <div class="flex items-center space-x-1">
                            <button id="viewModeList" class="p-2 text-gray-400 hover:text-gray-600 ${viewMode === 'list' ? 'text-blue-600' : ''}">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 10h16M4 14h16M4 18h16"></path>
                                </svg>
                            </button>
                            <button id="viewModeChat" class="p-2 text-gray-400 hover:text-gray-600 ${viewMode === 'chat' ? 'text-blue-600' : ''}">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"></path>
                                </svg>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <div id="messagesContainer" class="max-h-96 overflow-y-auto">
                <!-- Mensagens serão carregadas aqui -->
            </div>
        </div>

        <!-- Paginação -->
        <div id="pagination" class="mt-6 flex items-center justify-between">
            <!-- Paginação será inserida aqui -->
        </div>
    </div>
</div>

<!-- Modal de Enviar Mensagem -->
<div id="sendMessageModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50" style="display: none;">
    <div class="relative top-20 mx-auto p-5 border w-full max-w-lg shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <div class="flex items-center justify-between mb-4">
                <h3 class="text-lg font-medium text-gray-900">Enviar Mensagem</h3>
                <button id="closeSendModal" class="text-gray-400 hover:text-gray-600">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                </button>
            </div>
            <form id="sendMessageForm">
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Número do Destinatário *</label>
                        <input type="tel" id="recipientPhone" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" placeholder="5511999999999" required>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Tipo de Mensagem</label>
                        <select id="messageType" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                            <option value="text">Texto</option>
                            <option value="template">Template</option>
                        </select>
                    </div>
                    <div id="textMessageDiv">
                        <label class="block text-sm font-medium text-gray-700 mb-2">Mensagem *</label>
                        <textarea id="messageText" rows="4" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" placeholder="Digite sua mensagem..." required></textarea>
                    </div>
                    <div id="templateMessageDiv" style="display: none;">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Nome do Template</label>
                            <input type="text" id="templateName" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" placeholder="Ex: order_confirmed_v1">
                        </div>
                        <div class="mt-4">
                            <label class="block text-sm font-medium text-gray-700 mb-2">Variáveis (JSON)</label>
                            <textarea id="templateVars" rows="3" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" placeholder='{"nome": "João", "pedido": "#123"}'></textarea>
                        </div>
                    </div>
                </div>

                <div class="flex justify-end space-x-3 mt-6">
                    <button type="button" id="sendMessage" class="px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                        Enviar
                    </button>
                    <button type="button" id="cancelSend" class="px-4 py-2 bg-gray-300 text-gray-700 text-sm font-medium rounded-md hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500">
                        Cancelar
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Elementos DOM
    const sendMessageBtn = document.getElementById('sendMessageBtn');
    const sendMessageModal = document.getElementById('sendMessageModal');
    const closeSendModal = document.getElementById('closeSendModal');
    const sendMessageForm = document.getElementById('sendMessageForm');
    const sendMessage = document.getElementById('sendMessage');
    const cancelSend = document.getElementById('cancelSend');
    const messagesContainer = document.getElementById('messagesContainer');
    const refreshMessages = document.getElementById('refreshMessages');
    const applyFilters = document.getElementById('applyFilters');
    const messageType = document.getElementById('messageType');
    const textMessageDiv = document.getElementById('textMessageDiv');
    const templateMessageDiv = document.getElementById('templateMessageDiv');
    const viewModeList = document.getElementById('viewModeList');
    const viewModeChat = document.getElementById('viewModeChat');

    // Variáveis
    let messages = [];
    let currentPage = 1;
    let totalPages = 1;
    let viewMode = 'list';

    // Inicializar
    loadMessages();
    loadStats();

    // Event Listeners
    sendMessageBtn.addEventListener('click', () => openSendModal());
    closeSendModal.addEventListener('click', () => closeModal());
    sendMessage.addEventListener('click', sendMessageData);
    cancelSend.addEventListener('click', closeModal);
    refreshMessages.addEventListener('click', loadMessages);
    applyFilters.addEventListener('click', applyFiltersToMessages);
    messageType.addEventListener('change', toggleMessageType);
    viewModeList.addEventListener('click', () => setViewMode('list'));
    viewModeChat.addEventListener('click', () => setViewMode('chat'));

    // Fechar modal ao clicar fora
    window.addEventListener('click', function(event) {
        if (event.target === sendMessageModal) {
            closeModal();
        }
    });

    function openSendModal() {
        sendMessageModal.style.display = 'block';
        messageType.value = 'text';
        toggleMessageType();
    }

    function closeModal() {
        sendMessageModal.style.display = 'none';
        sendMessageForm.reset();
    }

    function toggleMessageType() {
        const type = messageType.value;
        if (type === 'text') {
            textMessageDiv.style.display = 'block';
            templateMessageDiv.style.display = 'none';
            document.getElementById('messageText').required = true;
            document.getElementById('templateName').required = false;
        } else {
            textMessageDiv.style.display = 'none';
            templateMessageDiv.style.display = 'block';
            document.getElementById('messageText').required = false;
            document.getElementById('templateName').required = true;
        }
    }

    function sendMessageData() {
        const phone = document.getElementById('recipientPhone').value.trim();
        const type = document.getElementById('messageType').value;
        const text = document.getElementById('messageText').value.trim();
        const templateName = document.getElementById('templateName').value.trim();
        const templateVars = document.getElementById('templateVars').value.trim();

        if (!phone) {
            alert('Por favor, insira o número do destinatário');
            return;
        }

        if (type === 'text' && !text) {
            alert('Por favor, digite a mensagem');
            return;
        }

        if (type === 'template' && !templateName) {
            alert('Por favor, insira o nome do template');
            return;
        }

        const formData = {
            to: phone,
            type: type,
            text: text,
            template_name: templateName,
            template_vars: templateVars ? JSON.parse(templateVars) : {}
        };

        sendMessage.disabled = true;
        sendMessage.textContent = 'Enviando...';

        fetch('/api/whatsapp/send', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
            },
            body: JSON.stringify(formData)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                closeModal();
                loadMessages();
                showNotification('Mensagem enviada com sucesso!', 'success');
            } else {
                alert('Erro ao enviar mensagem: ' + (data.message || data.error));
            }
        })
        .catch(error => {
            console.error('Erro:', error);
            alert('Erro ao enviar mensagem');
        })
        .finally(() => {
            sendMessage.disabled = false;
            sendMessage.textContent = 'Enviar';
        });
    }

    function loadMessages(page = 1) {
        const directionFilter = document.getElementById('directionFilter').value;
        const statusFilter = document.getElementById('statusFilter').value;
        const typeFilter = document.getElementById('typeFilter').value;
        const periodFilter = document.getElementById('periodFilter').value;
        const searchFilter = document.getElementById('searchFilter').value;

        let url = `/api/whatsapp/messages?loja_id=1&page=${page}`;
        
        if (directionFilter) url += `&direction=${directionFilter}`;
        if (statusFilter) url += `&status=${statusFilter}`;
        if (typeFilter) url += `&type=${typeFilter}`;
        if (periodFilter) url += `&period=${periodFilter}`;
        if (searchFilter) url += `&search=${encodeURIComponent(searchFilter)}`;

        fetch(url)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                messages = data.messages.data || data.messages;
                currentPage = data.messages.current_page || 1;
                totalPages = data.messages.last_page || 1;
                displayMessages(messages);
                updateMessagesCount(messages.length);
                updatePagination();
            }
        })
        .catch(error => {
            console.error('Erro ao carregar mensagens:', error);
        });
    }

    function displayMessages(messagesToShow) {
        if (messagesToShow.length === 0) {
            messagesContainer.innerHTML = `
                <div class="p-8 text-center text-gray-500">
                    <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"></path>
                    </svg>
                    <h3 class="mt-2 text-sm font-medium text-gray-900">Nenhuma mensagem encontrada</h3>
                    <p class="mt-1 text-sm text-gray-500">Comece enviando uma mensagem.</p>
                </div>
            `;
            return;
        }

        if (viewMode === 'list') {
            displayMessagesList(messagesToShow);
        } else {
            displayMessagesChat(messagesToShow);
        }
    }

    function displayMessagesList(messagesToShow) {
        messagesContainer.innerHTML = messagesToShow.map(message => `
            <div class="p-4 hover:bg-gray-50 border-b border-gray-200">
                <div class="flex items-start space-x-3">
                    <div class="flex-shrink-0">
                        <div class="w-8 h-8 rounded-full ${message.direction === 'IN' ? 'bg-green-100' : 'bg-blue-100'} flex items-center justify-center">
                            <span class="text-xs font-medium ${message.direction === 'IN' ? 'text-green-600' : 'text-blue-600'}">
                                ${message.direction === 'IN' ? 'IN' : 'OUT'}
                            </span>
                        </div>
                    </div>
                    <div class="flex-1 min-w-0">
                        <div class="flex items-center justify-between">
                            <p class="text-sm font-medium text-gray-900">${formatPhone(message.peer)}</p>
                            <p class="text-xs text-gray-500">${new Date(message.created_at).toLocaleString()}</p>
                        </div>
                        <p class="text-sm text-gray-600 mt-1">${message.body_text || message.content || '-'}</p>
                        <div class="flex items-center mt-2 space-x-2">
                            <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(message.status)}">
                                ${getStatusText(message.status)}
                            </span>
                            <span class="text-xs text-gray-500">${message.type}</span>
                            ${message.template_name ? `<span class="text-xs text-gray-500">Template: ${message.template_name}</span>` : ''}
                        </div>
                    </div>
                </div>
            </div>
        `).join('');
    }

    function displayMessagesChat(messagesToShow) {
        // Agrupar mensagens por telefone
        const groupedMessages = messagesToShow.reduce((groups, message) => {
            const phone = message.peer;
            if (!groups[phone]) {
                groups[phone] = [];
            }
            groups[phone].push(message);
            return groups;
        }, {});

        messagesContainer.innerHTML = Object.keys(groupedMessages).map(phone => {
            const phoneMessages = groupedMessages[phone].sort((a, b) => new Date(a.created_at) - new Date(b.created_at));
            return `
                <div class="border-b border-gray-200">
                    <div class="p-4 bg-gray-50">
                        <h4 class="text-sm font-medium text-gray-900">${formatPhone(phone)}</h4>
                        <p class="text-xs text-gray-500">${phoneMessages.length} mensagem${phoneMessages.length !== 1 ? 's' : ''}</p>
                    </div>
                    <div class="p-4 space-y-3">
                        ${phoneMessages.map(message => `
                            <div class="flex ${message.direction === 'OUT' ? 'justify-end' : 'justify-start'}">
                                <div class="max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${message.direction === 'OUT' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-900'}">
                                    <p class="text-sm">${message.body_text || message.content || '-'}</p>
                                    <p class="text-xs ${message.direction === 'OUT' ? 'text-blue-100' : 'text-gray-500'} mt-1">
                                        ${new Date(message.created_at).toLocaleTimeString()}
                                        ${message.status !== 'delivered' ? ` • ${getStatusText(message.status)}` : ''}
                                    </p>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            `;
        }).join('');
    }

    function formatPhone(phone) {
        const cleaned = phone.replace(/\D/g, '');
        if (cleaned.length === 13) {
            return `+${cleaned.slice(0, 2)} (${cleaned.slice(2, 4)}) ${cleaned.slice(4, 9)}-${cleaned.slice(9)}`;
        }
        return phone;
    }

    function getStatusColor(status) {
        const colors = {
            'queued': 'bg-yellow-100 text-yellow-800',
            'sent': 'bg-blue-100 text-blue-800',
            'delivered': 'bg-green-100 text-green-800',
            'read': 'bg-purple-100 text-purple-800',
            'failed': 'bg-red-100 text-red-800'
        };
        return colors[status] || 'bg-gray-100 text-gray-800';
    }

    function getStatusText(status) {
        const texts = {
            'queued': 'Na fila',
            'sent': 'Enviado',
            'delivered': 'Entregue',
            'read': 'Lido',
            'failed': 'Falhou'
        };
        return texts[status] || status;
    }

    function setViewMode(mode) {
        viewMode = mode;
        viewModeList.className = `p-2 text-gray-400 hover:text-gray-600 ${mode === 'list' ? 'text-blue-600' : ''}`;
        viewModeChat.className = `p-2 text-gray-400 hover:text-gray-600 ${mode === 'chat' ? 'text-blue-600' : ''}`;
        displayMessages(messages);
    }

    function updateMessagesCount(count) {
        document.getElementById('messagesCount').textContent = `${count} mensagem${count !== 1 ? 's' : ''}`;
    }

    function updatePagination() {
        const pagination = document.getElementById('pagination');
        if (totalPages <= 1) {
            pagination.innerHTML = '';
            return;
        }

        let paginationHTML = '<div class="flex items-center justify-between"><div class="flex-1 flex justify-between sm:hidden">';
        
        if (currentPage > 1) {
            paginationHTML += `<button onclick="loadMessages(${currentPage - 1})" class="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">Anterior</button>`;
        }
        
        if (currentPage < totalPages) {
            paginationHTML += `<button onclick="loadMessages(${currentPage + 1})" class="ml-3 relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">Próximo</button>`;
        }
        
        paginationHTML += '</div><div class="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">';
        paginationHTML += `<div><p class="text-sm text-gray-700">Página <span class="font-medium">${currentPage}</span> de <span class="font-medium">${totalPages}</span></p></div>`;
        paginationHTML += '<div><nav class="relative z-0 inline-flex rounded-md shadow-sm -space-x-px">';
        
        for (let i = 1; i <= totalPages; i++) {
            if (i === currentPage) {
                paginationHTML += `<span class="relative inline-flex items-center px-4 py-2 border border-blue-500 bg-blue-50 text-sm font-medium text-blue-600">${i}</span>`;
            } else {
                paginationHTML += `<button onclick="loadMessages(${i})" class="relative inline-flex items-center px-4 py-2 border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50">${i}</button>`;
            }
        }
        
        paginationHTML += '</nav></div></div></div>';
        pagination.innerHTML = paginationHTML;
    }

    function applyFiltersToMessages() {
        loadMessages(1);
    }

    function loadStats() {
        fetch('/api/whatsapp/messages/stats?loja_id=1')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const stats = data.stats;
                document.getElementById('messagesSent').textContent = stats.sent || 0;
                document.getElementById('messagesReceived').textContent = stats.received || 0;
                document.getElementById('messagesQueued').textContent = stats.queued || 0;
                document.getElementById('messagesFailed').textContent = stats.failed || 0;
            }
        })
        .catch(error => {
            console.error('Erro ao carregar estatísticas:', error);
        });
    }

    function showNotification(message, type = 'info') {
        alert(message);
    }

    // Tornar funções globais para uso nos botões
    window.loadMessages = loadMessages;
});
</script>
@endsection
