@props([])

<div {{ $attributes->merge(['class' => 'space-y-2']) }}>
    {{ $slot }}
</div>

