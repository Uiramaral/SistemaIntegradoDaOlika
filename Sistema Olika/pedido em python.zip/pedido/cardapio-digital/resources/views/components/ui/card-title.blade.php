@props([])

<h3 {{ $attributes->merge(['class' => 'text-2xl font-semibold leading-none tracking-tight']) }}>
    {{ $slot }}
</h3>

