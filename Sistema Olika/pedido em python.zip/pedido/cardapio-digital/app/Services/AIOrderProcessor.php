<?php

namespace App\Services;

use App\Models\Customer;
use App\Models\Product;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Settings;
use App\Models\DeliveryFee;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Cache;

class AIOrderProcessor
{
    private $cartService;
    private $deliveryService;
    private $paymentService;

    public function __construct()
    {
        $this->cartService = new AICartService();
        $this->deliveryService = new DeliveryService();
        $this->paymentService = new MercadoPagoService();
    }

    /**
     * Adicionar item ao carrinho via IA
     */
    public function addToCart(string $phone, int $productId, int $quantity = 1, array $context = []): array
    {
        try {
            DB::beginTransaction();

            // Buscar ou criar cliente
            $customer = Customer::findByPhone($phone);
            if (!$customer) {
                // Criar cliente temporário para o pedido
                $customer = $this->createTemporaryCustomer($phone, $context);
            }

            // Buscar produto
            $product = Product::find($productId);
            if (!$product || !$product->available) {
                throw new \Exception('Produto não disponível');
            }

            // Adicionar ao carrinho
            $cartKey = "ai_cart_{$phone}";
            $cart = Cache::get($cartKey, []);

            $itemKey = $productId;
            if (isset($cart[$itemKey])) {
                $cart[$itemKey]['quantity'] += $quantity;
            } else {
                $cart[$itemKey] = [
                    'product_id' => $productId,
                    'product_name' => $product->name,
                    'product_price' => $product->price,
                    'quantity' => $quantity,
                    'added_at' => now()->toISOString()
                ];
            }

            Cache::put($cartKey, $cart, 3600); // 1 hora

            // Calcular total
            $total = $this->calculateCartTotal($cart);

            DB::commit();

            return [
                'success' => true,
                'cart' => $cart,
                'cart_total' => $total,
                'customer' => $customer
            ];

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Erro ao adicionar item ao carrinho via IA', [
                'phone' => $phone,
                'product_id' => $productId,
                'error' => $e->getMessage()
            ]);

            return [
                'success' => false,
                'message' => 'Erro ao adicionar produto ao carrinho'
            ];
        }
    }

    /**
     * Remover item do carrinho
     */
    public function removeFromCart(string $phone, int $productId): array
    {
        try {
            $cartKey = "ai_cart_{$phone}";
            $cart = Cache::get($cartKey, []);

            if (isset($cart[$productId])) {
                unset($cart[$productId]);
                Cache::put($cartKey, $cart, 3600);

                $total = $this->calculateCartTotal($cart);

                return [
                    'success' => true,
                    'cart' => $cart,
                    'cart_total' => $total
                ];
            }

            return [
                'success' => false,
                'message' => 'Produto não encontrado no carrinho'
            ];

        } catch (\Exception $e) {
            Log::error('Erro ao remover item do carrinho', [
                'phone' => $phone,
                'product_id' => $productId,
                'error' => $e->getMessage()
            ]);

            return [
                'success' => false,
                'message' => 'Erro ao remover produto do carrinho'
            ];
        }
    }

    /**
     * Obter carrinho atual
     */
    public function getCart(string $phone): array
    {
        $cartKey = "ai_cart_{$phone}";
        $cart = Cache::get($cartKey, []);

        return [
            'items' => array_values($cart),
            'total' => $this->calculateCartTotal($cart),
            'item_count' => array_sum(array_column($cart, 'quantity'))
        ];
    }

    /**
     * Finalizar pedido via IA
     */
    public function completeOrder(string $phone, array $intent, array $context): array
    {
        try {
            DB::beginTransaction();

            // Buscar cliente
            $customer = Customer::findByPhone($phone);
            if (!$customer) {
                throw new \Exception('Cliente não encontrado');
            }

            // Buscar carrinho
            $cartKey = "ai_cart_{$phone}";
            $cart = Cache::get($cartKey, []);

            if (empty($cart)) {
                throw new \Exception('Carrinho vazio');
            }

            // Processar dados do pedido
            $orderData = $this->processOrderData($intent, $context, $customer);

            // Criar pedido
            $order = $this->createOrder($customer, $cart, $orderData);

            // Limpar carrinho
            Cache::forget($cartKey);

            // Processar pagamento se necessário
            if ($orderData['payment_method'] !== 'cash') {
                $paymentResult = $this->processPayment($order, $orderData);
                if (!$paymentResult['success']) {
                    throw new \Exception($paymentResult['message']);
                }
            }

            DB::commit();

            return [
                'success' => true,
                'order' => $order,
                'message' => 'Pedido realizado com sucesso'
            ];

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Erro ao finalizar pedido via IA', [
                'phone' => $phone,
                'error' => $e->getMessage(),
                'context' => $context
            ]);

            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }

    /**
     * Criar cliente temporário
     */
    private function createTemporaryCustomer(string $phone, array $context): Customer
    {
        $customerData = [
            'name' => $context['customer_name'] ?? 'Cliente WhatsApp',
            'phone' => preg_replace('/\D/', '', $phone),
            'email' => $context['customer_email'] ?? null,
            'loyalty_points' => 0,
            'order_count' => 0,
            'total_spent' => 0,
        ];

        return Customer::create($customerData);
    }

    /**
     * Calcular total do carrinho
     */
    private function calculateCartTotal(array $cart): float
    {
        $total = 0;
        foreach ($cart as $item) {
            $total += $item['product_price'] * $item['quantity'];
        }
        return $total;
    }

    /**
     * Processar dados do pedido
     */
    private function processOrderData(array $intent, array $context, Customer $customer): array
    {
        $entities = $intent['entities'] ?? [];
        
        // Método de pagamento
        $paymentMethod = $this->extractPaymentMethod($intent['original_message'] ?? '', $entities);
        
        // Data e horário de entrega
        $deliveryData = $this->extractDeliveryData($entities, $context);
        
        // Endereço de entrega
        $deliveryAddress = $this->extractDeliveryAddress($entities, $context, $customer);

        return [
            'payment_method' => $paymentMethod,
            'delivery_date' => $deliveryData['date'],
            'delivery_time_slot' => $deliveryData['time_slot'],
            'delivery_address' => $deliveryAddress,
            'notes' => $this->extractOrderNotes($intent['original_message'] ?? ''),
            'coupon_code' => $entities['coupon'] ?? null
        ];
    }

    /**
     * Extrair método de pagamento
     */
    private function extractPaymentMethod(string $message, array $entities): string
    {
        $message = strtolower($message);
        
        if (strpos($message, 'pix') !== false) {
            return 'pix';
        }
        
        if (strpos($message, 'cartão') !== false || strpos($message, 'cartao') !== false) {
            return 'credit_card';
        }
        
        if (strpos($message, 'dinheiro') !== false || strpos($message, 'na entrega') !== false) {
            return 'cash';
        }
        
        if (strpos($message, 'mercado pago') !== false) {
            return 'mercadopago';
        }
        
        // Padrão: dinheiro na entrega
        return 'cash';
    }

    /**
     * Extrair dados de entrega
     */
    private function extractDeliveryData(array $entities, array $context): array
    {
        $date = $context['delivery_date'] ?? now()->addDay()->format('Y-m-d');
        $timeSlot = $context['delivery_time_slot'] ?? '18:00-19:00';
        
        // Se menciona data específica na mensagem
        if (isset($entities['date'])) {
            $date = $entities['date'];
        }
        
        // Se menciona horário específico
        if (isset($entities['time'])) {
            $timeSlot = $entities['time'];
        }
        
        return [
            'date' => $date,
            'time_slot' => $timeSlot
        ];
    }

    /**
     * Extrair endereço de entrega
     */
    private function extractDeliveryAddress(array $entities, array $context, Customer $customer): array
    {
        // Se cliente já tem endereço cadastrado
        if ($customer->street && $customer->cep) {
            return [
                'cep' => $customer->cep,
                'street' => $customer->street,
                'number' => $customer->number,
                'complement' => $customer->complement,
                'neighborhood' => $customer->neighborhood,
                'city' => $customer->city,
                'state' => $customer->state,
                'reference' => $customer->reference
            ];
        }
        
        // Extrair do contexto da conversa
        if (isset($context['delivery_address'])) {
            return $context['delivery_address'];
        }
        
        // Extrair CEP se mencionado
        if (isset($entities['cep'])) {
            return [
                'cep' => $entities['cep'],
                'street' => $context['street'] ?? null,
                'number' => $context['number'] ?? null,
                'complement' => $context['complement'] ?? null,
                'neighborhood' => $context['neighborhood'] ?? null,
                'city' => $context['city'] ?? null,
                'state' => $context['state'] ?? null,
                'reference' => $context['reference'] ?? null
            ];
        }
        
        // Endereço padrão (será solicitado posteriormente)
        return [
            'cep' => null,
            'street' => null,
            'number' => null,
            'complement' => null,
            'neighborhood' => null,
            'city' => null,
            'state' => null,
            'reference' => null
        ];
    }

    /**
     * Extrair observações do pedido
     */
    private function extractOrderNotes(string $message): ?string
    {
        $notes = [];
        
        // Extrair observações comuns
        if (strpos($message, 'sem cebola') !== false) {
            $notes[] = 'Sem cebola';
        }
        
        if (strpos($message, 'sem pimenta') !== false) {
            $notes[] = 'Sem pimenta';
        }
        
        if (strpos($message, 'bem temperado') !== false) {
            $notes[] = 'Bem temperado';
        }
        
        if (strpos($message, 'pouco sal') !== false) {
            $notes[] = 'Pouco sal';
        }
        
        return !empty($notes) ? implode(', ', $notes) : null;
    }

    /**
     * Criar pedido no banco
     */
    private function createOrder(Customer $customer, array $cart, array $orderData): Order
    {
        // Calcular totais
        $subtotal = $this->calculateCartTotal($cart);
        $deliveryFee = $this->deliveryService->calculateFee($orderData['delivery_address']['cep'] ?? null);
        $total = $subtotal + $deliveryFee;
        
        // Gerar número do pedido
        $orderNumber = $this->generateOrderNumber();
        
        // Criar pedido
        $order = Order::create([
            'customer_id' => $customer->id,
            'order_number' => $orderNumber,
            'subtotal' => $subtotal,
            'delivery_fee' => $deliveryFee,
            'discount' => 0,
            'total' => $total,
            'payment_method' => $orderData['payment_method'],
            'payment_status' => $orderData['payment_method'] === 'cash' ? 'pending' : 'pending',
            'delivery_date' => $orderData['delivery_date'],
            'delivery_time_slot' => $orderData['delivery_time_slot'],
            'status' => 'pending',
            'notes' => $orderData['notes']
        ]);
        
        // Criar itens do pedido
        foreach ($cart as $item) {
            OrderItem::create([
                'order_id' => $order->id,
                'product_id' => $item['product_id'],
                'quantity' => $item['quantity'],
                'price' => $item['product_price'],
                'name' => $item['product_name'],
                'description' => null,
                'image' => null
            ]);
        }
        
        return $order;
    }

    /**
     * Processar pagamento
     */
    private function processPayment(Order $order, array $orderData): array
    {
        switch ($orderData['payment_method']) {
            case 'mercadopago':
                return $this->paymentService->createPreference($order);
                
            case 'pix':
                return $this->paymentService->createPixPayment($order);
                
            case 'credit_card':
                return $this->paymentService->createCreditCardPayment($order);
                
            default:
                return [
                    'success' => true,
                    'message' => 'Pagamento será processado na entrega'
                ];
        }
    }

    /**
     * Gerar número do pedido
     */
    private function generateOrderNumber(): string
    {
        $date = now()->format('Ymd');
        $random = str_pad(random_int(1, 9999), 4, '0', STR_PAD_LEFT);
        return "OLK{$date}{$random}";
    }

    /**
     * Validar carrinho
     */
    public function validateCart(string $phone): array
    {
        $cart = $this->getCart($phone);
        
        if (empty($cart['items'])) {
            return [
                'valid' => false,
                'message' => 'Carrinho vazio'
            ];
        }
        
        // Verificar se todos os produtos ainda estão disponíveis
        foreach ($cart['items'] as $item) {
            $product = Product::find($item['product_id']);
            if (!$product || !$product->available) {
                return [
                    'valid' => false,
                    'message' => "Produto {$item['product_name']} não está mais disponível"
                ];
            }
        }
        
        return [
            'valid' => true,
            'message' => 'Carrinho válido'
        ];
    }

    /**
     * Aplicar cupom de desconto
     */
    public function applyCoupon(string $phone, string $couponCode): array
    {
        try {
            // TODO: Implementar lógica de cupons
            return [
                'success' => false,
                'message' => 'Sistema de cupons em desenvolvimento'
            ];
        } catch (\Exception $e) {
            return [
                'success' => false,
                'message' => 'Erro ao aplicar cupom'
            ];
        }
    }

    /**
     * Calcular frete
     */
    public function calculateDeliveryFee(string $cep): array
    {
        try {
            $fee = $this->deliveryService->calculateFee($cep);
            
            return [
                'success' => true,
                'fee' => $fee,
                'estimated_time' => $this->deliveryService->getEstimatedTime($cep)
            ];
        } catch (\Exception $e) {
            return [
                'success' => false,
                'message' => 'Erro ao calcular frete'
            ];
        }
    }
}
