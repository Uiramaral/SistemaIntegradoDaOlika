@extends('dashboard.layout-complete')

@section('title', 'Opt-ins WhatsApp - Cardápio Digital Olika')

@section('content')
<div class="min-h-screen bg-gray-50">
    <!-- Header -->
    <div class="bg-white shadow-sm border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-6">
                <div>
                    <h1 class="text-2xl font-bold text-gray-900">Opt-ins WhatsApp</h1>
                    <p class="text-sm text-gray-600">Gerencie consentimentos para recebimento de mensagens</p>
                </div>
                <div class="flex space-x-3">
                    <button id="addOptinBtn" class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                        <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
                        </svg>
                        Adicionar Opt-in
                    </button>
                    <button id="exportOptins" class="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                        <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                        </svg>
                        Exportar
                    </button>
                </div>
            </div>
        </div>
    </div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <!-- Estatísticas -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div class="bg-white rounded-lg shadow p-6">
                <div class="flex items-center">
                    <div class="flex-shrink-0">
                        <div class="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                            <svg class="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                            </svg>
                        </div>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm font-medium text-gray-500">Opt-ins Ativos</p>
                        <p id="activeOptins" class="text-2xl font-semibold text-gray-900">0</p>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow p-6">
                <div class="flex items-center">
                    <div class="flex-shrink-0">
                        <div class="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center">
                            <svg class="w-5 h-5 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                            </svg>
                        </div>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm font-medium text-gray-500">Opt-outs</p>
                        <p id="optOuts" class="text-2xl font-semibold text-gray-900">0</p>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow p-6">
                <div class="flex items-center">
                    <div class="flex-shrink-0">
                        <div class="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                            <svg class="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1"></path>
                            </svg>
                        </div>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm font-medium text-gray-500">Taxa de Opt-in</p>
                        <p id="optinRate" class="text-2xl font-semibold text-gray-900">0%</p>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow p-6">
                <div class="flex items-center">
                    <div class="flex-shrink-0">
                        <div class="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                            <svg class="w-5 h-5 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path>
                            </svg>
                        </div>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm font-medium text-gray-500">Total de Contatos</p>
                        <p id="totalContacts" class="text-2xl font-semibold text-gray-900">0</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Filtros -->
        <div class="bg-white rounded-lg shadow mb-6">
            <div class="px-6 py-4 border-b border-gray-200">
                <h3 class="text-lg font-medium text-gray-900">Filtros</h3>
            </div>
            <div class="p-6">
                <div class="grid grid-cols-1 md:grid-cols-5 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Status</label>
                        <select id="statusFilter" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                            <option value="">Todos</option>
                            <option value="opted_in">Opt-in</option>
                            <option value="opted_out">Opt-out</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Fonte</label>
                        <select id="sourceFilter" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                            <option value="">Todas</option>
                            <option value="checkout">Checkout</option>
                            <option value="form">Formulário</option>
                            <option value="whatsapp">WhatsApp</option>
                            <option value="manual">Manual</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Período</label>
                        <select id="periodFilter" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                            <option value="">Todos</option>
                            <option value="today">Hoje</option>
                            <option value="week">Esta semana</option>
                            <option value="month">Este mês</option>
                            <option value="custom">Personalizado</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Buscar</label>
                        <input type="text" id="searchFilter" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" placeholder="Número ou notas...">
                    </div>
                    <div class="flex items-end">
                        <button id="applyFilters" class="w-full inline-flex justify-center items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                            Aplicar
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Lista de Opt-ins -->
        <div class="bg-white rounded-lg shadow">
            <div class="px-6 py-4 border-b border-gray-200">
                <div class="flex justify-between items-center">
                    <h3 class="text-lg font-medium text-gray-900">Lista de Contatos</h3>
                    <div class="flex items-center space-x-2">
                        <span id="optinsCount" class="text-sm text-gray-500">0 contatos</span>
                        <button id="refreshOptins" class="text-sm text-blue-600 hover:text-blue-500">
                            Atualizar
                        </button>
                    </div>
                </div>
            </div>
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                <input type="checkbox" id="selectAll" class="rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                            </th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Telefone</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Fonte</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Opt-in</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Opt-out</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Notas</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ações</th>
                        </tr>
                    </thead>
                    <tbody id="optinsTableBody" class="bg-white divide-y divide-gray-200">
                        <!-- Opt-ins serão carregados aqui -->
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Paginação -->
        <div id="pagination" class="mt-6 flex items-center justify-between">
            <!-- Paginação será inserida aqui -->
        </div>
    </div>
</div>

<!-- Modal de Adicionar/Editar Opt-in -->
<div id="optinModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50" style="display: none;">
    <div class="relative top-20 mx-auto p-5 border w-full max-w-md shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <div class="flex items-center justify-between mb-4">
                <h3 id="optinModalTitle" class="text-lg font-medium text-gray-900">Adicionar Opt-in</h3>
                <button id="closeOptinModal" class="text-gray-400 hover:text-gray-600">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                </button>
            </div>
            <form id="optinForm">
                <input type="hidden" id="optinId" value="">
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Número do Telefone *</label>
                        <input type="tel" id="phone" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" placeholder="5511999999999" required>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Status *</label>
                        <select id="status" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" required>
                            <option value="opted_in">Opt-in</option>
                            <option value="opted_out">Opt-out</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Fonte</label>
                        <select id="source" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                            <option value="manual">Manual</option>
                            <option value="checkout">Checkout</option>
                            <option value="form">Formulário</option>
                            <option value="whatsapp">WhatsApp</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Notas</label>
                        <textarea id="notes" rows="3" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" placeholder="Observações sobre este contato..."></textarea>
                    </div>
                </div>

                <div class="flex justify-end space-x-3 mt-6">
                    <button type="button" id="saveOptin" class="px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                        Salvar
                    </button>
                    <button type="button" id="cancelOptin" class="px-4 py-2 bg-gray-300 text-gray-700 text-sm font-medium rounded-md hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500">
                        Cancelar
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal de Confirmação -->
<div id="confirmModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50" style="display: none;">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <div class="flex items-center justify-center w-12 h-12 mx-auto bg-red-100 rounded-full">
                <svg class="w-6 h-6 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z"></path>
                </svg>
            </div>
            <div class="mt-3 text-center">
                <h3 class="text-lg font-medium text-gray-900">Confirmar Ação</h3>
                <div class="mt-2">
                    <p class="text-sm text-gray-500" id="confirmMessage">
                        Tem certeza que deseja realizar esta ação?
                    </p>
                </div>
            </div>
            <div class="flex justify-center space-x-3 mt-6">
                <button id="confirmAction" class="px-4 py-2 bg-red-600 text-white text-sm font-medium rounded-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500">
                    Confirmar
                </button>
                <button id="cancelAction" class="px-4 py-2 bg-gray-300 text-gray-700 text-sm font-medium rounded-md hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500">
                    Cancelar
                </button>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Elementos DOM
    const addOptinBtn = document.getElementById('addOptinBtn');
    const optinModal = document.getElementById('optinModal');
    const closeOptinModal = document.getElementById('closeOptinModal');
    const optinForm = document.getElementById('optinForm');
    const saveOptin = document.getElementById('saveOptin');
    const cancelOptin = document.getElementById('cancelOptin');
    const optinsTableBody = document.getElementById('optinsTableBody');
    const refreshOptins = document.getElementById('refreshOptins');
    const applyFilters = document.getElementById('applyFilters');
    const selectAll = document.getElementById('selectAll');
    const confirmModal = document.getElementById('confirmModal');
    const confirmAction = document.getElementById('confirmAction');
    const cancelAction = document.getElementById('cancelAction');

    // Variáveis
    let currentOptinId = null;
    let optins = [];
    let currentPage = 1;
    let totalPages = 1;
    let currentAction = null;

    // Inicializar
    loadOptins();
    loadStats();

    // Event Listeners
    addOptinBtn.addEventListener('click', () => openOptinModal());
    closeOptinModal.addEventListener('click', () => closeModal());
    saveOptin.addEventListener('click', saveOptinData);
    cancelOptin.addEventListener('click', closeModal);
    refreshOptins.addEventListener('click', loadOptins);
    applyFilters.addEventListener('click', applyFiltersToOptins);
    selectAll.addEventListener('change', toggleSelectAll);
    confirmAction.addEventListener('click', executeAction);
    cancelAction.addEventListener('click', () => confirmModal.style.display = 'none');

    // Fechar modais ao clicar fora
    window.addEventListener('click', function(event) {
        if (event.target === optinModal) {
            closeModal();
        }
        if (event.target === confirmModal) {
            confirmModal.style.display = 'none';
        }
    });

    function openOptinModal(optin = null) {
        currentOptinId = optin ? optin.id : null;
        
        if (optin) {
            document.getElementById('optinModalTitle').textContent = 'Editar Opt-in';
            document.getElementById('phone').value = optin.phone;
            document.getElementById('status').value = optin.opted_in_at ? 'opted_in' : 'opted_out';
            document.getElementById('source').value = optin.source || 'manual';
            document.getElementById('notes').value = optin.notes || '';
        } else {
            document.getElementById('optinModalTitle').textContent = 'Adicionar Opt-in';
            optinForm.reset();
            document.getElementById('status').value = 'opted_in';
            document.getElementById('source').value = 'manual';
        }
        
        optinModal.style.display = 'block';
    }

    function closeModal() {
        optinModal.style.display = 'none';
        optinForm.reset();
        currentOptinId = null;
    }

    function saveOptinData() {
        const formData = {
            phone: document.getElementById('phone').value.trim(),
            status: document.getElementById('status').value,
            source: document.getElementById('source').value,
            notes: document.getElementById('notes').value.trim()
        };

        if (!formData.phone) {
            alert('Por favor, insira o número do telefone');
            return;
        }

        const url = currentOptinId ? `/api/whatsapp/optins/${currentOptinId}` : '/api/whatsapp/optins';
        const method = currentOptinId ? 'PUT' : 'POST';

        fetch(url, {
            method: method,
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
            },
            body: JSON.stringify(formData)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                closeModal();
                loadOptins();
                loadStats();
                showNotification('Opt-in salvo com sucesso!', 'success');
            } else {
                alert('Erro ao salvar opt-in: ' + (data.message || data.error));
            }
        })
        .catch(error => {
            console.error('Erro:', error);
            alert('Erro ao salvar opt-in');
        });
    }

    function loadOptins(page = 1) {
        const statusFilter = document.getElementById('statusFilter').value;
        const sourceFilter = document.getElementById('sourceFilter').value;
        const periodFilter = document.getElementById('periodFilter').value;
        const searchFilter = document.getElementById('searchFilter').value;

        let url = `/api/whatsapp/optins?loja_id=1&page=${page}`;
        
        if (statusFilter) url += `&status=${statusFilter}`;
        if (sourceFilter) url += `&source=${sourceFilter}`;
        if (periodFilter) url += `&period=${periodFilter}`;
        if (searchFilter) url += `&search=${encodeURIComponent(searchFilter)}`;

        fetch(url)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                optins = data.optins.data || data.optins;
                currentPage = data.optins.current_page || 1;
                totalPages = data.optins.last_page || 1;
                displayOptins(optins);
                updateOptinsCount(optins.length);
                updatePagination();
            }
        })
        .catch(error => {
            console.error('Erro ao carregar opt-ins:', error);
        });
    }

    function displayOptins(optinsToShow) {
        if (optinsToShow.length === 0) {
            optinsTableBody.innerHTML = `
                <tr>
                    <td colspan="8" class="px-6 py-8 text-center text-gray-500">
                        Nenhum opt-in encontrado
                    </td>
                </tr>
            `;
            return;
        }

        optinsTableBody.innerHTML = optinsToShow.map(optin => `
            <tr class="hover:bg-gray-50">
                <td class="px-6 py-4 whitespace-nowrap">
                    <input type="checkbox" class="optin-checkbox rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50" value="${optin.id}">
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    ${formatPhone(optin.phone)}
                </td>
                <td class="px-6 py-4 whitespace-nowrap">
                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${optin.opted_in_at && !optin.opted_out_at ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}">
                        ${optin.opted_in_at && !optin.opted_out_at ? 'Opt-in' : 'Opt-out'}
                    </span>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    ${getSourceDisplayName(optin.source)}
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    ${optin.opted_in_at ? new Date(optin.opted_in_at).toLocaleDateString() : '-'}
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    ${optin.opted_out_at ? new Date(optin.opted_out_at).toLocaleDateString() : '-'}
                </td>
                <td class="px-6 py-4 text-sm text-gray-500 max-w-xs truncate">
                    ${optin.notes || '-'}
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <div class="flex space-x-2">
                        <button onclick="editOptin(${optin.id})" class="text-blue-600 hover:text-blue-900">
                            Editar
                        </button>
                        <button onclick="toggleOptin(${optin.id}, '${optin.opted_in_at && !optin.opted_out_at ? 'opted_in' : 'opted_out'}')" class="text-yellow-600 hover:text-yellow-900">
                            ${optin.opted_in_at && !optin.opted_out_at ? 'Opt-out' : 'Opt-in'}
                        </button>
                        <button onclick="deleteOptin(${optin.id})" class="text-red-600 hover:text-red-900">
                            Excluir
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');
    }

    function formatPhone(phone) {
        // Formatar telefone brasileiro
        const cleaned = phone.replace(/\D/g, '');
        if (cleaned.length === 13) {
            return `+${cleaned.slice(0, 2)} (${cleaned.slice(2, 4)}) ${cleaned.slice(4, 9)}-${cleaned.slice(9)}`;
        }
        return phone;
    }

    function getSourceDisplayName(source) {
        const names = {
            'checkout': 'Checkout',
            'form': 'Formulário',
            'whatsapp': 'WhatsApp',
            'manual': 'Manual'
        };
        return names[source] || source;
    }

    function updateOptinsCount(count) {
        document.getElementById('optinsCount').textContent = `${count} contato${count !== 1 ? 's' : ''}`;
    }

    function updatePagination() {
        const pagination = document.getElementById('pagination');
        if (totalPages <= 1) {
            pagination.innerHTML = '';
            return;
        }

        let paginationHTML = '<div class="flex items-center justify-between"><div class="flex-1 flex justify-between sm:hidden">';
        
        // Botão anterior
        if (currentPage > 1) {
            paginationHTML += `<button onclick="loadOptins(${currentPage - 1})" class="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">Anterior</button>`;
        }
        
        // Botão próximo
        if (currentPage < totalPages) {
            paginationHTML += `<button onclick="loadOptins(${currentPage + 1})" class="ml-3 relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">Próximo</button>`;
        }
        
        paginationHTML += '</div><div class="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">';
        paginationHTML += `<div><p class="text-sm text-gray-700">Página <span class="font-medium">${currentPage}</span> de <span class="font-medium">${totalPages}</span></p></div>`;
        paginationHTML += '<div><nav class="relative z-0 inline-flex rounded-md shadow-sm -space-x-px">';
        
        // Páginas
        for (let i = 1; i <= totalPages; i++) {
            if (i === currentPage) {
                paginationHTML += `<span class="relative inline-flex items-center px-4 py-2 border border-blue-500 bg-blue-50 text-sm font-medium text-blue-600">${i}</span>`;
            } else {
                paginationHTML += `<button onclick="loadOptins(${i})" class="relative inline-flex items-center px-4 py-2 border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50">${i}</button>`;
            }
        }
        
        paginationHTML += '</nav></div></div></div>';
        pagination.innerHTML = paginationHTML;
    }

    function applyFiltersToOptins() {
        loadOptins(1);
    }

    function toggleSelectAll() {
        const checkboxes = document.querySelectorAll('.optin-checkbox');
        checkboxes.forEach(checkbox => {
            checkbox.checked = selectAll.checked;
        });
    }

    function loadStats() {
        fetch('/api/whatsapp/optins/stats?loja_id=1')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const stats = data.stats;
                document.getElementById('activeOptins').textContent = stats.opted_in || 0;
                document.getElementById('optOuts').textContent = stats.opted_out || 0;
                document.getElementById('totalContacts').textContent = stats.total || 0;
                document.getElementById('optinRate').textContent = calculateOptinRate(stats) + '%';
            }
        })
        .catch(error => {
            console.error('Erro ao carregar estatísticas:', error);
        });
    }

    function calculateOptinRate(stats) {
        if (!stats.total || stats.total === 0) return 0;
        return Math.round(((stats.opted_in || 0) / stats.total) * 100);
    }

    function editOptin(optinId) {
        const optin = optins.find(o => o.id === optinId);
        if (optin) {
            openOptinModal(optin);
        }
    }

    function toggleOptin(optinId, currentStatus) {
        const newStatus = currentStatus === 'opted_in' ? 'opted_out' : 'opted_in';
        
        fetch(`/api/whatsapp/optins/${optinId}/toggle`, {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
            },
            body: JSON.stringify({ status: newStatus })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                loadOptins(currentPage);
                loadStats();
                showNotification(`Opt-in ${newStatus === 'opted_in' ? 'ativado' : 'desativado'} com sucesso!`, 'success');
            } else {
                alert('Erro ao alterar status do opt-in');
            }
        })
        .catch(error => {
            console.error('Erro:', error);
            alert('Erro ao alterar status do opt-in');
        });
    }

    function deleteOptin(optinId) {
        currentAction = () => {
            fetch(`/api/whatsapp/optins/${optinId}`, {
                method: 'DELETE',
                headers: {
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    confirmModal.style.display = 'none';
                    loadOptins(currentPage);
                    loadStats();
                    showNotification('Opt-in excluído com sucesso!', 'success');
                } else {
                    alert('Erro ao excluir opt-in');
                }
            })
            .catch(error => {
                console.error('Erro:', error);
                alert('Erro ao excluir opt-in');
            });
        };
        
        document.getElementById('confirmMessage').textContent = 'Tem certeza que deseja excluir este opt-in?';
        confirmModal.style.display = 'block';
    }

    function executeAction() {
        if (currentAction) {
            currentAction();
            currentAction = null;
        }
    }

    function showNotification(message, type = 'info') {
        // Implementar sistema de notificações
        alert(message);
    }

    // Tornar funções globais para uso nos botões
    window.loadOptins = loadOptins;
    window.editOptin = editOptin;
    window.toggleOptin = toggleOptin;
    window.deleteOptin = deleteOptin;
});
</script>
@endsection
