# 🌍 GUIA DE AMBIENTES - LOCAL E PRODUÇÃO

## 🎯 **VISÃO GERAL**

Este projeto está configurado para funcionar **automaticamente** em:
- 💻 **Local** (desenvolvimento)
- 🌐 **Produção** (servidor/HostGator)

---

## 🚀 **SETUP RÁPIDO**

### **Opção 1: Setup Automático (RECOMENDADO)**

```powershell
# Execute o script de configuração:
.\setup-ambiente.ps1

# Ou especifique o ambiente:
.\setup-ambiente.ps1 -Ambiente local
.\setup-ambiente.ps1 -Ambiente producao
```

O script vai:
1. ✅ Detectar o ambiente automaticamente
2. ✅ Copiar o .env correto
3. ✅ Gerar APP_KEY
4. ✅ Criar estrutura storage/
5. ✅ Limpar/otimizar cache
6. ✅ Testar banco de dados

### **Opção 2: Setup Manual**

#### **Para LOCAL:**
```bash
cd cardapio-digital
copy .env.local .env
php artisan key:generate
php artisan serve
```

#### **Para PRODUÇÃO:**
```bash
cd cardapio-digital
copy .env.production .env
php artisan key:generate
php artisan config:cache
php artisan route:cache
php artisan view:cache
```

---

## 📁 **ARQUIVOS DE AMBIENTE**

### **Arquivos Disponíveis:**

| Arquivo | Uso | Descrição |
|---------|-----|-----------|
| `.env.local` | 💻 Desenvolvimento | Debug ON, Sandbox, Logs verbosos |
| `.env.production` | 🌐 Produção | Debug OFF, Seguro, Otimizado |
| `.env` | 🔄 Atual | Arquivo ativo (copiado de um dos acima) |
| `env.example` | 📝 Modelo | Template de referência |

### **Diferenças Principais:**

| Configuração | Local | Produção |
|--------------|-------|----------|
| `APP_ENV` | `local` | `production` |
| `APP_DEBUG` | `true` ✅ | `false` ❌ |
| `APP_URL` | `http://localhost:8000` | `https://seudominio.com.br` |
| `LOG_LEVEL` | `debug` | `error` |
| `LOG_CHANNEL` | `stack` | `daily` |
| `DB_DATABASE` | `cardapio_digital` | `seuursu_cardapio_digital` |
| `DB_USERNAME` | `root` | `seuursu_cardapio_user` |
| `DB_PASSWORD` | ` ` (vazio) | Senha forte |
| `MERCADOPAGO_*` | Sandbox (TEST-) | Produção (APP-) |
| `MAIL_MAILER` | `log` | `smtp` |
| Cache | Limpo frequentemente | Otimizado (cached) |

---

## 🔧 **CONFIGURAÇÕES POR AMBIENTE**

### **💻 AMBIENTE LOCAL**

#### **Características:**
- ✅ Debug ativado
- ✅ Logs detalhados
- ✅ MercadoPago Sandbox
- ✅ Mail via log
- ✅ Banco local (root sem senha)
- ✅ Cache desabilitado
- ✅ Servidor: `php artisan serve`

#### **Quando usar:**
- Desenvolvimento
- Testes
- Correção de bugs
- Novas features

#### **Comandos úteis:**
```bash
# Iniciar servidor
php artisan serve

# Limpar cache
php artisan cache:clear
php artisan config:clear
php artisan route:clear
php artisan view:clear

# Ver logs
tail -f storage/logs/laravel.log

# Testar banco
php artisan tinker
>>> DB::connection()->getPdo();
```

### **🌐 AMBIENTE PRODUÇÃO**

#### **Características:**
- ❌ Debug desabilitado
- ⚠️ Logs apenas erros
- ✅ MercadoPago Produção
- ✅ Mail via SMTP
- 🔒 Banco com senha forte
- ⚡ Cache otimizado
- 🌐 Servidor: Apache/Nginx

#### **Quando usar:**
- Sistema ao vivo
- Clientes reais
- Pagamentos reais
- Dados reais

#### **Comandos úteis:**
```bash
# Otimizar cache
php artisan config:cache
php artisan route:cache
php artisan view:cache

# Ver logs (últimas 50 linhas)
tail -n 50 storage/logs/laravel-$(date +%Y-%m-%d).log

# Limpar logs antigos
find storage/logs -name "*.log" -mtime +30 -delete
```

---

## 🔄 **MUDANÇA DE AMBIENTE**

### **De LOCAL para PRODUÇÃO:**

```bash
# 1. Fazer backup do .env atual
cp .env .env.backup

# 2. Usar .env de produção
cp .env.production .env

# 3. Editar credenciais
nano .env
# Preencher: DB_*, APP_URL, MERCADOPAGO_*, etc

# 4. Gerar nova APP_KEY
php artisan key:generate

# 5. Otimizar
php artisan config:cache
php artisan route:cache
php artisan view:cache

# 6. VERIFICAR APP_DEBUG=false!
grep APP_DEBUG .env
# Deve mostrar: APP_DEBUG=false
```

### **De PRODUÇÃO para LOCAL:**

```bash
# 1. Fazer backup
cp .env .env.backup

# 2. Usar .env local
cp .env.local .env

# 3. Editar se necessário
nano .env

# 4. Limpar cache
php artisan cache:clear
php artisan config:clear
php artisan route:clear
php artisan view:clear

# 5. Iniciar servidor
php artisan serve
```

### **⚡ Usando o Script Automático:**

```powershell
# Para Local:
.\setup-ambiente.ps1 -Ambiente local

# Para Produção:
.\setup-ambiente.ps1 -Ambiente producao

# Auto-detectar:
.\setup-ambiente.ps1
```

---

## 🗃️ **BANCO DE DADOS**

### **LOCAL:**
```sql
-- Importar estrutura
mysql -u root cardapio_digital < CARDAPIO_DIGITAL_COMPLETO.sql

-- Ou via phpMyAdmin:
-- 1. Criar banco: cardapio_digital
-- 2. Importar: CARDAPIO_DIGITAL_COMPLETO.sql
```

### **PRODUÇÃO:**
```sql
-- Via cPanel phpMyAdmin:
-- 1. Criar banco: seuursu_cardapio_digital
-- 2. Criar usuário: seuursu_cardapio_user
-- 3. Dar todas permissões
-- 4. Importar: CARDAPIO_DIGITAL_COMPLETO.sql
-- 5. Atualizar .env com credenciais
```

---

## 🔒 **SEGURANÇA**

### **✅ SEMPRE FAZER (Produção):**

1. **`.env` com permissões corretas:**
   ```bash
   chmod 600 .env
   ```

2. **`APP_DEBUG=false`**
   ```env
   APP_DEBUG=false  # NUNCA true em produção!
   ```

3. **Senha forte no banco:**
   ```env
   DB_PASSWORD=S3nh4@Mu1t0!F0rt3#2024
   ```

4. **APP_KEY única:**
   ```bash
   php artisan key:generate --force
   ```

5. **HTTPS ativo:**
   ```env
   APP_URL=https://seudominio.com.br  # COM https://
   ```

6. **Logs limitados:**
   ```env
   LOG_LEVEL=error  # Não debug!
   ```

### **❌ NUNCA FAZER (Produção):**

1. ❌ `APP_DEBUG=true`
2. ❌ Senha vazia ou fraca
3. ❌ HTTP (sem SSL)
4. ❌ `.env` público
5. ❌ Logs verbosos
6. ❌ Tokens de sandbox

---

## 🧪 **TESTES**

### **Testar Ambiente Atual:**

```bash
# Ver ambiente ativo
php artisan tinker
>>> config('app.env');
>>> config('app.debug');
>>> config('database.connections.mysql.database');

# Testar banco
>>> DB::connection()->getPdo();

# Ver APP_URL
>>> config('app.url');
```

### **Verificar Configurações:**

```bash
# Ver todas configs
php artisan config:show

# Ver config específica
php artisan tinker
>>> config('app');
>>> config('database');
>>> config('services');
```

---

## 📊 **CHECKLIST DE DEPLOY**

### **Antes de Subir para Produção:**

- [ ] ✅ `.env.production` configurado
- [ ] ✅ `APP_DEBUG=false`
- [ ] ✅ `APP_KEY` gerada
- [ ] ✅ Credenciais DB corretas
- [ ] ✅ Banco importado
- [ ] ✅ Permissões storage/ (755)
- [ ] ✅ HTTPS ativo
- [ ] ✅ MercadoPago PRODUÇÃO
- [ ] ✅ Cache otimizado
- [ ] ✅ Testar todas funcionalidades
- [ ] ✅ Backup do banco
- [ ] ✅ Logs monitorados

### **Depois de Subir para Produção:**

- [ ] ✅ Acessar site principal
- [ ] ✅ Testar menu público
- [ ] ✅ Testar dashboard (/dashboard)
- [ ] ✅ Fazer pedido teste
- [ ] ✅ Verificar logs (sem erros)
- [ ] ✅ Testar pagamento (pequeno valor)
- [ ] ✅ Configurar backup automático
- [ ] ✅ Monitorar por 24h

---

## 🚨 **PROBLEMAS COMUNS**

### **1. "No application encryption key"**
```bash
# Solução:
php artisan key:generate
```

### **2. "SQLSTATE[HY000] [1045] Access denied"**
```env
# Verificar .env:
DB_DATABASE=nome_correto
DB_USERNAME=usuario_correto
DB_PASSWORD=senha_correta
```

### **3. "The stream or file could not be opened"**
```bash
# Permissões:
chmod -R 755 storage
chmod -R 755 bootstrap/cache
```

### **4. Página em branco**
```bash
# Ver logs:
tail -f storage/logs/laravel.log

# Ou temporariamente:
# .env: APP_DEBUG=true (APENAS PARA DEBUG!)
```

### **5. Cache não atualiza**
```bash
# Limpar tudo:
php artisan cache:clear
php artisan config:clear
php artisan route:clear
php artisan view:clear
php artisan optimize:clear
```

---

## 📞 **SUPORTE**

### **Logs para Debug:**

**Local:**
```bash
storage/logs/laravel.log
```

**Produção:**
```bash
storage/logs/laravel-YYYY-MM-DD.log
```

### **Informações Úteis:**

```bash
# Versão PHP
php -v

# Extensões PHP
php -m

# Teste Laravel
php artisan about

# Teste banco
php artisan db:show
```

---

## 🎯 **RESUMO RÁPIDO**

### **Para DESENVOLVER:**
```powershell
.\setup-ambiente.ps1 -Ambiente local
php artisan serve
# Acessar: http://localhost:8000
```

### **Para PRODUÇÃO:**
```powershell
.\setup-ambiente.ps1 -Ambiente producao
# Upload para servidor
# Configurar domínio
# Acessar: https://seudominio.com.br
```

---

**✅ SISTEMA PRONTO PARA RODAR EM QUALQUER AMBIENTE!**

**Data:** $(date +%Y-%m-%d)  
**Versão:** 1.0 - Multi-Ambiente

