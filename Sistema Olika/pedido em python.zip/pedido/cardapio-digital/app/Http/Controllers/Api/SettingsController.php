<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Settings;
use App\Services\MercadoPagoService;
use App\Services\WhatsAppService;
use App\Services\GoogleMapsService;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Validator;

class SettingsController extends Controller
{
    /**
     * Obter configurações
     */
    public function index(): JsonResponse
    {
        $settings = Settings::getSettings();

        return response()->json([
            'success' => true,
            'data' => $settings
        ]);
    }

    /**
     * Atualizar configurações
     */
    public function update(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'business_name' => 'sometimes|required|string|max:255',
            'logo' => 'nullable|string|max:500',
            'header_image' => 'nullable|string|max:500',
            'primary_color' => 'sometimes|required|string|max:7',
            'description' => 'nullable|string',
            'phone' => 'nullable|string|max:20',
            'address' => 'nullable|string',
            'delivery_info' => 'nullable|string',
            'min_delivery_value' => 'nullable|numeric|min:0',
            'is_open' => 'boolean',
            'mercado_pago_access_token' => 'nullable|string',
            'mercado_pago_public_key' => 'nullable|string',
            'mercado_pago_return_url' => 'nullable|string|max:500',
            'mercado_pago_webhook_url' => 'nullable|string|max:500',
            'mercado_pago_environment' => 'sometimes|required|in:sandbox,production',
            'display_mode' => 'sometimes|required|in:grid,list,compact',
            'whatsapp_api_url' => 'nullable|string|max:500',
            'whatsapp_api_token' => 'nullable|string',
            'google_maps_api_key' => 'nullable|string',
            'free_delivery_threshold' => 'nullable|numeric|min:0',
            'order_cutoff_time' => 'nullable|date_format:H:i',
            'advance_order_days' => 'nullable|integer|min:1|max:30',
            'debug_mode' => 'boolean',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Dados inválidos',
                'errors' => $validator->errors()
            ], 422);
        }

        $settings = Settings::updateSettings($request->all());

        return response()->json([
            'success' => true,
            'message' => 'Configurações atualizadas com sucesso',
            'data' => $settings
        ]);
    }

    /**
     * Obter configurações públicas
     */
    public function public(): JsonResponse
    {
        $settings = Settings::getSettings();

        return response()->json([
            'success' => true,
            'data' => $settings->getPublicSettings()
        ]);
    }

    /**
     * Toggle status da loja
     */
    public function toggleStatus(): JsonResponse
    {
        $settings = Settings::getSettings();
        $settings->toggleStatus();

        return response()->json([
            'success' => true,
            'message' => $settings->isOpen() ? 'Loja aberta' : 'Loja fechada',
            'data' => $settings
        ]);
    }

    /**
     * Validar configuração do Mercado Pago
     */
    public function validateMercadoPago(): JsonResponse
    {
        try {
            $mercadoPagoService = new MercadoPagoService();
            $result = $mercadoPagoService->validateConfiguration();

            return response()->json($result);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Erro ao validar configuração: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Validar configuração do WhatsApp
     */
    public function validateWhatsApp(): JsonResponse
    {
        try {
            $whatsAppService = new WhatsAppService();
            $result = $whatsAppService->validateConfiguration();

            return response()->json($result);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Erro ao validar configuração: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Validar configuração do Google Maps
     */
    public function validateGoogleMaps(): JsonResponse
    {
        try {
            $googleMapsService = new GoogleMapsService();
            $result = $googleMapsService->validateConfiguration();

            return response()->json($result);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Erro ao validar configuração: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Obter configuração específica
     */
    public function get(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'key' => 'required|string'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Chave é obrigatória',
                'errors' => $validator->errors()
            ], 422);
        }

        $value = Settings::get($request->key);

        return response()->json([
            'success' => true,
            'data' => [
                'key' => $request->key,
                'value' => $value
            ]
        ]);
    }

    /**
     * Definir configuração específica
     */
    public function set(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'key' => 'required|string',
            'value' => 'required'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Chave e valor são obrigatórios',
                'errors' => $validator->errors()
            ], 422);
        }

        Settings::set($request->key, $request->value);

        return response()->json([
            'success' => true,
            'message' => 'Configuração atualizada com sucesso'
        ]);
    }

    /**
     * Resetar configurações para padrão
     */
    public function reset(): JsonResponse
    {
        $settings = Settings::getSettings();
        
        // Manter apenas configurações essenciais
        $defaultSettings = [
            'business_name' => 'Olika - Pães Artesanais',
            'primary_color' => '#FF8C00',
            'description' => 'Pães e massas artesanais feitos com amor e ingredientes selecionados',
            'phone' => '(11) 99999-9999',
            'delivery_info' => 'Entrega grátis acima de R$ 100,00',
            'min_delivery_value' => 100,
            'free_delivery_threshold' => 100,
            'is_open' => true,
            'display_mode' => 'grid',
            'mercado_pago_environment' => 'sandbox',
            'advance_order_days' => 1,
            'debug_mode' => false,
        ];

        $settings->update($defaultSettings);

        return response()->json([
            'success' => true,
            'message' => 'Configurações resetadas para padrão',
            'data' => $settings
        ]);
    }

    /**
     * Exportar configurações
     */
    public function export(): JsonResponse
    {
        $settings = Settings::getSettings();

        return response()->json([
            'success' => true,
            'data' => $settings->toArray()
        ]);
    }

    /**
     * Importar configurações
     */
    public function import(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'settings' => 'required|array'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Dados de configuração são obrigatórios',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $settings = Settings::updateSettings($request->settings);

            return response()->json([
                'success' => true,
                'message' => 'Configurações importadas com sucesso',
                'data' => $settings
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Erro ao importar configurações: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Obter status do sistema
     */
    public function systemStatus(): JsonResponse
    {
        $settings = Settings::getSettings();

        $status = [
            'loja_aberta' => $settings->isOpen(),
            'mercado_pago_configurado' => $settings->isMercadoPagoConfigured(),
            'whatsapp_configurado' => $settings->isWhatsAppConfigured(),
            'google_maps_configurado' => $settings->isGoogleMapsConfigured(),
            'ambiente_mercado_pago' => $settings->mercado_pago_environment,
            'modo_debug' => $settings->debug_mode,
            'horario_corte' => $settings->order_cutoff_time,
            'corte_ultrapassado' => $settings->isOrderCutoffPassed(),
        ];

        return response()->json([
            'success' => true,
            'data' => $status
        ]);
    }
}
