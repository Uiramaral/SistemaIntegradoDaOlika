<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('conversas_suporte', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('cliente_id')->nullable();
            $table->string('subscriber_id', 50)->nullable()->comment('ID do subscriber no ManyChat');
            $table->string('telefone', 20);
            $table->string('nome', 150);
            $table->enum('status', ['ativa', 'encerrada', 'aguardando'])->default('ativa');
            $table->string('assunto', 100)->nullable()->comment('Classificação automática do assunto');
            $table->json('metadata')->nullable();
            $table->timestamp('created_at')->useCurrent();
            $table->timestamp('updated_at')->useCurrent()->useCurrentOnUpdate();
            
            $table->index('subscriber_id', 'idx_subscriber_id');
            $table->index('telefone', 'idx_telefone');
            $table->index('status', 'idx_status');
            $table->index('created_at', 'idx_created_at');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('conversas_suporte');
    }
};
