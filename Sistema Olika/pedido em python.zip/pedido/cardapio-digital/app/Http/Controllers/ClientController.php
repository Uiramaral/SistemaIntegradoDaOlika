<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Category;
use App\Models\Settings;
use Illuminate\Http\Request;

class ClientController extends Controller
{
    /**
     * Exibir menu público
     */
    public function menu()
    {
        $products = Product::with('category')
            ->where('available', true)
            ->where('visible', true)
            ->orderBy('featured', 'desc')
            ->orderBy('name')
            ->get();

        $featuredProducts = $products->where('featured', true);

        $categories = Category::where('available', true)
            ->where('visible', true)
            ->orderBy('sort_order')
            ->orderBy('name')
            ->get();

        $settings = Settings::getSettings();

        return view('client.menu-new', compact('products', 'featuredProducts', 'categories', 'settings'));
    }

    /**
     * Exibir carrinho
     */
    public function cart()
    {
        $settings = Settings::getSettings();
        return view('client.cart-complete', compact('settings'));
    }

    /**
     * Exibir checkout
     */
    public function checkout()
    {
        $settings = Settings::getSettings();
        return view('client.checkout-complete', compact('settings'));
    }

    /**
     * Exibir página de produto
     */
    public function product($id)
    {
        $product = Product::with('category')->findOrFail($id);
        $relatedProducts = Product::where('category_id', $product->category_id)
            ->where('id', '!=', $product->id)
            ->where('available', true)
            ->where('visible', true)
            ->limit(4)
            ->get();

        $settings = Settings::getSettings();

        return view('client.product', compact('product', 'relatedProducts', 'settings'));
    }

    /**
     * Buscar produtos
     */
    public function search(Request $request)
    {
        $query = $request->get('q', '');
        $category = $request->get('category');

        $productsQuery = Product::with('category')
            ->where('available', true)
            ->where('visible', true);

        if ($query) {
            $productsQuery->where(function($q) use ($query) {
                $q->where('name', 'like', "%{$query}%")
                  ->orWhere('description', 'like', "%{$query}%");
            });
        }

        if ($category) {
            $productsQuery->where('category_id', $category);
        }

        $products = $productsQuery->orderBy('featured', 'desc')
            ->orderBy('name')
            ->get();

        $categories = Category::where('available', true)
            ->where('visible', true)
            ->orderBy('sort_order')
            ->orderBy('name')
            ->get();

        $settings = Settings::getSettings();

        return view('client.search', compact('products', 'categories', 'settings', 'query'));
    }
}
