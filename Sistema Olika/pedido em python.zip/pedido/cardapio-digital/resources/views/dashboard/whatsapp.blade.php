@extends('dashboard.layout-complete')

@section('title', 'WhatsApp - Cardápio Digital Olika')

@section('content')
<div class="min-h-screen bg-gray-50">
    <!-- Header -->
    <div class="bg-white shadow-sm border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-6">
                <div>
                    <h1 class="text-2xl font-bold text-gray-900">WhatsApp</h1>
                    <p class="text-sm text-gray-600">Gerencie conexões e mensagens do WhatsApp</p>
                </div>
                <div class="flex space-x-3">
                    <button id="refreshStatus" class="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                        <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path>
                        </svg>
                        Atualizar
                    </button>
                </div>
            </div>
        </div>
    </div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <!-- Status Cards -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <!-- Status da Conexão -->
            <div class="bg-white rounded-lg shadow p-6">
                <div class="flex items-center">
                    <div class="flex-shrink-0">
                        <div id="connectionStatus" class="w-3 h-3 rounded-full bg-gray-400"></div>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm font-medium text-gray-500">Status</p>
                        <p id="connectionStatusText" class="text-lg font-semibold text-gray-900">Desconectado</p>
                    </div>
                </div>
            </div>

            <!-- Total de Mensagens -->
            <div class="bg-white rounded-lg shadow p-6">
                <div class="flex items-center">
                    <div class="flex-shrink-0">
                        <svg class="w-8 h-8 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"></path>
                        </svg>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm font-medium text-gray-500">Mensagens Hoje</p>
                        <p id="messagesToday" class="text-lg font-semibold text-gray-900">0</p>
                    </div>
                </div>
            </div>

            <!-- Taxa de Entrega -->
            <div class="bg-white rounded-lg shadow p-6">
                <div class="flex items-center">
                    <div class="flex-shrink-0">
                        <svg class="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                        </svg>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm font-medium text-gray-500">Taxa de Entrega</p>
                        <p id="deliveryRate" class="text-lg font-semibold text-gray-900">0%</p>
                    </div>
                </div>
            </div>

            <!-- Opt-ins -->
            <div class="bg-white rounded-lg shadow p-6">
                <div class="flex items-center">
                    <div class="flex-shrink-0">
                        <svg class="w-8 h-8 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path>
                        </svg>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm font-medium text-gray-500">Opt-ins</p>
                        <p id="optInsCount" class="text-lg font-semibold text-gray-900">0</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <!-- Conexão WhatsApp -->
            <div class="lg:col-span-2">
                <div class="bg-white rounded-lg shadow">
                    <div class="px-6 py-4 border-b border-gray-200">
                        <h3 class="text-lg font-medium text-gray-900">Conexão WhatsApp</h3>
                    </div>
                    <div class="p-6">
                        <!-- Status da Sessão -->
                        <div id="sessionStatus" class="mb-6">
                            <div class="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                                <div class="flex items-center">
                                    <div id="sessionStatusIndicator" class="w-3 h-3 rounded-full bg-gray-400 mr-3"></div>
                                    <div>
                                        <p class="text-sm font-medium text-gray-900">Sessão Ativa</p>
                                        <p id="sessionStatusText" class="text-sm text-gray-500">Nenhuma sessão ativa</p>
                                    </div>
                                </div>
                                <div class="flex space-x-2">
                                    <button id="connectBtn" class="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                        Conectar
                                    </button>
                                    <button id="disconnectBtn" class="inline-flex items-center px-3 py-2 border border-gray-300 text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500" style="display: none;">
                                        Desconectar
                                    </button>
                                </div>
                            </div>
                        </div>

                        <!-- Formulário de Conexão -->
                        <div id="connectionForm" class="space-y-4" style="display: none;">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Número do WhatsApp</label>
                                <input type="tel" id="phoneNumber" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" placeholder="5511999999999">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Modo de Conexão</label>
                                <select id="adapterType" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                                    <option value="non_official">Não-oficial (Recomendado)</option>
                                    <option value="cloud_api">Cloud API (Oficial)</option>
                                </select>
                            </div>
                            <div class="flex space-x-3">
                                <button id="startConnection" class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                    Iniciar Conexão
                                </button>
                                <button id="cancelConnection" class="inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                    Cancelar
                                </button>
                            </div>
                        </div>

                        <!-- Código de Emparelhamento -->
                        <div id="pairingCode" class="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg" style="display: none;">
                            <div class="flex items-center">
                                <svg class="w-5 h-5 text-blue-600 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                                <div>
                                    <p class="text-sm font-medium text-blue-900">Código de Emparelhamento</p>
                                    <p class="text-sm text-blue-700">Digite este código no WhatsApp para conectar</p>
                                </div>
                            </div>
                            <div class="mt-3">
                                <div class="text-2xl font-mono font-bold text-blue-900 text-center p-3 bg-white border border-blue-300 rounded">
                                    <span id="pairingCodeValue">ABC12345</span>
                                </div>
                                <div class="mt-2 text-xs text-blue-600 text-center">
                                    Vá em: WhatsApp > Dispositivos conectados > Conectar com número
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Estatísticas Rápidas -->
            <div class="space-y-6">
                <!-- Estatísticas -->
                <div class="bg-white rounded-lg shadow">
                    <div class="px-6 py-4 border-b border-gray-200">
                        <h3 class="text-lg font-medium text-gray-900">Estatísticas</h3>
                    </div>
                    <div class="p-6 space-y-4">
                        <div class="flex justify-between">
                            <span class="text-sm text-gray-600">Mensagens Enviadas</span>
                            <span id="messagesSent" class="text-sm font-medium text-gray-900">0</span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-sm text-gray-600">Mensagens Recebidas</span>
                            <span id="messagesReceived" class="text-sm font-medium text-gray-900">0</span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-sm text-gray-600">Taxa de Sucesso</span>
                            <span id="successRate" class="text-sm font-medium text-gray-900">0%</span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-sm text-gray-600">Última Atividade</span>
                            <span id="lastActivity" class="text-sm font-medium text-gray-900">-</span>
                        </div>
                    </div>
                </div>

                <!-- Ações Rápidas -->
                <div class="bg-white rounded-lg shadow">
                    <div class="px-6 py-4 border-b border-gray-200">
                        <h3 class="text-lg font-medium text-gray-900">Ações Rápidas</h3>
                    </div>
                    <div class="p-6 space-y-3">
                        <button id="viewMessages" class="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 rounded-md">
                            📱 Ver Mensagens
                        </button>
                        <button id="manageRules" class="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 rounded-md">
                            ⚙️ Gerenciar Regras
                        </button>
                        <button id="viewOptins" class="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 rounded-md">
                            👥 Gerenciar Opt-ins
                        </button>
                        <button id="viewTemplates" class="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 rounded-md">
                            📝 Templates
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Mensagens Recentes -->
        <div class="mt-8">
            <div class="bg-white rounded-lg shadow">
                <div class="px-6 py-4 border-b border-gray-200">
                    <div class="flex justify-between items-center">
                        <h3 class="text-lg font-medium text-gray-900">Mensagens Recentes</h3>
                        <button id="refreshMessages" class="text-sm text-blue-600 hover:text-blue-500">
                            Atualizar
                        </button>
                    </div>
                </div>
                <div class="divide-y divide-gray-200">
                    <div id="messagesList" class="max-h-96 overflow-y-auto">
                        <!-- Mensagens serão carregadas aqui -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal de Configurações -->
<div id="settingsModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50" style="display: none;">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <div class="flex items-center justify-between mb-4">
                <h3 class="text-lg font-medium text-gray-900">Configurações WhatsApp</h3>
                <button id="closeSettingsModal" class="text-gray-400 hover:text-gray-600">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                </button>
            </div>
            <div class="space-y-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Adapter Padrão</label>
                    <select id="defaultAdapter" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                        <option value="non_official">Não-oficial</option>
                        <option value="cloud_api">Cloud API</option>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Rate Limit (msg/min)</label>
                    <input type="number" id="rateLimit" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" value="60">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Janela de Envio</label>
                    <div class="flex space-x-2">
                        <input type="time" id="sendWindowStart" class="flex-1 px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" value="09:00">
                        <span class="flex items-center text-gray-500">até</span>
                        <input type="time" id="sendWindowEnd" class="flex-1 px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" value="20:30">
                    </div>
                </div>
            </div>
            <div class="flex justify-end space-x-3 mt-6">
                <button id="saveSettings" class="px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                    Salvar
                </button>
                <button id="cancelSettings" class="px-4 py-2 bg-gray-300 text-gray-700 text-sm font-medium rounded-md hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500">
                    Cancelar
                </button>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Variáveis globais
    let currentSession = null;
    let refreshInterval = null;

    // Elementos DOM
    const connectBtn = document.getElementById('connectBtn');
    const disconnectBtn = document.getElementById('disconnectBtn');
    const connectionForm = document.getElementById('connectionForm');
    const pairingCode = document.getElementById('pairingCode');
    const phoneNumber = document.getElementById('phoneNumber');
    const adapterType = document.getElementById('adapterType');
    const startConnection = document.getElementById('startConnection');
    const cancelConnection = document.getElementById('cancelConnection');
    const refreshStatus = document.getElementById('refreshStatus');
    const refreshMessages = document.getElementById('refreshMessages');
    const messagesList = document.getElementById('messagesList');

    // Inicializar
    loadWhatsAppStatus();
    loadMessages();
    startAutoRefresh();

    // Event Listeners
    connectBtn.addEventListener('click', showConnectionForm);
    disconnectBtn.addEventListener('click', disconnectWhatsApp);
    startConnection.addEventListener('click', startWhatsAppConnection);
    cancelConnection.addEventListener('click', hideConnectionForm);
    refreshStatus.addEventListener('click', loadWhatsAppStatus);
    refreshMessages.addEventListener('click', loadMessages);

    // Funções
    function showConnectionForm() {
        connectionForm.style.display = 'block';
        connectBtn.style.display = 'none';
    }

    function hideConnectionForm() {
        connectionForm.style.display = 'none';
        connectBtn.style.display = 'inline-flex';
        pairingCode.style.display = 'none';
    }

    function startWhatsAppConnection() {
        const phone = phoneNumber.value.trim();
        const adapter = adapterType.value;

        if (!phone) {
            alert('Por favor, insira o número do WhatsApp');
            return;
        }

        startConnection.disabled = true;
        startConnection.textContent = 'Conectando...';

        fetch('/api/whatsapp/connect', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
            },
            body: JSON.stringify({
                loja_id: 1,
                phone: phone,
                adapter: adapter
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                currentSession = data.session_id;
                
                if (data.pairing_code) {
                    document.getElementById('pairingCodeValue').textContent = data.pairing_code;
                    pairingCode.style.display = 'block';
                }
                
                hideConnectionForm();
                loadWhatsAppStatus();
            } else {
                alert('Erro ao conectar: ' + (data.message || data.error));
            }
        })
        .catch(error => {
            console.error('Erro:', error);
            alert('Erro ao conectar WhatsApp');
        })
        .finally(() => {
            startConnection.disabled = false;
            startConnection.textContent = 'Iniciar Conexão';
        });
    }

    function disconnectWhatsApp() {
        if (confirm('Tem certeza que deseja desconectar o WhatsApp?')) {
            // Implementar desconexão
            loadWhatsAppStatus();
        }
    }

    function loadWhatsAppStatus() {
        fetch('/api/whatsapp/sessions?loja_id=1')
        .then(response => response.json())
        .then(data => {
            if (data.success && data.sessions.length > 0) {
                const session = data.sessions[0];
                updateConnectionStatus(session);
                currentSession = session.id;
            } else {
                updateConnectionStatus(null);
                currentSession = null;
            }
        })
        .catch(error => {
            console.error('Erro ao carregar status:', error);
        });
    }

    function updateConnectionStatus(session) {
        const statusIndicator = document.getElementById('connectionStatusIndicator');
        const statusText = document.getElementById('connectionStatusText');
        const connectionStatus = document.getElementById('connectionStatus');
        const connectionStatusText = document.getElementById('connectionStatusText');

        if (session && session.status === 'connected') {
            statusIndicator.className = 'w-3 h-3 rounded-full bg-green-400 mr-3';
            statusText.textContent = 'Conectado';
            connectionStatus.className = 'w-3 h-3 rounded-full bg-green-400';
            connectionStatusText.textContent = 'Conectado';
            connectBtn.style.display = 'none';
            disconnectBtn.style.display = 'inline-flex';
        } else {
            statusIndicator.className = 'w-3 h-3 rounded-full bg-gray-400 mr-3';
            statusText.textContent = 'Desconectado';
            connectionStatus.className = 'w-3 h-3 rounded-full bg-gray-400';
            connectionStatusText.textContent = 'Desconectado';
            connectBtn.style.display = 'inline-flex';
            disconnectBtn.style.display = 'none';
        }
    }

    function loadMessages() {
        if (!currentSession) {
            messagesList.innerHTML = '<div class="p-4 text-center text-gray-500">Nenhuma sessão ativa</div>';
            return;
        }

        fetch(`/api/whatsapp/messages?session_id=${currentSession}&limit=10`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                displayMessages(data.messages);
            }
        })
        .catch(error => {
            console.error('Erro ao carregar mensagens:', error);
        });
    }

    function displayMessages(messages) {
        if (messages.length === 0) {
            messagesList.innerHTML = '<div class="p-4 text-center text-gray-500">Nenhuma mensagem encontrada</div>';
            return;
        }

        messagesList.innerHTML = messages.map(message => `
            <div class="p-4 hover:bg-gray-50">
                <div class="flex items-start space-x-3">
                    <div class="flex-shrink-0">
                        <div class="w-8 h-8 rounded-full ${message.direction === 'IN' ? 'bg-green-100' : 'bg-blue-100'} flex items-center justify-center">
                            <span class="text-xs font-medium ${message.direction === 'IN' ? 'text-green-600' : 'text-blue-600'}">
                                ${message.direction === 'IN' ? 'IN' : 'OUT'}
                            </span>
                        </div>
                    </div>
                    <div class="flex-1 min-w-0">
                        <div class="flex items-center justify-between">
                            <p class="text-sm font-medium text-gray-900">${message.peer}</p>
                            <p class="text-xs text-gray-500">${new Date(message.created_at).toLocaleString()}</p>
                        </div>
                        <p class="text-sm text-gray-600 mt-1">${message.content}</p>
                        <div class="flex items-center mt-2 space-x-2">
                            <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(message.status)}">
                                ${getStatusText(message.status)}
                            </span>
                            <span class="text-xs text-gray-500">${message.type}</span>
                        </div>
                    </div>
                </div>
            </div>
        `).join('');
    }

    function getStatusColor(status) {
        const colors = {
            'queued': 'bg-yellow-100 text-yellow-800',
            'sent': 'bg-blue-100 text-blue-800',
            'delivered': 'bg-green-100 text-green-800',
            'read': 'bg-purple-100 text-purple-800',
            'failed': 'bg-red-100 text-red-800'
        };
        return colors[status] || 'bg-gray-100 text-gray-800';
    }

    function getStatusText(status) {
        const texts = {
            'queued': 'Na fila',
            'sent': 'Enviado',
            'delivered': 'Entregue',
            'read': 'Lido',
            'failed': 'Falhou'
        };
        return texts[status] || status;
    }

    function startAutoRefresh() {
        refreshInterval = setInterval(() => {
            loadWhatsAppStatus();
            if (currentSession) {
                loadMessages();
            }
        }, 30000); // Atualizar a cada 30 segundos
    }

    // Carregar estatísticas
    function loadStats() {
        fetch('/api/whatsapp/stats?loja_id=1')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const stats = data.stats;
                document.getElementById('messagesToday').textContent = stats.messages.total || 0;
                document.getElementById('deliveryRate').textContent = calculateDeliveryRate(stats.messages) + '%';
                document.getElementById('optInsCount').textContent = stats.optins.opted_in || 0;
                document.getElementById('messagesSent').textContent = stats.messages.sent || 0;
                document.getElementById('messagesReceived').textContent = stats.messages.total - stats.messages.sent || 0;
                document.getElementById('successRate').textContent = calculateSuccessRate(stats.messages) + '%';
            }
        })
        .catch(error => {
            console.error('Erro ao carregar estatísticas:', error);
        });
    }

    function calculateDeliveryRate(messages) {
        if (!messages.delivered || !messages.sent) return 0;
        return Math.round((messages.delivered / messages.sent) * 100);
    }

    function calculateSuccessRate(messages) {
        if (!messages.sent || !messages.total) return 0;
        return Math.round((messages.sent / messages.total) * 100);
    }

    // Carregar estatísticas na inicialização
    loadStats();
});
</script>
@endsection
