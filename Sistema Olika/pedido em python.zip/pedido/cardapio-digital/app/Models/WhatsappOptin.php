<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WhatsappOptin extends Model
{
    use HasFactory;

    protected $fillable = [
        'loja_id',
        'phone',
        'opted_in_at',
        'opted_out_at',
        'source',
        'notes',
    ];

    protected $casts = [
        'opted_in_at' => 'datetime',
        'opted_out_at' => 'datetime',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    /**
     * Verificar se o usuário optou por receber mensagens
     */
    public function hasOptedIn(): bool
    {
        return !is_null($this->opted_in_at) && is_null($this->opted_out_at);
    }

    /**
     * Verificar se o usuário optou por não receber mensagens
     */
    public function hasOptedOut(): bool
    {
        return !is_null($this->opted_out_at);
    }

    /**
     * Verificar se o usuário pode receber mensagens
     */
    public function canReceiveMessages(): bool
    {
        return $this->hasOptedIn();
    }

    /**
     * Registrar opt-in
     */
    public function optIn(string $source = 'manual', ?string $notes = null): void
    {
        $this->update([
            'opted_in_at' => now(),
            'opted_out_at' => null,
            'source' => $source,
            'notes' => $notes,
        ]);
    }

    /**
     * Registrar opt-out
     */
    public function optOut(?string $notes = null): void
    {
        $this->update([
            'opted_out_at' => now(),
            'notes' => $notes,
        ]);
    }

    /**
     * Scope para usuários que optaram por receber mensagens
     */
    public function scopeOptedIn($query)
    {
        return $query->whereNotNull('opted_in_at')
                    ->whereNull('opted_out_at');
    }

    /**
     * Scope para usuários que optaram por não receber mensagens
     */
    public function scopeOptedOut($query)
    {
        return $query->whereNotNull('opted_out_at');
    }

    /**
     * Scope para uma loja específica
     */
    public function scopeLoja($query, int $lojaId)
    {
        return $query->where('loja_id', $lojaId);
    }

    /**
     * Scope para um telefone específico
     */
    public function scopePhone($query, string $phone)
    {
        return $query->where('phone', $phone);
    }

    /**
     * Scope para uma fonte específica
     */
    public function scopeSource($query, string $source)
    {
        return $query->where('source', $source);
    }

    /**
     * Buscar ou criar opt-in para um telefone
     */
    public static function findOrCreate(int $lojaId, string $phone, string $source = 'manual'): self
    {
        return static::firstOrCreate(
            ['loja_id' => $lojaId, 'phone' => $phone],
            ['source' => $source]
        );
    }

    /**
     * Verificar se um telefone pode receber mensagens
     */
    public static function canReceiveMessages(int $lojaId, string $phone): bool
    {
        $optin = static::where('loja_id', $lojaId)
                      ->where('phone', $phone)
                      ->first();
                      
        return $optin ? $optin->canReceiveMessages() : false;
    }

    /**
     * Obter estatísticas de opt-ins
     */
    public static function getStats(int $lojaId): array
    {
        $total = static::where('loja_id', $lojaId)->count();
        $optedIn = static::where('loja_id', $lojaId)->optedIn()->count();
        $optedOut = static::where('loja_id', $lojaId)->optedOut()->count();
        
        return [
            'total' => $total,
            'opted_in' => $optedIn,
            'opted_out' => $optedOut,
            'opt_in_rate' => $total > 0 ? round(($optedIn / $total) * 100, 2) : 0,
        ];
    }
}
