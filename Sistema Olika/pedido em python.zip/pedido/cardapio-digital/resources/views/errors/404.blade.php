<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404 - Página não encontrada | {{ config('app.name') }}</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="bg-background antialiased">
    <div class="min-h-screen flex items-center justify-center px-4">
        <div class="text-center max-w-2xl">
            <!-- Ilustração 404 -->
            <div class="mb-8 relative">
                <svg class="mx-auto h-64 w-64 text-muted-foreground/30" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <circle cx="12" cy="12" r="10" stroke-width="0.5" fill="currentColor" opacity="0.1"/>
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <div class="absolute inset-0 flex items-center justify-center">
                    <svg class="w-24 h-24 text-primary animate-bounce" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                    </svg>
                </div>
            </div>

            <h1 class="text-6xl md:text-8xl font-bold text-primary mb-4 animate-pulse">404</h1>
            <h2 class="text-2xl md:text-3xl font-semibold mb-4">Ops! Página não encontrada</h2>
            <p class="text-muted-foreground mb-8 text-lg">
                Parece que você se perdeu no cardápio... 🍕<br>
                A página que você está procurando não existe ou foi movida.
            </p>

            <div class="space-y-4">
                <div class="flex flex-col sm:flex-row gap-4 justify-center">
                    <a href="/" class="inline-flex items-center justify-center px-6 py-3 bg-primary text-white rounded-lg hover:bg-primary/90 transition shadow-lg hover:shadow-xl transform hover:-translate-y-0.5">
                        <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
                        </svg>
                        Voltar ao Cardápio
                    </a>
                    
                    <a href="/busca" class="inline-flex items-center justify-center px-6 py-3 border-2 border-primary text-primary rounded-lg hover:bg-primary/10 transition">
                        <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                        </svg>
                        Buscar Produtos
                    </a>
                </div>

                <!-- Sugestões -->
                <div class="mt-16">
                    <h3 class="text-lg font-semibold mb-6 text-foreground">Que tal explorar nossas categorias:</h3>
                    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-3xl mx-auto">
                        @php
                            $categories = \App\Models\Category::where('active', true)->take(4)->get();
                        @endphp
                        
                        @forelse($categories as $category)
                            <a href="/categoria/{{ $category->slug }}" class="group p-6 border-2 rounded-lg hover:border-primary hover:shadow-lg transition transform hover:-translate-y-1 bg-card">
                                <div class="text-4xl mb-3 group-hover:scale-110 transition-transform">
                                    {{ $category->icon ?? '🍴' }}
                                </div>
                                <p class="font-medium group-hover:text-primary transition">{{ $category->name }}</p>
                                <p class="text-xs text-muted-foreground mt-1">
                                    {{ $category->products_count ?? 0 }} produtos
                                </p>
                            </a>
                        @empty
                            <a href="/" class="col-span-full p-6 border-2 rounded-lg hover:border-primary hover:shadow-lg transition bg-card">
                                <div class="text-4xl mb-3">🍕</div>
                                <p class="font-medium">Ver Todo Cardápio</p>
                            </a>
                        @endforelse
                    </div>
                </div>

                <!-- Produtos em Destaque -->
                @php
                    $featuredProducts = \App\Models\Product::where('available', true)
                        ->where('featured', true)
                        ->take(3)
                        ->get();
                @endphp
                
                @if($featuredProducts->count() > 0)
                    <div class="mt-16">
                        <h3 class="text-lg font-semibold mb-6 text-foreground">Produtos em Destaque:</h3>
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
                            @foreach($featuredProducts as $product)
                                <a href="/produto/{{ $product->id }}" class="group border rounded-lg overflow-hidden hover:shadow-xl transition transform hover:-translate-y-1 bg-card">
                                    @if($product->image)
                                        <img src="{{ $product->image }}" alt="{{ $product->name }}" class="w-full h-40 object-cover group-hover:scale-105 transition-transform" />
                                    @else
                                        <div class="w-full h-40 bg-muted flex items-center justify-center text-4xl">
                                            🍽️
                                        </div>
                                    @endif
                                    <div class="p-4">
                                        <h4 class="font-medium group-hover:text-primary transition mb-1">{{ $product->name }}</h4>
                                        <p class="text-sm text-muted-foreground mb-2 line-clamp-2">{{ $product->description }}</p>
                                        <p class="text-lg font-bold text-primary">R$ {{ number_format($product->price, 2, ',', '.') }}</p>
                                    </div>
                                </a>
                            @endforeach
                        </div>
                    </div>
                @endif

                <!-- Informações de Contato -->
                <div class="mt-16 p-6 bg-muted/50 rounded-lg">
                    <p class="text-sm text-muted-foreground mb-4">
                        Se você acredita que isso é um erro, entre em contato conosco:
                    </p>
                    <div class="flex flex-wrap justify-center gap-4">
                        @if($whatsapp = config('app.whatsapp'))
                            <a href="https://wa.me/{{ preg_replace('/\D/', '', $whatsapp) }}" target="_blank" class="inline-flex items-center text-sm text-primary hover:underline">
                                <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 24 24">
                                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                                </svg>
                                WhatsApp
                            </a>
                        @endif
                        
                        @if($email = config('app.support_email'))
                            <a href="mailto:{{ $email }}" class="inline-flex items-center text-sm text-primary hover:underline">
                                <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                                </svg>
                                E-mail
                            </a>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Toast Container (se necessário) -->
    @include('components.ui.toast')
</body>
</html>

