import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { toast } from "sonner";
import { Lock } from "lucide-react";

const DashboardLogin = () => {
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    
    const savedPassword = localStorage.getItem("dashboardPassword") || "admin123";
    
    if (password === savedPassword) {
      sessionStorage.setItem("dashboardAuth", "true");
      toast.success("Acesso autorizado");
      navigate("/dashboard");
    } else {
      toast.error("Senha incorreta");
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
            <Lock className="h-6 w-6 text-primary" />
          </div>
          <CardTitle>Dashboard - Acesso Restrito</CardTitle>
          <CardDescription>
            Digite a senha para acessar o painel administrativo
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <Label htmlFor="password">Senha</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Digite a senha"
                autoFocus
              />
              <p className="text-xs text-muted-foreground mt-2">
                Senha padrão: admin123
              </p>
            </div>
            <Button type="submit" className="w-full">
              Acessar Dashboard
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default DashboardLogin;