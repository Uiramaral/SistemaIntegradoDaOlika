<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // View: Conversas ativas com última mensagem
        DB::statement("
            CREATE VIEW v_conversas_ativas AS
            SELECT 
                cs.id,
                cs.cliente_id,
                cs.subscriber_id,
                cs.telefone,
                cs.nome,
                cs.status,
                cs.assunto,
                cs.created_at,
                cs.updated_at,
                c.name as cliente_nome,
                c.email as cliente_email,
                (SELECT COUNT(*) FROM mensagens_suporte ms WHERE ms.conversa_id = cs.id) as total_mensagens,
                (SELECT ms.conteudo FROM mensagens_suporte ms WHERE ms.conversa_id = cs.id ORDER BY ms.created_at DESC LIMIT 1) as ultima_mensagem,
                (SELECT ms.role FROM mensagens_suporte ms WHERE ms.conversa_id = cs.id ORDER BY ms.created_at DESC LIMIT 1) as ultima_mensagem_role,
                (SELECT ms.created_at FROM mensagens_suporte ms WHERE ms.conversa_id = cs.id ORDER BY ms.created_at DESC LIMIT 1) as ultima_mensagem_data,
                (SELECT SUM(ms.tokens_total) FROM mensagens_suporte ms WHERE ms.conversa_id = cs.id) as total_tokens,
                (SELECT SUM(ms.custo_estimado) FROM mensagens_suporte ms WHERE ms.conversa_id = cs.id) as custo_total
            FROM conversas_suporte cs
            LEFT JOIN customers c ON c.id = cs.cliente_id
            WHERE cs.status = 'ativa'
            ORDER BY cs.updated_at DESC
        ");

        // View: Estatísticas por subscriber
        DB::statement("
            CREATE VIEW v_estatisticas_subscribers AS
            SELECT 
                cs.subscriber_id,
                cs.telefone,
                cs.nome,
                COUNT(DISTINCT cs.id) as total_conversas,
                COUNT(ms.id) as total_mensagens,
                SUM(ms.tokens_total) as total_tokens,
                SUM(ms.custo_estimado) as custo_total,
                AVG(ms.tokens_total) as media_tokens_por_mensagem,
                AVG(ms.custo_estimado) as media_custo_por_mensagem,
                MAX(cs.created_at) as primeira_conversa,
                MAX(cs.updated_at) as ultima_atividade,
                GROUP_CONCAT(DISTINCT cs.assunto) as assuntos_abordados
            FROM conversas_suporte cs
            LEFT JOIN mensagens_suporte ms ON ms.conversa_id = cs.id
            WHERE cs.subscriber_id IS NOT NULL
            GROUP BY cs.subscriber_id, cs.telefone, cs.nome
            ORDER BY total_mensagens DESC
        ");

        // View: Estatísticas de tokens
        DB::statement("
            CREATE VIEW v_estatisticas_tokens AS
            SELECT 
                DATE(ms.created_at) as data,
                COUNT(*) as total_mensagens,
                SUM(ms.tokens_prompt) as tokens_prompt,
                SUM(ms.tokens_completion) as tokens_completion,
                SUM(ms.tokens_total) as tokens_total,
                SUM(ms.custo_estimado) as custo_total,
                AVG(ms.tokens_total) as media_tokens_por_mensagem,
                AVG(ms.custo_estimado) as media_custo_por_mensagem,
                COUNT(DISTINCT ms.conversa_id) as conversas_ativas,
                ms.model_usado
            FROM mensagens_suporte ms
            WHERE ms.role = 'assistant'
            GROUP BY DATE(ms.created_at), ms.model_usado
            ORDER BY data DESC
        ");

        // View: Custos por conversa
        DB::statement("
            CREATE VIEW v_custos_por_conversa AS
            SELECT 
                cs.id as conversa_id,
                cs.subscriber_id,
                cs.telefone,
                cs.nome,
                cs.assunto,
                cs.created_at as inicio_conversa,
                cs.updated_at as ultima_atividade,
                COUNT(ms.id) as total_mensagens,
                SUM(ms.tokens_total) as total_tokens,
                SUM(ms.custo_estimado) as custo_total,
                AVG(ms.tokens_total) as media_tokens_por_mensagem,
                AVG(ms.custo_estimado) as media_custo_por_mensagem,
                DATEDIFF(cs.updated_at, cs.created_at) as dias_duracao,
                TIMESTAMPDIFF(MINUTE, cs.created_at, cs.updated_at) as minutos_duracao
            FROM conversas_suporte cs
            LEFT JOIN mensagens_suporte ms ON ms.conversa_id = cs.id AND ms.role = 'assistant'
            GROUP BY cs.id, cs.subscriber_id, cs.telefone, cs.nome, cs.assunto, cs.created_at, cs.updated_at
            ORDER BY custo_total DESC
        ");

        // View: Performance por assunto
        DB::statement("
            CREATE VIEW v_performance_por_assunto AS
            SELECT 
                cs.assunto,
                COUNT(DISTINCT cs.id) as total_conversas,
                COUNT(ms.id) as total_mensagens,
                SUM(ms.tokens_total) as total_tokens,
                SUM(ms.custo_estimado) as custo_total,
                AVG(ms.tokens_total) as media_tokens_por_mensagem,
                AVG(ms.custo_estimado) as media_custo_por_mensagem,
                AVG(TIMESTAMPDIFF(MINUTE, cs.created_at, cs.updated_at)) as media_duracao_minutos,
                COUNT(CASE WHEN ms.classificacao->>'intencao' = 'resolvido' THEN 1 END) as conversas_resolvidas,
                ROUND(COUNT(CASE WHEN ms.classificacao->>'intencao' = 'resolvido' THEN 1 END) / COUNT(DISTINCT cs.id) * 100, 2) as taxa_resolucao
            FROM conversas_suporte cs
            LEFT JOIN mensagens_suporte ms ON ms.conversa_id = cs.id
            WHERE cs.assunto IS NOT NULL
            GROUP BY cs.assunto
            ORDER BY total_conversas DESC
        ");

        // View: Métricas de performance da IA
        DB::statement("
            CREATE VIEW v_metricas_ia AS
            SELECT 
                DATE(ms.created_at) as data,
                ms.model_usado,
                COUNT(*) as total_mensagens,
                AVG(ms.tokens_total) as media_tokens,
                AVG(ms.custo_estimado) as media_custo,
                SUM(ms.tokens_total) as total_tokens,
                SUM(ms.custo_estimado) as custo_total,
                AVG(JSON_EXTRACT(ms.classificacao, '$.confianca')) as media_confianca,
                COUNT(CASE WHEN JSON_EXTRACT(ms.classificacao, '$.confianca') >= 0.8 THEN 1 END) as mensagens_alta_confianca,
                COUNT(CASE WHEN JSON_EXTRACT(ms.classificacao, '$.confianca') < 0.8 THEN 1 END) as mensagens_baixa_confianca,
                ROUND(COUNT(CASE WHEN JSON_EXTRACT(ms.classificacao, '$.confianca') >= 0.8 THEN 1 END) / COUNT(*) * 100, 2) as taxa_sucesso
            FROM mensagens_suporte ms
            WHERE ms.role = 'assistant' AND ms.classificacao IS NOT NULL
            GROUP BY DATE(ms.created_at), ms.model_usado
            ORDER BY data DESC
        ");

        // View: Análise de sentimentos
        DB::statement("
            CREATE VIEW v_analise_sentimentos AS
            SELECT 
                JSON_EXTRACT(ms.classificacao, '$.sentimento') as sentimento,
                JSON_EXTRACT(ms.classificacao, '$.urgencia') as urgencia,
                JSON_EXTRACT(ms.classificacao, '$.intencao') as intencao,
                COUNT(*) as total_mensagens,
                AVG(JSON_EXTRACT(ms.classificacao, '$.confianca')) as media_confianca,
                SUM(ms.tokens_total) as total_tokens,
                SUM(ms.custo_estimado) as custo_total,
                DATE(ms.created_at) as data
            FROM mensagens_suporte ms
            WHERE ms.role = 'user' AND ms.classificacao IS NOT NULL
            GROUP BY 
                JSON_EXTRACT(ms.classificacao, '$.sentimento'),
                JSON_EXTRACT(ms.classificacao, '$.urgencia'),
                JSON_EXTRACT(ms.classificacao, '$.intencao'),
                DATE(ms.created_at)
            ORDER BY data DESC, total_mensagens DESC
        ");
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        DB::statement('DROP VIEW IF EXISTS v_conversas_ativas');
        DB::statement('DROP VIEW IF EXISTS v_estatisticas_subscribers');
        DB::statement('DROP VIEW IF EXISTS v_estatisticas_tokens');
        DB::statement('DROP VIEW IF EXISTS v_custos_por_conversa');
        DB::statement('DROP VIEW IF EXISTS v_performance_por_assunto');
        DB::statement('DROP VIEW IF EXISTS v_metricas_ia');
        DB::statement('DROP VIEW IF EXISTS v_analise_sentimentos');
    }
};
