<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use App\Models\WhatsappSession;
use App\Models\WhatsappMessage;
use App\Models\WhatsappOptin;

class WhatsappWebhookController extends Controller
{
    /**
     * Webhook do gateway não-oficial
     * POST /api/whatsapp/webhook/gateway
     */
    public function gateway(Request $request): JsonResponse
    {
        try {
            // Verificar assinatura do webhook se configurado
            $webhookSecret = config('services.whatsapp_gateway.webhook_secret');
            if ($webhookSecret && !$this->verifyWebhookSignature($request, $webhookSecret)) {
                Log::warning('Webhook signature inválida', [
                    'ip' => $request->ip(),
                    'user_agent' => $request->userAgent()
                ]);
                return response()->json(['error' => 'Unauthorized'], 401);
            }

            $event = $request->all();
            Log::info('Webhook gateway recebido', $event);

            $eventType = $event['type'] ?? null;
            $sessionId = $event['session_id'] ?? null;

            switch ($eventType) {
                case 'message_received':
                    $this->handleMessageReceived($event);
                    break;
                
                case 'message_status':
                    $this->handleMessageStatus($event);
                    break;
                
                case 'session_status':
                    $this->handleSessionStatus($event);
                    break;
                
                default:
                    Log::info('Tipo de evento não tratado', ['type' => $eventType]);
            }

            return response()->json(['received' => true]);

        } catch (\Exception $e) {
            Log::error('Erro ao processar webhook gateway', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);

            return response()->json(['error' => 'Internal server error'], 500);
        }
    }

    /**
     * Verificação do webhook Cloud API (GET)
     * GET /api/whatsapp/webhook/cloud
     */
    public function cloudVerify(Request $request): JsonResponse
    {
        $mode = $request->input('hub_mode');
        $token = $request->input('hub_verify_token');
        $challenge = $request->input('hub_challenge');

        $verifyToken = env('WHATS_CLOUD_WEBHOOK_VERIFY_TOKEN');

        if ($mode === 'subscribe' && $token === $verifyToken) {
            Log::info('Webhook Cloud API verificado com sucesso');
            return response($challenge, 200);
        }

        Log::warning('Falha na verificação do webhook Cloud API', [
            'mode' => $mode,
            'token' => $token,
            'expected_token' => $verifyToken
        ]);

        return response('Forbidden', 403);
    }

    /**
     * Webhook Cloud API (POST)
     * POST /api/whatsapp/webhook/cloud
     */
    public function cloud(Request $request): JsonResponse
    {
        try {
            $payload = $request->all();
            Log::info('Webhook Cloud API recebido', $payload);

            // Verificar se é um evento válido
            if (!isset($payload['entry']) || !is_array($payload['entry'])) {
                return response()->json(['ok' => true]);
            }

            foreach ($payload['entry'] as $entry) {
                $this->processCloudEntry($entry);
            }

            return response()->json(['ok' => true]);

        } catch (\Exception $e) {
            Log::error('Erro ao processar webhook Cloud API', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);

            return response()->json(['error' => 'Internal server error'], 500);
        }
    }

    /**
     * Processar entrada do Cloud API
     */
    private function processCloudEntry(array $entry): void
    {
        $changes = $entry['changes'] ?? [];
        
        foreach ($changes as $change) {
            $value = $change['value'] ?? [];
            
            // Processar mensagens recebidas
            if (isset($value['messages'])) {
                $this->processCloudMessages($value['messages'], $value);
            }
            
            // Processar status de mensagens
            if (isset($value['statuses'])) {
                $this->processCloudStatuses($value['statuses'], $value);
            }
        }
    }

    /**
     * Processar mensagens do Cloud API
     */
    private function processCloudMessages(array $messages, array $value): void
    {
        $phoneNumberId = $value['metadata']['phone_number_id'] ?? null;
        
        if (!$phoneNumberId) {
            Log::warning('Phone number ID não encontrado nas mensagens do Cloud API');
            return;
        }

        // Buscar sessão pelo phone number ID
        $session = WhatsappSession::where('instance_id', $phoneNumberId)
            ->where('adapter', 'cloud_api')
            ->first();

        if (!$session) {
            Log::warning('Sessão não encontrada para phone number ID', ['phone_number_id' => $phoneNumberId]);
            return;
        }

        foreach ($messages as $message) {
            $this->handleCloudMessage($session, $message);
        }
    }

    /**
     * Processar status do Cloud API
     */
    private function processCloudStatuses(array $statuses, array $value): void
    {
        $phoneNumberId = $value['metadata']['phone_number_id'] ?? null;
        
        if (!$phoneNumberId) {
            Log::warning('Phone number ID não encontrado nos status do Cloud API');
            return;
        }

        // Buscar sessão pelo phone number ID
        $session = WhatsappSession::where('instance_id', $phoneNumberId)
            ->where('adapter', 'cloud_api')
            ->first();

        if (!$session) {
            Log::warning('Sessão não encontrada para phone number ID', ['phone_number_id' => $phoneNumberId]);
            return;
        }

        foreach ($statuses as $status) {
            $this->handleCloudStatus($session, $status);
        }
    }

    /**
     * Processar mensagem do Cloud API
     */
    private function handleCloudMessage(WhatsappSession $session, array $message): void
    {
        $from = $message['from'] ?? '';
        $messageId = $message['id'] ?? '';
        $type = $message['type'] ?? 'text';
        $timestamp = $message['timestamp'] ?? time();

        $bodyText = null;
        $mediaUrl = null;

        switch ($type) {
            case 'text':
                $bodyText = $message['text']['body'] ?? '';
                break;
            case 'image':
                $bodyText = $message['image']['caption'] ?? '';
                $mediaUrl = $message['image']['id'] ?? '';
                break;
            case 'document':
                $bodyText = $message['document']['caption'] ?? '';
                $mediaUrl = $message['document']['id'] ?? '';
                break;
        }

        // Salvar mensagem
        $session->messages()->create([
            'loja_id' => $session->loja_id,
            'direction' => 'IN',
            'peer' => $from,
            'type' => $type,
            'body_text' => $bodyText,
            'media_url' => $mediaUrl,
            'status' => 'delivered',
            'provider_msg_id' => $messageId,
            'created_at' => now()->setTimestamp($timestamp),
        ]);

        // Processar opt-out automático
        if ($bodyText && stripos($bodyText, 'sair') !== false) {
            $this->handleOptOut($session->loja_id, $from);
        }

        Log::info('Mensagem Cloud API processada', [
            'session_id' => $session->id,
            'from' => $from,
            'type' => $type
        ]);
    }

    /**
     * Processar status do Cloud API
     */
    private function handleCloudStatus(WhatsappSession $session, array $status): void
    {
        $messageId = $status['id'] ?? '';
        $statusValue = $status['status'] ?? '';
        $timestamp = $status['timestamp'] ?? time();

        // Mapear status do Cloud API para nosso sistema
        $mappedStatus = $this->mapCloudStatus($statusValue);

        // Atualizar mensagem
        $message = WhatsappMessage::where('provider_msg_id', $messageId)
            ->where('session_id', $session->id)
            ->first();

        if ($message) {
            $message->updateStatus($mappedStatus);
        }

        Log::info('Status Cloud API processado', [
            'session_id' => $session->id,
            'message_id' => $messageId,
            'status' => $mappedStatus
        ]);
    }

    /**
     * Mapear status do Cloud API
     */
    private function mapCloudStatus(string $cloudStatus): string
    {
        $mapping = [
            'sent' => 'sent',
            'delivered' => 'delivered',
            'read' => 'read',
            'failed' => 'failed',
        ];

        return $mapping[$cloudStatus] ?? 'sent';
    }

    /**
     * Processar mensagem recebida (gateway)
     */
    private function handleMessageReceived(array $event): void
    {
        $sessionId = $event['session_id'] ?? null;
        $from = $event['from'] ?? '';
        $text = $event['text'] ?? '';
        $messageId = $event['id'] ?? '';

        if (!$sessionId) {
            Log::warning('Session ID não encontrado na mensagem recebida');
            return;
        }

        $session = WhatsappSession::find($sessionId);
        if (!$session) {
            Log::warning('Sessão não encontrada', ['session_id' => $sessionId]);
            return;
        }

        // Salvar mensagem
        $session->messages()->create([
            'loja_id' => $session->loja_id,
            'direction' => 'IN',
            'peer' => $from,
            'type' => 'text',
            'body_text' => $text,
            'status' => 'delivered',
            'provider_msg_id' => $messageId,
        ]);

        // Processar opt-out automático
        if (stripos($text, 'sair') !== false) {
            $this->handleOptOut($session->loja_id, $from);
        }

        Log::info('Mensagem recebida processada', [
            'session_id' => $sessionId,
            'from' => $from
        ]);
    }

    /**
     * Processar status de mensagem (gateway)
     */
    private function handleMessageStatus(array $event): void
    {
        $messageId = $event['message_id'] ?? '';
        $status = $event['status'] ?? '';
        $sessionId = $event['session_id'] ?? null;

        if (!$messageId || !$sessionId) {
            return;
        }

        $message = WhatsappMessage::where('provider_msg_id', $messageId)
            ->where('session_id', $sessionId)
            ->first();

        if ($message) {
            $message->updateStatus($status);
        }

        Log::info('Status de mensagem processado', [
            'message_id' => $messageId,
            'status' => $status
        ]);
    }

    /**
     * Processar status de sessão (gateway)
     */
    private function handleSessionStatus(array $event): void
    {
        $sessionId = $event['session_id'] ?? null;
        $status = $event['status'] ?? 'disconnected';

        if (!$sessionId) {
            return;
        }

        $session = WhatsappSession::find($sessionId);
        if ($session) {
            $session->updateStatus($status);
        }

        Log::info('Status de sessão processado', [
            'session_id' => $sessionId,
            'status' => $status
        ]);
    }

    /**
     * Processar opt-out automático
     */
    private function handleOptOut(int $lojaId, string $phone): void
    {
        $optin = WhatsappOptin::where('loja_id', $lojaId)
            ->where('phone', $phone)
            ->first();

        if ($optin && $optin->hasOptedIn()) {
            $optin->optOut('Opt-out automático via mensagem');
            Log::info('Opt-out automático processado', [
                'loja_id' => $lojaId,
                'phone' => $phone
            ]);
        }
    }

    /**
     * Verificar assinatura do webhook
     */
    private function verifyWebhookSignature(Request $request, string $secret): bool
    {
        $signature = $request->header('X-Hub-Signature-256');
        $payload = $request->getContent();
        
        if (!$signature) {
            return false;
        }

        $expectedSignature = 'sha256=' . hash_hmac('sha256', $payload, $secret);
        
        return hash_equals($expectedSignature, $signature);
    }
}
