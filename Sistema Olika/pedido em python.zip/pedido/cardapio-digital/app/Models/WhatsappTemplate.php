<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WhatsappTemplate extends Model
{
    use HasFactory;

    protected $fillable = [
        'loja_id',
        'name',
        'category',
        'status',
        'language',
        'body',
    ];

    protected $casts = [
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    /**
     * Verificar se o template está aprovado
     */
    public function isApproved(): bool
    {
        return $this->status === 'approved';
    }

    /**
     * Verificar se o template foi rejeitado
     */
    public function isRejected(): bool
    {
        return $this->status === 'rejected';
    }

    /**
     * Verificar se o template está em revisão
     */
    public function isInReview(): bool
    {
        return $this->status === 'in_review';
    }

    /**
     * Verificar se é template de marketing
     */
    public function isMarketing(): bool
    {
        return $this->category === 'marketing';
    }

    /**
     * Verificar se é template de utilidade
     */
    public function isUtility(): bool
    {
        return $this->category === 'utility';
    }

    /**
     * Verificar se é template de autenticação
     */
    public function isAuthentication(): bool
    {
        return $this->category === 'authentication';
    }

    /**
     * Verificar se é template de serviço
     */
    public function isService(): bool
    {
        return $this->category === 'service';
    }

    /**
     * Renderizar template com variáveis
     */
    public function render(array $vars = []): string
    {
        $content = $this->body;
        
        foreach ($vars as $index => $value) {
            $content = str_replace("{{" . ($index + 1) . "}}", $value, $content);
        }
        
        return $content;
    }

    /**
     * Obter variáveis do template
     */
    public function getVariables(): array
    {
        preg_match_all('/\{\{(\d+)\}\}/', $this->body, $matches);
        return array_map('intval', $matches[1]);
    }

    /**
     * Verificar se pode ser usado
     */
    public function canBeUsed(): bool
    {
        return $this->isApproved();
    }

    /**
     * Marcar como aprovado
     */
    public function approve(): void
    {
        $this->update(['status' => 'approved']);
    }

    /**
     * Marcar como rejeitado
     */
    public function reject(): void
    {
        $this->update(['status' => 'rejected']);
    }

    /**
     * Marcar como em revisão
     */
    public function markAsInReview(): void
    {
        $this->update(['status' => 'in_review']);
    }

    /**
     * Scope para templates aprovados
     */
    public function scopeApproved($query)
    {
        return $query->where('status', 'approved');
    }

    /**
     * Scope para templates rejeitados
     */
    public function scopeRejected($query)
    {
        return $query->where('status', 'rejected');
    }

    /**
     * Scope para templates em revisão
     */
    public function scopeInReview($query)
    {
        return $query->where('status', 'in_review');
    }

    /**
     * Scope para uma categoria específica
     */
    public function scopeCategory($query, string $category)
    {
        return $query->where('category', $category);
    }

    /**
     * Scope para uma loja específica
     */
    public function scopeLoja($query, int $lojaId)
    {
        return $query->where('loja_id', $lojaId);
    }

    /**
     * Scope para um idioma específico
     */
    public function scopeLanguage($query, string $language)
    {
        return $query->where('language', $language);
    }

    /**
     * Buscar template por nome
     */
    public static function findByName(int $lojaId, string $name): ?self
    {
        return static::where('loja_id', $lojaId)
                    ->where('name', $name)
                    ->first();
    }

    /**
     * Obter estatísticas dos templates
     */
    public static function getStats(int $lojaId): array
    {
        $total = static::where('loja_id', $lojaId)->count();
        $approved = static::where('loja_id', $lojaId)->approved()->count();
        $rejected = static::where('loja_id', $lojaId)->rejected()->count();
        $inReview = static::where('loja_id', $lojaId)->inReview()->count();
        
        return [
            'total' => $total,
            'approved' => $approved,
            'rejected' => $rejected,
            'in_review' => $inReview,
            'approval_rate' => $total > 0 ? round(($approved / $total) * 100, 2) : 0,
        ];
    }
}
