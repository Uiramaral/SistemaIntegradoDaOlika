# 🌐 **CONFIGURAÇÃO HOSTGATOR - CARDÁPIO DIGITAL OLIKA**

## 🎯 **Guia Completo para Hostgator + phpMyAdmin**

### 📋 **Passo 1: Acessar o cPanel**

1. Faça login na sua conta Hostgator
2. Acesse o **cPanel**
3. Procure por **"phpMyAdmin"**
4. Clique para abrir

### 📋 **Passo 2: Criar Banco de Dados**

#### **Opção A: Via cPanel (Recomendado)**
1. No cPanel, vá em **"Bancos de Dados MySQL"**
2. Crie um novo banco: `cardapio_digital`
3. Anote o nome completo (geralmente: `seu_usuario_cardapio_digital`)

#### **Opção B: Via phpMyAdmin**
1. No phpMyAdmin, clique em **"Novo"**
2. Nome do banco: `cardapio_digital`
3. Collation: `utf8mb4_unicode_ci`
4. Clique em **"Criar"**

### 📋 **Passo 3: Criar Usuário do Banco**

1. No cPanel, vá em **"Usuários MySQL"**
2. Crie um usuário (ex: `cardapio_user`)
3. Defina uma senha forte
4. Adicione o usuário ao banco `cardapio_digital`
5. Dê todas as permissões

### 📋 **Passo 4: Importar Estrutura SQL**

#### **Via phpMyAdmin:**
1. Selecione o banco `cardapio_digital`
2. Vá na aba **"Importar"**
3. Clique em **"Escolher arquivo"**
4. Selecione: `database/cardapio_digital.sql`
5. Clique em **"Executar"**

#### **Via cPanel File Manager:**
1. Faça upload do arquivo `cardapio_digital.sql`
2. No phpMyAdmin, vá em **"Importar"**
3. Selecione o arquivo e execute

### 📋 **Passo 5: Configurar Laravel**

#### **Arquivo `.env`:**
```env
# ============================================
# CONFIGURAÇÃO HOSTGATOR
# ============================================
APP_NAME="Cardápio Digital Olika"
APP_ENV=production
APP_DEBUG=false
APP_URL=https://seudominio.com

# ============================================
# BANCO DE DADOS HOSTGATOR
# ============================================
DB_CONNECTION=mysql
DB_HOST=localhost
DB_PORT=3306
DB_DATABASE=seu_usuario_cardapio_digital
DB_USERNAME=seu_usuario_mysql
DB_PASSWORD=sua_senha_mysql

# ============================================
# CONFIGURAÇÕES HOSTGATOR
# ============================================
CACHE_DRIVER=file
SESSION_DRIVER=file
QUEUE_CONNECTION=sync

# ============================================
# INTEGRAÇÕES
# ============================================
MERCADOPAGO_ACCESS_TOKEN=seu_token_producao
MERCADOPAGO_PUBLIC_KEY=sua_public_key_producao
WHATSAPP_API_URL=https://sua-api-whatsapp.com
GOOGLE_MAPS_API_KEY=sua_chave_google_maps
```

### 📋 **Passo 6: Upload dos Arquivos**

#### **Via cPanel File Manager:**
1. Acesse **"Gerenciador de Arquivos"**
2. Vá para a pasta `public_html`
3. Faça upload de todos os arquivos do projeto
4. Extraia se necessário

#### **Via FTP:**
```bash
# Configurações FTP Hostgator
Host: ftp.seudominio.com
Usuário: seu_usuario_ftp
Senha: sua_senha_ftp
Porta: 21
```

### 📋 **Passo 7: Configurar Permissões**

No cPanel File Manager:
1. Selecione a pasta `storage`
2. Clique com botão direito
3. **"Permissões"**
4. Marque: **755** ou **777**
5. Repita para `bootstrap/cache`

### 📋 **Passo 8: Configurar Domínio**

1. No cPanel, vá em **"Subdomínios"**
2. Crie um subdomínio (ex: `admin.seudominio.com`)
3. Ou use o domínio principal

### 📋 **Passo 9: Testar Instalação**

1. Acesse seu domínio
2. Deve aparecer o menu público
3. Acesse `/dashboard` para o admin
4. Teste as funcionalidades

---

## 🔧 **Configurações Específicas Hostgator**

### **📁 Estrutura de Pastas:**
```
public_html/
├── cardapio-digital/          # Seu projeto
│   ├── app/
│   ├── database/
│   ├── resources/
│   ├── routes/
│   ├── public/               # Ponto de entrada
│   └── .env
├── index.html                # Página inicial
└── outros_arquivos/
```

### **🌐 Configuração de Domínio:**

#### **Opção A: Subdomínio**
```
admin.seudominio.com → /public_html/cardapio-digital/public
```

#### **Opção B: Pasta**
```
seudominio.com/cardapio → /public_html/cardapio-digital/public
```

#### **Opção C: Domínio Principal**
```
seudominio.com → /public_html/cardapio-digital/public
```

---

## 🚀 **Comandos Úteis Hostgator**

### **Via Terminal (se disponível):**
```bash
# Navegar para o projeto
cd public_html/cardapio-digital

# Configurar cache
php artisan config:cache
php artisan route:cache
php artisan view:cache

# Gerar chave
php artisan key:generate

# Testar conexão
php artisan tinker
```

### **Via cPanel Cron Jobs:**
```bash
# Backup diário (opcional)
0 2 * * * mysqldump -u usuario -p senha banco > backup_$(date +\%Y\%m\%d).sql
```

---

## 📊 **Verificação pós-Instalação**

### **No phpMyAdmin:**
```sql
-- Verificar tabelas criadas
SHOW TABLES;

-- Verificar dados iniciais
SELECT COUNT(*) FROM categories;
SELECT COUNT(*) FROM products;
SELECT COUNT(*) FROM settings;

-- Resultado esperado:
-- categories: 4
-- products: 6  
-- settings: 18
```

### **No Site:**
- ✅ Menu público carrega
- ✅ Produtos aparecem
- ✅ Carrinho funciona
- ✅ Dashboard admin acessível
- ✅ API responde corretamente

---

## 🔒 **Segurança Hostgator**

### **Configurações Recomendadas:**
```env
# Produção
APP_DEBUG=false
APP_ENV=production

# Banco
DB_HOST=localhost
DB_DATABASE=usuario_banco_seguro
DB_USERNAME=usuario_mysql_seguro
DB_PASSWORD=senha_muito_forte_123!
```

### **Permissões de Arquivos:**
- `storage/`: 755
- `bootstrap/cache/`: 755
- `.env`: 600 (apenas proprietário)

---

## 📞 **Suporte Hostgator**

### **Em caso de problemas:**
1. **Chat Online** - Disponível 24/7
2. **Ticket de Suporte** - Via cPanel
3. **Telefone** - Horário comercial
4. **Documentação** - Base de conhecimento

### **Problemas Comuns:**
- ❌ Erro 500: Verificar permissões
- ❌ Banco não conecta: Verificar credenciais
- ❌ Página em branco: Verificar logs de erro
- ❌ Upload falha: Verificar limite de arquivo

---

## 🎉 **Próximos Passos**

1. ✅ Banco configurado no phpMyAdmin
2. ✅ Arquivos enviados via cPanel
3. ⚙️ Configurar `.env` com dados Hostgator
4. 🔧 Ajustar permissões de arquivos
5. 🌐 Configurar domínio/subdomínio
6. 🚀 Testar todas as funcionalidades
7. 📊 Configurar backup automático

**Sistema pronto na Hostgator! 🎯**
