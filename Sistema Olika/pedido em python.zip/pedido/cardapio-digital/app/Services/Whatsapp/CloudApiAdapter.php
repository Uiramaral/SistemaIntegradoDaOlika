<?php

namespace App\Services\Whatsapp;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use App\Models\WhatsappTemplate;

class CloudApiAdapter implements WhatsappAdapterInterface
{
    protected string $baseUrl;
    protected string $accessToken;
    protected string $phoneNumberId;
    protected string $wabaId;

    public function __construct()
    {
        $this->baseUrl = rtrim(config('services.whatsapp_cloud.api_base'), '/');
        $this->accessToken = config('services.whatsapp_cloud.access_token');
        $this->phoneNumberId = config('services.whatsapp_cloud.phone_number_id');
        $this->wabaId = config('services.whatsapp_cloud.waba_id');
        
        // Validar configurações obrigatórias
        if (empty($this->accessToken)) {
            throw new \Exception('WHATS_CLOUD_ACCESS_TOKEN não configurado no .env');
        }
        
        if (empty($this->phoneNumberId)) {
            throw new \Exception('WHATS_CLOUD_PHONE_NUMBER_ID não configurado no .env');
        }
    }

    public function connect(int $lojaId, string $phone): array
    {
        // Na Cloud API não existe "pairing code". Apenas retorna status básico.
        Log::info('Conectando sessão WhatsApp Cloud API', [
            'loja_id' => $lojaId,
            'phone' => $phone
        ]);

        return [
            'status' => 'connected',
            'pairing_code' => null,
            'instance_id' => $this->phoneNumberId,
            'auth_meta' => [
                'phone_number_id' => $this->phoneNumberId,
                'waba_id' => $this->wabaId
            ]
        ];
    }

    public function status(int $sessionId): array
    {
        try {
            // Verificar status do número de telefone
            $response = Http::withToken($this->accessToken)
                ->timeout(10)
                ->get("{$this->baseUrl}/{$this->phoneNumberId}");

            if (!$response->successful()) {
                return ['status' => 'disconnected', 'instance_id' => null];
            }

            $data = $response->json();

            return [
                'status' => 'connected',
                'instance_id' => $this->phoneNumberId,
                'phone_status' => $data['status'] ?? 'unknown'
            ];

        } catch (\Exception $e) {
            Log::error('Erro ao verificar status da Cloud API', [
                'session_id' => $sessionId,
                'error' => $e->getMessage()
            ]);

            return ['status' => 'disconnected', 'instance_id' => null];
        }
    }

    public function sendText(int $sessionId, string $to, string $text, array $meta = []): array
    {
        try {
            Log::info('Enviando mensagem de texto via Cloud API', [
                'session_id' => $sessionId,
                'to' => $to,
                'text_length' => strlen($text)
            ]);

            $url = "{$this->baseUrl}/{$this->phoneNumberId}/messages";
            
            $response = Http::withToken($this->accessToken)
                ->timeout(30)
                ->post($url, [
                    'messaging_product' => 'whatsapp',
                    'to' => $to,
                    'type' => 'text',
                    'text' => [
                        'preview_url' => false,
                        'body' => $text
                    ]
                ]);

            if (!$response->successful()) {
                $error = $response->json();
                throw new \Exception('Erro ao enviar mensagem: ' . ($error['error']['message'] ?? $response->body()));
            }

            $data = $response->json();

            return [
                'provider_msg_id' => $data['messages'][0]['id'] ?? null,
                'status' => 'sent'
            ];

        } catch (\Exception $e) {
            Log::error('Erro ao enviar mensagem de texto via Cloud API', [
                'session_id' => $sessionId,
                'to' => $to,
                'error' => $e->getMessage()
            ]);

            return [
                'provider_msg_id' => null,
                'status' => 'failed',
                'error' => $e->getMessage()
            ];
        }
    }

    public function sendTemplate(int $sessionId, string $to, string $templateName, array $vars = []): array
    {
        try {
            Log::info('Enviando template via Cloud API', [
                'session_id' => $sessionId,
                'to' => $to,
                'template_name' => $templateName,
                'vars' => $vars
            ]);

            $components = [];
            if (!empty($vars)) {
                $components[] = [
                    'type' => 'body',
                    'parameters' => array_map(function($value) {
                        return [
                            'type' => 'text',
                            'text' => (string) $value
                        ];
                    }, array_values($vars))
                ];
            }

            $url = "{$this->baseUrl}/{$this->phoneNumberId}/messages";
            
            $response = Http::withToken($this->accessToken)
                ->timeout(30)
                ->post($url, [
                    'messaging_product' => 'whatsapp',
                    'to' => $to,
                    'type' => 'template',
                    'template' => [
                        'name' => $templateName,
                        'language' => ['code' => 'pt_BR'],
                        'components' => $components
                    ]
                ]);

            if (!$response->successful()) {
                $error = $response->json();
                throw new \Exception('Erro ao enviar template: ' . ($error['error']['message'] ?? $response->body()));
            }

            $data = $response->json();

            return [
                'provider_msg_id' => $data['messages'][0]['id'] ?? null,
                'status' => 'sent'
            ];

        } catch (\Exception $e) {
            Log::error('Erro ao enviar template via Cloud API', [
                'session_id' => $sessionId,
                'to' => $to,
                'template_name' => $templateName,
                'error' => $e->getMessage()
            ]);

            return [
                'provider_msg_id' => null,
                'status' => 'failed',
                'error' => $e->getMessage()
            ];
        }
    }

    public function sendMedia(int $sessionId, string $to, string $mediaUrl, string $type = 'image', string $caption = ''): array
    {
        try {
            Log::info('Enviando mídia via Cloud API', [
                'session_id' => $sessionId,
                'to' => $to,
                'type' => $type,
                'media_url' => $mediaUrl
            ]);

            $url = "{$this->baseUrl}/{$this->phoneNumberId}/messages";
            
            $messageData = [
                'messaging_product' => 'whatsapp',
                'to' => $to,
                'type' => $type,
            ];

            if ($type === 'image') {
                $messageData['image'] = [
                    'link' => $mediaUrl,
                    'caption' => $caption
                ];
            } elseif ($type === 'document') {
                $messageData['document'] = [
                    'link' => $mediaUrl,
                    'caption' => $caption
                ];
            } else {
                throw new \Exception("Tipo de mídia '{$type}' não suportado");
            }

            $response = Http::withToken($this->accessToken)
                ->timeout(30)
                ->post($url, $messageData);

            if (!$response->successful()) {
                $error = $response->json();
                throw new \Exception('Erro ao enviar mídia: ' . ($error['error']['message'] ?? $response->body()));
            }

            $data = $response->json();

            return [
                'provider_msg_id' => $data['messages'][0]['id'] ?? null,
                'status' => 'sent'
            ];

        } catch (\Exception $e) {
            Log::error('Erro ao enviar mídia via Cloud API', [
                'session_id' => $sessionId,
                'to' => $to,
                'type' => $type,
                'error' => $e->getMessage()
            ]);

            return [
                'provider_msg_id' => null,
                'status' => 'failed',
                'error' => $e->getMessage()
            ];
        }
    }

    public function isAvailable(): bool
    {
        try {
            $response = Http::withToken($this->accessToken)
                ->timeout(5)
                ->get("{$this->baseUrl}/{$this->phoneNumberId}");

            return $response->successful();
        } catch (\Exception $e) {
            return false;
        }
    }

    public function getInfo(): array
    {
        return [
            'name' => 'WhatsApp Cloud API',
            'type' => 'cloud_api',
            'base_url' => $this->baseUrl,
            'phone_number_id' => $this->phoneNumberId,
            'waba_id' => $this->wabaId,
            'available' => $this->isAvailable()
        ];
    }
}
