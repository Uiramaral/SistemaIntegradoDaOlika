<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Log;
use App\Services\Whatsapp\WhatsappService;
use App\Models\WhatsappSession;
use App\Models\WhatsappMessage;
use App\Models\WhatsappOptin;

class WhatsappController extends Controller
{
    private $whatsappService;

    public function __construct()
    {
        $this->whatsappService = new WhatsappService();
    }

    /**
     * Conectar WhatsApp
     * POST /api/whatsapp/connect
     */
    public function connect(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'loja_id' => 'required|integer|min:1',
            'phone' => 'required|string|max:32',
            'adapter' => 'nullable|string|in:non_official,cloud_api'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'error' => 'Dados inválidos',
                'details' => $validator->errors()
            ], 400);
        }

        $lojaId = $request->input('loja_id');
        $phone = preg_replace('/\D+/', '', $request->input('phone'));
        $adapter = $request->input('adapter', 'non_official');

        $result = $this->whatsappService->connect($lojaId, $phone, $adapter);

        return response()->json($result, $result['success'] ? 200 : 400);
    }

    /**
     * Verificar status da sessão
     * GET /api/whatsapp/session/status
     */
    public function status(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'session_id' => 'required|integer|min:1'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'error' => 'Dados inválidos',
                'details' => $validator->errors()
            ], 400);
        }

        $sessionId = $request->input('session_id');
        $result = $this->whatsappService->getStatus($sessionId);

        return response()->json($result, $result['success'] ? 200 : 400);
    }

    /**
     * Enviar mensagem
     * POST /api/whatsapp/send
     */
    public function send(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'session_id' => 'required|integer|min:1',
            'to' => 'required|string|max:32',
            'type' => 'required|string|in:text,template,image,file',
            'text' => 'required_if:type,text|string|max:4096',
            'template_name' => 'required_if:type,template|string|max:128',
            'template_vars' => 'nullable|array',
            'media_url' => 'required_if:type,image,file|url|max:2048',
            'caption' => 'nullable|string|max:1024'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'error' => 'Dados inválidos',
                'details' => $validator->errors()
            ], 400);
        }

        $sessionId = $request->input('session_id');
        $to = preg_replace('/\D+/', '', $request->input('to'));
        $type = $request->input('type');

        $data = [
            'text' => $request->input('text'),
            'template_name' => $request->input('template_name'),
            'template_vars' => $request->input('template_vars', []),
            'media_url' => $request->input('media_url'),
            'caption' => $request->input('caption'),
        ];

        $result = $this->whatsappService->sendMessage($sessionId, $to, $type, $data);

        return response()->json($result, $result['success'] ? 200 : 400);
    }

    /**
     * Registrar opt-in
     * POST /api/whatsapp/opt-in
     */
    public function optIn(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'loja_id' => 'required|integer|min:1',
            'phone' => 'required|string|max:32',
            'source' => 'nullable|string|max:64',
            'notes' => 'nullable|string|max:255'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'error' => 'Dados inválidos',
                'details' => $validator->errors()
            ], 400);
        }

        $lojaId = $request->input('loja_id');
        $phone = preg_replace('/\D+/', '', $request->input('phone'));
        $source = $request->input('source', 'manual');
        $notes = $request->input('notes');

        $result = $this->whatsappService->optIn($lojaId, $phone, $source, $notes);

        return response()->json($result, $result['success'] ? 200 : 400);
    }

    /**
     * Registrar opt-out
     * POST /api/whatsapp/opt-out
     */
    public function optOut(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'loja_id' => 'required|integer|min:1',
            'phone' => 'required|string|max:32',
            'notes' => 'nullable|string|max:255'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'error' => 'Dados inválidos',
                'details' => $validator->errors()
            ], 400);
        }

        $lojaId = $request->input('loja_id');
        $phone = preg_replace('/\D+/', '', $request->input('phone'));
        $notes = $request->input('notes');

        $result = $this->whatsappService->optOut($lojaId, $phone, $notes);

        return response()->json($result, $result['success'] ? 200 : 400);
    }

    /**
     * Obter sessões de uma loja
     * GET /api/whatsapp/sessions
     */
    public function sessions(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'loja_id' => 'required|integer|min:1'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'error' => 'Dados inválidos',
                'details' => $validator->errors()
            ], 400);
        }

        $lojaId = $request->input('loja_id');
        $sessions = WhatsappSession::where('loja_id', $lojaId)
            ->with('messages')
            ->orderBy('updated_at', 'desc')
            ->get()
            ->map(function ($session) {
                return [
                    'id' => $session->id,
                    'phone' => $session->phone,
                    'adapter' => $session->adapter,
                    'status' => $session->status,
                    'last_seen_at' => $session->last_seen_at,
                    'error_message' => $session->error_message,
                    'stats' => $session->getStats(),
                    'created_at' => $session->created_at,
                    'updated_at' => $session->updated_at,
                ];
            });

        return response()->json([
            'success' => true,
            'sessions' => $sessions
        ]);
    }

    /**
     * Obter mensagens de uma sessão
     * GET /api/whatsapp/messages
     */
    public function messages(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'session_id' => 'required|integer|min:1',
            'limit' => 'nullable|integer|min:1|max:100',
            'offset' => 'nullable|integer|min:0'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'error' => 'Dados inválidos',
                'details' => $validator->errors()
            ], 400);
        }

        $sessionId = $request->input('session_id');
        $limit = $request->input('limit', 50);
        $offset = $request->input('offset', 0);

        $messages = WhatsappMessage::where('session_id', $sessionId)
            ->orderBy('created_at', 'desc')
            ->limit($limit)
            ->offset($offset)
            ->get()
            ->map(function ($message) {
                return [
                    'id' => $message->id,
                    'direction' => $message->direction,
                    'peer' => $message->peer,
                    'type' => $message->type,
                    'content' => $message->getFormattedContent(),
                    'status' => $message->status,
                    'provider_msg_id' => $message->provider_msg_id,
                    'error_message' => $message->error_message,
                    'created_at' => $message->created_at,
                ];
            });

        return response()->json([
            'success' => true,
            'messages' => $messages
        ]);
    }

    /**
     * Obter estatísticas
     * GET /api/whatsapp/stats
     */
    public function stats(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'loja_id' => 'required|integer|min:1'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'error' => 'Dados inválidos',
                'details' => $validator->errors()
            ], 400);
        }

        $lojaId = $request->input('loja_id');
        $stats = $this->whatsappService->getStats($lojaId);

        return response()->json([
            'success' => true,
            'stats' => $stats
        ]);
    }

    /**
     * Processar evento de pedido
     * POST /api/whatsapp/process-event
     */
    public function processEvent(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'loja_id' => 'required|integer|min:1',
            'event_key' => 'required|string|max:64',
            'phone' => 'required|string|max:32',
            'data' => 'nullable|array'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'error' => 'Dados inválidos',
                'details' => $validator->errors()
            ], 400);
        }

        $lojaId = $request->input('loja_id');
        $eventKey = $request->input('event_key');
        $phone = preg_replace('/\D+/', '', $request->input('phone'));
        $data = array_merge($request->input('data', []), ['phone' => $phone]);

        $result = $this->whatsappService->processOrderEvent($lojaId, $eventKey, $data);

        return response()->json($result, $result['success'] ? 200 : 400);
    }
}
