import { useEffect, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { CheckCircle2, Clock, Home, Package } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useMenu } from "@/contexts/MenuContext";
import { Order } from "@/types/menu";

const OrderSuccess = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { orders, config } = useMenu();
  const [order, setOrder] = useState<Order | null>(null);

  const orderId = searchParams.get("order_id");
  const paymentMethod = searchParams.get("payment");
  const paymentStatus = searchParams.get("status");

  useEffect(() => {
    if (orderId) {
      const foundOrder = orders.find(o => o.id === orderId);
      if (foundOrder) {
        setOrder(foundOrder);
      }
    }
  }, [orderId, orders]);

  if (!order) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="max-w-md w-full">
          <CardContent className="pt-6">
            <div className="text-center">
              <p className="text-muted-foreground mb-4">Pedido não encontrado</p>
              <Button onClick={() => navigate("/")}>
                Voltar ao Menu
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const isPending = paymentStatus === 'pending';
  const isMercadoPago = paymentMethod === 'mercadopago' || order.paymentMethod === 'mercadopago';

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="container mx-auto max-w-2xl py-8">
        <Card>
          <CardHeader>
            <div className="flex flex-col items-center text-center space-y-4">
              {isPending ? (
                <>
                  <Clock className="h-16 w-16 text-warning" />
                  <CardTitle className="text-2xl">Pagamento Pendente</CardTitle>
                  <p className="text-muted-foreground">
                    Seu pedido foi registrado e está aguardando confirmação do pagamento
                  </p>
                </>
              ) : (
                <>
                  <CheckCircle2 className="h-16 w-16 text-success" />
                  <CardTitle className="text-2xl">Pedido Realizado com Sucesso!</CardTitle>
                  <p className="text-muted-foreground">
                    Seu pedido foi recebido e está sendo processado
                  </p>
                </>
              )}
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="bg-muted p-4 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-muted-foreground">Número do Pedido</span>
                <span className="font-bold">#{order.id}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Forma de Pagamento</span>
                <span className="font-semibold">
                  {isMercadoPago ? 'Mercado Pago' : 'WhatsApp'}
                </span>
              </div>
            </div>

            <div>
              <h3 className="font-semibold mb-3 flex items-center gap-2">
                <Package className="h-5 w-5" />
                Itens do Pedido
              </h3>
              <div className="space-y-2">
                {order.items.map((item, index) => (
                  <div key={index} className="flex justify-between text-sm">
                    <span>{item.quantity}x {item.name}</span>
                    <span>R$ {(item.price * item.quantity).toFixed(2)}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="border-t pt-4 space-y-2">
              <div className="flex justify-between">
                <span>Subtotal:</span>
                <span>R$ {order.subtotal.toFixed(2)}</span>
              </div>
              {order.deliveryFee > 0 && (
                <div className="flex justify-between">
                  <span>Taxa de Entrega:</span>
                  <span>R$ {order.deliveryFee.toFixed(2)}</span>
                </div>
              )}
              {order.discount > 0 && (
                <div className="flex justify-between text-success">
                  <span>Desconto{order.couponCode ? ` (${order.couponCode})` : ''}:</span>
                  <span>-R$ {order.discount.toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between text-lg font-bold border-t pt-2">
                <span>Total:</span>
                <span className="text-primary">R$ {order.total.toFixed(2)}</span>
              </div>
            </div>

            {isMercadoPago && !isPending && (
              <div className="bg-success/10 border border-success/20 p-4 rounded-lg">
                <p className="text-sm text-success">
                  Pagamento confirmado via Mercado Pago. Você receberá atualizações do pedido em breve.
                </p>
              </div>
            )}

            {!isMercadoPago && (
              <div className="bg-primary/10 border border-primary/20 p-4 rounded-lg">
                <p className="text-sm">
                  Seu pedido foi enviado via WhatsApp para <strong>{config.businessName}</strong>. 
                  Aguarde o contato para confirmação e detalhes de pagamento.
                </p>
              </div>
            )}

            <div className="pt-4">
              <Button className="w-full" size="lg" onClick={() => navigate("/")}>
                <Home className="h-5 w-5 mr-2" />
                Voltar ao Menu
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default OrderSuccess;
