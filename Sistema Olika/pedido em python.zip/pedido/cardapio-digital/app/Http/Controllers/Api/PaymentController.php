<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Settings;
use App\Services\MercadoPagoService;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class PaymentController extends Controller
{
    /**
     * Criar preferência de pagamento Mercado Pago
     */
    public function createPreference(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'order_id' => 'required|exists:orders,id',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Pedido inválido',
                'errors' => $validator->errors()
            ], 422);
        }

        $order = Order::with(['customer', 'items.product'])->find($request->order_id);

        if ($order->status !== 'pending') {
            return response()->json([
                'success' => false,
                'message' => 'Pedido não está pendente de pagamento'
            ], 422);
        }

        try {
            $mercadoPagoService = new MercadoPagoService();
            
            if (!$mercadoPagoService->isConfigured()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Mercado Pago não está configurado'
                ], 503);
            }

            $preference = $mercadoPagoService->createPreference($order);

            if ($preference['success']) {
                // Atualizar pedido com ID da preferência
                $order->update([
                    'mercado_pago_payment_id' => $preference['preference_id']
                ]);

                return response()->json([
                    'success' => true,
                    'message' => 'Preferência criada com sucesso',
                    'data' => $preference
                ]);
            } else {
                return response()->json([
                    'success' => false,
                    'message' => $preference['message']
                ], 500);
            }

        } catch (\Exception $e) {
            Log::error('Erro ao criar preferência: ' . $e->getMessage());
            
            return response()->json([
                'success' => false,
                'message' => 'Erro interno do servidor'
            ], 500);
        }
    }

    /**
     * Verificar status do pagamento
     */
    public function checkPaymentStatus(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'payment_id' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'ID do pagamento é obrigatório',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $mercadoPagoService = new MercadoPagoService();
            
            if (!$mercadoPagoService->isConfigured()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Mercado Pago não está configurado'
                ], 503);
            }

            $paymentStatus = $mercadoPagoService->getPaymentStatus($request->payment_id);

            if ($paymentStatus['success']) {
                // Buscar pedido relacionado
                $order = Order::where('mercado_pago_payment_id', $request->payment_id)->first();

                if ($order) {
                    // Atualizar status do pedido baseado no pagamento
                    $this->updateOrderStatusByPayment($order, $paymentStatus['data']);
                }

                return response()->json([
                    'success' => true,
                    'data' => $paymentStatus['data'],
                    'order' => $order ? $order->fresh() : null
                ]);
            } else {
                return response()->json([
                    'success' => false,
                    'message' => $paymentStatus['message']
                ], 404);
            }

        } catch (\Exception $e) {
            Log::error('Erro ao verificar status do pagamento: ' . $e->getMessage());
            
            return response()->json([
                'success' => false,
                'message' => 'Erro interno do servidor'
            ], 500);
        }
    }

    /**
     * Webhook do Mercado Pago
     */
    public function webhook(Request $request): JsonResponse
    {
        try {
            $data = $request->all();
            
            Log::info('Webhook Mercado Pago recebido:', $data);

            // Verificar se é uma notificação de pagamento
            if (isset($data['type']) && $data['type'] === 'payment') {
                $paymentId = $data['data']['id'] ?? null;
                
                if ($paymentId) {
                    $mercadoPagoService = new MercadoPagoService();
                    $paymentStatus = $mercadoPagoService->getPaymentStatus($paymentId);
                    
                    if ($paymentStatus['success']) {
                        // Buscar pedido relacionado
                        $order = Order::where('mercado_pago_payment_id', $paymentId)->first();
                        
                        if ($order) {
                            $this->updateOrderStatusByPayment($order, $paymentStatus['data']);
                            
                            Log::info("Pedido {$order->id} atualizado via webhook", [
                                'payment_id' => $paymentId,
                                'status' => $paymentStatus['data']['status']
                            ]);
                        }
                    }
                }
            }

            return response()->json(['success' => true]);

        } catch (\Exception $e) {
            Log::error('Erro no webhook Mercado Pago: ' . $e->getMessage());
            
            return response()->json([
                'success' => false,
                'message' => 'Erro interno do servidor'
            ], 500);
        }
    }

    /**
     * Processar pagamento via WhatsApp (simulado)
     */
    public function processWhatsAppPayment(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'order_id' => 'required|exists:orders,id',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Pedido inválido',
                'errors' => $validator->errors()
            ], 422);
        }

        $order = Order::with(['customer'])->find($request->order_id);

        if ($order->status !== 'pending') {
            return response()->json([
                'success' => false,
                'message' => 'Pedido não está pendente de pagamento'
            ], 422);
        }

        try {
            DB::beginTransaction();

            // Simular processamento do pagamento
            $order->update([
                'status' => 'confirmed',
                'payment_status' => 'pending_whatsapp',
                'payment_method' => 'whatsapp',
                'payment_date' => now()
            ]);

            // Enviar mensagem WhatsApp
            $whatsAppService = new \App\Services\WhatsAppService();
            
            if ($whatsAppService->isConfigured()) {
                $whatsAppService->sendPaymentMessage($order);
            }

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Pedido confirmado. Aguardando pagamento via WhatsApp.',
                'data' => [
                    'order' => $order->fresh(),
                    'whatsapp_sent' => $whatsAppService->isConfigured()
                ]
            ]);

        } catch (\Exception $e) {
            DB::rollback();
            Log::error('Erro ao processar pagamento WhatsApp: ' . $e->getMessage());
            
            return response()->json([
                'success' => false,
                'message' => 'Erro ao processar pagamento'
            ], 500);
        }
    }

    /**
     * Confirmar pagamento manual (para WhatsApp)
     */
    public function confirmManualPayment(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'order_id' => 'required|exists:orders,id',
            'payment_confirmation' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Dados inválidos',
                'errors' => $validator->errors()
            ], 422);
        }

        $order = Order::find($request->order_id);

        if ($order->status !== 'confirmed' || $order->payment_status !== 'pending_whatsapp') {
            return response()->json([
                'success' => false,
                'message' => 'Pedido não está aguardando confirmação de pagamento'
            ], 422);
        }

        try {
            DB::beginTransaction();

            // Confirmar pagamento
            $order->update([
                'status' => 'paid',
                'payment_status' => 'paid',
                'payment_date' => now(),
                'payment_confirmation' => $request->payment_confirmation
            ]);

            // Aplicar pontos de fidelidade
            $loyaltyProgram = \App\Models\LoyaltyProgram::getDefault();
            $order->applyLoyaltyPoints($loyaltyProgram);

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Pagamento confirmado com sucesso',
                'data' => [
                    'order' => $order->fresh(),
                    'loyalty_points_earned' => $order->loyalty_points_earned
                ]
            ]);

        } catch (\Exception $e) {
            DB::rollback();
            Log::error('Erro ao confirmar pagamento: ' . $e->getMessage());
            
            return response()->json([
                'success' => false,
                'message' => 'Erro ao confirmar pagamento'
            ], 500);
        }
    }

    /**
     * Cancelar pagamento
     */
    public function cancelPayment(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'order_id' => 'required|exists:orders,id',
            'reason' => 'nullable|string|max:255',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Pedido inválido',
                'errors' => $validator->errors()
            ], 422);
        }

        $order = Order::find($request->order_id);

        if (!in_array($order->status, ['pending', 'confirmed'])) {
            return response()->json([
                'success' => false,
                'message' => 'Pedido não pode ser cancelado'
            ], 422);
        }

        try {
            DB::beginTransaction();

            $order->update([
                'status' => 'cancelled',
                'payment_status' => 'cancelled',
                'cancellation_reason' => $request->reason,
                'cancelled_at' => now()
            ]);

            // Se for Mercado Pago, tentar cancelar o pagamento
            if ($order->payment_method === 'mercadopago' && $order->mercado_pago_payment_id) {
                $mercadoPagoService = new MercadoPagoService();
                $mercadoPagoService->cancelPayment($order->mercado_pago_payment_id);
            }

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Pagamento cancelado com sucesso',
                'data' => [
                    'order' => $order->fresh()
                ]
            ]);

        } catch (\Exception $e) {
            DB::rollback();
            Log::error('Erro ao cancelar pagamento: ' . $e->getMessage());
            
            return response()->json([
                'success' => false,
                'message' => 'Erro ao cancelar pagamento'
            ], 500);
        }
    }

    /**
     * Obter métodos de pagamento disponíveis
     */
    public function getPaymentMethods(): JsonResponse
    {
        $settings = Settings::getSettings();

        return response()->json([
            'success' => true,
            'data' => [
                'whatsapp' => [
                    'enabled' => $settings->whatsapp_payment_enabled ?? true,
                    'name' => 'WhatsApp',
                    'description' => 'Pague via WhatsApp',
                    'icon' => 'whatsapp'
                ],
                'mercadopago' => [
                    'enabled' => $settings->mercadopago_enabled ?? true,
                    'name' => 'Mercado Pago',
                    'description' => 'Cartão, PIX, Boleto',
                    'icon' => 'credit-card'
                ]
            ]
        ]);
    }

    /**
     * Atualizar status do pedido baseado no pagamento
     */
    private function updateOrderStatusByPayment(Order $order, array $paymentData): void
    {
        $status = $paymentData['status'];
        $paymentStatus = $paymentData['status_detail'];

        $orderStatus = match ($status) {
            'approved' => 'paid',
            'pending' => 'confirmed',
            'in_process' => 'confirmed',
            'rejected' => 'cancelled',
            'cancelled' => 'cancelled',
            'refunded' => 'cancelled',
            default => 'pending'
        };

        $orderPaymentStatus = match ($status) {
            'approved' => 'paid',
            'pending' => 'pending',
            'in_process' => 'processing',
            'rejected' => 'rejected',
            'cancelled' => 'cancelled',
            'refunded' => 'refunded',
            default => 'pending'
        };

        $order->update([
            'status' => $orderStatus,
            'payment_status' => $orderPaymentStatus,
            'payment_date' => $status === 'approved' ? now() : null,
            'payment_details' => json_encode($paymentData)
        ]);

        // Se pagamento aprovado, aplicar pontos de fidelidade
        if ($status === 'approved') {
            $loyaltyProgram = \App\Models\LoyaltyProgram::getDefault();
            $order->applyLoyaltyPoints($loyaltyProgram);
        }
    }
}
