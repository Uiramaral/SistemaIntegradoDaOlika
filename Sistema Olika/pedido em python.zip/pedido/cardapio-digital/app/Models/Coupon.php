<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Carbon\Carbon;

class Coupon extends Model
{
    use HasFactory;

    protected $fillable = [
        'code',
        'description',
        'discount_type',
        'discount_value',
        'is_public',
        'first_purchase_only',
        'valid_until',
        'min_purchase_value',
        'active',
        'usage_limit',
        'usage_count',
    ];

    protected $casts = [
        'discount_value' => 'decimal:2',
        'min_purchase_value' => 'decimal:2',
        'is_public' => 'boolean',
        'first_purchase_only' => 'boolean',
        'active' => 'boolean',
        'usage_limit' => 'integer',
        'usage_count' => 'integer',
        'valid_until' => 'datetime',
    ];

    protected $dates = [
        'created_at',
        'updated_at',
        'valid_until',
    ];

    const DISCOUNT_PERCENTAGE = 'percentage';
    const DISCOUNT_FIXED = 'fixed';

    /**
     * Relacionamento com pedidos
     */
    public function orders(): HasMany
    {
        return $this->hasMany(Order::class, 'coupon_code', 'code');
    }

    /**
     * Scope para cupons ativos
     */
    public function scopeActive($query)
    {
        return $query->where('active', true)
                    ->where(function ($q) {
                        $q->whereNull('valid_until')
                          ->orWhere('valid_until', '>', now());
                    });
    }

    /**
     * Scope para cupons públicos
     */
    public function scopePublic($query)
    {
        return $query->where('is_public', true);
    }

    /**
     * Scope para cupons disponíveis
     */
    public function scopeAvailable($query)
    {
        return $query->active()
                    ->where(function ($q) {
                        $q->whereNull('usage_limit')
                          ->orWhereRaw('usage_count < usage_limit');
                    });
    }

    /**
     * Buscar cupom por código
     */
    public static function findByCode(string $code): ?self
    {
        return self::where('code', strtoupper($code))->first();
    }

    /**
     * Validar cupom
     */
    public function isValid(): bool
    {
        // Verificar se está ativo
        if (!$this->active) {
            return false;
        }

        // Verificar se não expirou
        if ($this->valid_until && $this->valid_until->isPast()) {
            return false;
        }

        // Verificar limite de uso
        if ($this->usage_limit && $this->usage_count >= $this->usage_limit) {
            return false;
        }

        return true;
    }

    /**
     * Validar cupom para um pedido específico
     */
    public function isValidForOrder(float $subtotal, Customer $customer = null): bool
    {
        // Verificar se cupom é válido
        if (!$this->isValid()) {
            return false;
        }

        // Verificar valor mínimo de compra
        if ($this->min_purchase_value && $subtotal < $this->min_purchase_value) {
            return false;
        }

        // Verificar se é primeira compra apenas
        if ($this->first_purchase_only && $customer && !$customer->isFirstPurchase()) {
            return false;
        }

        return true;
    }

    /**
     * Calcular desconto
     */
    public function calculateDiscount(float $subtotal): float
    {
        if ($this->discount_type === self::DISCOUNT_PERCENTAGE) {
            return ($subtotal * $this->discount_value) / 100;
        }

        return min($this->discount_value, $subtotal);
    }

    /**
     * Obter valor de desconto formatado
     */
    public function getFormattedDiscountValueAttribute(): string
    {
        if ($this->discount_type === self::DISCOUNT_PERCENTAGE) {
            return $this->discount_value . '%';
        }

        return 'R$ ' . number_format($this->discount_value, 2, ',', '.');
    }

    /**
     * Obter tipo de desconto formatado
     */
    public function getDiscountTypeLabelAttribute(): string
    {
        return $this->discount_type === self::DISCOUNT_PERCENTAGE ? 'Porcentagem' : 'Valor Fixo';
    }

    /**
     * Incrementar contador de uso
     */
    public function incrementUsage(): void
    {
        $this->increment('usage_count');
    }

    /**
     * Verificar se cupom pode ser usado
     */
    public function canBeUsed(): bool
    {
        if (!$this->usage_limit) {
            return true;
        }

        return $this->usage_count < $this->usage_limit;
    }

    /**
     * Obter status do cupom
     */
    public function getStatusAttribute(): string
    {
        if (!$this->active) {
            return 'Inativo';
        }

        if ($this->valid_until && $this->valid_until->isPast()) {
            return 'Expirado';
        }

        if ($this->usage_limit && $this->usage_count >= $this->usage_limit) {
            return 'Esgotado';
        }

        return 'Ativo';
    }

    /**
     * Verificar se cupom está expirado
     */
    public function isExpired(): bool
    {
        return $this->valid_until && $this->valid_until->isPast();
    }

    /**
     * Verificar se cupom está esgotado
     */
    public function isExhausted(): bool
    {
        return $this->usage_limit && $this->usage_count >= $this->usage_limit;
    }

    /**
     * Ativar cupom
     */
    public function activate(): void
    {
        $this->active = true;
        $this->save();
    }

    /**
     * Desativar cupom
     */
    public function deactivate(): void
    {
        $this->active = false;
        $this->save();
    }

    /**
     * Toggle status do cupom
     */
    public function toggleStatus(): void
    {
        $this->active = !$this->active;
        $this->save();
    }

    /**
     * Boot do modelo
     */
    protected static function boot()
    {
        parent::boot();

        static::creating(function ($coupon) {
            $coupon->code = strtoupper($coupon->code);
        });

        static::updating(function ($coupon) {
            if ($coupon->isDirty('code')) {
                $coupon->code = strtoupper($coupon->code);
            }
        });
    }
}
