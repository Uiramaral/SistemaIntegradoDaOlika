<div class="product-card bg-white rounded-lg shadow-sm border overflow-hidden">
    <!-- Grid Mode -->
    <div x-show="displayMode === 'grid'" class="h-full flex flex-col">
        <div class="aspect-square bg-gray-100 overflow-hidden">
            <img 
                :src="product.image || '/images/placeholder-product.jpg'" 
                :alt="product.name"
                class="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                @click="selectedProduct = product"
            >
        </div>
        
        <div class="p-4 flex-1 flex flex-col">
            <div class="flex-1">
                <h3 class="font-semibold text-gray-900 mb-2" x-text="product.name"></h3>
                <p class="text-sm text-gray-600 mb-3 line-clamp-2" x-text="product.description"></p>
            </div>
            
            <div class="flex items-center justify-between">
                <span class="text-xl font-bold text-blue-600" x-text="formatCurrency(product.price)"></span>
                <button 
                    @click="addToCart(product.id)"
                    class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors"
                >
                    Adicionar
                </button>
            </div>
        </div>
    </div>

    <!-- List Mode -->
    <div x-show="displayMode === 'list'" class="flex">
        <div class="w-24 h-24 bg-gray-100 overflow-hidden flex-shrink-0">
            <img 
                :src="product.image || '/images/placeholder-product.jpg'" 
                :alt="product.name"
                class="w-full h-full object-cover"
                @click="selectedProduct = product"
            >
        </div>
        
        <div class="flex-1 p-4 flex items-center justify-between">
            <div class="flex-1">
                <h3 class="font-semibold text-gray-900 mb-1" x-text="product.name"></h3>
                <p class="text-sm text-gray-600 mb-2" x-text="product.description"></p>
                <span class="text-lg font-bold text-blue-600" x-text="formatCurrency(product.price)"></span>
            </div>
            
            <button 
                @click="addToCart(product.id)"
                class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors ml-4"
            >
                Adicionar
            </button>
        </div>
    </div>

    <!-- Compact Mode -->
    <div x-show="displayMode === 'compact'" class="text-center">
        <div class="aspect-square bg-gray-100 overflow-hidden">
            <img 
                :src="product.image || '/images/placeholder-product.jpg'" 
                :alt="product.name"
                class="w-full h-full object-cover"
                @click="selectedProduct = product"
            >
        </div>
        
        <div class="p-2">
            <h3 class="font-medium text-sm text-gray-900 mb-1 line-clamp-2" x-text="product.name"></h3>
            <div class="flex items-center justify-between">
                <span class="text-sm font-bold text-blue-600" x-text="formatCurrency(product.price)"></span>
                <button 
                    @click="addToCart(product.id)"
                    class="bg-blue-600 hover:bg-blue-700 text-white px-2 py-1 rounded text-xs font-medium transition-colors"
                >
                    +
                </button>
            </div>
        </div>
    </div>
</div>
