# 📱 Sistema WhatsApp Chatbot - Cardápio Digital Olika

## 📋 **Visão Geral**

Sistema completo de integração WhatsApp baseado no modelo chatbot que permite conectar o cardápio digital ao WhatsApp da loja, enviando e recebendo mensagens automaticamente.

---

## 🏗️ **Arquitetura do Sistema**

### **Componentes Principais:**
- **Adapters Duplos** - Suporte para modo não-oficial e oficial
- **Sistema de Sessões** - Gerenciamento de conexões WhatsApp
- **Sistema de Regras** - Automação baseada em eventos de pedidos
- **Opt-in/Opt-out** - Controle de consentimento LGPD
- **Rate Limiting** - Controle de envio para evitar bloqueios

---

## 🗄️ **Estrutura do Banco de Dados**

### **1. Tabela: `whatsapp_sessions`**
```sql
CREATE TABLE `whatsapp_sessions` (
  `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `loja_id` BIGINT UNSIGNED NOT NULL,
  `phone` VARCHAR(32) NOT NULL,
  `adapter` ENUM('non_official','cloud_api') NOT NULL DEFAULT 'non_official',
  `status` ENUM('connecting','connected','disconnected','error') NOT NULL DEFAULT 'disconnected',
  `instance_id` VARCHAR(128) NULL,
  `auth_meta_json` JSON NULL,
  `last_seen_at` DATETIME NULL,
  `error_message` VARCHAR(255) NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

### **2. Tabela: `whatsapp_messages`**
```sql
CREATE TABLE `whatsapp_messages` (
  `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `loja_id` BIGINT UNSIGNED NOT NULL,
  `session_id` BIGINT UNSIGNED NOT NULL,
  `direction` ENUM('IN','OUT') NOT NULL,
  `peer` VARCHAR(32) NOT NULL,
  `type` ENUM('text','image','file','template') NOT NULL DEFAULT 'text',
  `body_text` MEDIUMTEXT NULL,
  `media_url` TEXT NULL,
  `template_name` VARCHAR(128) NULL,
  `template_vars` JSON NULL,
  `status` ENUM('queued','sent','delivered','read','failed') NOT NULL DEFAULT 'queued',
  `provider_msg_id` VARCHAR(128) NULL,
  `error_message` VARCHAR(255) NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

### **3. Tabela: `whatsapp_optins`**
```sql
CREATE TABLE `whatsapp_optins` (
  `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `loja_id` BIGINT UNSIGNED NOT NULL,
  `phone` VARCHAR(32) NOT NULL,
  `opted_in_at` DATETIME NULL,
  `opted_out_at` DATETIME NULL,
  `source` VARCHAR(64) NULL,
  `notes` VARCHAR(255) NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

### **4. Tabela: `whatsapp_rules`**
```sql
CREATE TABLE `whatsapp_rules` (
  `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `loja_id` BIGINT UNSIGNED NOT NULL,
  `event_key` VARCHAR(64) NOT NULL,
  `enabled` TINYINT(1) NOT NULL DEFAULT 1,
  `adapter` ENUM('non_official','cloud_api','any') NOT NULL DEFAULT 'any',
  `template_name` VARCHAR(128) NOT NULL,
  `template_body` MEDIUMTEXT NOT NULL,
  `template_vars` JSON NULL,
  `send_window` VARCHAR(32) NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

### **5. Tabela: `whatsapp_templates`**
```sql
CREATE TABLE `whatsapp_templates` (
  `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `loja_id` BIGINT UNSIGNED NOT NULL,
  `name` VARCHAR(128) NOT NULL,
  `category` ENUM('marketing','utility','authentication','service') NOT NULL DEFAULT 'utility',
  `status` ENUM('approved','rejected','in_review') NOT NULL DEFAULT 'in_review',
  `language` VARCHAR(10) NOT NULL DEFAULT 'pt_BR',
  `body` MEDIUMTEXT NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

---

## 🔄 **Fluxo de Funcionamento**

### **1. Conexão WhatsApp**
```php
// Endpoint: POST /api/whatsapp/connect
{
  "loja_id": 1,
  "phone": "5511999999999",
  "adapter": "non_official"
}

// Resposta (modo não-oficial)
{
  "success": true,
  "session_id": 123,
  "status": "connecting",
  "pairing_code": "ABC12345",
  "adapter": "non_official",
  "message": "Conectando... Aguarde alguns instantes."
}
```

### **2. Processo de Emparelhamento (Não-oficial)**
1. **Lojista** chama `POST /api/whatsapp/connect`
2. **Sistema** gera código de emparelhamento
3. **Lojista** vai no WhatsApp > Dispositivos conectados > Conectar com número
4. **Lojista** digita o código de 8 caracteres
5. **Sistema** recebe webhook de conexão e marca como conectado

### **3. Envio de Mensagens**
```php
// Endpoint: POST /api/whatsapp/send
{
  "session_id": 123,
  "to": "5511999999999",
  "type": "text",
  "text": "Olá! Seu pedido foi confirmado."
}

// Ou template
{
  "session_id": 123,
  "to": "5511999999999",
  "type": "template",
  "template_name": "order_confirmed",
  "template_vars": {
    "pedido": "#OLK001",
    "nome": "João",
    "previsao": "18:00-19:00",
    "total": "45,90"
  }
}
```

---

## 🎯 **Sistema de Regras Automáticas**

### **Eventos Suportados:**
- `order_confirmed` - Pedido confirmado
- `out_for_delivery` - Saiu para entrega
- `delivered` - Pedido entregue
- `cancelled` - Pedido cancelado
- `winback_7d` - Winback 7 dias
- `winback_30d` - Winback 30 dias
- `birthday` - Aniversário do cliente

### **Exemplo de Regra:**
```php
// Pedido confirmado
{
  "event_key": "order_confirmed",
  "template_name": "order_confirmed",
  "template_body": "🍞 Pedido {{pedido}} confirmado, {{nome}}! Previsão: {{previsao}}. Total: R$ {{total}}.",
  "template_vars": ["pedido", "nome", "previsao", "total"],
  "send_window": "09:00-20:30",
  "adapter": "any"
}
```

---

## 🔧 **Configuração**

### **1. Variáveis de Ambiente**
```env
# Seletor do adapter
WHATS_ADAPTER_DEFAULT=non_official

# NÃO-OFICIAL (Gateway Node)
WHATS_GATEWAY_BASE_URL=http://localhost:21465
WHATS_GATEWAY_TOKEN=supersecreto
WHATS_WEBHOOK_SECRET=whsec_123

# OFICIAL (Cloud API)
WHATS_CLOUD_PHONE_NUMBER_ID=123456789012345
WHATS_CLOUD_WABA_ID=345678901234567
WHATS_CLOUD_ACCESS_TOKEN=EAAG...
WHATS_CLOUD_WEBHOOK_VERIFY_TOKEN=verify_olika
WHATS_CLOUD_API_BASE=https://graph.facebook.com/v20.0
```

### **2. Executar Migrações**
```bash
php artisan migrate
```

### **3. Criar Regras Padrão**
```bash
php artisan whatsapp:create-default-rules 1
```

---

## 📱 **Modos de Operação**

### **Modo Não-oficial (Recomendado para início)**
- **Vantagens**: Rápido de implementar, sem custos, sem aprovação
- **Desvantagens**: Maior risco de bloqueio, menos estável
- **Uso**: Ideal para testes e início de operação

### **Modo Oficial (Recomendado para produção)**
- **Vantagens**: Estável, escalável, sem risco de bloqueio
- **Desvantagens**: Custos, aprovação de templates, janela de 24h
- **Uso**: Ideal para operação em produção

---

## 🚀 **API Endpoints**

### **Conexão e Status**
- `POST /api/whatsapp/connect` - Conectar WhatsApp
- `GET /api/whatsapp/session/status` - Status da sessão
- `GET /api/whatsapp/sessions` - Listar sessões

### **Mensagens**
- `POST /api/whatsapp/send` - Enviar mensagem
- `GET /api/whatsapp/messages` - Listar mensagens

### **Opt-in/Opt-out**
- `POST /api/whatsapp/opt-in` - Registrar opt-in
- `POST /api/whatsapp/opt-out` - Registrar opt-out

### **Eventos e Estatísticas**
- `POST /api/whatsapp/process-event` - Processar evento de pedido
- `GET /api/whatsapp/stats` - Estatísticas

### **Webhooks**
- `POST /api/whatsapp/webhook/gateway` - Webhook gateway não-oficial
- `GET /api/whatsapp/webhook/cloud` - Verificação webhook Cloud API
- `POST /api/whatsapp/webhook/cloud` - Webhook Cloud API

---

## 🛡️ **Conformidade LGPD**

### **Opt-in Explícito**
- Checkbox no checkout: "Quero receber atualizações pelo WhatsApp"
- Confirmação via WhatsApp: "Digite SIM para receber mensagens"
- Registro automático de opt-in

### **Opt-out Fácil**
- Resposta "SAIR" para qualquer mensagem
- Link de opt-out no rodapé das mensagens
- Remoção imediata da lista

### **Controle de Dados**
- Criptografia de dados sensíveis
- Logs de auditoria
- Política de retenção configurável

---

## 📊 **Monitoramento e Métricas**

### **Estatísticas Disponíveis**
- Total de sessões (conectadas/desconectadas)
- Mensagens enviadas/recebidas
- Taxa de entrega e leitura
- Opt-ins/opt-outs
- Performance por adapter

### **Logs Importantes**
```
📱 Conectando WhatsApp - loja_id: 1, phone: 5511999999999
✅ WhatsApp conectado - session_id: 123, adapter: non_official
📤 Enviando mensagem - to: 5511999999999, type: template
✅ Mensagem enviada - message_id: msg_123, status: sent
📥 Mensagem recebida - from: 5511999999999, text: "Olá"
🚫 Opt-out processado - phone: 5511999999999
```

---

## 🔄 **Migração entre Adapters**

### **Passo a Passo**
1. **Configurar Cloud API** - Obter credenciais da Meta
2. **Criar Templates** - Submeter templates para aprovação
3. **Testar Adapter** - Usar modo de teste
4. **Alterar Configuração** - Mudar adapter na sessão
5. **Monitorar** - Acompanhar métricas e performance

### **Exemplo de Migração**
```php
// Alterar adapter da sessão
$session = WhatsappSession::find(123);
$session->update(['adapter' => 'cloud_api']);

// O sistema automaticamente usará o CloudApiAdapter
```

---

## 🎯 **Boas Práticas**

### **Para Evitar Bloqueios**
- ✅ Opt-in explícito sempre
- ✅ Rate limiting (1-2 msg/s)
- ✅ Janelas de horário respeitadas
- ✅ Variação de conteúdo
- ✅ Opt-out fácil e imediato

### **Para Melhor Performance**
- ✅ Usar filas para envio
- ✅ Monitorar status das sessões
- ✅ Reconexão automática
- ✅ Logs estruturados
- ✅ Métricas em tempo real

### **Para Conformidade**
- ✅ Consentimento explícito
- ✅ Dados criptografados
- ✅ Auditoria completa
- ✅ Política de retenção
- ✅ Direito ao esquecimento

---

## 🚀 **Exemplo de Uso Completo**

### **1. Conectar WhatsApp**
```bash
curl -X POST http://localhost/api/whatsapp/connect \
  -H "Content-Type: application/json" \
  -d '{
    "loja_id": 1,
    "phone": "5511999999999",
    "adapter": "non_official"
  }'
```

### **2. Verificar Status**
```bash
curl -X GET "http://localhost/api/whatsapp/session/status?session_id=123"
```

### **3. Enviar Mensagem**
```bash
curl -X POST http://localhost/api/whatsapp/send \
  -H "Content-Type: application/json" \
  -d '{
    "session_id": 123,
    "to": "5511999999999",
    "type": "text",
    "text": "Olá! Seu pedido foi confirmado."
  }'
```

### **4. Processar Evento de Pedido**
```bash
curl -X POST http://localhost/api/whatsapp/process-event \
  -H "Content-Type: application/json" \
  -d '{
    "loja_id": 1,
    "event_key": "order_confirmed",
    "phone": "5511999999999",
    "data": {
      "pedido": "#OLK001",
      "nome": "João Silva",
      "previsao": "18:00-19:00",
      "total": "45,90"
    }
  }'
```

---

## 🎉 **Sistema Pronto para Produção**

O sistema WhatsApp Chatbot está **100% funcional** e oferece:

- ✅ **Dual Adapter** - Suporte para modo não-oficial e oficial
- ✅ **Sistema de Sessões** - Gerenciamento completo de conexões
- ✅ **Regras Automáticas** - Automação baseada em eventos
- ✅ **Opt-in/Opt-out** - Conformidade LGPD
- ✅ **Rate Limiting** - Controle de envio
- ✅ **Monitoramento** - Métricas e logs completos
- ✅ **Migração Fácil** - Troca de adapter sem reescrever código

**Sistema implementado com sucesso e pronto para uso!** 🚀
