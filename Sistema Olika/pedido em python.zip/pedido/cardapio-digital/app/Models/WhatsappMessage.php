<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class WhatsappMessage extends Model
{
    use HasFactory;

    protected $fillable = [
        'loja_id',
        'session_id',
        'direction',
        'peer',
        'type',
        'body_text',
        'media_url',
        'template_name',
        'template_vars',
        'status',
        'provider_msg_id',
        'error_message',
    ];

    protected $casts = [
        'template_vars' => 'array',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    /**
     * Relacionamento com sessão
     */
    public function session(): BelongsTo
    {
        return $this->belongsTo(WhatsappSession::class, 'session_id');
    }

    /**
     * Verificar se é mensagem de entrada
     */
    public function isIncoming(): bool
    {
        return $this->direction === 'IN';
    }

    /**
     * Verificar se é mensagem de saída
     */
    public function isOutgoing(): bool
    {
        return $this->direction === 'OUT';
    }

    /**
     * Verificar se é mensagem de texto
     */
    public function isText(): bool
    {
        return $this->type === 'text';
    }

    /**
     * Verificar se é mensagem de template
     */
    public function isTemplate(): bool
    {
        return $this->type === 'template';
    }

    /**
     * Verificar se é mensagem de mídia
     */
    public function isMedia(): bool
    {
        return in_array($this->type, ['image', 'file']);
    }

    /**
     * Verificar se a mensagem foi enviada com sucesso
     */
    public function isSent(): bool
    {
        return $this->status === 'sent';
    }

    /**
     * Verificar se a mensagem foi entregue
     */
    public function isDelivered(): bool
    {
        return $this->status === 'delivered';
    }

    /**
     * Verificar se a mensagem foi lida
     */
    public function isRead(): bool
    {
        return $this->status === 'read';
    }

    /**
     * Verificar se a mensagem falhou
     */
    public function isFailed(): bool
    {
        return $this->status === 'failed';
    }

    /**
     * Verificar se a mensagem está na fila
     */
    public function isQueued(): bool
    {
        return $this->status === 'queued';
    }

    /**
     * Atualizar status da mensagem
     */
    public function updateStatus(string $status, ?string $errorMessage = null): void
    {
        $this->update([
            'status' => $status,
            'error_message' => $errorMessage,
        ]);
    }

    /**
     * Obter conteúdo da mensagem formatado
     */
    public function getFormattedContent(): string
    {
        if ($this->isTemplate() && $this->template_vars) {
            return $this->renderTemplate();
        }
        
        return $this->body_text ?? '';
    }

    /**
     * Renderizar template com variáveis
     */
    private function renderTemplate(): string
    {
        $content = $this->body_text ?? '';
        $vars = $this->template_vars ?? [];
        
        foreach ($vars as $key => $value) {
            $content = str_replace("{{$key}}", $value, $content);
        }
        
        return $content;
    }

    /**
     * Scope para mensagens de entrada
     */
    public function scopeIncoming($query)
    {
        return $query->where('direction', 'IN');
    }

    /**
     * Scope para mensagens de saída
     */
    public function scopeOutgoing($query)
    {
        return $query->where('direction', 'OUT');
    }

    /**
     * Scope para mensagens de texto
     */
    public function scopeText($query)
    {
        return $query->where('type', 'text');
    }

    /**
     * Scope para mensagens de template
     */
    public function scopeTemplate($query)
    {
        return $query->where('type', 'template');
    }

    /**
     * Scope para um status específico
     */
    public function scopeStatus($query, string $status)
    {
        return $query->where('status', $status);
    }

    /**
     * Scope para uma loja específica
     */
    public function scopeLoja($query, int $lojaId)
    {
        return $query->where('loja_id', $lojaId);
    }

    /**
     * Scope para um peer específico
     */
    public function scopePeer($query, string $peer)
    {
        return $query->where('peer', $peer);
    }

    /**
     * Scope para mensagens recentes
     */
    public function scopeRecent($query, int $days = 7)
    {
        return $query->where('created_at', '>=', now()->subDays($days));
    }
}
