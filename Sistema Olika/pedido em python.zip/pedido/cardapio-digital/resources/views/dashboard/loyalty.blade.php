@extends('dashboard.layout-complete')

@section('title', 'Programa de Fidelidade')

@section('content')
<div class="space-y-6" x-data="loyaltyManagement()">
    <div class="flex items-center justify-between">
        <div>
            <h1 class="text-3xl font-bold">Programa de Fidelidade</h1>
            <p class="text-muted-foreground mt-1">Gerencie pontos e recompensas dos clientes</p>
        </div>
        <button 
            @click="createReward()"
            class="inline-flex items-center justify-center rounded-md text-sm font-medium bg-primary text-white hover:bg-primary/90 h-10 px-4"
        >
            <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" />
            </svg>
            Nova Recompensa
        </button>
    </div>

    <!-- Stats Cards -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div class="border rounded-lg p-6 bg-gradient-to-br from-blue-50 to-blue-100">
            <div class="flex items-center justify-between mb-2">
                <p class="text-sm text-muted-foreground">Clientes Ativos</p>
                <svg class="w-8 h-8 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
                </svg>
            </div>
            <p class="text-3xl font-bold text-blue-600" x-text="stats.active_customers || 0"></p>
            <p class="text-xs text-muted-foreground mt-1">+12% este mês</p>
        </div>
        
        <div class="border rounded-lg p-6 bg-gradient-to-br from-green-50 to-green-100">
            <div class="flex items-center justify-between mb-2">
                <p class="text-sm text-muted-foreground">Pontos Distribuídos</p>
                <svg class="w-8 h-8 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" />
                </svg>
            </div>
            <p class="text-3xl font-bold text-green-600" x-text="(stats.points_distributed || 0).toLocaleString()"></p>
            <p class="text-xs text-muted-foreground mt-1">Total acumulado</p>
        </div>
        
        <div class="border rounded-lg p-6 bg-gradient-to-br from-yellow-50 to-yellow-100">
            <div class="flex items-center justify-between mb-2">
                <p class="text-sm text-muted-foreground">Resgates Hoje</p>
                <svg class="w-8 h-8 text-yellow-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v13m0-13V6a2 2 0 112 2h-2zm0 0V5.5A2.5 2.5 0 109.5 8H12zm-7 4h14M5 12a2 2 0 110-4h14a2 2 0 110 4M5 12v7a2 2 0 002 2h10a2 2 0 002-2v-7" />
                </svg>
            </div>
            <p class="text-3xl font-bold text-yellow-600" x-text="stats.redemptions_today || 0"></p>
            <p class="text-xs text-muted-foreground mt-1">Resgates realizados</p>
        </div>
        
        <div class="border rounded-lg p-6 bg-gradient-to-br from-purple-50 to-purple-100">
            <div class="flex items-center justify-between mb-2">
                <p class="text-sm text-muted-foreground">Taxa de Engajamento</p>
                <svg class="w-8 h-8 text-purple-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                </svg>
            </div>
            <p class="text-3xl font-bold text-purple-600" x-text="(stats.engagement_rate || 0) + '%'"></p>
            <p class="text-xs text-muted-foreground mt-1">Clientes participando</p>
        </div>
    </div>

    <!-- Tabs -->
    <div x-data="{ activeTab: 'rewards' }">
        <div class="inline-flex h-10 items-center justify-center rounded-md bg-muted p-1 text-muted-foreground mb-6">
            <button 
                @click="activeTab = 'rewards'"
                :class="activeTab === 'rewards' ? 'bg-background text-foreground shadow-sm' : ''"
                class="inline-flex items-center justify-center whitespace-nowrap rounded-sm px-3 py-1.5 text-sm font-medium ring-offset-background transition-all"
            >
                🎁 Recompensas
            </button>
            <button 
                @click="activeTab = 'customers'"
                :class="activeTab === 'customers' ? 'bg-background text-foreground shadow-sm' : ''"
                class="inline-flex items-center justify-center whitespace-nowrap rounded-sm px-3 py-1.5 text-sm font-medium ring-offset-background transition-all"
            >
                👥 Clientes
            </button>
            <button 
                @click="activeTab = 'config'"
                :class="activeTab === 'config' ? 'bg-background text-foreground shadow-sm' : ''"
                class="inline-flex items-center justify-center whitespace-nowrap rounded-sm px-3 py-1.5 text-sm font-medium ring-offset-background transition-all"
            >
                ⚙️ Configurações
            </button>
        </div>

        <!-- Recompensas Tab -->
        <div x-show="activeTab === 'rewards'" x-transition>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <template x-for="reward in rewards" :key="reward.id">
                    <div class="border rounded-lg p-6 hover:shadow-lg transition">
                        <div class="flex items-start justify-between mb-4">
                            <div class="flex-1">
                                <h3 class="font-semibold text-lg mb-1" x-text="reward.name"></h3>
                                <p class="text-sm text-muted-foreground mb-3" x-text="reward.description"></p>
                            </div>
                        </div>
                        
                        <div class="space-y-2 mb-4 p-4 bg-muted/30 rounded-lg">
                            <div class="flex items-center justify-between text-sm">
                                <span class="text-muted-foreground">💎 Pontos:</span>
                                <span class="font-bold text-primary text-lg" x-text="reward.points + ' pts'"></span>
                            </div>
                            <div class="flex items-center justify-between text-sm">
                                <span class="text-muted-foreground">📊 Resgates:</span>
                                <span class="font-medium" x-text="reward.redemptions || 0"></span>
                            </div>
                            <div class="flex items-center justify-between text-sm">
                                <span class="text-muted-foreground">💰 Valor:</span>
                                <span class="font-medium">R$ <span x-text="(reward.value || 0).toFixed(2).replace('.', ',')"></span></span>
                            </div>
                            <div class="flex items-center justify-between text-sm">
                                <span class="text-muted-foreground">Status:</span>
                                <span 
                                    :class="reward.active ? 'text-green-600' : 'text-red-600'"
                                    class="font-medium"
                                    x-text="reward.active ? '✓ Ativa' : '✗ Inativa'"
                                ></span>
                            </div>
                        </div>
                        
                        <div class="flex gap-2">
                            <button 
                                @click="editReward(reward)"
                                class="flex-1 inline-flex items-center justify-center rounded-md text-sm font-medium border border-input bg-background hover:bg-accent h-9 px-3"
                            >
                                Editar
                            </button>
                            <button 
                                @click="toggleReward(reward.id)"
                                :class="reward.active ? 'bg-red-500 hover:bg-red-600' : 'bg-green-500 hover:bg-green-600'"
                                class="flex-1 inline-flex items-center justify-center rounded-md text-sm font-medium text-white h-9 px-3"
                                x-text="reward.active ? 'Desativar' : 'Ativar'"
                            ></button>
                        </div>
                    </div>
                </template>
            </div>
        </div>

        <!-- Clientes Tab -->
        <div x-show="activeTab === 'customers'" x-transition>
            <div class="border rounded-lg">
                <div class="p-6 border-b">
                    <h3 class="font-semibold text-lg">🏆 Top 10 Clientes</h3>
                </div>
                <div class="p-6">
                    <div class="space-y-3">
                        <template x-for="(customer, index) in topCustomers" :key="customer.id">
                            <div class="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition">
                                <div class="flex items-center gap-4">
                                    <div 
                                        class="w-10 h-10 rounded-full flex items-center justify-center font-bold text-white text-lg"
                                        :class="{
                                            'bg-gradient-to-br from-yellow-400 to-yellow-600': index === 0,
                                            'bg-gradient-to-br from-gray-300 to-gray-500': index === 1,
                                            'bg-gradient-to-br from-orange-400 to-orange-600': index === 2,
                                            'bg-gradient-to-br from-blue-400 to-blue-600': index > 2
                                        }"
                                    >
                                        <span x-text="index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : (index + 1)"></span>
                                    </div>
                                    <div>
                                        <p class="font-medium" x-text="customer.name"></p>
                                        <p class="text-xs text-muted-foreground" x-text="customer.email"></p>
                                    </div>
                                </div>
                                <div class="text-right">
                                    <p class="font-bold text-primary text-lg" x-text="(customer.points || 0) + ' pts'"></p>
                                    <p class="text-xs text-muted-foreground">
                                        <span x-text="customer.redemptions || 0"></span> resgates • 
                                        R$ <span x-text="((customer.total_spent || 0)).toFixed(2).replace('.', ',')"></span>
                                    </p>
                                </div>
                            </div>
                        </template>
                    </div>
                </div>
            </div>
        </div>

        <!-- Configurações Tab -->
        <div x-show="activeTab === 'config'" x-transition>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div class="border rounded-lg p-6">
                    <h3 class="font-semibold text-lg mb-4">⚙️ Regras de Pontuação</h3>
                    
                    <div class="space-y-4">
                        <div>
                            <label class="text-sm font-medium">💰 Pontos por R$ 1,00 gasto</label>
                            <input 
                                type="number" 
                                x-model="config.points_per_real"
                                class="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm mt-2"
                                min="0"
                                step="0.1"
                            />
                            <p class="text-xs text-muted-foreground mt-1">Ex: 1 ponto = R$ 1,00 gasto</p>
                        </div>

                        <div>
                            <label class="text-sm font-medium">🎂 Bônus de aniversário (pontos)</label>
                            <input 
                                type="number" 
                                x-model="config.birthday_bonus"
                                class="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm mt-2"
                                min="0"
                            />
                            <p class="text-xs text-muted-foreground mt-1">Pontos ganhos no aniversário</p>
                        </div>

                        <div>
                            <label class="text-sm font-medium">⏰ Expiração de pontos (dias)</label>
                            <input 
                                type="number" 
                                x-model="config.points_expiration"
                                class="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm mt-2"
                                min="0"
                            />
                            <p class="text-xs text-muted-foreground mt-1">0 = sem expiração</p>
                        </div>

                        <div>
                            <label class="text-sm font-medium">🎁 Pontos boas-vindas</label>
                            <input 
                                type="number" 
                                x-model="config.welcome_bonus"
                                class="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm mt-2"
                                min="0"
                            />
                            <p class="text-xs text-muted-foreground mt-1">Pontos para novos clientes</p>
                        </div>

                        <div class="flex items-center justify-between p-4 border rounded-lg mt-4">
                            <div>
                                <p class="font-medium">Programa ativo</p>
                                <p class="text-sm text-muted-foreground">Ativar/desativar programa</p>
                            </div>
                            <label class="inline-flex items-center cursor-pointer">
                                <input 
                                    type="checkbox" 
                                    x-model="config.program_enabled"
                                    class="sr-only peer"
                                />
                                <div class="relative w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                            </label>
                        </div>

                        <button 
                            @click="saveConfig()"
                            class="w-full inline-flex items-center justify-center rounded-md text-sm font-medium bg-primary text-white hover:bg-primary/90 h-10 px-4 mt-4"
                        >
                            💾 Salvar Configurações
                        </button>
                    </div>
                </div>

                <div class="border rounded-lg p-6">
                    <h3 class="font-semibold text-lg mb-4">📊 Estatísticas do Programa</h3>
                    
                    <div class="space-y-4">
                        <div class="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                            <p class="text-sm text-blue-600 mb-1">Total de Participantes</p>
                            <p class="text-3xl font-bold text-blue-700" x-text="stats.total_participants || 0"></p>
                        </div>
                        
                        <div class="p-4 bg-green-50 border border-green-200 rounded-lg">
                            <p class="text-sm text-green-600 mb-1">Pontos em Circulação</p>
                            <p class="text-3xl font-bold text-green-700" x-text="(stats.points_in_circulation || 0).toLocaleString()"></p>
                        </div>
                        
                        <div class="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                            <p class="text-sm text-yellow-600 mb-1">Total Resgatado (R$)</p>
                            <p class="text-3xl font-bold text-yellow-700">R$ <span x-text="((stats.total_redeemed || 0)).toFixed(2).replace('.', ',')"></span></p>
                        </div>
                        
                        <div class="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                            <p class="text-sm text-purple-600 mb-1">ROI do Programa</p>
                            <p class="text-3xl font-bold text-purple-700" x-text="(stats.roi || 0) + '%'"></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function loyaltyManagement() {
    return {
        stats: @json($stats ?? ['active_customers' => 0, 'points_distributed' => 0, 'redemptions_today' => 0, 'engagement_rate' => 0]),
        rewards: @json($rewards ?? []),
        config: @json($config ?? ['points_per_real' => 1, 'birthday_bonus' => 100, 'points_expiration' => 365, 'welcome_bonus' => 50, 'program_enabled' => true]),
        topCustomers: @json($topCustomers ?? []),
        
        createReward() {
            window.location.href = '/dashboard/loyalty/rewards/create';
        },
        
        editReward(reward) {
            window.location.href = `/dashboard/loyalty/rewards/${reward.id}/edit`;
        },
        
        toggleReward(id) {
            fetch(`/api/loyalty/rewards/${id}/toggle`, {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': document.querySelector('meta[name=csrf-token]').content
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    window.showToast('Status atualizado!', 'success');
                    window.location.reload();
                }
            })
            .catch(error => {
                console.error('Erro:', error);
                window.showToast('Erro ao atualizar', 'error');
            });
        },
        
        saveConfig() {
            fetch('/api/loyalty/config', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name=csrf-token]').content
                },
                body: JSON.stringify(this.config)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    window.showToast('Configurações salvas com sucesso!', 'success');
                }
            })
            .catch(error => {
                console.error('Erro:', error);
                window.showToast('Erro ao salvar configurações', 'error');
            });
        }
    }
}
</script>
@endsection

