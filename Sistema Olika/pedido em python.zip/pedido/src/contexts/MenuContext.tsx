import React, { createContext, useContext, useState, useEffect } from "react";
import { Product, CartItem, Category, MenuConfig, Coupon, Customer, DeliveryFee, Order } from "@/types/menu";

interface MenuContextType {
  products: Product[];
  categories: Category[];
  cart: CartItem[];
  config: MenuConfig;
  coupons: Coupon[];
  customers: Customer[];
  deliveryFees: DeliveryFee[];
  orders: Order[];
  appliedCoupon: Coupon | null;
  currentCustomer: Customer | null;
  addToCart: (product: Product) => void;
  removeFromCart: (productId: string) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  updateConfig: (config: Partial<MenuConfig>) => void;
  addProduct: (product: Product) => void;
  updateProduct: (product: Product) => void;
  deleteProduct: (productId: string) => void;
  addCategory: (category: Category) => void;
  deleteCategory: (categoryId: string) => void;
  addCoupon: (coupon: Coupon) => void;
  updateCoupon: (coupon: Coupon) => void;
  deleteCoupon: (couponId: string) => void;
  applyCoupon: (code: string) => boolean;
  removeCoupon: () => void;
  addCustomer: (customer: Omit<Customer, 'id' | 'orderCount'>) => Customer;
  updateCustomer: (customer: Customer) => void;
  setCurrentCustomer: (customer: Customer | null) => void;
  addDeliveryFee: (fee: DeliveryFee) => void;
  updateDeliveryFee: (cep: string, fee: number) => void;
  deleteDeliveryFee: (cep: string) => void;
  getDeliveryFee: (cep: string) => number;
  createOrder: (order: Omit<Order, 'id' | 'createdAt'>) => Order;
}

const MenuContext = createContext<MenuContextType | undefined>(undefined);

// Dados de exemplo
const defaultProducts: Product[] = [
  {
    id: "1",
    name: "Pão de Fermentação Natural",
    description: "Pão rústico feito com fermentação natural de 24h",
    price: 18.00,
    image: "https://images.unsplash.com/photo-1509440159596-0249088772ff?w=800&q=80",
    category: "paes-rusticos",
    available: true,
  },
  {
    id: "2",
    name: "Focaccia de Alecrim",
    description: "Focaccia italiana com alecrim fresco e azeite",
    price: 22.00,
    image: "https://images.unsplash.com/photo-1555507036-ab1f4038808a?w=800&q=80",
    category: "focaccias",
    available: true,
  },
  {
    id: "3",
    name: "Baguete Francesa",
    description: "Baguete crocante tradicional francesa",
    price: 12.00,
    image: "https://images.unsplash.com/photo-1549931319-a545dcf3bc73?w=800&q=80",
    category: "paes-rusticos",
    available: true,
  },
  {
    id: "4",
    name: "Croissant de Manteiga",
    description: "Croissant folhado artesanal com manteiga francesa",
    price: 8.00,
    image: "https://images.unsplash.com/photo-1555507036-ab1f4038808a?w=800&q=80",
    category: "paes-doces",
    available: true,
  },
  {
    id: "5",
    name: "Pão de Forma Integral",
    description: "Pão de forma integral com grãos",
    price: 15.00,
    image: "https://images.unsplash.com/photo-1586444248902-2f64eddc13df?w=800&q=80",
    category: "paes-forma",
    available: true,
  },
  {
    id: "6",
    name: "Brownie de Chocolate",
    description: "Brownie úmido com chocolate belga 70% cacau",
    price: 10.00,
    image: "https://images.unsplash.com/photo-1515037893149-de7f840978e2?w=800&q=80",
    category: "paes-doces",
    available: true,
  },
];

const defaultCategories: Category[] = [
  { id: "novidades", name: "Novidades 🎉" },
  { id: "paes-doces", name: "Pães Doces/Brownies" },
  { id: "focaccias", name: "Focaccias" },
  { id: "paes-rusticos", name: "Pães Rústicos" },
  { id: "paes-forma", name: "Pães de Forma" },
];

const defaultConfig: MenuConfig = {
  businessName: "Olika - Pães Artesanais",
  description: "Pães e massas artesanais feitos com amor e ingredientes selecionados",
  primaryColor: "#FF8C00",
  phone: "(11) 99999-9999",
  deliveryInfo: "Entrega grátis acima de R$ 100,00",
  minDeliveryValue: 100,
  isOpen: true,
  displayMode: 'grid',
};

const defaultCoupons: Coupon[] = [
  {
    id: "1",
    code: "BEMVINDO",
    description: "10% de desconto na primeira compra",
    discountType: "percentage",
    discountValue: 10,
    isPublic: true,
    firstPurchaseOnly: true,
    active: true,
  },
  {
    id: "2",
    code: "FRETE20",
    description: "R$ 20 de desconto",
    discountType: "fixed",
    discountValue: 20,
    isPublic: false,
    firstPurchaseOnly: false,
    minPurchaseValue: 100,
    active: true,
  },
];

export const MenuProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem("menuProducts");
      return saved ? JSON.parse(saved) : defaultProducts;
    } catch (error) {
      console.error("Erro ao carregar produtos do localStorage:", error);
      return defaultProducts;
    }
  });

  const [categories, setCategories] = useState<Category[]>(() => {
    const saved = localStorage.getItem("menuCategories");
    return saved ? JSON.parse(saved) : defaultCategories;
  });

  const [cart, setCart] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem("menuCart");
    return saved ? JSON.parse(saved) : [];
  });

  const [config, setConfig] = useState<MenuConfig>(() => {
    const saved = localStorage.getItem("menuConfig");
    return saved ? JSON.parse(saved) : defaultConfig;
  });

  const [coupons, setCoupons] = useState<Coupon[]>(() => {
    const saved = localStorage.getItem("menuCoupons");
    return saved ? JSON.parse(saved) : defaultCoupons;
  });

  const [customers, setCustomers] = useState<Customer[]>(() => {
    const saved = localStorage.getItem("menuCustomers");
    return saved ? JSON.parse(saved) : [];
  });

  const [deliveryFees, setDeliveryFees] = useState<DeliveryFee[]>(() => {
    const saved = localStorage.getItem("menuDeliveryFees");
    return saved ? JSON.parse(saved) : [];
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = localStorage.getItem("menuOrders");
    return saved ? JSON.parse(saved) : [];
  });

  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(null);
  const [currentCustomer, setCurrentCustomer] = useState<Customer | null>(null);

  useEffect(() => {
    localStorage.setItem("menuProducts", JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem("menuCategories", JSON.stringify(categories));
  }, [categories]);

  useEffect(() => {
    localStorage.setItem("menuCart", JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem("menuConfig", JSON.stringify(config));
  }, [config]);

  useEffect(() => {
    localStorage.setItem("menuCoupons", JSON.stringify(coupons));
  }, [coupons]);

  useEffect(() => {
    localStorage.setItem("menuCustomers", JSON.stringify(customers));
  }, [customers]);

  useEffect(() => {
    localStorage.setItem("menuDeliveryFees", JSON.stringify(deliveryFees));
  }, [deliveryFees]);

  useEffect(() => {
    localStorage.setItem("menuOrders", JSON.stringify(orders));
  }, [orders]);

  const addToCart = (product: Product) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { ...product, quantity: 1 }];
    });
  };

  const removeFromCart = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.id !== productId));
  };

  const updateQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
    } else {
      setCart((prev) =>
        prev.map((item) => (item.id === productId ? { ...item, quantity } : item))
      );
    }
  };

  const clearCart = () => {
    setCart([]);
  };

  const updateConfig = (newConfig: Partial<MenuConfig>) => {
    setConfig((prev) => ({ ...prev, ...newConfig }));
  };

  const addProduct = (product: Product) => {
    setProducts((prev) => [...prev, product]);
  };

  const updateProduct = (product: Product) => {
    setProducts((prev) => prev.map((p) => (p.id === product.id ? product : p)));
  };

  const deleteProduct = (productId: string) => {
    setProducts((prev) => prev.filter((p) => p.id !== productId));
  };

  const addCategory = (category: Category) => {
    setCategories((prev) => [...prev, category]);
  };

  const deleteCategory = (categoryId: string) => {
    setCategories((prev) => prev.filter((c) => c.id !== categoryId));
  };

  const addCoupon = (coupon: Coupon) => {
    setCoupons((prev) => [...prev, coupon]);
  };

  const updateCoupon = (coupon: Coupon) => {
    setCoupons((prev) => prev.map((c) => (c.id === coupon.id ? coupon : c)));
  };

  const deleteCoupon = (couponId: string) => {
    setCoupons((prev) => prev.filter((c) => c.id !== couponId));
  };

  const applyCoupon = (code: string): boolean => {
    const coupon = coupons.find(
      (c) => c.code.toUpperCase() === code.toUpperCase() && c.active
    );
    
    if (!coupon) return false;

    const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
    
    if (coupon.minPurchaseValue && subtotal < coupon.minPurchaseValue) {
      return false;
    }

    if (coupon.firstPurchaseOnly && currentCustomer && currentCustomer.orderCount > 0) {
      return false;
    }

    setAppliedCoupon(coupon);
    return true;
  };

  const removeCoupon = () => {
    setAppliedCoupon(null);
  };

  const addCustomer = (customerData: Omit<Customer, 'id' | 'orderCount'>): Customer => {
    const newCustomer: Customer = {
      ...customerData,
      id: Date.now().toString(),
      orderCount: 0,
    };
    setCustomers((prev) => [...prev, newCustomer]);
    return newCustomer;
  };

  const updateCustomer = (customer: Customer) => {
    setCustomers((prev) => prev.map((c) => (c.id === customer.id ? customer : c)));
  };

  const addDeliveryFee = (fee: DeliveryFee) => {
    setDeliveryFees((prev) => [...prev, fee]);
  };

  const updateDeliveryFee = (cep: string, fee: number) => {
    setDeliveryFees((prev) =>
      prev.map((f) => (f.cep === cep ? { ...f, fee } : f))
    );
  };

  const deleteDeliveryFee = (cep: string) => {
    setDeliveryFees((prev) => prev.filter((f) => f.cep !== cep));
  };

  const getDeliveryFee = (cep: string): number => {
    const fee = deliveryFees.find((f) => f.cep === cep.replace(/\D/g, ''));
    return fee ? fee.fee : 0;
  };

  const createOrder = (orderData: Omit<Order, 'id' | 'createdAt'>): Order => {
    const newOrder: Order = {
      ...orderData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
    };
    setOrders((prev) => [...prev, newOrder]);
    
    if (currentCustomer) {
      updateCustomer({ ...currentCustomer, orderCount: currentCustomer.orderCount + 1 });
    }
    
    return newOrder;
  };

  return (
    <MenuContext.Provider
      value={{
        products,
        categories,
        cart,
        config,
        coupons,
        customers,
        deliveryFees,
        orders,
        appliedCoupon,
        currentCustomer,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        updateConfig,
        addProduct,
        updateProduct,
        deleteProduct,
        addCategory,
        deleteCategory,
        addCoupon,
        updateCoupon,
        deleteCoupon,
        applyCoupon,
        removeCoupon,
        addCustomer,
        updateCustomer,
        setCurrentCustomer,
        addDeliveryFee,
        updateDeliveryFee,
        deleteDeliveryFee,
        getDeliveryFee,
        createOrder,
      }}
    >
      {children}
    </MenuContext.Provider>
  );
};

export const useMenu = () => {
  const context = useContext(MenuContext);
  if (!context) {
    throw new Error("useMenu must be used within MenuProvider");
  }
  return context;
};
