@props([
    'text' => '',
    'position' => 'top',
])

<div class="relative inline-block" x-data="{ show: false }">
    <div @mouseenter="show = true" @mouseleave="show = false">
        {{ $slot }}
    </div>
    
    <div 
        x-show="show"
        x-transition
        class="absolute z-50 px-2 py-1 text-xs font-medium text-white bg-gray-900 rounded shadow-sm whitespace-nowrap
        @if($position === 'top') bottom-full left-1/2 -translate-x-1/2 mb-2
        @elseif($position === 'bottom') top-full left-1/2 -translate-x-1/2 mt-2
        @elseif($position === 'left') right-full top-1/2 -translate-y-1/2 mr-2
        @elseif($position === 'right') left-full top-1/2 -translate-y-1/2 ml-2
        @endif"
    >
        {{ $text }}
    </div>
</div>

