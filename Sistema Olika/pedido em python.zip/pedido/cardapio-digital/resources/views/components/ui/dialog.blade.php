@props([
    'id' => null,
    'title' => '',
    'open' => false,
])

@php
$dialogId = $id ?? 'dialog-' . uniqid();
@endphp

<!-- Modal Backdrop -->
<div 
    id="{{ $dialogId }}"
    class="fixed inset-0 z-50 bg-black/80 {{ $open ? '' : 'hidden' }}"
    x-data="{ open: {{ $open ? 'true' : 'false' }} }"
    x-show="open"
    @click.self="open = false"
    x-transition:enter="transition ease-out duration-200"
    x-transition:enter-start="opacity-0"
    x-transition:enter-end="opacity-100"
    x-transition:leave="transition ease-in duration-150"
    x-transition:leave-start="opacity-100"
    x-transition:leave-end="opacity-0"
>
    <!-- Modal Content -->
    <div class="fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 sm:rounded-lg">
        @if($title)
            <div class="flex items-center justify-between">
                <h2 class="text-lg font-semibold">{{ $title }}</h2>
                <button 
                    @click="open = false"
                    class="rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2"
                >
                    <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>
            </div>
        @endif
        
        <div>
            {{ $slot }}
        </div>
    </div>
</div>

