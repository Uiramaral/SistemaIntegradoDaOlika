<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('mensagens_suporte', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('conversa_id');
            $table->string('subscriber_id', 50)->nullable();
            $table->enum('role', ['user', 'assistant', 'system']);
            $table->text('conteudo');
            $table->json('metadata')->nullable();
            $table->boolean('processada')->default(false);
            $table->json('classificacao')->nullable()->comment('Análise de intenção e sentimento');
            $table->unsignedInteger('tokens_prompt')->default(0);
            $table->unsignedInteger('tokens_completion')->default(0);
            $table->unsignedInteger('tokens_total')->default(0);
            $table->string('model_usado', 50)->nullable();
            $table->decimal('custo_estimado', 10, 6)->default(0);
            $table->timestamp('created_at')->useCurrent();
            $table->timestamp('updated_at')->useCurrent()->useCurrentOnUpdate();
            
            $table->index('conversa_id', 'idx_conversa_id');
            $table->index('subscriber_id', 'idx_subscriber_id');
            $table->index('role', 'idx_role');
            $table->index('tokens_total', 'idx_tokens_total');
            $table->index('created_at', 'idx_created_at');
            
            $table->foreign('conversa_id')->references('id')->on('conversas_suporte')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('mensagens_suporte');
    }
};
