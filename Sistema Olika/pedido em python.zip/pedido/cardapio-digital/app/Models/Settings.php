<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Cache;

class Settings extends Model
{
    use HasFactory;

    protected $fillable = [
        'business_name',
        'logo',
        'header_image',
        'primary_color',
        'description',
        'phone',
        'address',
        'delivery_info',
        'min_delivery_value',
        'is_open',
        'mercado_pago_access_token',
        'mercado_pago_public_key',
        'mercado_pago_return_url',
        'mercado_pago_webhook_url',
        'mercado_pago_environment',
        'display_mode',
        'whatsapp_api_url',
        'whatsapp_api_token',
        'google_maps_api_key',
        'free_delivery_threshold',
        'order_cutoff_time',
        'advance_order_days',
        'database_url',
        'api_base_url',
        'debug_mode',
    ];

    protected $casts = [
        'min_delivery_value' => 'decimal:2',
        'free_delivery_threshold' => 'decimal:2',
        'is_open' => 'boolean',
        'debug_mode' => 'boolean',
        'advance_order_days' => 'integer',
    ];

    protected $dates = [
        'created_at',
        'updated_at',
    ];

    const ENVIRONMENT_SANDBOX = 'sandbox';
    const ENVIRONMENT_PRODUCTION = 'production';

    const DISPLAY_MODE_GRID = 'grid';
    const DISPLAY_MODE_LIST = 'list';
    const DISPLAY_MODE_COMPACT = 'compact';

    /**
     * Obter configurações do sistema
     */
    public static function getSettings(): self
    {
        return Cache::remember('system_settings', 3600, function () {
            return self::first() ?? self::createDefault();
        });
    }

    /**
     * Criar configurações padrão
     */
    public static function createDefault(): self
    {
        return self::create([
            'business_name' => 'Olika - Pães Artesanais',
            'primary_color' => '#FF8C00',
            'description' => 'Pães e massas artesanais feitos com amor e ingredientes selecionados',
            'phone' => '(11) 99999-9999',
            'delivery_info' => 'Entrega grátis acima de R$ 100,00',
            'min_delivery_value' => 100,
            'free_delivery_threshold' => 100,
            'is_open' => true,
            'display_mode' => self::DISPLAY_MODE_GRID,
            'mercado_pago_environment' => self::ENVIRONMENT_SANDBOX,
            'order_cutoff_time' => '20:00',
            'advance_order_days' => 1,
            'debug_mode' => false,
        ]);
    }

    /**
     * Atualizar configurações
     */
    public static function updateSettings(array $data): self
    {
        $settings = self::getSettings();
        
        $settings->update($data);
        
        // Limpar cache
        Cache::forget('system_settings');
        
        return $settings->fresh();
    }

    /**
     * Obter configuração específica
     */
    public static function get(string $key, $default = null)
    {
        $settings = self::getSettings();
        
        return $settings->{$key} ?? $default;
    }

    /**
     * Definir configuração específica
     */
    public static function set(string $key, $value): void
    {
        $settings = self::getSettings();
        
        $settings->update([$key => $value]);
        
        // Limpar cache
        Cache::forget('system_settings');
    }

    /**
     * Verificar se loja está aberta
     */
    public function isOpen(): bool
    {
        return $this->is_open;
    }

    /**
     * Abrir loja
     */
    public function open(): void
    {
        $this->is_open = true;
        $this->save();
        
        Cache::forget('system_settings');
    }

    /**
     * Fechar loja
     */
    public function close(): void
    {
        $this->is_open = false;
        $this->save();
        
        Cache::forget('system_settings');
    }

    /**
     * Toggle status da loja
     */
    public function toggleStatus(): void
    {
        $this->is_open = !$this->is_open;
        $this->save();
        
        Cache::forget('system_settings');
    }

    /**
     * Verificar se Mercado Pago está configurado
     */
    public function isMercadoPagoConfigured(): bool
    {
        return !empty($this->mercado_pago_access_token) && 
               !empty($this->mercado_pago_public_key);
    }

    /**
     * Verificar se WhatsApp está configurado
     */
    public function isWhatsAppConfigured(): bool
    {
        return !empty($this->whatsapp_api_url) && 
               !empty($this->whatsapp_api_token);
    }

    /**
     * Verificar se Google Maps está configurado
     */
    public function isGoogleMapsConfigured(): bool
    {
        return !empty($this->google_maps_api_key);
    }

    /**
     * Obter cor primária formatada
     */
    public function getFormattedPrimaryColorAttribute(): string
    {
        return $this->primary_color ?: '#FF8C00';
    }

    /**
     * Obter valor mínimo de entrega formatado
     */
    public function getFormattedMinDeliveryValueAttribute(): string
    {
        return 'R$ ' . number_format($this->min_delivery_value, 2, ',', '.');
    }

    /**
     * Obter threshold de entrega grátis formatado
     */
    public function getFormattedFreeDeliveryThresholdAttribute(): string
    {
        return 'R$ ' . number_format($this->free_delivery_threshold, 2, ',', '.');
    }

    /**
     * Verificar se é ambiente de produção
     */
    public function isProductionEnvironment(): bool
    {
        return $this->mercado_pago_environment === self::ENVIRONMENT_PRODUCTION;
    }

    /**
     * Verificar se é ambiente de sandbox
     */
    public function isSandboxEnvironment(): bool
    {
        return $this->mercado_pago_environment === self::ENVIRONMENT_SANDBOX;
    }

    /**
     * Obter ambiente do Mercado Pago formatado
     */
    public function getMercadoPagoEnvironmentLabelAttribute(): string
    {
        return $this->isProductionEnvironment() ? 'Produção' : 'Sandbox';
    }

    /**
     * Obter modo de exibição formatado
     */
    public function getDisplayModeLabelAttribute(): string
    {
        $modes = [
            self::DISPLAY_MODE_GRID => 'Grid',
            self::DISPLAY_MODE_LIST => 'Lista',
            self::DISPLAY_MODE_COMPACT => 'Compacto',
        ];

        return $modes[$this->display_mode] ?? 'Grid';
    }

    /**
     * Verificar se horário de corte já passou
     */
    public function isOrderCutoffPassed(): bool
    {
        if (!$this->order_cutoff_time) {
            return false;
        }

        $cutoffTime = Carbon::createFromFormat('H:i', $this->order_cutoff_time);
        $now = Carbon::now();

        return $now->format('H:i') > $cutoffTime->format('H:i');
    }

    /**
     * Obter configurações públicas (sem dados sensíveis)
     */
    public function getPublicSettings(): array
    {
        return [
            'business_name' => $this->business_name,
            'logo' => $this->logo,
            'header_image' => $this->header_image,
            'primary_color' => $this->primary_color,
            'description' => $this->description,
            'phone' => $this->phone,
            'address' => $this->address,
            'delivery_info' => $this->delivery_info,
            'min_delivery_value' => $this->min_delivery_value,
            'is_open' => $this->is_open,
            'display_mode' => $this->display_mode,
            'free_delivery_threshold' => $this->free_delivery_threshold,
            'order_cutoff_time' => $this->order_cutoff_time,
            'advance_order_days' => $this->advance_order_days,
            'mercado_pago_public_key' => $this->mercado_pago_public_key,
            'mercado_pago_environment' => $this->mercado_pago_environment,
        ];
    }

    /**
     * Boot do modelo
     */
    protected static function boot()
    {
        parent::boot();

        static::saved(function ($settings) {
            Cache::forget('system_settings');
        });

        static::updated(function ($settings) {
            Cache::forget('system_settings');
        });
    }
}
