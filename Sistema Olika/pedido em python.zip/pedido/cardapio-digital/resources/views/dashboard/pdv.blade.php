@extends('dashboard.layout-complete')

@section('title', 'PDV - Cardápio Digital Olika')
@section('page-title', 'Ponto de Venda (PDV)')

@section('content')
<div class="space-y-6">
    <!-- Header do PDV -->
    <div class="bg-white rounded-xl p-6 shadow-lg">
        <div class="flex items-center justify-between">
            <div>
                <h2 class="text-2xl font-bold text-gray-900">Ponto de Venda</h2>
                <p class="text-gray-600">Gerencie vendas e pedidos em tempo real</p>
            </div>
            <div class="flex items-center space-x-4">
                <div class="text-right">
                    <p class="text-sm text-gray-500">Vendas Hoje</p>
                    <p class="text-2xl font-bold text-green-600">R$ 1.234</p>
                </div>
                <div class="text-right">
                    <p class="text-sm text-gray-500">Pedidos</p>
                    <p class="text-2xl font-bold text-blue-600">23</p>
                </div>
            </div>
        </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Produtos -->
        <div class="lg:col-span-2">
            <div class="bg-white rounded-xl shadow-lg">
                <!-- Filtros -->
                <div class="p-6 border-b border-gray-200">
                    <div class="flex flex-col sm:flex-row gap-4">
                        <!-- Busca -->
                        <div class="flex-1">
                            <div class="relative">
                                <input 
                                    type="text" 
                                    id="product-search"
                                    placeholder="Buscar produtos..."
                                    class="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                                >
                                <svg class="absolute left-3 top-2.5 w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                                </svg>
                            </div>
                        </div>
                        
                        <!-- Categoria -->
                        <select id="category-filter" class="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                            <option value="">Todas as categorias</option>
                            <option value="1">Pratos Principais</option>
                            <option value="2">Bebidas</option>
                            <option value="3">Sobremesas</option>
                        </select>
                    </div>
                </div>

                <!-- Lista de Produtos -->
                <div class="p-6">
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4" id="products-grid">
                        <!-- Produto 1 -->
                        <div class="product-card border border-gray-200 rounded-lg p-4 hover:shadow-md transition cursor-pointer" data-product-id="1">
                            <div class="flex items-center space-x-4">
                                <img src="/placeholder.svg" alt="Pizza Margherita" class="w-16 h-16 object-cover rounded-lg">
                                <div class="flex-1">
                                    <h3 class="font-semibold text-gray-900">Pizza Margherita</h3>
                                    <p class="text-sm text-gray-500">Molho de tomate, mussarela, manjericão</p>
                                    <p class="text-lg font-bold text-green-600">R$ 45,00</p>
                                </div>
                                <button class="add-to-cart bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
                                    </svg>
                                </button>
                            </div>
                        </div>

                        <!-- Produto 2 -->
                        <div class="product-card border border-gray-200 rounded-lg p-4 hover:shadow-md transition cursor-pointer" data-product-id="2">
                            <div class="flex items-center space-x-4">
                                <img src="/placeholder.svg" alt="Hambúrguer Clássico" class="w-16 h-16 object-cover rounded-lg">
                                <div class="flex-1">
                                    <h3 class="font-semibold text-gray-900">Hambúrguer Clássico</h3>
                                    <p class="text-sm text-gray-500">Pão, carne, queijo, alface, tomate</p>
                                    <p class="text-lg font-bold text-green-600">R$ 25,00</p>
                                </div>
                                <button class="add-to-cart bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
                                    </svg>
                                </button>
                            </div>
                        </div>

                        <!-- Produto 3 -->
                        <div class="product-card border border-gray-200 rounded-lg p-4 hover:shadow-md transition cursor-pointer" data-product-id="3">
                            <div class="flex items-center space-x-4">
                                <img src="/placeholder.svg" alt="Refrigerante" class="w-16 h-16 object-cover rounded-lg">
                                <div class="flex-1">
                                    <h3 class="font-semibold text-gray-900">Refrigerante</h3>
                                    <p class="text-sm text-gray-500">Coca-Cola, Pepsi, Guaraná</p>
                                    <p class="text-lg font-bold text-green-600">R$ 8,00</p>
                                </div>
                                <button class="add-to-cart bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
                                    </svg>
                                </button>
                            </div>
                        </div>

                        <!-- Produto 4 -->
                        <div class="product-card border border-gray-200 rounded-lg p-4 hover:shadow-md transition cursor-pointer" data-product-id="4">
                            <div class="flex items-center space-x-4">
                                <img src="/placeholder.svg" alt="Pudim" class="w-16 h-16 object-cover rounded-lg">
                                <div class="flex-1">
                                    <h3 class="font-semibold text-gray-900">Pudim</h3>
                                    <p class="text-sm text-gray-500">Pudim de leite condensado</p>
                                    <p class="text-lg font-bold text-green-600">R$ 12,00</p>
                                </div>
                                <button class="add-to-cart bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
                                    </svg>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Carrinho e Finalização -->
        <div class="lg:col-span-1">
            <div class="bg-white rounded-xl shadow-lg">
                <!-- Header do Carrinho -->
                <div class="p-6 border-b border-gray-200">
                    <h3 class="text-lg font-semibold text-gray-900">Carrinho de Vendas</h3>
                    <p class="text-sm text-gray-500" id="cart-count">0 itens</p>
                </div>

                <!-- Itens do Carrinho -->
                <div class="p-6">
                    <div id="cart-items" class="space-y-4">
                        <!-- Itens serão adicionados via JavaScript -->
                    </div>

                    <!-- Carrinho Vazio -->
                    <div id="empty-cart" class="text-center py-8">
                        <svg class="w-16 h-16 mx-auto text-gray-300 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4m0 0L7 13m0 0l-2.5 5M7 13l2.5 5m6-5v6a2 2 0 01-2 2H9a2 2 0 01-2-2v-6m8 0V9a2 2 0 00-2-2H9a2 2 0 00-2 2v4.01"></path>
                        </svg>
                        <p class="text-gray-500">Carrinho vazio</p>
                        <p class="text-sm text-gray-400">Adicione produtos para começar</p>
                    </div>
                </div>

                <!-- Resumo do Pedido -->
                <div class="p-6 border-t border-gray-200">
                    <div class="space-y-3">
                        <div class="flex justify-between">
                            <span class="text-gray-600">Subtotal</span>
                            <span id="subtotal">R$ 0,00</span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-600">Desconto</span>
                            <span id="discount">-R$ 0,00</span>
                        </div>
                        <hr>
                        <div class="flex justify-between text-lg font-bold">
                            <span>Total</span>
                            <span id="total" class="text-green-600">R$ 0,00</span>
                        </div>
                    </div>

                    <!-- Botões de Ação -->
                    <div class="mt-6 space-y-3">
                        <button id="clear-cart" class="w-full bg-gray-300 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-400 transition">
                            Limpar Carrinho
                        </button>
                        <button id="finalize-sale" class="w-full bg-green-600 text-white py-3 px-4 rounded-lg hover:bg-green-700 transition font-medium" disabled>
                            Finalizar Venda
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal de Finalização -->
<div id="finalize-modal" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden flex items-center justify-center p-4">
    <div class="bg-white rounded-xl max-w-md w-full p-6">
        <h3 class="text-xl font-bold text-gray-900 mb-4">Finalizar Venda</h3>
        
        <!-- Forma de Pagamento -->
        <div class="space-y-4">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Forma de Pagamento</label>
                <div class="space-y-2">
                    <label class="flex items-center">
                        <input type="radio" name="payment_method" value="cash" class="mr-3" checked>
                        <span>Dinheiro</span>
                    </label>
                    <label class="flex items-center">
                        <input type="radio" name="payment_method" value="card" class="mr-3">
                        <span>Cartão</span>
                    </label>
                    <label class="flex items-center">
                        <input type="radio" name="payment_method" value="pix" class="mr-3">
                        <span>PIX</span>
                    </label>
                </div>
            </div>

            <!-- Valor Recebido (apenas para dinheiro) -->
            <div id="cash-received" class="hidden">
                <label class="block text-sm font-medium text-gray-700 mb-2">Valor Recebido</label>
                <input type="number" id="received-amount" step="0.01" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                <p class="text-sm text-gray-500 mt-1">Troco: <span id="change-amount">R$ 0,00</span></p>
            </div>

            <!-- Cliente -->
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Cliente</label>
                <select id="customer-select" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <option value="">Cliente Avulso</option>
                    <option value="1">João Silva</option>
                    <option value="2">Maria Santos</option>
                </select>
            </div>
        </div>

        <div class="flex space-x-3 mt-6">
            <button id="cancel-sale" class="flex-1 bg-gray-300 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-400 transition">
                Cancelar
            </button>
            <button id="confirm-sale" class="flex-1 bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition">
                Confirmar Venda
            </button>
        </div>
    </div>
</div>

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    let cart = [];
    let products = [
        { id: 1, name: 'Pizza Margherita', price: 45.00, category: 1 },
        { id: 2, name: 'Hambúrguer Clássico', price: 25.00, category: 1 },
        { id: 3, name: 'Refrigerante', price: 8.00, category: 2 },
        { id: 4, name: 'Pudim', price: 12.00, category: 3 }
    ];

    // Adicionar produto ao carrinho
    document.querySelectorAll('.add-to-cart').forEach(button => {
        button.addEventListener('click', function(e) {
            e.stopPropagation();
            const productCard = this.closest('.product-card');
            const productId = parseInt(productCard.dataset.productId);
            const product = products.find(p => p.id === productId);
            
            if (product) {
                addToCart(product);
            }
        });
    });

    // Adicionar ao carrinho
    function addToCart(product) {
        const existingItem = cart.find(item => item.id === product.id);
        
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            cart.push({
                ...product,
                quantity: 1
            });
        }
        
        updateCartDisplay();
        showToast(`${product.name} adicionado ao carrinho!`, 'success');
    }

    // Atualizar exibição do carrinho
    function updateCartDisplay() {
        const cartItems = document.getElementById('cart-items');
        const emptyCart = document.getElementById('empty-cart');
        const cartCount = document.getElementById('cart-count');
        const subtotal = document.getElementById('subtotal');
        const total = document.getElementById('total');
        const finalizeBtn = document.getElementById('finalize-sale');

        if (cart.length === 0) {
            cartItems.innerHTML = '';
            emptyCart.classList.remove('hidden');
            cartCount.textContent = '0 itens';
            subtotal.textContent = 'R$ 0,00';
            total.textContent = 'R$ 0,00';
            finalizeBtn.disabled = true;
            return;
        }

        emptyCart.classList.add('hidden');
        finalizeBtn.disabled = false;

        // Renderizar itens
        cartItems.innerHTML = cart.map(item => `
            <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div class="flex-1">
                    <h4 class="font-medium text-gray-900">${item.name}</h4>
                    <p class="text-sm text-gray-500">R$ ${item.price.toFixed(2).replace('.', ',')} cada</p>
                </div>
                <div class="flex items-center space-x-2">
                    <button class="quantity-btn w-8 h-8 rounded-full border border-gray-300 flex items-center justify-center hover:bg-gray-100" data-id="${item.id}" data-action="decrease">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 12H4"></path>
                        </svg>
                    </button>
                    <span class="w-8 text-center font-medium">${item.quantity}</span>
                    <button class="quantity-btn w-8 h-8 rounded-full border border-gray-300 flex items-center justify-center hover:bg-gray-100" data-id="${item.id}" data-action="increase">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
                        </svg>
                    </button>
                </div>
                <div class="text-right ml-4">
                    <div class="font-medium text-gray-900">R$ ${(item.price * item.quantity).toFixed(2).replace('.', ',')}</div>
                    <button class="remove-item text-red-600 text-sm hover:text-red-800" data-id="${item.id}">
                        Remover
                    </button>
                </div>
            </div>
        `).join('');

        // Adicionar event listeners
        document.querySelectorAll('.quantity-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const id = parseInt(this.dataset.id);
                const action = this.dataset.action;
                updateQuantity(id, action);
            });
        });

        document.querySelectorAll('.remove-item').forEach(btn => {
            btn.addEventListener('click', function() {
                const id = parseInt(this.dataset.id);
                removeFromCart(id);
            });
        });

        // Calcular totais
        const subtotalValue = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
        
        cartCount.textContent = `${totalItems} ${totalItems === 1 ? 'item' : 'itens'}`;
        subtotal.textContent = `R$ ${subtotalValue.toFixed(2).replace('.', ',')}`;
        total.textContent = `R$ ${subtotalValue.toFixed(2).replace('.', ',')}`;
    }

    // Atualizar quantidade
    function updateQuantity(id, action) {
        const item = cart.find(item => item.id === id);
        if (!item) return;

        if (action === 'increase') {
            item.quantity += 1;
        } else if (action === 'decrease') {
            item.quantity -= 1;
            if (item.quantity <= 0) {
                removeFromCart(id);
                return;
            }
        }

        updateCartDisplay();
    }

    // Remover do carrinho
    function removeFromCart(id) {
        cart = cart.filter(item => item.id !== id);
        updateCartDisplay();
    }

    // Limpar carrinho
    document.getElementById('clear-cart').addEventListener('click', function() {
        if (cart.length === 0) return;
        
        if (confirm('Tem certeza que deseja limpar o carrinho?')) {
            cart = [];
            updateCartDisplay();
            showToast('Carrinho limpo!', 'info');
        }
    });

    // Finalizar venda
    document.getElementById('finalize-sale').addEventListener('click', function() {
        if (cart.length === 0) return;
        
        document.getElementById('finalize-modal').classList.remove('hidden');
    });

    // Cancelar venda
    document.getElementById('cancel-sale').addEventListener('click', function() {
        document.getElementById('finalize-modal').classList.add('hidden');
    });

    // Confirmar venda
    document.getElementById('confirm-sale').addEventListener('click', function() {
        const paymentMethod = document.querySelector('input[name="payment_method"]:checked').value;
        const customerId = document.getElementById('customer-select').value;
        
        // Simular finalização da venda
        showToast('Venda finalizada com sucesso!', 'success');
        
        // Limpar carrinho
        cart = [];
        updateCartDisplay();
        
        // Fechar modal
        document.getElementById('finalize-modal').classList.add('hidden');
    });

    // Mostrar/ocultar campo de valor recebido
    document.querySelectorAll('input[name="payment_method"]').forEach(radio => {
        radio.addEventListener('change', function() {
            const cashReceived = document.getElementById('cash-received');
            if (this.value === 'cash') {
                cashReceived.classList.remove('hidden');
            } else {
                cashReceived.classList.add('hidden');
            }
        });
    });

    // Calcular troco
    document.getElementById('received-amount').addEventListener('input', function() {
        const received = parseFloat(this.value) || 0;
        const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        const change = received - total;
        
        document.getElementById('change-amount').textContent = 
            change >= 0 ? `R$ ${change.toFixed(2).replace('.', ',')}` : 'Valor insuficiente';
    });

    // Filtros
    document.getElementById('product-search').addEventListener('input', function() {
        filterProducts();
    });

    document.getElementById('category-filter').addEventListener('change', function() {
        filterProducts();
    });

    function filterProducts() {
        const searchTerm = document.getElementById('product-search').value.toLowerCase();
        const categoryFilter = document.getElementById('category-filter').value;
        
        document.querySelectorAll('.product-card').forEach(card => {
            const productId = parseInt(card.dataset.productId);
            const product = products.find(p => p.id === productId);
            
            const matchesSearch = product.name.toLowerCase().includes(searchTerm);
            const matchesCategory = !categoryFilter || product.category == categoryFilter;
            
            if (matchesSearch && matchesCategory) {
                card.style.display = 'block';
            } else {
                card.style.display = 'none';
            }
        });
    }
});
</script>
@endpush
@endsection
