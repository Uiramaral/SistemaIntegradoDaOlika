@extends('client.layout')

@section('title', 'Buscar Produtos')

@section('content')
<div class="min-h-screen bg-background py-8">
    <div class="container mx-auto px-4">
        <h1 class="text-3xl font-bold mb-6">Buscar Produtos</h1>
        
        <!-- Barra de Busca -->
        <div class="mb-8">
            <div class="relative">
                <input 
                    type="search" 
                    placeholder="Digite o que você procura..." 
                    class="w-full h-12 pl-12 pr-4 text-lg border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-ring"
                    id="searchInput"
                    autocomplete="off"
                />
                <svg class="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
            </div>
        </div>

        <!-- Filtros -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            <select class="h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm" id="categoryFilter">
                <option value="">Todas as Categorias</option>
                @foreach($categories as $category)
                    <option value="{{ $category->id }}">{{ $category->name }}</option>
                @endforeach
            </select>

            <select class="h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm" id="priceFilter">
                <option value="">Todos os Preços</option>
                <option value="0-20">Até R$ 20</option>
                <option value="20-50">R$ 20 - R$ 50</option>
                <option value="50-100">R$ 50 - R$ 100</option>
                <option value="100+">Acima de R$ 100</option>
            </select>

            <select class="h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm" id="sortFilter">
                <option value="relevance">Relevância</option>
                <option value="price_asc">Menor Preço</option>
                <option value="price_desc">Maior Preço</option>
                <option value="name">Nome A-Z</option>
            </select>

            <div class="flex items-center gap-2 px-3">
                <input type="checkbox" id="availableOnly" checked class="h-4 w-4 rounded border-primary" />
                <label for="availableOnly" class="text-sm">Apenas Disponíveis</label>
            </div>
        </div>

        <!-- Resultados -->
        <div id="searchResults">
            <div class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6">
                @forelse($products as $product)
                    @include('client.components.product-card', ['product' => $product])
                @empty
                    <div class="col-span-full text-center py-12">
                        <svg class="mx-auto h-24 w-24 text-muted-foreground mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                        </svg>
                        <p class="text-muted-foreground text-lg">Nenhum produto encontrado</p>
                        <p class="text-sm text-muted-foreground mt-2">Tente usar palavras-chave diferentes</p>
                    </div>
                @endforelse
            </div>
        </div>

        <!-- Loading State -->
        <div id="loadingState" class="hidden">
            <div class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6">
                @for($i = 0; $i < 8; $i++)
                    <div class="border rounded-lg overflow-hidden">
                        <div class="animate-pulse">
                            <div class="bg-gray-300 h-48"></div>
                            <div class="p-4 space-y-3">
                                <div class="h-4 bg-gray-300 rounded w-3/4"></div>
                                <div class="h-4 bg-gray-300 rounded w-1/2"></div>
                                <div class="h-8 bg-gray-300 rounded"></div>
                            </div>
                        </div>
                    </div>
                @endfor
            </div>
        </div>
    </div>
</div>

<script>
let searchTimeout;

function performSearch() {
    const query = document.getElementById('searchInput').value;
    const category = document.getElementById('categoryFilter').value;
    const price = document.getElementById('priceFilter').value;
    const sort = document.getElementById('sortFilter').value;
    const availableOnly = document.getElementById('availableOnly').checked;

    // Mostrar loading
    document.getElementById('searchResults').classList.add('hidden');
    document.getElementById('loadingState').classList.remove('hidden');

    // Fazer requisição
    fetch(`/api/search?q=${encodeURIComponent(query)}&category=${category}&price=${price}&sort=${sort}&available=${availableOnly}`)
        .then(response => response.json())
        .then(data => {
            updateResults(data.products);
        })
        .catch(error => {
            console.error('Erro na busca:', error);
            window.showToast('Erro ao buscar produtos', 'error');
        })
        .finally(() => {
            document.getElementById('loadingState').classList.add('hidden');
            document.getElementById('searchResults').classList.remove('hidden');
        });
}

// Busca em tempo real (debounced)
document.getElementById('searchInput').addEventListener('input', function() {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(performSearch, 500);
});

// Aplicar filtros
['categoryFilter', 'priceFilter', 'sortFilter', 'availableOnly'].forEach(id => {
    document.getElementById(id).addEventListener('change', performSearch);
});

function updateResults(products) {
    const container = document.getElementById('searchResults').querySelector('.grid');
    
    if (products.length === 0) {
        container.innerHTML = `
            <div class="col-span-full text-center py-12">
                <p class="text-muted-foreground text-lg">Nenhum produto encontrado</p>
            </div>
        `;
        return;
    }

    container.innerHTML = products.map(product => `
        <div class="border rounded-lg overflow-hidden hover:shadow-lg transition">
            <img src="${product.image}" alt="${product.name}" class="w-full h-48 object-cover" />
            <div class="p-4">
                <h3 class="font-semibold mb-2">${product.name}</h3>
                <p class="text-sm text-muted-foreground mb-4">${product.description}</p>
                <div class="flex items-center justify-between">
                    <span class="text-xl font-bold text-primary">R$ ${product.price.toFixed(2)}</span>
                    <button class="px-4 py-2 bg-primary text-white rounded-md hover:bg-primary/90">
                        Adicionar
                    </button>
                </div>
            </div>
        </div>
    `).join('');
}
</script>
@endsection

