@extends('dashboard.layout-complete')

@section('title', 'Gestão de Cupons - Cardápio Digital Olika')
@section('page-title', 'Gestão de Cupons')

@section('content')
<div class="space-y-6">
    <!-- Header com Ações -->
    <div class="bg-white rounded-xl p-6 shadow-lg">
        <div class="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
            <div>
                <h2 class="text-2xl font-bold text-gray-900">Cupons de Desconto</h2>
                <p class="text-gray-600">Gerencie cupons e promoções do seu restaurante</p>
            </div>
            
            <div class="flex flex-col sm:flex-row gap-4">
                <!-- Busca -->
                <div class="relative">
                    <input 
                        type="text" 
                        id="search-coupons"
                        placeholder="Buscar cupons..."
                        class="w-full sm:w-64 pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                    <svg class="absolute left-3 top-2.5 w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                    </svg>
                </div>
                
                <!-- Status -->
                <select id="status-filter" class="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <option value="">Todos os status</option>
                    <option value="active">Ativos</option>
                    <option value="inactive">Inativos</option>
                    <option value="expired">Expirados</option>
                </select>
                
                <!-- Botão Adicionar -->
                <button id="add-coupon-btn" class="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition flex items-center space-x-2">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
                    </svg>
                    <span>Adicionar Cupom</span>
                </button>
            </div>
        </div>
    </div>

    <!-- Stats Cards -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div class="bg-white rounded-xl p-6 shadow-lg">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-gray-600">Total de Cupons</p>
                    <p class="text-2xl font-bold text-gray-900">12</p>
                </div>
                <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <svg class="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z"></path>
                    </svg>
                </div>
            </div>
        </div>
        
        <div class="bg-white rounded-xl p-6 shadow-lg">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-gray-600">Ativos</p>
                    <p class="text-2xl font-bold text-green-600">8</p>
                </div>
                <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                    <svg class="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                    </svg>
                </div>
            </div>
        </div>
        
        <div class="bg-white rounded-xl p-6 shadow-lg">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-gray-600">Usados Hoje</p>
                    <p class="text-2xl font-bold text-yellow-600">23</p>
                </div>
                <div class="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                    <svg class="w-6 h-6 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                </div>
            </div>
        </div>
        
        <div class="bg-white rounded-xl p-6 shadow-lg">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-gray-600">Desconto Total</p>
                    <p class="text-2xl font-bold text-purple-600">R$ 450</p>
                </div>
                <div class="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                    <svg class="w-6 h-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1"></path>
                    </svg>
                </div>
            </div>
        </div>
    </div>

    <!-- Lista de Cupons -->
    <div class="bg-white rounded-xl shadow-lg">
        <div class="p-6 border-b border-gray-200">
            <h3 class="text-lg font-semibold text-gray-900">Lista de Cupons</h3>
        </div>
        
        <div class="overflow-x-auto">
            <table class="w-full">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Cupom</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tipo</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Valor</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Usos</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Validade</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ações</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200" id="coupons-table-body">
                    <!-- Cupom 1 -->
                    <tr class="hover:bg-gray-50">
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="flex items-center space-x-3">
                                <div class="w-10 h-10 bg-green-500 rounded-lg flex items-center justify-center">
                                    <span class="text-white font-bold text-sm">10</span>
                                </div>
                                <div>
                                    <div class="text-sm font-medium text-gray-900">DESCONTO10</div>
                                    <div class="text-sm text-gray-500">10% de desconto</div>
                                </div>
                            </div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">Percentual</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">10%</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            <span class="font-medium">15/100</span>
                            <div class="w-full bg-gray-200 rounded-full h-2 mt-1">
                                <div class="bg-blue-600 h-2 rounded-full" style="width: 15%"></div>
                            </div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                Ativo
                            </span>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">31/12/2024</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                            <button class="text-blue-600 hover:text-blue-900 edit-coupon" data-coupon-id="1">Editar</button>
                            <button class="text-red-600 hover:text-red-900 deactivate-coupon" data-coupon-id="1">Desativar</button>
                            <button class="text-gray-600 hover:text-gray-900 copy-coupon" data-coupon-code="DESCONTO10">Copiar</button>
                        </td>
                    </tr>
                    
                    <!-- Cupom 2 -->
                    <tr class="hover:bg-gray-50">
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="flex items-center space-x-3">
                                <div class="w-10 h-10 bg-blue-500 rounded-lg flex items-center justify-center">
                                    <span class="text-white font-bold text-sm">R$</span>
                                </div>
                                <div>
                                    <div class="text-sm font-medium text-gray-900">FREEGRATIS</div>
                                    <div class="text-sm text-gray-500">R$ 20,00 de desconto</div>
                                </div>
                            </div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">Valor Fixo</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">R$ 20,00</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            <span class="font-medium">5/50</span>
                            <div class="w-full bg-gray-200 rounded-full h-2 mt-1">
                                <div class="bg-green-600 h-2 rounded-full" style="width: 10%"></div>
                            </div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                Ativo
                            </span>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">15/01/2025</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                            <button class="text-blue-600 hover:text-blue-900 edit-coupon" data-coupon-id="2">Editar</button>
                            <button class="text-red-600 hover:text-red-900 deactivate-coupon" data-coupon-id="2">Desativar</button>
                            <button class="text-gray-600 hover:text-gray-900 copy-coupon" data-coupon-code="FREEGRATIS">Copiar</button>
                        </td>
                    </tr>
                    
                    <!-- Cupom 3 -->
                    <tr class="hover:bg-gray-50">
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="flex items-center space-x-3">
                                <div class="w-10 h-10 bg-red-500 rounded-lg flex items-center justify-center">
                                    <span class="text-white font-bold text-sm">X</span>
                                </div>
                                <div>
                                    <div class="text-sm font-medium text-gray-900">BEMVINDO</div>
                                    <div class="text-sm text-gray-500">15% de desconto</div>
                                </div>
                            </div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">Percentual</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">15%</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            <span class="font-medium">25/25</span>
                            <div class="w-full bg-gray-200 rounded-full h-2 mt-1">
                                <div class="bg-red-600 h-2 rounded-full" style="width: 100%"></div>
                            </div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">
                                Expirado
                            </span>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">01/12/2024</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                            <button class="text-blue-600 hover:text-blue-900 edit-coupon" data-coupon-id="3">Editar</button>
                            <button class="text-green-600 hover:text-green-900 reactivate-coupon" data-coupon-id="3">Reativar</button>
                            <button class="text-gray-600 hover:text-gray-900 copy-coupon" data-coupon-code="BEMVINDO">Copiar</button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal de Adicionar/Editar Cupom -->
<div id="coupon-modal" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden flex items-center justify-center p-4">
    <div class="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div class="p-6 border-b border-gray-200">
            <div class="flex items-center justify-between">
                <h3 class="text-xl font-bold text-gray-900" id="coupon-modal-title">Adicionar Cupom</h3>
                <button id="close-coupon-modal" class="text-gray-500 hover:text-gray-700">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                </button>
            </div>
        </div>
        
        <form id="coupon-form" class="p-6 space-y-6">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- Código -->
                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Código do Cupom *</label>
                    <input type="text" name="code" required class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 uppercase" placeholder="Ex: DESCONTO10">
                </div>
                
                <!-- Descrição -->
                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Descrição</label>
                    <textarea name="description" rows="2" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="Descrição do cupom..."></textarea>
                </div>
                
                <!-- Tipo de Desconto -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Tipo de Desconto *</label>
                    <select name="discount_type" required class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="">Selecione o tipo</option>
                        <option value="percentage">Percentual (%)</option>
                        <option value="fixed">Valor Fixo (R$)</option>
                    </select>
                </div>
                
                <!-- Valor do Desconto -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Valor do Desconto *</label>
                    <input type="number" name="discount_value" step="0.01" required class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
                
                <!-- Valor Mínimo -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Valor Mínimo do Pedido</label>
                    <input type="number" name="min_order_value" step="0.01" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
                
                <!-- Limite de Usos -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Limite de Usos</label>
                    <input type="number" name="usage_limit" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="Deixe vazio para ilimitado">
                </div>
                
                <!-- Data de Início -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Data de Início</label>
                    <input type="datetime-local" name="starts_at" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
                
                <!-- Data de Fim -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Data de Fim</label>
                    <input type="datetime-local" name="expires_at" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
            </div>
            
            <!-- Opções Adicionais -->
            <div class="space-y-4">
                <h4 class="font-semibold text-gray-900">Opções Adicionais</h4>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="flex items-center">
                        <input type="checkbox" name="is_active" id="is_active" class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500">
                        <label for="is_active" class="ml-2 text-sm font-medium text-gray-700">Cupom Ativo</label>
                    </div>
                    
                    <div class="flex items-center">
                        <input type="checkbox" name="one_time_use" id="one_time_use" class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500">
                        <label for="one_time_use" class="ml-2 text-sm font-medium text-gray-700">Uso Único por Cliente</label>
                    </div>
                    
                    <div class="flex items-center">
                        <input type="checkbox" name="free_shipping" id="free_shipping" class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500">
                        <label for="free_shipping" class="ml-2 text-sm font-medium text-gray-700">Frete Grátis</label>
                    </div>
                    
                    <div class="flex items-center">
                        <input type="checkbox" name="first_order_only" id="first_order_only" class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500">
                        <label for="first_order_only" class="ml-2 text-sm font-medium text-gray-700">Apenas Primeiro Pedido</label>
                    </div>
                </div>
            </div>
            
            <!-- Botões -->
            <div class="flex space-x-3 pt-6">
                <button type="button" id="cancel-coupon" class="flex-1 bg-gray-300 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-400 transition">
                    Cancelar
                </button>
                <button type="submit" class="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition">
                    Salvar Cupom
                </button>
            </div>
        </form>
    </div>
</div>

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    const modal = document.getElementById('coupon-modal');
    const form = document.getElementById('coupon-form');
    const modalTitle = document.getElementById('coupon-modal-title');
    
    // Abrir modal para adicionar cupom
    document.getElementById('add-coupon-btn').addEventListener('click', function() {
        modalTitle.textContent = 'Adicionar Cupom';
        form.reset();
        modal.classList.remove('hidden');
    });
    
    // Fechar modal
    document.getElementById('close-coupon-modal').addEventListener('click', function() {
        modal.classList.add('hidden');
    });
    
    document.getElementById('cancel-coupon').addEventListener('click', function() {
        modal.classList.add('hidden');
    });
    
    // Editar cupom
    document.querySelectorAll('.edit-coupon').forEach(button => {
        button.addEventListener('click', function() {
            const couponId = this.dataset.couponId;
            modalTitle.textContent = 'Editar Cupom';
            // Aqui você carregaria os dados do cupom
            modal.classList.remove('hidden');
        });
    });
    
    // Desativar cupom
    document.querySelectorAll('.deactivate-coupon').forEach(button => {
        button.addEventListener('click', function() {
            const couponId = this.dataset.couponId;
            if (confirm('Tem certeza que deseja desativar este cupom?')) {
                showToast('Cupom desativado com sucesso!', 'success');
                // Aqui você faria a chamada para a API
            }
        });
    });
    
    // Reativar cupom
    document.querySelectorAll('.reactivate-coupon').forEach(button => {
        button.addEventListener('click', function() {
            const couponId = this.dataset.couponId;
            if (confirm('Tem certeza que deseja reativar este cupom?')) {
                showToast('Cupom reativado com sucesso!', 'success');
                // Aqui você faria a chamada para a API
            }
        });
    });
    
    // Copiar código do cupom
    document.querySelectorAll('.copy-coupon').forEach(button => {
        button.addEventListener('click', function() {
            const couponCode = this.dataset.couponCode;
            navigator.clipboard.writeText(couponCode).then(function() {
                showToast(`Código ${couponCode} copiado!`, 'success');
            });
        });
    });
    
    // Salvar cupom
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        
        // Simular salvamento
        showToast('Cupom salvo com sucesso!', 'success');
        modal.classList.add('hidden');
        
        // Aqui você faria a chamada para a API
        // saveCoupon(formData);
    });
    
    // Filtros
    const searchInput = document.getElementById('search-coupons');
    const statusFilter = document.getElementById('status-filter');
    
    function applyFilters() {
        const searchTerm = searchInput.value.toLowerCase();
        const selectedStatus = statusFilter.value;
        
        const rows = document.querySelectorAll('#coupons-table-body tr');
        
        rows.forEach(row => {
            const couponCode = row.querySelector('td:first-child .text-sm').textContent.toLowerCase();
            const status = row.querySelector('td:nth-child(5) span').textContent;
            
            const matchesSearch = couponCode.includes(searchTerm);
            const matchesStatus = !selectedStatus || status.toLowerCase().includes(selectedStatus);
            
            if (matchesSearch && matchesStatus) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    }
    
    searchInput.addEventListener('input', applyFilters);
    statusFilter.addEventListener('change', applyFilters);
    
    // Gerar código automático
    const codeInput = document.querySelector('input[name="code"]');
    codeInput.addEventListener('blur', function() {
        if (!this.value) {
            // Gerar código automático baseado na descrição
            const description = document.querySelector('textarea[name="description"]').value;
            if (description) {
                const autoCode = description.replace(/[^a-zA-Z0-9]/g, '').substring(0, 10).toUpperCase();
                this.value = autoCode;
            }
        }
    });
    
    // Atualizar valor mínimo quando tipo de desconto mudar
    const discountType = document.querySelector('select[name="discount_type"]');
    const minOrderValue = document.querySelector('input[name="min_order_value"]');
    
    discountType.addEventListener('change', function() {
        if (this.value === 'percentage') {
            minOrderValue.placeholder = 'Ex: 50.00 (R$)';
        } else if (this.value === 'fixed') {
            minOrderValue.placeholder = 'Ex: 30.00 (R$)';
        }
    });
});
</script>
@endpush
@endsection
