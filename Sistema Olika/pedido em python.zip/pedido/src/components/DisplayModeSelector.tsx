import { LayoutGrid, List, Grid3x3 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { DisplayMode } from "@/types/menu";

interface DisplayModeSelectorProps {
  mode: DisplayMode;
  onChange: (mode: DisplayMode) => void;
}

export const DisplayModeSelector = ({ mode, onChange }: DisplayModeSelectorProps) => {
  return (
    <div className="flex gap-1 bg-muted p-1 rounded-lg">
      <Button
        variant={mode === 'grid' ? 'default' : 'ghost'}
        size="sm"
        onClick={() => onChange('grid')}
        className="px-3"
      >
        <LayoutGrid className="h-4 w-4" />
      </Button>
      <Button
        variant={mode === 'list' ? 'default' : 'ghost'}
        size="sm"
        onClick={() => onChange('list')}
        className="px-3"
      >
        <List className="h-4 w-4" />
      </Button>
      <Button
        variant={mode === 'compact' ? 'default' : 'ghost'}
        size="sm"
        onClick={() => onChange('compact')}
        className="px-3"
      >
        <Grid3x3 className="h-4 w-4" />
      </Button>
    </div>
  );
};