#!/bin/bash

# ============================================
# SCRIPT DE DEPLOY - CARDÁPIO DIGITAL OLIKA
# ============================================

echo "🚀 Iniciando deploy do Cardápio Digital Olika..."

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Função para imprimir mensagens coloridas
print_message() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

# 1. Verificar se o PHP está instalado
echo "📋 Verificando dependências..."
if ! command -v php &> /dev/null; then
    print_error "PHP não encontrado. Instale o PHP 8.1+ primeiro."
    exit 1
fi

if ! command -v composer &> /dev/null; then
    print_error "Composer não encontrado. Instale o Composer primeiro."
    exit 1
fi

print_message "PHP e Composer encontrados"

# 2. Instalar dependências
echo "📦 Instalando dependências do Composer..."
composer install --no-dev --optimize-autoloader

if [ $? -eq 0 ]; then
    print_message "Dependências instaladas com sucesso"
else
    print_error "Erro ao instalar dependências"
    exit 1
fi

# 3. Configurar arquivo .env
echo "⚙️  Configurando ambiente..."
if [ ! -f .env ]; then
    if [ -f .env.example ]; then
        cp .env.example .env
        print_message "Arquivo .env criado a partir do .env.example"
    else
        print_error "Arquivo .env.example não encontrado"
        exit 1
    fi
else
    print_warning "Arquivo .env já existe"
fi

# 4. Gerar chave da aplicação
echo "🔑 Gerando chave da aplicação..."
php artisan key:generate

# 5. Configurar cache
echo "🗄️  Configurando cache..."
php artisan config:cache
php artisan route:cache
php artisan view:cache

# 6. Executar migrações
echo "🗃️  Executando migrações do banco de dados..."
php artisan migrate --force

if [ $? -eq 0 ]; then
    print_message "Migrações executadas com sucesso"
else
    print_error "Erro ao executar migrações. Verifique a conexão com o banco."
    exit 1
fi

# 7. Criar link simbólico para storage
echo "🔗 Criando link simbólico para storage..."
php artisan storage:link

# 8. Configurar permissões
echo "🔐 Configurando permissões..."
chmod -R 755 storage bootstrap/cache
chown -R www-data:www-data storage bootstrap/cache

# 9. Verificar configuração
echo "🔍 Verificando configuração..."
php artisan about

echo ""
echo "🎉 Deploy concluído com sucesso!"
echo ""
echo "📋 Próximos passos:"
echo "1. Configure o arquivo .env com seus dados de produção"
echo "2. Configure o servidor web (Nginx/Apache)"
echo "3. Configure SSL/HTTPS"
echo "4. Configure backup automático do banco"
echo ""
echo "🌐 Acesse: https://seu-dominio.com"
echo "🏢 Admin: https://seu-dominio.com/dashboard"
echo ""
echo "📚 Documentação: CONFIGURACAO_FINAL.md"
