import { useState } from "react";
import { useMenu } from "@/contexts/MenuContext";
import { MenuHeader } from "@/components/MenuHeader";
import { CategoryTabs } from "@/components/CategoryTabs";
import ProductCard from "@/components/ProductCard";
import { ProductDetailDialog } from "@/components/ProductDetailDialog";
import { DisplayModeSelector } from "@/components/DisplayModeSelector";
import { Product, DisplayMode } from "@/types/menu";
import { Star } from "lucide-react";

const Index = () => {
  const { products, categories, config, updateConfig } = useMenu();
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const displayMode = config.displayMode || 'grid';

  const featuredProducts = products.filter((p) => p.available && p.featured);
  
  const filteredProducts = selectedCategory === "all"
    ? products.filter((p) => p.available)
    : products.filter((p) => p.category === selectedCategory && p.available);

  const handleDisplayModeChange = (mode: DisplayMode) => {
    updateConfig({ displayMode: mode });
  };

  return (
    <div className="min-h-screen bg-background">
      <MenuHeader />

      <main className="container mx-auto px-4 py-6">
        <div className="flex items-center justify-between mb-6 gap-4">
          <div className="flex-1 overflow-x-auto">
            <CategoryTabs
              selectedCategory={selectedCategory}
              onSelectCategory={setSelectedCategory}
            />
          </div>
          <DisplayModeSelector mode={displayMode} onChange={handleDisplayModeChange} />
        </div>

        {featuredProducts.length > 0 && selectedCategory === "all" && (
          <div className="mb-8">
            <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
              <Star className="h-6 w-6 fill-primary text-primary" />
              Produtos em Destaque
            </h2>
            <div className={
              displayMode === 'grid' 
                ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
                : displayMode === 'list'
                ? "space-y-4"
                : "grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4"
            }>
              {featuredProducts.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onClick={() => setSelectedProduct(product)}
                  displayMode={displayMode}
                />
              ))}
            </div>
          </div>
        )}

        <div className={
          displayMode === 'grid' 
            ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
            : displayMode === 'list'
            ? "space-y-4"
            : "grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4"
        }>
          {filteredProducts.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onClick={() => setSelectedProduct(product)}
              displayMode={displayMode}
            />
          ))}
        </div>

        {filteredProducts.length === 0 && (
          <div className="text-center py-12 text-muted-foreground">
            Nenhum produto disponível nesta categoria
          </div>
        )}
      </main>

      <ProductDetailDialog
        product={selectedProduct}
        open={!!selectedProduct}
        onOpenChange={(open) => !open && setSelectedProduct(null)}
      />
    </div>
  );
};

export default Index;