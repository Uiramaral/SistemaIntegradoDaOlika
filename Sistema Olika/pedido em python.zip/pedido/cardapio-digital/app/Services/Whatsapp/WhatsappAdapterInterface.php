<?php

namespace App\Services\Whatsapp;

interface WhatsappAdapterInterface
{
    /**
     * Conectar sessão WhatsApp
     * 
     * @param int $lojaId ID da loja
     * @param string $phone Número do telefone
     * @return array ['status' => '...', 'pairing_code' => '...', 'instance_id' => '...', 'auth_meta' => '...']
     */
    public function connect(int $lojaId, string $phone): array;

    /**
     * Verificar status da sessão
     * 
     * @param int $sessionId ID da sessão
     * @return array ['status' => '...', 'instance_id' => '...']
     */
    public function status(int $sessionId): array;

    /**
     * Enviar mensagem de texto
     * 
     * @param int $sessionId ID da sessão
     * @param string $to Número de destino
     * @param string $text Texto da mensagem
     * @param array $meta Metadados adicionais
     * @return array ['provider_msg_id' => '...', 'status' => '...']
     */
    public function sendText(int $sessionId, string $to, string $text, array $meta = []): array;

    /**
     * Enviar template
     * 
     * @param int $sessionId ID da sessão
     * @param string $to Número de destino
     * @param string $templateName Nome do template
     * @param array $vars Variáveis do template
     * @return array ['provider_msg_id' => '...', 'status' => '...']
     */
    public function sendTemplate(int $sessionId, string $to, string $templateName, array $vars = []): array;

    /**
     * Enviar mídia
     * 
     * @param int $sessionId ID da sessão
     * @param string $to Número de destino
     * @param string $mediaUrl URL da mídia
     * @param string $type Tipo da mídia (image, file, etc.)
     * @param string $caption Legenda da mídia
     * @return array ['provider_msg_id' => '...', 'status' => '...']
     */
    public function sendMedia(int $sessionId, string $to, string $mediaUrl, string $type = 'image', string $caption = ''): array;

    /**
     * Verificar se o adapter está disponível
     * 
     * @return bool
     */
    public function isAvailable(): bool;

    /**
     * Obter informações do adapter
     * 
     * @return array
     */
    public function getInfo(): array;
}
