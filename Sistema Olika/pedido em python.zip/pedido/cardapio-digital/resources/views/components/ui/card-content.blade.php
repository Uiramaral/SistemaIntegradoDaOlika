@props([])

<div {{ $attributes->merge(['class' => 'p-6 pt-0']) }}>
    {{ $slot }}
</div>

