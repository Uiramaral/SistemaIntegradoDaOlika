<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Mailgun, Postmark, AWS and more. This file provides the de facto
    | location for this type of information, allowing packages to have
    | a conventional file to locate the various service credentials.
    |
    */

    'mailgun' => [
        'domain' => env('MAILGUN_DOMAIN'),
        'secret' => env('MAILGUN_SECRET'),
        'endpoint' => env('MAILGUN_ENDPOINT', 'api.mailgun.net'),
        'scheme' => 'https',
    ],

    'postmark' => [
        'token' => env('POSTMARK_TOKEN'),
    ],

    'ses' => [
        'key' => env('AWS_ACCESS_KEY_ID'),
        'secret' => env('AWS_SECRET_ACCESS_KEY'),
        'region' => env('AWS_DEFAULT_REGION', 'us-east-1'),
    ],

    'openai' => [
        'api_key' => env('OPENAI_API_KEY'),
        'organization' => env('OPENAI_ORGANIZATION'),
        'model' => env('OPENAI_MODEL', 'gpt-5-nano'),
        'max_tokens' => env('OPENAI_MAX_TOKENS', 1000),
        'temperature' => env('OPENAI_TEMPERATURE', 0.7),
    ],

    'mercadopago' => [
        'access_token' => env('MERCADOPAGO_ACCESS_TOKEN'),
        'public_key' => env('MERCADOPAGO_PUBLIC_KEY'),
        'webhook_secret' => env('MERCADOPAGO_WEBHOOK_SECRET'),
        'environment' => env('MERCADOPAGO_ENVIRONMENT', 'sandbox'),
    ],

    'whatsapp' => [
        'default_adapter' => env('WHATS_ADAPTER_DEFAULT', 'non_official'),
    ],
    'whatsapp_gateway' => [
        'base_url' => env('WHATS_GATEWAY_BASE_URL', 'http://localhost:21465'),
        'token' => env('WHATS_GATEWAY_TOKEN', ''),
        'webhook_secret' => env('WHATS_WEBHOOK_SECRET', ''),
    ],
    'whatsapp_cloud' => [
        'phone_number_id' => env('WHATS_CLOUD_PHONE_NUMBER_ID', ''),
        'waba_id' => env('WHATS_CLOUD_WABA_ID', ''),
        'access_token' => env('WHATS_CLOUD_ACCESS_TOKEN', ''),
        'webhook_verify_token' => env('WHATS_CLOUD_WEBHOOK_VERIFY_TOKEN', ''),
        'api_base' => env('WHATS_CLOUD_API_BASE', 'https://graph.facebook.com/v20.0'),
    ],

    'google_maps' => [
        'api_key' => env('GOOGLE_MAPS_API_KEY'),
        'geocoding_api_url' => 'https://maps.googleapis.com/maps/api/geocode/json',
        'distance_matrix_api_url' => 'https://maps.googleapis.com/maps/api/distancematrix/json',
    ],

];
