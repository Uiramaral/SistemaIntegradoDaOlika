# 🗄️ **CARDÁPIO DIGITAL OLIKA - INSTALAÇÃO SQL**

## ✅ **Sistema criado sem migrations - Pronto para MariaDB/MySQL**

### 📁 **Arquivos SQL Criados:**

1. **`database/cardapio_digital.sql`** - Script SQL completo (500+ linhas)
2. **`install_database.sql`** - Script de instalação rápida
3. **`install_without_migrations.php`** - Script PHP de instalação
4. **`INSTALACAO_BANCO.md`** - Guia completo de instalação

---

## 🚀 **INSTALAÇÃO RÁPIDA**

### **Opção 1: Via MySQL/MariaDB**

```bash
# 1. Conectar no banco
mysql -u root -p

# 2. Executar script
source /caminho/cardapio-digital/database/cardapio_digital.sql;
```

### **Opção 2: Via Linha de Comando**

```bash
# Executar diretamente
mysql -u root -p < database/cardapio_digital.sql
```

### **Opção 3: Script PHP**

```bash
# Executar script de instalação
php install_without_migrations.php
```

---

## 📊 **O QUE É CRIADO**

### **🗂️ Estrutura Completa:**
- ✅ **12 tabelas** com relacionamentos
- ✅ **3 views** para relatórios
- ✅ **2 procedures** úteis
- ✅ **3 triggers** automáticos
- ✅ **Dados iniciais** incluídos

### **📋 Tabelas Criadas:**
1. `customers` - Clientes com autenticação
2. `categories` - Categorias de produtos
3. `products` - Produtos do cardápio
4. `orders` - Pedidos dos clientes
5. `order_items` - Itens dos pedidos
6. `coupons` - Cupons e promoções
7. `loyalty_programs` - Programa de fidelidade
8. `referrals` - Sistema de indicações
9. `delivery_fees` - Taxas de entrega
10. `delivery_schedules` - Agendamento
11. `settings` - Configurações
12. `personal_access_tokens` - Tokens

### **📈 Dados Iniciais:**
- ✅ 4 categorias padrão
- ✅ 6 produtos de exemplo
- ✅ 3 cupons de desconto
- ✅ 4 zonas de entrega
- ✅ 18 configurações
- ✅ Programa de fidelidade

---

## ⚙️ **CONFIGURAÇÃO LARAVEL**

### **Arquivo `.env`**

```env
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=cardapio_digital
DB_USERNAME=root
DB_PASSWORD=
```

### **Configuração Remota**

```env
DB_CONNECTION=mysql
DB_HOST=IP_DO_SERVIDOR_BANCO
DB_PORT=3306
DB_DATABASE=cardapio_digital
DB_USERNAME=cardapio_user
DB_PASSWORD=senha_segura
```

---

## 🔧 **FUNCIONALIDADES INCLUÍDAS**

### **🗄️ Banco de Dados:**
- ✅ Estrutura completa com foreign keys
- ✅ Índices para performance
- ✅ Triggers automáticos
- ✅ Views para relatórios
- ✅ Procedures úteis

### **📊 Relatórios Automáticos:**
- `v_sales_stats` - Estatísticas de vendas
- `v_top_products` - Produtos mais vendidos
- `v_top_customers` - Clientes mais frequentes

### **⚡ Automações:**
- Geração automática de número do pedido
- Atualização de contadores do cliente
- Contador de uso de cupons

---

## 🎯 **VANTAGENS DA ABORDAGEM SQL**

### ✅ **Simplicidade**
- Um script SQL único
- Sem dependência de migrations
- Instalação em qualquer servidor

### ✅ **Controle Total**
- Estrutura personalizada
- Triggers e procedures customizados
- Dados iniciais incluídos

### ✅ **Compatibilidade**
- MariaDB e MySQL
- Fácil migração futura
- Backup simples

### ✅ **Performance**
- Índices otimizados
- Views para consultas complexas
- Procedures para operações frequentes

---

## 🔄 **MIGRAÇÃO FUTURA**

### **Para phpMyAdmin:**
- Exportar estrutura e dados
- Importar no novo servidor
- Atualizar configurações

### **Para outros bancos:**
- Adaptar sintaxe SQL
- Manter estrutura de relacionamentos
- Testar funcionalidades

---

## 📋 **COMANDOS ÚTEIS**

### **Verificar Instalação:**
```sql
-- Ver todas as tabelas
SHOW TABLES;

-- Ver dados iniciais
SELECT * FROM categories;
SELECT * FROM products LIMIT 5;

-- Verificar estrutura
DESCRIBE customers;
```

### **Backup:**
```bash
# Backup completo
mysqldump -u root -p cardapio_digital > backup.sql

# Restaurar
mysql -u root -p cardapio_digital < backup.sql
```

---

## 🎉 **RESULTADO FINAL**

✅ **Banco de dados 100% funcional**  
✅ **Estrutura otimizada para performance**  
✅ **Dados iniciais para teste**  
✅ **Compatível com MariaDB/MySQL**  
✅ **Pronto para produção**  
✅ **Fácil manutenção e backup**  

**Sistema pronto para uso sem migrations! 🚀**
