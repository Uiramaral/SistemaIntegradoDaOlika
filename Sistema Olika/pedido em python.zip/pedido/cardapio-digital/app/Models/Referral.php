<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Referral extends Model
{
    use HasFactory;

    protected $fillable = [
        'referrer_id',
        'referred_id',
        'bonus_earned',
        'status',
    ];

    protected $casts = [
        'bonus_earned' => 'integer',
    ];

    protected $dates = [
        'created_at',
        'updated_at',
    ];

    const STATUS_PENDING = 'pending';
    const STATUS_COMPLETED = 'completed';

    /**
     * Relacionamento com cliente que indicou
     */
    public function referrer(): BelongsTo
    {
        return $this->belongsTo(Customer::class, 'referrer_id');
    }

    /**
     * Relacionamento com cliente indicado
     */
    public function referred(): BelongsTo
    {
        return $this->belongsTo(Customer::class, 'referred_id');
    }

    /**
     * Scope para indicações pendentes
     */
    public function scopePending($query)
    {
        return $query->where('status', self::STATUS_PENDING);
    }

    /**
     * Scope para indicações completadas
     */
    public function scopeCompleted($query)
    {
        return $query->where('status', self::STATUS_COMPLETED);
    }

    /**
     * Scope para indicações por referenciador
     */
    public function scopeByReferrer($query, $referrerId)
    {
        return $query->where('referrer_id', $referrerId);
    }

    /**
     * Scope para indicações por indicado
     */
    public function scopeByReferred($query, $referredId)
    {
        return $query->where('referred_id', $referredId);
    }

    /**
     * Marcar indicação como completada
     */
    public function complete(): void
    {
        $this->status = self::STATUS_COMPLETED;
        $this->save();
    }

    /**
     * Verificar se indicação está pendente
     */
    public function isPending(): bool
    {
        return $this->status === self::STATUS_PENDING;
    }

    /**
     * Verificar se indicação está completada
     */
    public function isCompleted(): bool
    {
        return $this->status === self::STATUS_COMPLETED;
    }

    /**
     * Processar indicação
     */
    public function process(LoyaltyProgram $loyaltyProgram): void
    {
        if ($this->isPending() && $this->referrer) {
            // Adicionar pontos ao referenciador
            $this->referrer->addLoyaltyPoints($this->bonus_earned);
            
            // Marcar como completada
            $this->complete();
        }
    }

    /**
     * Criar indicação
     */
    public static function createReferral(Customer $referrer, Customer $referred, LoyaltyProgram $loyaltyProgram): self
    {
        return self::create([
            'referrer_id' => $referrer->id,
            'referred_id' => $referred->id,
            'bonus_earned' => $loyaltyProgram->referral_bonus,
            'status' => self::STATUS_PENDING,
        ]);
    }

    /**
     * Verificar se cliente já foi indicado por outro
     */
    public static function hasBeenReferredBy(Customer $customer, Customer $referrer): bool
    {
        return self::where('referred_id', $customer->id)
                   ->where('referrer_id', $referrer->id)
                   ->exists();
    }

    /**
     * Contar indicações feitas por cliente
     */
    public static function countReferralsBy(Customer $customer): int
    {
        return self::where('referrer_id', $customer->id)->count();
    }

    /**
     * Contar indicações completadas por cliente
     */
    public static function countCompletedReferralsBy(Customer $customer): int
    {
        return self::where('referrer_id', $customer->id)
                   ->where('status', self::STATUS_COMPLETED)
                   ->count();
    }

    /**
     * Obter total de pontos ganhos por indicações
     */
    public static function getTotalBonusEarnedBy(Customer $customer): int
    {
        return self::where('referrer_id', $customer->id)
                   ->where('status', self::STATUS_COMPLETED)
                   ->sum('bonus_earned');
    }

    /**
     * Obter status formatado
     */
    public function getStatusLabelAttribute(): string
    {
        $statusLabels = [
            self::STATUS_PENDING => 'Pendente',
            self::STATUS_COMPLETED => 'Completada',
        ];

        return $statusLabels[$this->status] ?? 'Desconhecido';
    }

    /**
     * Boot do modelo
     */
    protected static function boot()
    {
        parent::boot();

        static::creating(function ($referral) {
            // Verificar se não existe indicação duplicada
            $exists = self::where('referrer_id', $referral->referrer_id)
                          ->where('referred_id', $referral->referred_id)
                          ->exists();
            
            if ($exists) {
                throw new \Exception('Indicação duplicada não permitida');
            }
        });
    }
}
