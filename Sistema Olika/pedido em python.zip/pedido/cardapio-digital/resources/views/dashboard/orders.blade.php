@extends('dashboard.layout-complete')

@section('title', 'Gestão de Pedidos - Cardápio Digital Olika')
@section('page-title', 'Gestão de Pedidos')

@section('content')
<div class="space-y-6">
    <!-- Header com Filtros -->
    <div class="bg-white rounded-xl p-6 shadow-lg">
        <div class="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
            <div>
                <h2 class="text-2xl font-bold text-gray-900">Pedidos</h2>
                <p class="text-gray-600">Gerencie todos os pedidos do seu restaurante</p>
            </div>
            
            <!-- Filtros -->
            <div class="flex flex-col sm:flex-row gap-4">
                <!-- Busca -->
                <div class="relative">
                    <input 
                        type="text" 
                        id="search-orders"
                        placeholder="Buscar por cliente, pedido..."
                        class="w-full sm:w-64 pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                    <svg class="absolute left-3 top-2.5 w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                    </svg>
                </div>
                
                <!-- Status -->
                <select id="status-filter" class="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <option value="">Todos os status</option>
                    <option value="pending">Pendente</option>
                    <option value="confirmed">Confirmado</option>
                    <option value="preparing">Preparando</option>
                    <option value="ready">Pronto</option>
                    <option value="delivered">Entregue</option>
                    <option value="cancelled">Cancelado</option>
                </select>
                
                <!-- Data -->
                <input 
                    type="date" 
                    id="date-filter"
                    class="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
            </div>
        </div>
    </div>

    <!-- Stats Cards -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div class="bg-white rounded-xl p-6 shadow-lg">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-gray-600">Total Hoje</p>
                    <p class="text-2xl font-bold text-gray-900">23</p>
                </div>
                <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <svg class="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"></path>
                    </svg>
                </div>
            </div>
        </div>
        
        <div class="bg-white rounded-xl p-6 shadow-lg">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-gray-600">Pendentes</p>
                    <p class="text-2xl font-bold text-yellow-600">5</p>
                </div>
                <div class="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                    <svg class="w-6 h-6 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                </div>
            </div>
        </div>
        
        <div class="bg-white rounded-xl p-6 shadow-lg">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-gray-600">Preparando</p>
                    <p class="text-2xl font-bold text-blue-600">8</p>
                </div>
                <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <svg class="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path>
                    </svg>
                </div>
            </div>
        </div>
        
        <div class="bg-white rounded-xl p-6 shadow-lg">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-gray-600">Faturamento</p>
                    <p class="text-2xl font-bold text-green-600">R$ 1.234</p>
                </div>
                <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                    <svg class="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1"></path>
                    </svg>
                </div>
            </div>
        </div>
    </div>

    <!-- Lista de Pedidos -->
    <div class="bg-white rounded-xl shadow-lg">
        <div class="p-6 border-b border-gray-200">
            <h3 class="text-lg font-semibold text-gray-900">Lista de Pedidos</h3>
        </div>
        
        <div class="overflow-x-auto">
            <table class="w-full">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Pedido</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Cliente</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Itens</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Data</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ações</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200" id="orders-table-body">
                    <!-- Pedido 1 -->
                    <tr class="hover:bg-gray-50">
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm font-medium text-gray-900">#1234</div>
                            <div class="text-sm text-gray-500">WhatsApp</div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm font-medium text-gray-900">João Silva</div>
                            <div class="text-sm text-gray-500">(11) 99999-9999</div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm text-gray-900">3 itens</div>
                            <div class="text-sm text-gray-500">Pizza, Refrigerante</div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <select class="status-select text-sm border-0 bg-transparent focus:ring-0" data-order-id="1234">
                                <option value="pending" selected>Pendente</option>
                                <option value="confirmed">Confirmado</option>
                                <option value="preparing">Preparando</option>
                                <option value="ready">Pronto</option>
                                <option value="delivered">Entregue</option>
                                <option value="cancelled">Cancelado</option>
                            </select>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">R$ 45,00</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">15:30</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                            <button class="text-blue-600 hover:text-blue-900 view-order" data-order-id="1234">Ver</button>
                            <button class="text-green-600 hover:text-green-900 confirm-order" data-order-id="1234">Confirmar</button>
                        </td>
                    </tr>
                    
                    <!-- Pedido 2 -->
                    <tr class="hover:bg-gray-50">
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm font-medium text-gray-900">#1233</div>
                            <div class="text-sm text-gray-500">Site</div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm font-medium text-gray-900">Maria Santos</div>
                            <div class="text-sm text-gray-500">(11) 88888-8888</div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm text-gray-900">2 itens</div>
                            <div class="text-sm text-gray-500">Hambúrguer, Batata</div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <select class="status-select text-sm border-0 bg-transparent focus:ring-0" data-order-id="1233">
                                <option value="pending">Pendente</option>
                                <option value="confirmed" selected>Confirmado</option>
                                <option value="preparing">Preparando</option>
                                <option value="ready">Pronto</option>
                                <option value="delivered">Entregue</option>
                                <option value="cancelled">Cancelado</option>
                            </select>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">R$ 32,50</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">15:15</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                            <button class="text-blue-600 hover:text-blue-900 view-order" data-order-id="1233">Ver</button>
                            <button class="text-blue-600 hover:text-blue-900 prepare-order" data-order-id="1233">Preparar</button>
                        </td>
                    </tr>
                    
                    <!-- Pedido 3 -->
                    <tr class="hover:bg-gray-50">
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm font-medium text-gray-900">#1232</div>
                            <div class="text-sm text-gray-500">PDV</div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm font-medium text-gray-900">Pedro Costa</div>
                            <div class="text-sm text-gray-500">Cliente Avulso</div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm text-gray-900">1 item</div>
                            <div class="text-sm text-gray-500">Refrigerante</div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <select class="status-select text-sm border-0 bg-transparent focus:ring-0" data-order-id="1232">
                                <option value="pending">Pendente</option>
                                <option value="confirmed">Confirmado</option>
                                <option value="preparing" selected>Preparando</option>
                                <option value="ready">Pronto</option>
                                <option value="delivered">Entregue</option>
                                <option value="cancelled">Cancelado</option>
                            </select>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">R$ 8,00</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">15:00</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                            <button class="text-blue-600 hover:text-blue-900 view-order" data-order-id="1232">Ver</button>
                            <button class="text-green-600 hover:text-green-900 ready-order" data-order-id="1232">Pronto</button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal de Detalhes do Pedido -->
<div id="order-modal" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden flex items-center justify-center p-4">
    <div class="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div class="p-6 border-b border-gray-200">
            <div class="flex items-center justify-between">
                <h3 class="text-xl font-bold text-gray-900">Detalhes do Pedido #1234</h3>
                <button id="close-order-modal" class="text-gray-500 hover:text-gray-700">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                </button>
            </div>
        </div>
        
        <div class="p-6 space-y-6">
            <!-- Informações do Cliente -->
            <div>
                <h4 class="font-semibold text-gray-900 mb-3">Informações do Cliente</h4>
                <div class="bg-gray-50 rounded-lg p-4">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <p class="text-sm text-gray-600">Nome</p>
                            <p class="font-medium">João Silva</p>
                        </div>
                        <div>
                            <p class="text-sm text-gray-600">Telefone</p>
                            <p class="font-medium">(11) 99999-9999</p>
                        </div>
                        <div>
                            <p class="text-sm text-gray-600">Endereço</p>
                            <p class="font-medium">Rua das Flores, 123</p>
                        </div>
                        <div>
                            <p class="text-sm text-gray-600">Bairro</p>
                            <p class="font-medium">Centro</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Itens do Pedido -->
            <div>
                <h4 class="font-semibold text-gray-900 mb-3">Itens do Pedido</h4>
                <div class="space-y-3">
                    <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div class="flex items-center space-x-3">
                            <img src="/placeholder.svg" alt="Pizza Margherita" class="w-12 h-12 object-cover rounded">
                            <div>
                                <p class="font-medium">Pizza Margherita</p>
                                <p class="text-sm text-gray-500">Qtd: 1</p>
                            </div>
                        </div>
                        <span class="font-medium">R$ 45,00</span>
                    </div>
                    
                    <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div class="flex items-center space-x-3">
                            <img src="/placeholder.svg" alt="Refrigerante" class="w-12 h-12 object-cover rounded">
                            <div>
                                <p class="font-medium">Refrigerante</p>
                                <p class="text-sm text-gray-500">Qtd: 2</p>
                            </div>
                        </div>
                        <span class="font-medium">R$ 16,00</span>
                    </div>
                </div>
            </div>
            
            <!-- Resumo -->
            <div class="border-t pt-4">
                <div class="space-y-2">
                    <div class="flex justify-between">
                        <span class="text-gray-600">Subtotal</span>
                        <span>R$ 61,00</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-gray-600">Taxa de Entrega</span>
                        <span>R$ 5,00</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-gray-600">Desconto</span>
                        <span class="text-green-600">-R$ 10,00</span>
                    </div>
                    <hr>
                    <div class="flex justify-between text-lg font-bold">
                        <span>Total</span>
                        <span class="text-green-600">R$ 56,00</span>
                    </div>
                </div>
            </div>
            
            <!-- Ações -->
            <div class="flex space-x-3 pt-4">
                <button class="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition">
                    Confirmar Pedido
                </button>
                <button class="flex-1 bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition">
                    Marcar como Pronto
                </button>
                <button class="flex-1 bg-red-600 text-white py-2 px-4 rounded-lg hover:bg-red-700 transition">
                    Cancelar
                </button>
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Filtros
    const searchInput = document.getElementById('search-orders');
    const statusFilter = document.getElementById('status-filter');
    const dateFilter = document.getElementById('date-filter');
    
    // Atualizar status do pedido
    document.querySelectorAll('.status-select').forEach(select => {
        select.addEventListener('change', function() {
            const orderId = this.dataset.orderId;
            const newStatus = this.value;
            
            // Simular atualização
            showToast(`Status do pedido #${orderId} atualizado para ${newStatus}`, 'success');
            
            // Aqui você faria a chamada para a API
            // updateOrderStatus(orderId, newStatus);
        });
    });
    
    // Ver detalhes do pedido
    document.querySelectorAll('.view-order').forEach(button => {
        button.addEventListener('click', function() {
            const orderId = this.dataset.orderId;
            document.getElementById('order-modal').classList.remove('hidden');
        });
    });
    
    // Fechar modal
    document.getElementById('close-order-modal').addEventListener('click', function() {
        document.getElementById('order-modal').classList.add('hidden');
    });
    
    // Confirmar pedido
    document.querySelectorAll('.confirm-order').forEach(button => {
        button.addEventListener('click', function() {
            const orderId = this.dataset.orderId;
            if (confirm(`Confirmar pedido #${orderId}?`)) {
                showToast(`Pedido #${orderId} confirmado!`, 'success');
                // Aqui você faria a chamada para a API
            }
        });
    });
    
    // Preparar pedido
    document.querySelectorAll('.prepare-order').forEach(button => {
        button.addEventListener('click', function() {
            const orderId = this.dataset.orderId;
            if (confirm(`Marcar pedido #${orderId} como preparando?`)) {
                showToast(`Pedido #${orderId} sendo preparado!`, 'success');
                // Aqui você faria a chamada para a API
            }
        });
    });
    
    // Pedido pronto
    document.querySelectorAll('.ready-order').forEach(button => {
        button.addEventListener('click', function() {
            const orderId = this.dataset.orderId;
            if (confirm(`Marcar pedido #${orderId} como pronto?`)) {
                showToast(`Pedido #${orderId} está pronto!`, 'success');
                // Aqui você faria a chamada para a API
            }
        });
    });
    
    // Filtros em tempo real
    function applyFilters() {
        const searchTerm = searchInput.value.toLowerCase();
        const selectedStatus = statusFilter.value;
        const selectedDate = dateFilter.value;
        
        const rows = document.querySelectorAll('#orders-table-body tr');
        
        rows.forEach(row => {
            const orderNumber = row.querySelector('td:first-child .text-sm').textContent.toLowerCase();
            const customerName = row.querySelector('td:nth-child(2) .text-sm').textContent.toLowerCase();
            const currentStatus = row.querySelector('.status-select').value;
            
            const matchesSearch = orderNumber.includes(searchTerm) || customerName.includes(searchTerm);
            const matchesStatus = !selectedStatus || currentStatus === selectedStatus;
            const matchesDate = !selectedDate; // Implementar filtro de data se necessário
            
            if (matchesSearch && matchesStatus && matchesDate) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    }
    
    searchInput.addEventListener('input', applyFilters);
    statusFilter.addEventListener('change', applyFilters);
    dateFilter.addEventListener('change', applyFilters);
    
    // Atualizar estatísticas em tempo real
    function updateStats() {
        // Simular atualização das estatísticas
        // Aqui você faria chamadas para a API para obter dados em tempo real
    }
    
    // Atualizar a cada 30 segundos
    setInterval(updateStats, 30000);
});
</script>
@endpush
@endsection
