@props([
    'id' => null,
    'title' => '',
    'open' => false,
])

@php
$itemId = $id ?? 'accordion-item-' . uniqid();
@endphp

<div 
    x-data="{ open: {{ $open ? 'true' : 'false' }} }"
    {{ $attributes->merge(['class' => 'border rounded-lg']) }}
>
    <button 
        @click="open = !open"
        class="flex w-full items-center justify-between p-4 text-left font-medium transition-all hover:bg-muted/50"
    >
        <span>{{ $title }}</span>
        <svg 
            :class="open ? 'rotate-180' : ''"
            class="h-4 w-4 shrink-0 transition-transform duration-200"
            fill="none" 
            stroke="currentColor" 
            viewBox="0 0 24 24"
        >
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
        </svg>
    </button>
    
    <div 
        x-show="open"
        x-collapse
        class="overflow-hidden"
    >
        <div class="p-4 pt-0">
            {{ $slot }}
        </div>
    </div>
</div>

