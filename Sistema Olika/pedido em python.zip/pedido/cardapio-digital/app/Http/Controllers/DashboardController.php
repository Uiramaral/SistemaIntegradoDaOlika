<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Product;
use App\Models\Customer;
use App\Models\Settings;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class DashboardController extends Controller
{
    /**
     * Exibir dashboard
     */
    public function index()
    {
        $settings = Settings::getSettings();
        
        // Estatísticas básicas
        $stats = [
            'orders_count' => Order::where('created_at', '>=', Carbon::now()->subDays(7))->count(),
            'revenue' => Order::where('created_at', '>=', Carbon::now()->subDays(7))->sum('total'),
            'customers_count' => Customer::where('created_at', '>=', Carbon::now()->subDays(7))->count(),
            'menu_views' => 46, // Simulado por enquanto
        ];

        return view('dashboard.dashboard-complete', compact('settings', 'stats'));
    }

    /**
     * Obter estatísticas via API
     */
    public function getStats(Request $request)
    {
        $period = $request->get('period', 7);
        $metric = $request->get('metric', 'orders');
        
        $startDate = Carbon::now()->subDays($period);
        
        $stats = [
            'orders_count' => Order::where('created_at', '>=', $startDate)->count(),
            'revenue' => Order::where('created_at', '>=', $startDate)->sum('total'),
            'customers_count' => Customer::where('created_at', '>=', $startDate)->count(),
            'menu_views' => 46, // Simulado
            'period' => $period,
            'metric' => $metric
        ];

        return response()->json([
            'success' => true,
            'data' => $stats
        ]);
    }

    /**
     * Obter pedidos recentes
     */
    public function getRecentOrders()
    {
        $orders = Order::with(['customer', 'items.product'])
            ->orderBy('created_at', 'desc')
            ->limit(10)
            ->get();

        return response()->json([
            'success' => true,
            'data' => $orders
        ]);
    }

    /**
     * Obter produtos mais vendidos
     */
    public function getTopProducts()
    {
        $topProducts = DB::table('order_items')
            ->join('products', 'order_items.product_id', '=', 'products.id')
            ->join('orders', 'order_items.order_id', '=', 'orders.id')
            ->where('orders.status', '!=', 'cancelled')
            ->select(
                'products.id',
                'products.name',
                'products.image',
                DB::raw('SUM(order_items.quantity) as total_quantity'),
                DB::raw('SUM(order_items.quantity * order_items.price) as total_revenue')
            )
            ->groupBy('products.id', 'products.name', 'products.image')
            ->orderBy('total_quantity', 'desc')
            ->limit(10)
            ->get();

        return response()->json([
            'success' => true,
            'data' => $topProducts
        ]);
    }

    /**
     * Obter estatísticas de clientes
     */
    public function getCustomersStats()
    {
        $totalCustomers = Customer::count();
        $newCustomers = Customer::where('created_at', '>=', Carbon::now()->subDays(30))->count();
        $activeCustomers = Customer::whereHas('orders', function($query) {
            $query->where('created_at', '>=', Carbon::now()->subDays(30));
        })->count();

        return response()->json([
            'success' => true,
            'data' => [
                'total' => $totalCustomers,
                'new' => $newCustomers,
                'active' => $activeCustomers
            ]
        ]);
    }

    /**
     * Obter gráfico de pedidos
     */
    public function getOrdersChart(Request $request)
    {
        $period = $request->get('period', 7);
        $startDate = Carbon::now()->subDays($period);
        
        $orders = Order::where('created_at', '>=', $startDate)
            ->selectRaw('DATE(created_at) as date, COUNT(*) as count')
            ->groupBy('date')
            ->orderBy('date')
            ->get();

        $chartData = [
            'labels' => $orders->pluck('date')->map(function($date) {
                return Carbon::parse($date)->format('d/m');
            })->toArray(),
            'data' => $orders->pluck('count')->toArray()
        ];

        return response()->json([
            'success' => true,
            'data' => $chartData
        ]);
    }

    /**
     * Obter gráfico de receita
     */
    public function getRevenueChart(Request $request)
    {
        $period = $request->get('period', 7);
        $startDate = Carbon::now()->subDays($period);
        
        $revenue = Order::where('created_at', '>=', $startDate)
            ->where('status', '!=', 'cancelled')
            ->selectRaw('DATE(created_at) as date, SUM(total) as total')
            ->groupBy('date')
            ->orderBy('date')
            ->get();

        $chartData = [
            'labels' => $revenue->pluck('date')->map(function($date) {
                return Carbon::parse($date)->format('d/m');
            })->toArray(),
            'data' => $revenue->pluck('total')->toArray()
        ];

        return response()->json([
            'success' => true,
            'data' => $chartData
        ]);
    }
}
