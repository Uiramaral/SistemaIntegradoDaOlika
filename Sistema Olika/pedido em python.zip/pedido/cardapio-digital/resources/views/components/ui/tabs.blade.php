@props([
    'id' => null,
    'active' => null,
])

@php
$tabsId = $id ?? 'tabs-' . uniqid();
@endphp

<div 
    x-data="{ activeTab: '{{ $active }}' }"
    {{ $attributes->merge(['class' => 'w-full']) }}
>
    {{ $slot }}
</div>

