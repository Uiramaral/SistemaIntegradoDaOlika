@props([
    'orientation' => 'horizontal',
])

@php
$classes = $orientation === 'horizontal' 
    ? 'h-[1px] w-full bg-border' 
    : 'h-full w-[1px] bg-border';
@endphp

<div {{ $attributes->merge(['class' => $classes]) }}></div>

