{{-- Toast Container --}}
<div 
    id="toast-container"
    class="fixed top-4 right-4 z-50 space-y-2"
    x-data="toastManager()"
    @toast.window="addToast($event.detail)"
>
    <template x-for="toast in toasts" :key="toast.id">
        <div 
            x-show="toast.show"
            x-transition:enter="transition ease-out duration-300"
            x-transition:enter-start="opacity-0 transform translate-x-full"
            x-transition:enter-end="opacity-100 transform translate-x-0"
            x-transition:leave="transition ease-in duration-200"
            x-transition:leave-start="opacity-100"
            x-transition:leave-end="opacity-0 transform translate-x-full"
            class="flex items-center p-4 mb-4 text-sm rounded-lg shadow-lg max-w-xs"
            :class="{
                'bg-green-100 text-green-800': toast.type === 'success',
                'bg-red-100 text-red-800': toast.type === 'error',
                'bg-yellow-100 text-yellow-800': toast.type === 'warning',
                'bg-blue-100 text-blue-800': toast.type === 'info'
            }"
            role="alert"
        >
            <div class="flex-1" x-text="toast.message"></div>
            <button 
                @click="removeToast(toast.id)"
                class="ml-auto -mx-1.5 -my-1.5 rounded-lg p-1.5 inline-flex h-8 w-8 hover:bg-gray-200"
            >
                <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                    <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd"></path>
                </svg>
            </button>
        </div>
    </template>
</div>

<script>
function toastManager() {
    return {
        toasts: [],
        addToast(data) {
            const id = Date.now();
            this.toasts.push({
                id,
                message: data.message,
                type: data.type || 'info',
                show: true
            });
            setTimeout(() => this.removeToast(id), data.duration || 5000);
        },
        removeToast(id) {
            const index = this.toasts.findIndex(t => t.id === id);
            if (index > -1) {
                this.toasts[index].show = false;
                setTimeout(() => {
                    this.toasts.splice(index, 1);
                }, 300);
            }
        }
    }
}

// Helper function
window.showToast = function(message, type = 'info', duration = 5000) {
    window.dispatchEvent(new CustomEvent('toast', {
        detail: { message, type, duration }
    }));
}
</script>

