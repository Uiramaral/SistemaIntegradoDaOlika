@extends('client.layout-new')

@section('title', 'Carrinho - Cardápio Digital Olika')

@section('content')
<div class="min-h-screen bg-gray-50">
    <!-- Header -->
    <header class="bg-white shadow-sm border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-4">
                <div class="flex items-center">
                    <a href="{{ route('menu') }}" class="flex items-center space-x-3">
                        <svg class="w-6 h-6 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path>
                        </svg>
                        <span class="text-gray-600">Voltar ao Menu</span>
                    </a>
                </div>
                <div class="flex items-center space-x-3">
                    <div class="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                        <span class="text-white font-bold text-lg">O</span>
                    </div>
                    <div>
                        <h1 class="text-xl font-bold text-gray-900">Olika</h1>
                        <p class="text-sm text-gray-500">Carrinho de Compras</p>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <!-- Carrinho -->
            <div class="lg:col-span-2">
                <div class="bg-white rounded-xl shadow-lg p-6">
                    <div class="flex items-center justify-between mb-6">
                        <h2 class="text-2xl font-bold text-gray-900">Seu Carrinho</h2>
                        <span class="text-sm text-gray-500" id="item-count">0 itens</span>
                    </div>

                    <!-- Lista de Itens -->
                    <div id="cart-items" class="space-y-4">
                        <!-- Itens serão carregados via JavaScript -->
                    </div>

                    <!-- Carrinho Vazio -->
                    <div id="empty-cart" class="text-center py-12 hidden">
                        <svg class="w-16 h-16 mx-auto text-gray-300 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4m0 0L7 13m0 0l-2.5 5M7 13l2.5 5m6-5v6a2 2 0 01-2 2H9a2 2 0 01-2-2v-6m8 0V9a2 2 0 00-2-2H9a2 2 0 00-2 2v4.01"></path>
                        </svg>
                        <h3 class="text-lg font-medium text-gray-900 mb-2">Seu carrinho está vazio</h3>
                        <p class="text-gray-500 mb-6">Adicione alguns produtos deliciosos!</p>
                        <a href="{{ route('menu') }}" class="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition">
                            Ver Cardápio
                        </a>
                    </div>
                </div>
            </div>

            <!-- Resumo do Pedido -->
            <div class="lg:col-span-1">
                <div class="bg-white rounded-xl shadow-lg p-6 sticky top-4">
                    <h3 class="text-xl font-bold text-gray-900 mb-4">Resumo do Pedido</h3>
                    
                    <!-- Subtotal -->
                    <div class="flex justify-between items-center py-2">
                        <span class="text-gray-600">Subtotal</span>
                        <span class="font-medium" id="subtotal">R$ 0,00</span>
                    </div>
                    
                    <!-- Taxa de Entrega -->
                    <div class="flex justify-between items-center py-2">
                        <span class="text-gray-600">Taxa de Entrega</span>
                        <span class="font-medium" id="delivery-fee">R$ 0,00</span>
                    </div>
                    
                    <!-- Desconto -->
                    <div class="flex justify-between items-center py-2" id="discount-row" style="display: none;">
                        <span class="text-gray-600">Desconto</span>
                        <span class="font-medium text-green-600" id="discount">-R$ 0,00</span>
                    </div>
                    
                    <hr class="my-4">
                    
                    <!-- Total -->
                    <div class="flex justify-between items-center py-2">
                        <span class="text-lg font-bold text-gray-900">Total</span>
                        <span class="text-xl font-bold text-green-600" id="total">R$ 0,00</span>
                    </div>

                    <!-- Cupom de Desconto -->
                    <div class="mt-6">
                        <div class="flex space-x-2">
                            <input 
                                type="text" 
                                id="coupon-code" 
                                placeholder="Código do cupom"
                                class="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                            >
                            <button 
                                id="apply-coupon" 
                                class="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 transition"
                            >
                                Aplicar
                            </button>
                        </div>
                        <div id="coupon-message" class="mt-2 text-sm hidden"></div>
                    </div>

                    <!-- Botão Finalizar -->
                    <button 
                        id="checkout-btn" 
                        class="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition font-medium mt-6 disabled:opacity-50 disabled:cursor-not-allowed"
                        disabled
                    >
                        Finalizar Pedido
                    </button>

                    <!-- Informações de Entrega -->
                    <div class="mt-6 p-4 bg-gray-50 rounded-lg">
                        <h4 class="font-medium text-gray-900 mb-2">📦 Informações de Entrega</h4>
                        <p class="text-sm text-gray-600">• Entrega em até 60 minutos</p>
                        <p class="text-sm text-gray-600">• Frete grátis acima de R$ 50,00</p>
                        <p class="text-sm text-gray-600">• Pagamento na entrega ou online</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal de Confirmação -->
<div id="confirm-modal" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden flex items-center justify-center p-4">
    <div class="bg-white rounded-xl max-w-md w-full p-6">
        <h3 class="text-xl font-bold text-gray-900 mb-4">Confirmar Remoção</h3>
        <p class="text-gray-600 mb-6">Tem certeza que deseja remover este item do carrinho?</p>
        <div class="flex space-x-3">
            <button 
                id="confirm-remove" 
                class="flex-1 bg-red-600 text-white py-2 rounded-lg hover:bg-red-700 transition"
            >
                Remover
            </button>
            <button 
                id="cancel-remove" 
                class="flex-1 bg-gray-300 text-gray-700 py-2 rounded-lg hover:bg-gray-400 transition"
            >
                Cancelar
            </button>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    let cart = [];
    let itemToRemove = null;

    // Carregar carrinho
    loadCart();

    // Carregar carrinho do localStorage ou API
    function loadCart() {
        fetch('/api/cart')
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    cart = data.items || [];
                    renderCart();
                }
            })
            .catch(error => {
                console.error('Erro ao carregar carrinho:', error);
                // Fallback para localStorage
                const savedCart = localStorage.getItem('cart');
                if (savedCart) {
                    cart = JSON.parse(savedCart);
                    renderCart();
                }
            });
    }

    // Renderizar carrinho
    function renderCart() {
        const cartItems = document.getElementById('cart-items');
        const emptyCart = document.getElementById('empty-cart');
        const itemCount = document.getElementById('item-count');
        const subtotal = document.getElementById('subtotal');
        const total = document.getElementById('total');
        const checkoutBtn = document.getElementById('checkout-btn');

        if (cart.length === 0) {
            cartItems.innerHTML = '';
            emptyCart.classList.remove('hidden');
            itemCount.textContent = '0 itens';
            subtotal.textContent = 'R$ 0,00';
            total.textContent = 'R$ 0,00';
            checkoutBtn.disabled = true;
            return;
        }

        emptyCart.classList.add('hidden');
        checkoutBtn.disabled = false;

        // Calcular totais
        const subtotalValue = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        const deliveryFee = subtotalValue >= 50 ? 0 : 5; // Frete grátis acima de R$ 50
        const totalValue = subtotalValue + deliveryFee;

        // Atualizar contadores
        const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
        itemCount.textContent = `${totalItems} ${totalItems === 1 ? 'item' : 'itens'}`;
        subtotal.textContent = `R$ ${subtotalValue.toFixed(2).replace('.', ',')}`;
        document.getElementById('delivery-fee').textContent = `R$ ${deliveryFee.toFixed(2).replace('.', ',')}`;
        total.textContent = `R$ ${totalValue.toFixed(2).replace('.', ',')}`;

        // Renderizar itens
        cartItems.innerHTML = cart.map(item => `
            <div class="flex items-center space-x-4 p-4 border border-gray-200 rounded-lg">
                <img src="${item.image || '/placeholder.svg'}" alt="${item.name}" class="w-16 h-16 object-cover rounded-lg">
                <div class="flex-1">
                    <h3 class="font-medium text-gray-900">${item.name}</h3>
                    <p class="text-sm text-gray-500">R$ ${item.price.toFixed(2).replace('.', ',')} cada</p>
                </div>
                <div class="flex items-center space-x-2">
                    <button class="quantity-btn w-8 h-8 rounded-full border border-gray-300 flex items-center justify-center hover:bg-gray-50" data-id="${item.id}" data-action="decrease">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 12H4"></path>
                        </svg>
                    </button>
                    <span class="w-8 text-center font-medium">${item.quantity}</span>
                    <button class="quantity-btn w-8 h-8 rounded-full border border-gray-300 flex items-center justify-center hover:bg-gray-50" data-id="${item.id}" data-action="increase">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
                        </svg>
                    </button>
                </div>
                <div class="text-right">
                    <div class="font-medium text-gray-900">R$ ${(item.price * item.quantity).toFixed(2).replace('.', ',')}</div>
                    <button class="remove-item text-red-600 text-sm hover:text-red-800" data-id="${item.id}">
                        Remover
                    </button>
                </div>
            </div>
        `).join('');

        // Adicionar event listeners
        document.querySelectorAll('.quantity-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const id = this.dataset.id;
                const action = this.dataset.action;
                updateQuantity(id, action);
            });
        });

        document.querySelectorAll('.remove-item').forEach(btn => {
            btn.addEventListener('click', function() {
                const id = this.dataset.id;
                itemToRemove = id;
                document.getElementById('confirm-modal').classList.remove('hidden');
            });
        });
    }

    // Atualizar quantidade
    function updateQuantity(id, action) {
        const item = cart.find(item => item.id == id);
        if (!item) return;

        if (action === 'increase') {
            item.quantity++;
        } else if (action === 'decrease') {
            item.quantity--;
            if (item.quantity <= 0) {
                removeItem(id);
                return;
            }
        }

        saveCart();
        renderCart();
    }

    // Remover item
    function removeItem(id) {
        cart = cart.filter(item => item.id != id);
        saveCart();
        renderCart();
    }

    // Salvar carrinho
    function saveCart() {
        localStorage.setItem('cart', JSON.stringify(cart));
        
        // Sincronizar com API
        fetch('/api/cart/sync', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
            },
            body: JSON.stringify({ items: cart })
        }).catch(error => console.error('Erro ao sincronizar carrinho:', error));
    }

    // Aplicar cupom
    document.getElementById('apply-coupon').addEventListener('click', function() {
        const code = document.getElementById('coupon-code').value;
        if (!code) return;

        fetch('/api/cart/apply-coupon', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
            },
            body: JSON.stringify({ code: code })
        })
        .then(response => response.json())
        .then(data => {
            const message = document.getElementById('coupon-message');
            if (data.success) {
                message.textContent = 'Cupom aplicado com sucesso!';
                message.className = 'mt-2 text-sm text-green-600';
                message.classList.remove('hidden');
                renderCart();
            } else {
                message.textContent = data.message || 'Cupom inválido';
                message.className = 'mt-2 text-sm text-red-600';
                message.classList.remove('hidden');
            }
        })
        .catch(error => {
            console.error('Erro ao aplicar cupom:', error);
        });
    });

    // Finalizar pedido
    document.getElementById('checkout-btn').addEventListener('click', function() {
        if (cart.length === 0) return;
        window.location.href = '/checkout';
    });

    // Modal de confirmação
    document.getElementById('confirm-remove').addEventListener('click', function() {
        if (itemToRemove) {
            removeItem(itemToRemove);
            itemToRemove = null;
        }
        document.getElementById('confirm-modal').classList.add('hidden');
    });

    document.getElementById('cancel-remove').addEventListener('click', function() {
        itemToRemove = null;
        document.getElementById('confirm-modal').classList.add('hidden');
    });
});
</script>
@endsection
