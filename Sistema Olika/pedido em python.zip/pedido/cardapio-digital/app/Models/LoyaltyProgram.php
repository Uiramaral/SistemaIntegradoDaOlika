<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LoyaltyProgram extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'points_per_real',
        'points_to_discount',
        'birthday_bonus',
        'referral_bonus',
        'active',
    ];

    protected $casts = [
        'points_per_real' => 'decimal:2',
        'points_to_discount' => 'integer',
        'birthday_bonus' => 'integer',
        'referral_bonus' => 'integer',
        'active' => 'boolean',
    ];

    protected $dates = [
        'created_at',
        'updated_at',
    ];

    /**
     * Calcular pontos ganhos por valor gasto
     */
    public function calculatePointsEarned(float $amount): int
    {
        return floor($amount * $this->points_per_real);
    }

    /**
     * Calcular desconto por pontos
     */
    public function calculateDiscountByPoints(int $points): float
    {
        return floor($points / $this->points_to_discount);
    }

    /**
     * Calcular pontos necessários para desconto
     */
    public function calculatePointsNeededForDiscount(float $discountAmount): int
    {
        return ceil($discountAmount * $this->points_to_discount);
    }

    /**
     * Verificar se programa está ativo
     */
    public function isActive(): bool
    {
        return $this->active;
    }

    /**
     * Ativar programa
     */
    public function activate(): void
    {
        $this->active = true;
        $this->save();
    }

    /**
     * Desativar programa
     */
    public function deactivate(): void
    {
        $this->active = false;
        $this->save();
    }

    /**
     * Toggle status do programa
     */
    public function toggleStatus(): void
    {
        $this->active = !$this->active;
        $this->save();
    }

    /**
     * Obter configuração padrão
     */
    public static function getDefault(): self
    {
        return self::first() ?? self::create([
            'name' => 'Programa de Fidelidade Olika',
            'points_per_real' => 1,
            'points_to_discount' => 100,
            'birthday_bonus' => 50,
            'referral_bonus' => 100,
            'active' => true,
        ]);
    }

    /**
     * Obter taxa de conversão de pontos para reais
     */
    public function getPointsToRealRateAttribute(): float
    {
        return 1 / $this->points_to_discount;
    }

    /**
     * Obter taxa de conversão de reais para pontos
     */
    public function getRealToPointsRateAttribute(): float
    {
        return $this->points_per_real;
    }

    /**
     * Validar se configuração é válida
     */
    public function isValidConfiguration(): bool
    {
        return $this->points_per_real > 0 
            && $this->points_to_discount > 0
            && $this->birthday_bonus >= 0
            && $this->referral_bonus >= 0;
    }

    /**
     * Obter resumo do programa
     */
    public function getSummaryAttribute(): array
    {
        return [
            'name' => $this->name,
            'points_per_real' => $this->points_per_real,
            'points_to_discount' => $this->points_to_discount,
            'birthday_bonus' => $this->birthday_bonus,
            'referral_bonus' => $this->referral_bonus,
            'active' => $this->active,
            'points_to_real_rate' => $this->points_to_real_rate,
            'real_to_points_rate' => $this->real_to_points_rate,
        ];
    }
}
