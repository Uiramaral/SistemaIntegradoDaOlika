<?php

namespace App\Services;

use App\Models\Product;
use App\Models\Category;
use App\Models\Settings;
use Illuminate\Support\Facades\Log;

class AIResponseGenerator
{
    private $settings;
    private $responseTemplates;

    public function __construct()
    {
        $this->settings = Settings::getSettings();
        $this->responseTemplates = $this->loadResponseTemplates();
    }

    /**
     * Gerar resposta personalizada
     */
    public function generateResponse(string $intent, array $context = [], array $data = []): string
    {
        $template = $this->getTemplate($intent);
        
        if (!$template) {
            return $this->getFallbackResponse();
        }

        return $this->processTemplate($template, $context, $data);
    }

    /**
     * Carregar templates de resposta
     */
    private function loadResponseTemplates(): array
    {
        return [
            'greeting' => [
                'templates' => [
                    "Olá! 👋 Bem-vindo ao {business_name}! Como posso ajudar você hoje?",
                    "Oi! 😊 Seja bem-vindo ao {business_name}! Em que posso ajudar?",
                    "Olá! 🎉 É um prazer te atender no {business_name}!",
                    "Oi! 😄 Bem-vindo ao {business_name}! Vamos fazer seu pedido?"
                ],
                'variables' => ['business_name', 'customer_name']
            ],
            'menu_request' => [
                'templates' => [
                    "📋 *NOSSO CARDÁPIO*\n\n{categories_list}\n\n💡 *Para fazer um pedido, digite:*\n• \"Quero pedir\" - Para começar um pedido\n• \"Produto X\" - Informações sobre um produto",
                    "🍽️ *Aqui está nosso cardápio:*\n\n{categories_list}\n\n🎯 *Como pedir:*\n• \"Quero [produto]\" - Para adicionar ao pedido\n• \"Cardápio completo\" - Ver todos os produtos"
                ],
                'variables' => ['categories_list']
            ],
            'product_inquiry' => [
                'templates' => [
                    "🍽️ *{product_name}*\n\n💰 *Preço:* R$ {product_price}\n{product_description}{product_ingredients}{product_preparation_time}\n\n💡 *Para adicionar ao pedido:*\n\"Quero {product_name}\" ou \"Adicionar {product_name}\"",
                    "📦 *{product_name}*\n\n💵 *Valor:* R$ {product_price}\n{product_description}\n\n🛒 *Gostou?* Digite \"Quero {product_name}\" para adicionar ao seu pedido!"
                ],
                'variables' => ['product_name', 'product_price', 'product_description', 'product_ingredients', 'product_preparation_time']
            ],
            'order_start' => [
                'templates' => [
                    "🍽️ Ótimo, {customer_name}! Vamos fazer seu pedido!\n\n📋 *Como funciona:*\n• Digite o nome do produto que deseja\n• Confirme a quantidade\n• Escolha a forma de pagamento\n\n💡 *Exemplo:* \"Quero 2 Prato do Dia\"",
                    "🎯 Perfeito! Vamos montar seu pedido!\n\n🍽️ *Para pedir:*\n• \"Quero [produto]\" - Adicionar produto\n• \"Ver pedido\" - Revisar carrinho\n• \"Finalizar\" - Concluir pedido\n\n✨ *Exemplo:* \"Quero 1 Frango Grelhado\""
                ],
                'variables' => ['customer_name']
            ],
            'add_to_cart' => [
                'templates' => [
                    "✅ *Adicionado ao pedido!*\n\n🍽️ *{product_name}*\n📦 *Quantidade:* {quantity}\n💰 *Valor:* R$ {item_total}\n\n🛒 *Total do pedido:* R$ {cart_total}\n\n💡 *Para continuar:*\n• Digite outro produto\n• \"Finalizar pedido\" - Para concluir\n• \"Ver pedido\" - Para revisar",
                    "🎉 *Produto adicionado!*\n\n📦 {product_name} x{quantity}\n💵 R$ {item_total}\n\n🛒 *Total:* R$ {cart_total}\n\n✨ *Próximos passos:*\n• Adicionar mais produtos\n• \"Finalizar\" quando estiver pronto"
                ],
                'variables' => ['product_name', 'quantity', 'item_total', 'cart_total']
            ],
            'order_complete' => [
                'templates' => [
                    "🎉 *Pedido realizado com sucesso!*\n\n📋 *Pedido #{order_number}*\n🛒 *Total:* R$ {order_total}\n📅 *Entrega:* {delivery_date} às {delivery_time}\n💳 *Pagamento:* {payment_method}\n\n📱 *Acompanhe seu pedido:*\n• Status será enviado por aqui\n• Tempo estimado: {estimated_time}\n\n🙏 *Obrigado pela preferência!*",
                    "✅ *Pedido confirmado!*\n\n🆔 *#{order_number}*\n💰 *Total:* R$ {order_total}\n🚚 *Entrega:* {delivery_date} - {delivery_time}\n💳 *Pagamento:* {payment_method}\n\n⏱️ *Tempo estimado:* {estimated_time}\n📞 *Dúvidas?* Entre em contato!\n\n🎯 *Obrigado por escolher {business_name}!*"
                ],
                'variables' => ['order_number', 'order_total', 'delivery_date', 'delivery_time', 'payment_method', 'estimated_time', 'business_name']
            ],
            'order_status' => [
                'templates' => [
                    "📋 *Último Pedido:*\n\n🆔 *Pedido #{order_number}*\n📅 *Data:* {order_date}\n💰 *Total:* R$ {order_total}\n📦 *Status:* {order_status}\n🚚 *Entrega:* {delivery_date} às {delivery_time}",
                    "📦 *Status do Pedido #{order_number}:*\n\n📅 *Realizado em:* {order_date}\n💵 *Valor:* R$ {order_total}\n🏷️ *Status:* {order_status}\n🚛 *Entrega:* {delivery_date} - {delivery_time}\n\n💡 *Precisa de ajuda?* Estou aqui!"
                ],
                'variables' => ['order_number', 'order_date', 'order_total', 'order_status', 'delivery_date', 'delivery_time']
            ],
            'delivery_info' => [
                'templates' => [
                    "🚚 *INFORMAÇÕES DE ENTREGA*\n\n📍 *Área de entrega:* {delivery_radius}km\n💰 *Taxa de entrega:*\n{delivery_fees}\n\n🎉 *Entrega grátis:* A partir de R$ {free_delivery_threshold}\n\n⏱️ *Tempo de entrega:* {delivery_time}\n📅 *Horário:* {business_hours}",
                    "🚛 *ENTREGA E FRETE*\n\n📍 *Cobertura:* {delivery_radius}km\n💸 *Valores:*\n{delivery_fees}\n\n🎁 *Grátis:* Acima de R$ {free_delivery_threshold}\n\n⏰ *Prazo:* {delivery_time}\n🕒 *Funcionamento:* {business_hours}"
                ],
                'variables' => ['delivery_radius', 'delivery_fees', 'free_delivery_threshold', 'delivery_time', 'business_hours']
            ],
            'payment_info' => [
                'templates' => [
                    "💳 *FORMAS DE PAGAMENTO*\n\n{payment_methods}\n\n🔒 *Pagamento 100% seguro*",
                    "💰 *PAGAMENTO*\n\n{payment_methods}\n\n🛡️ *Transações seguras*"
                ],
                'variables' => ['payment_methods']
            ],
            'complaint' => [
                'templates' => [
                    "😔 Lamento pelo inconveniente! Sua opinião é muito importante para nós.\n\n📞 *Vamos resolver isso juntos:*\n• Nossa equipe será notificada\n• Retornaremos em até 2 horas\n• Faremos o possível para resolver\n\n🙏 *Obrigado pela paciência!*",
                    "😟 Sinto muito pelo problema! Vamos resolver isso rapidamente.\n\n🔧 *Próximos passos:*\n• Equipe notificada\n• Retorno em até 2h\n• Solução garantida\n\n💙 *Obrigado por nos dar a chance de resolver!*"
                ],
                'variables' => []
            ],
            'compliment' => [
                'templates' => [
                    "😊 Muito obrigado! Ficamos felizes em saber que você gostou!",
                    "🙏 Obrigado pelo elogio! Isso nos motiva cada vez mais!",
                    "🥰 Que bom saber que estamos no caminho certo! Muito obrigado!",
                    "💖 Seu feedback é muito importante para nós! Obrigado!"
                ],
                'variables' => []
            ],
            'help' => [
                'templates' => [
                    "🆘 *COMO POSSO AJUDAR?*\n\n📋 *Cardápio:* Digite \"cardápio\"\n🍽️ *Fazer pedido:* Digite \"quero pedir\"\n📦 *Status do pedido:* Digite \"status do pedido\"\n🚚 *Entrega:* Digite \"entrega\"\n💳 *Pagamento:* Digite \"pagamento\"\n📞 *Falar com atendente:* Digite \"atendente\"\n\n💡 *Dica:* Seja específico na sua mensagem para melhor atendimento!",
                    "❓ *CENTRO DE AJUDA*\n\n🍽️ \"cardápio\" - Ver produtos\n🛒 \"quero pedir\" - Fazer pedido\n📋 \"status\" - Acompanhar pedido\n🚛 \"entrega\" - Informações de frete\n💳 \"pagamento\" - Formas de pagar\n👤 \"atendente\" - Falar com pessoa\n\n✨ *Dica:* Use comandos simples para melhor resultado!"
                ],
                'variables' => []
            ],
            'unknown' => [
                'templates' => [
                    "🤔 Não entendi bem sua mensagem. Que tal tentar:\n• \"Cardápio\"\n• \"Quero pedir\"\n• \"Ajuda\"",
                    "😅 Desculpe, não consegui entender. Posso ajudar com:\n• Fazer um pedido\n• Ver o cardápio\n• Informações de entrega",
                    "🤷‍♂️ Não entendi essa mensagem. Digite \"ajuda\" para ver todas as opções disponíveis!"
                ],
                'variables' => []
            ]
        ];
    }

    /**
     * Obter template para intenção
     */
    private function getTemplate(string $intent): ?array
    {
        return $this->responseTemplates[$intent] ?? null;
    }

    /**
     * Processar template com variáveis
     */
    private function processTemplate(array $template, array $context, array $data): string
    {
        $templates = $template['templates'];
        $selectedTemplate = $templates[array_rand($templates)];
        
        // Substituir variáveis
        $variables = $template['variables'];
        foreach ($variables as $variable) {
            $value = $this->getVariableValue($variable, $context, $data);
            $selectedTemplate = str_replace("{{$variable}}", $value, $selectedTemplate);
        }

        return $selectedTemplate;
    }

    /**
     * Obter valor da variável
     */
    private function getVariableValue(string $variable, array $context, array $data): string
    {
        switch ($variable) {
            case 'business_name':
                return $this->settings->business_name ?? 'Cardápio Digital Olika';
                
            case 'customer_name':
                return $context['customer_name'] ?? 'Cliente';
                
            case 'categories_list':
                return $this->generateCategoriesList();
                
            case 'product_name':
                return $data['product_name'] ?? '';
                
            case 'product_price':
                return number_format($data['product_price'] ?? 0, 2, ',', '.');
                
            case 'product_description':
                $description = $data['product_description'] ?? '';
                return $description ? "📝 *Descrição:* {$description}\n" : '';
                
            case 'product_ingredients':
                $ingredients = $data['product_ingredients'] ?? '';
                return $ingredients ? "🥘 *Ingredientes:* {$ingredients}\n" : '';
                
            case 'product_preparation_time':
                $time = $data['product_preparation_time'] ?? '';
                return $time ? "⏱️ *Tempo de preparo:* {$time} minutos\n" : '';
                
            case 'quantity':
                return $data['quantity'] ?? '1';
                
            case 'item_total':
                return number_format($data['item_total'] ?? 0, 2, ',', '.');
                
            case 'cart_total':
                return number_format($data['cart_total'] ?? 0, 2, ',', '.');
                
            case 'order_number':
                return $data['order_number'] ?? '';
                
            case 'order_total':
                return number_format($data['order_total'] ?? 0, 2, ',', '.');
                
            case 'delivery_date':
                return $data['delivery_date'] ?? '';
                
            case 'delivery_time':
                return $data['delivery_time'] ?? '';
                
            case 'payment_method':
                return $this->formatPaymentMethod($data['payment_method'] ?? '');
                
            case 'estimated_time':
                return $data['estimated_time'] ?? '30-60 minutos';
                
            case 'order_date':
                return $data['order_date'] ?? '';
                
            case 'order_status':
                return $this->formatOrderStatus($data['order_status'] ?? '');
                
            case 'delivery_radius':
                return $this->settings->delivery_radius ?? '10';
                
            case 'delivery_fees':
                return $this->generateDeliveryFeesList();
                
            case 'free_delivery_threshold':
                return number_format($this->settings->free_delivery_threshold ?? 50, 2, ',', '.');
                
            case 'delivery_time':
                return '30-60 minutos';
                
            case 'business_hours':
                return $this->settings->business_hours_monday ?? '08:00-18:00';
                
            case 'payment_methods':
                return $this->generatePaymentMethodsList();
                
            default:
                return $data[$variable] ?? $context[$variable] ?? '';
        }
    }

    /**
     * Gerar lista de categorias
     */
    private function generateCategoriesList(): string
    {
        $categories = Category::where('available', true)
            ->where('visible', true)
            ->orderBy('sort_order')
            ->limit(4)
            ->get();

        $list = '';
        foreach ($categories as $category) {
            $list .= "🍽️ *{$category->name}*\n";
            
            $products = Product::where('category_id', $category->id)
                ->where('available', true)
                ->where('visible', true)
                ->limit(2)
                ->get();

            foreach ($products as $product) {
                $price = number_format($product->price, 2, ',', '.');
                $list .= "• {$product->name} - R$ {$price}\n";
            }
            
            $list .= "\n";
        }

        return trim($list);
    }

    /**
     * Gerar lista de taxas de entrega
     */
    private function generateDeliveryFeesList(): string
    {
        $fees = [
            'Centro' => 'R$ 5,00',
            'Zona Sul' => 'R$ 8,00',
            'Zona Norte' => 'R$ 10,00',
            'Zona Oeste' => 'R$ 7,00'
        ];

        $list = '';
        foreach ($fees as $zone => $price) {
            $list .= "• {$zone}: {$price}\n";
        }

        return trim($list);
    }

    /**
     * Gerar lista de formas de pagamento
     */
    private function generatePaymentMethodsList(): string
    {
        $list = '';
        
        if ($this->settings->mercadopago_enabled ?? true) {
            $list .= "📱 *Mercado Pago:*\n";
            $list .= "• PIX\n";
            $list .= "• Cartão de crédito/débito\n";
            $list .= "• Boleto bancário\n\n";
        }
        
        if ($this->settings->whatsapp_payment_enabled ?? true) {
            $list .= "📲 *WhatsApp:*\n";
            $list .= "• Pix via WhatsApp\n";
            $list .= "• Transferência bancária\n\n";
        }
        
        $list .= "💰 *Dinheiro:* Aceito na entrega\n";

        return trim($list);
    }

    /**
     * Formatar método de pagamento
     */
    private function formatPaymentMethod(string $method): string
    {
        $methods = [
            'pix' => 'PIX',
            'credit_card' => 'Cartão de Crédito',
            'debit_card' => 'Cartão de Débito',
            'mercadopago' => 'Mercado Pago',
            'cash' => 'Dinheiro',
            'whatsapp' => 'WhatsApp'
        ];

        return $methods[$method] ?? ucfirst($method);
    }

    /**
     * Formatar status do pedido
     */
    private function formatOrderStatus(string $status): string
    {
        $statuses = [
            'pending' => '⏳ Aguardando confirmação',
            'confirmed' => '✅ Pedido confirmado',
            'preparing' => '👨‍🍳 Preparando seu pedido',
            'ready' => '🍽️ Pedido pronto para entrega',
            'delivering' => '🚚 Saiu para entrega',
            'completed' => '🎉 Pedido entregue',
            'cancelled' => '❌ Pedido cancelado'
        ];

        return $statuses[$status] ?? $status;
    }

    /**
     * Resposta de fallback
     */
    private function getFallbackResponse(): string
    {
        $responses = [
            "😔 Desculpe, estou com dificuldades técnicas no momento. Por favor, tente novamente em alguns instantes.",
            "🤖 Ops! Algo deu errado. Que tal tentar uma mensagem mais simples?",
            "😅 Desculpe, não consegui processar sua mensagem. Digite \"ajuda\" para ver as opções disponíveis."
        ];

        return $responses[array_rand($responses)];
    }

    /**
     * Gerar resposta de erro personalizada
     */
    public function generateErrorResponse(string $error, array $context = []): string
    {
        $errorResponses = [
            'product_not_found' => "😔 Produto não encontrado. Verifique o nome e tente novamente ou digite \"cardápio\" para ver nossas opções.",
            'cart_empty' => "🛒 Seu carrinho está vazio. Que tal adicionar alguns produtos? Digite \"cardápio\" para ver nossas opções.",
            'delivery_not_available' => "🚚 Infelizmente não entregamos nesta região. Entre em contato conosco para mais informações.",
            'payment_error' => "💳 Erro no processamento do pagamento. Tente novamente ou escolha outra forma de pagamento.",
            'order_error' => "❌ Erro ao processar seu pedido. Nossa equipe foi notificada e entrará em contato em breve."
        ];

        return $errorResponses[$error] ?? $this->getFallbackResponse();
    }

    /**
     * Gerar resposta de confirmação
     */
    public function generateConfirmationResponse(string $action, array $data = []): string
    {
        $confirmations = [
            'order_confirmed' => "✅ Pedido confirmado! Você receberá atualizações por aqui.",
            'payment_processed' => "💳 Pagamento processado com sucesso!",
            'delivery_scheduled' => "📅 Entrega agendada! Aguarde confirmação.",
            'customer_created' => "👤 Cliente cadastrado com sucesso!"
        ];

        return $confirmations[$action] ?? "✅ Ação realizada com sucesso!";
    }
}
