<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class OrderItem extends Model
{
    use HasFactory;

    protected $fillable = [
        'order_id',
        'product_id',
        'quantity',
        'price',
        'name',
        'description',
        'image',
    ];

    protected $casts = [
        'quantity' => 'integer',
        'price' => 'decimal:2',
    ];

    protected $dates = [
        'created_at',
        'updated_at',
    ];

    /**
     * Relacionamento com pedido
     */
    public function order(): BelongsTo
    {
        return $this->belongsTo(Order::class);
    }

    /**
     * Relacionamento com produto
     */
    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }

    /**
     * Calcular subtotal do item
     */
    public function getSubtotalAttribute(): float
    {
        return $this->price * $this->quantity;
    }

    /**
     * Obter subtotal formatado
     */
    public function getFormattedSubtotalAttribute(): string
    {
        return 'R$ ' . number_format($this->subtotal, 2, ',', '.');
    }

    /**
     * Obter preço formatado
     */
    public function getFormattedPriceAttribute(): string
    {
        return 'R$ ' . number_format($this->price, 2, ',', '.');
    }

    /**
     * Obter URL da imagem ou placeholder
     */
    public function getImageUrlAttribute(): string
    {
        if ($this->image && filter_var($this->image, FILTER_VALIDATE_URL)) {
            return $this->image;
        }

        if ($this->image && file_exists(public_path('storage/' . $this->image))) {
            return asset('storage/' . $this->image);
        }

        return 'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=800&q=80';
    }

    /**
     * Criar item do pedido a partir de produto
     */
    public static function fromProduct(Product $product, int $quantity): array
    {
        return [
            'product_id' => $product->id,
            'quantity' => $quantity,
            'price' => $product->price,
            'name' => $product->name,
            'description' => $product->description,
            'image' => $product->image,
        ];
    }

    /**
     * Criar múltiplos itens a partir de array de produtos
     */
    public static function fromProducts(array $products): array
    {
        $items = [];
        
        foreach ($products as $productData) {
            if (isset($productData['id']) && isset($productData['quantity'])) {
                $product = Product::find($productData['id']);
                if ($product) {
                    $items[] = self::fromProduct($product, $productData['quantity']);
                }
            }
        }

        return $items;
    }

    /**
     * Validar se produto ainda está disponível
     */
    public function isProductAvailable(): bool
    {
        if (!$this->product) {
            return false;
        }

        return $this->product->isAvailableForSale();
    }

    /**
     * Verificar se preço ainda está correto
     */
    public function isPriceCorrect(): bool
    {
        if (!$this->product) {
            return false;
        }

        return $this->price == $this->product->price;
    }

    /**
     * Atualizar preço do item se necessário
     */
    public function updatePriceIfNeeded(): void
    {
        if ($this->product && !$this->isPriceCorrect()) {
            $this->price = $this->product->price;
            $this->save();
        }
    }
}
