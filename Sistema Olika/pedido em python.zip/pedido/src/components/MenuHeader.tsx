import { ShoppingCart, Settings, Search } from "lucide-react";
import { Link } from "react-router-dom";
import { useMenu } from "@/contexts/MenuContext";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

export const MenuHeader = () => {
  const { cart, config } = useMenu();
  const cartItemsCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <header className="sticky top-0 z-50 bg-background border-b">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center text-primary-foreground font-bold text-xl">
              {config.businessName.charAt(0)}
            </div>
            <div>
              <h1 className="font-bold text-lg">{config.businessName}</h1>
              <span className={`text-xs font-medium ${config.isOpen ? "text-success" : "text-destructive"}`}>
                {config.isOpen ? "Aberto" : "Fechado"}
              </span>
            </div>
          </Link>

          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" asChild>
              <Link to="/search">
                <Search className="h-5 w-5" />
              </Link>
            </Button>

            <Button variant="ghost" size="icon" className="relative" asChild>
              <Link to="/cart">
                <ShoppingCart className="h-5 w-5" />
                {cartItemsCount > 0 && (
                  <Badge className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs">
                    {cartItemsCount}
                  </Badge>
                )}
              </Link>
            </Button>

            <Button variant="ghost" size="icon" asChild>
              <Link to="/settings">
                <Settings className="h-5 w-5" />
              </Link>
            </Button>
          </div>
        </div>

        {config.deliveryInfo && (
          <div className="pb-3 text-sm text-muted-foreground">
            {config.deliveryInfo}
          </div>
        )}
      </div>
    </header>
  );
};
