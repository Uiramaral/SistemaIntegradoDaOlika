<?php

namespace App\Services;

use App\Models\ConversaSuporte;
use App\Models\MensagemSuporte;
use App\Models\Customer;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Http;
use Carbon\Carbon;

class SuporteIAService
{
    private $openaiApiKey;
    private $openaiOrganization;
    private $openaiModel;
    private $openaiApiUrl;

    public function __construct()
    {
        $this->openaiApiKey = config('services.openai.api_key');
        $this->openaiOrganization = config('services.openai.organization');
        $this->openaiModel = config('services.openai.model', 'gpt-5-nano');
        $this->openaiApiUrl = 'https://api.openai.com/v1/chat/completions';
    }

    /**
     * Processar mensagem do suporte
     */
    public function processarMensagem(array $dados): array
    {
        try {
            $startTime = microtime(true);
            
            Log::info('🆕 Processando mensagem de suporte', $dados);

            // 1. Buscar ou criar conversa
            $conversa = $this->buscarOuCriarConversa($dados);
            
            // 2. Salvar mensagem do usuário
            $mensagemUsuario = MensagemSuporte::criarMensagemUsuario([
                'conversa_id' => $conversa->id,
                'subscriber_id' => $dados['subscriber_id'] ?? null,
                'conteudo' => $dados['mensagem'],
                'metadata' => [
                    'nome' => $dados['nome'],
                    'telefone' => $dados['telefone'],
                    'timestamp' => now()->toISOString(),
                ]
            ]);

            // 3. Analisar mensagem com IA
            $analise = $this->analisarMensagemComIA($dados['mensagem'], $conversa);
            
            // 4. Atualizar classificação da mensagem
            $mensagemUsuario->atualizarClassificacao($analise['classificacao']);
            $mensagemUsuario->marcarProcessada();

            // 5. Gerenciar histórico temporal
            $historico = $this->gerenciarHistoricoTemporal($conversa, $analise);
            
            // 6. Gerar resposta com IA
            $resposta = $this->gerarRespostaComIA($dados['mensagem'], $historico, $analise, $conversa);
            
            // 7. Salvar mensagem do assistant
            $mensagemAssistant = MensagemSuporte::criarMensagemAssistant([
                'conversa_id' => $conversa->id,
                'subscriber_id' => $dados['subscriber_id'] ?? null,
                'conteudo' => $resposta['conteudo'],
                'classificacao' => $analise['classificacao'],
                'tokens_prompt' => $resposta['tokens_prompt'],
                'tokens_completion' => $resposta['tokens_completion'],
                'tokens_total' => $resposta['tokens_total'],
                'model_usado' => $this->openaiModel,
                'custo_estimado' => $resposta['custo_estimado'],
                'metadata' => [
                    'historico_usado' => count($historico),
                    'estrategia_historico' => $resposta['estrategia_historico'],
                    'processing_time_ms' => round((microtime(true) - $startTime) * 1000),
                ]
            ]);

            // 8. Atualizar conversa
            $conversa->update([
                'assunto' => $analise['classificacao']['assunto'] ?? $conversa->assunto,
                'updated_at' => now(),
            ]);

            $processingTime = round((microtime(true) - $startTime) * 1000);

            Log::info('✅ Mensagem processada com sucesso', [
                'conversa_id' => $conversa->id,
                'tokens_usados' => $resposta['tokens_total'],
                'custo' => $resposta['custo_estimado'],
                'tempo_processamento' => $processingTime . 'ms'
            ]);

            return [
                'success' => true,
                'conversa_id' => $conversa->id,
                'resposta' => $resposta['conteudo'],
                'assunto' => $analise['classificacao']['assunto'] ?? null,
                'intencao' => $analise['classificacao']['intencao'] ?? null,
                'tokens_usados' => $resposta['tokens_total'],
                'custo_estimado' => $resposta['custo_estimado'],
                'processing_time_ms' => $processingTime,
                'estrategia_historico' => $resposta['estrategia_historico'],
            ];

        } catch (\Exception $e) {
            Log::error('❌ Erro no processamento de suporte IA', [
                'dados' => $dados,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);

            return [
                'success' => false,
                'error' => 'Erro interno do servidor',
                'message' => 'Desculpe, ocorreu um erro. Tente novamente em alguns instantes.'
            ];
        }
    }

    /**
     * Buscar ou criar conversa
     */
    private function buscarOuCriarConversa(array $dados): ConversaSuporte
    {
        // 1. Buscar conversa ativa por subscriber_id
        if (!empty($dados['subscriber_id'])) {
            $conversa = ConversaSuporte::buscarAtivaPorSubscriber($dados['subscriber_id']);
            if ($conversa) {
                Log::info('📝 Continuando conversa existente por subscriber_id', [
                    'conversa_id' => $conversa->id,
                    'subscriber_id' => $dados['subscriber_id']
                ]);
                return $conversa;
            }
        }

        // 2. Buscar conversa ativa por telefone
        $conversa = ConversaSuporte::buscarAtivaPorTelefone($dados['telefone']);
        if ($conversa) {
            // Atualizar subscriber_id se necessário
            if (!empty($dados['subscriber_id'])) {
                $conversa->atualizarSubscriberId($dados['subscriber_id']);
            }
            
            Log::info('📝 Continuando conversa existente por telefone', [
                'conversa_id' => $conversa->id,
                'telefone' => $dados['telefone']
            ]);
            return $conversa;
        }

        // 3. Buscar cliente existente
        $cliente = Customer::where('phone', $dados['telefone'])->first();

        // 4. Criar nova conversa
        $conversa = ConversaSuporte::criarConversa([
            'cliente_id' => $cliente?->id,
            'subscriber_id' => $dados['subscriber_id'] ?? null,
            'telefone' => $dados['telefone'],
            'nome' => $dados['nome'],
            'metadata' => [
                'criada_via' => 'whatsapp',
                'primeira_mensagem' => $dados['mensagem'],
            ]
        ]);

        Log::info('🆕 Nova conversa criada', [
            'conversa_id' => $conversa->id,
            'telefone' => $dados['telefone'],
            'subscriber_id' => $dados['subscriber_id'] ?? null
        ]);

        return $conversa;
    }

    /**
     * Analisar mensagem com IA
     */
    private function analisarMensagemComIA(string $mensagem, ConversaSuporte $conversa): array
    {
        $prompt = $this->criarPromptAnalise($mensagem, $conversa);

        $response = $this->chamarOpenAI($prompt, 0.1); // Temperatura baixa para análise

        $classificacao = json_decode($response['content'], true);
        
        if (!$classificacao) {
            $classificacao = [
                'intencao' => 'outros',
                'sentimento' => 'neutro',
                'urgencia' => 'baixa',
                'assunto' => 'geral',
                'confianca' => 0.5
            ];
        }

        return [
            'classificacao' => $classificacao,
            'tokens_prompt' => $response['tokens_prompt'],
            'tokens_completion' => $response['tokens_completion'],
            'tokens_total' => $response['tokens_total'],
            'custo_estimado' => $response['custo_estimado'],
        ];
    }

    /**
     * Gerenciar histórico temporal
     */
    private function gerenciarHistoricoTemporal(ConversaSuporte $conversa, array $analise): array
    {
        $diasDesdeUltima = $conversa->getDiasDesdeUltimaMensagem();
        $totalMensagens = $conversa->getTotalMensagens();

        Log::info('📊 Analisando histórico temporal', [
            'conversa_id' => $conversa->id,
            'dias_desde_ultima' => $diasDesdeUltima,
            'total_mensagens' => $totalMensagens
        ]);

        // Regras temporais
        if ($diasDesdeUltima >= 2) {
            Log::info('🆕 Nova conversa do dia - sem histórico');
            return [];
        } elseif ($diasDesdeUltima == 1) {
            Log::info('📝 Continuando conversa de ontem - usando histórico com resumo');
            return $this->aplicarHistoricoInteligente($conversa, $analise);
        } elseif ($diasDesdeUltima == 0) {
            Log::info('📝 Continuando conversa de hoje - usando histórico normal');
            return $this->aplicarHistoricoInteligente($conversa, $analise);
        }

        return [];
    }

    /**
     * Aplicar histórico inteligente
     */
    private function aplicarHistoricoInteligente(ConversaSuporte $conversa, array $analise): array
    {
        $totalMensagens = $conversa->getTotalMensagens();

        if ($totalMensagens <= 5) {
            // Conversa curta - usar todas as mensagens
            Log::info('📝 Usando todas as mensagens (conversa curta)');
            return $this->obterTodasMensagens($conversa);
        } elseif ($totalMensagens <= 15) {
            // Conversa média - usar últimas 8 mensagens
            Log::info('📝 Usando últimas 8 mensagens (conversa média)');
            return $this->obterUltimasMensagens($conversa, 8);
        } else {
            // Conversa longa - resumo + últimas 3 mensagens
            Log::info('📝 Usando resumo + últimas 3 mensagens (conversa longa)');
            return $this->usarResumoComUltimas($conversa, $analise);
        }
    }

    /**
     * Obter todas as mensagens
     */
    private function obterTodasMensagens(ConversaSuporte $conversa): array
    {
        return $conversa->mensagens()
            ->orderBy('created_at', 'asc')
            ->get()
            ->map(function ($msg) {
                return [
                    'role' => $msg->role,
                    'content' => $msg->conteudo,
                    'timestamp' => $msg->created_at->toISOString(),
                ];
            })
            ->toArray();
    }

    /**
     * Obter últimas mensagens
     */
    private function obterUltimasMensagens(ConversaSuporte $conversa, int $limit): array
    {
        return $conversa->mensagens()
            ->orderBy('created_at', 'desc')
            ->limit($limit)
            ->get()
            ->reverse()
            ->map(function ($msg) {
                return [
                    'role' => $msg->role,
                    'content' => $msg->conteudo,
                    'timestamp' => $msg->created_at->toISOString(),
                ];
            })
            ->toArray();
    }

    /**
     * Usar resumo com últimas mensagens
     */
    private function usarResumoComUltimas(ConversaSuporte $conversa, array $analise): array
    {
        // Separar mensagens antigas (excluir últimas 3)
        $mensagensAntigas = $conversa->mensagens()
            ->orderBy('created_at', 'asc')
            ->skip(3)
            ->get();

        $ultimasMensagens = $conversa->mensagens()
            ->orderBy('created_at', 'desc')
            ->limit(3)
            ->get()
            ->reverse();

        // Gerar resumo das mensagens antigas
        $resumo = $this->gerarResumoMensagens($mensagensAntigas, $analise);

        // Combinar resumo + últimas mensagens
        $historico = [];
        
        if ($resumo) {
            $historico[] = [
                'role' => 'system',
                'content' => "Resumo da conversa anterior: {$resumo}",
            ];
        }

        foreach ($ultimasMensagens as $msg) {
            $historico[] = [
                'role' => $msg->role,
                'content' => $msg->conteudo,
                'timestamp' => $msg->created_at->toISOString(),
            ];
        }

        Log::info('📝 Usando resumo + últimas mensagens', [
            'resumo_tokens' => strlen($resumo),
            'ultimas_mensagens' => $ultimasMensagens->count(),
            'total_historico' => count($historico)
        ]);

        return $historico;
    }

    /**
     * Gerar resumo de mensagens
     */
    private function gerarResumoMensagens($mensagens, array $analise): string
    {
        if ($mensagens->isEmpty()) {
            return '';
        }

        $assunto = $analise['classificacao']['assunto'] ?? 'geral';
        $prompt = $this->criarPromptResumo($mensagens, $assunto);

        $response = $this->chamarOpenAI($prompt, 0.3);
        
        return $response['content'] ?? '';
    }

    /**
     * Gerar resposta com IA
     */
    private function gerarRespostaComIA(string $mensagem, array $historico, array $analise, ConversaSuporte $conversa): array
    {
        $prompt = $this->criarPromptResposta($mensagem, $historico, $analise, $conversa);
        
        $response = $this->chamarOpenAI($prompt, 0.7);

        return [
            'conteudo' => $response['content'],
            'tokens_prompt' => $response['tokens_prompt'],
            'tokens_completion' => $response['tokens_completion'],
            'tokens_total' => $response['tokens_total'],
            'custo_estimado' => $response['custo_estimado'],
            'estrategia_historico' => $this->determinarEstrategiaHistorico($historico),
        ];
    }

    /**
     * Chamar API do OpenAI
     */
    private function chamarOpenAI(array $messages, float $temperature = 0.7): array
    {
        $response = Http::withHeaders([
            'Authorization' => 'Bearer ' . $this->openaiApiKey,
            'Content-Type' => 'application/json',
            'OpenAI-Organization' => $this->openaiOrganization,
        ])->post($this->openaiApiUrl, [
            'model' => $this->openaiModel,
            'messages' => $messages,
            'temperature' => $temperature,
            'max_tokens' => 1000,
        ]);

        if (!$response->successful()) {
            throw new \Exception('Erro na API OpenAI: ' . $response->body());
        }

        $data = $response->json();
        $usage = $data['usage'];

        // Calcular custo estimado (preços aproximados do GPT-4)
        $custoPorToken = 0.00003; // $0.03 por 1K tokens
        $custoEstimado = ($usage['total_tokens'] * $custoPorToken) / 1000;

        return [
            'content' => $data['choices'][0]['message']['content'],
            'tokens_prompt' => $usage['prompt_tokens'],
            'tokens_completion' => $usage['completion_tokens'],
            'tokens_total' => $usage['total_tokens'],
            'custo_estimado' => $custoEstimado,
        ];
    }

    /**
     * Criar prompt para análise
     */
    private function criarPromptAnalise(string $mensagem, ConversaSuporte $conversa): array
    {
        return [
            [
                'role' => 'system',
                'content' => 'Você é um assistente especializado em análise de mensagens de suporte. Analise a mensagem e retorne um JSON com: intencao, sentimento, urgencia, assunto, confianca. Intenções: duvida_produto, suporte_tecnico, reclamacao, elogio, cancelamento, renovacao, pagamento, outros. Sentimentos: positivo, neutro, negativo. Urgência: baixa, media, alta. Assuntos: duvida_produto, suporte_tecnico, reclamacao, elogio, cancelamento, renovacao, pagamento, geral.'
            ],
            [
                'role' => 'user',
                'content' => "Analise esta mensagem: \"{$mensagem}\""
            ]
        ];
    }

    /**
     * Criar prompt para resumo
     */
    private function criarPromptResumo($mensagens, string $assunto): array
    {
        $conteudo = $mensagens->map(function ($msg) {
            return "[{$msg->role}] {$msg->conteudo}";
        })->join("\n");

        $prompts = [
            'duvida_produto' => 'Resuma as dúvidas sobre produtos mencionadas nesta conversa, focando nos produtos específicos e perguntas feitas.',
            'suporte_tecnico' => 'Resuma os problemas técnicos relatados, incluindo sintomas e tentativas de solução.',
            'reclamacao' => 'Resuma as reclamações apresentadas, incluindo problemas específicos e expectativas do cliente.',
            'elogio' => 'Resuma os elogios e feedback positivo recebido.',
            'cancelamento' => 'Resuma as solicitações de cancelamento e motivos apresentados.',
            'renovacao' => 'Resuma as questões sobre renovação e continuidade do serviço.',
            'pagamento' => 'Resuma os problemas de pagamento e questões financeiras.',
            'geral' => 'Resuma os principais pontos desta conversa de forma concisa.'
        ];

        $instrucao = $prompts[$assunto] ?? $prompts['geral'];

        return [
            [
                'role' => 'system',
                'content' => "Você é um assistente especializado em resumir conversas de suporte. {$instrucao} Mantenha o resumo conciso e focado nos pontos principais."
            ],
            [
                'role' => 'user',
                'content' => "Resuma esta conversa:\n\n{$conteudo}"
            ]
        ];
    }

    /**
     * Criar prompt para resposta
     */
    private function criarPromptResposta(string $mensagem, array $historico, array $analise, ConversaSuporte $conversa): array
    {
        $messages = [
            [
                'role' => 'system',
                'content' => 'Você é um assistente de suporte especializado em cardápio digital. Seja prestativo, amigável e profissional. Responda em português brasileiro. Se não souber algo, seja honesto e ofereça alternativas.'
            ]
        ];

        // Adicionar histórico se existir
        foreach ($historico as $msg) {
            $messages[] = $msg;
        }

        // Adicionar mensagem atual
        $messages[] = [
            'role' => 'user',
            'content' => $mensagem
        ];

        return $messages;
    }

    /**
     * Determinar estratégia de histórico
     */
    private function determinarEstrategiaHistorico(array $historico): string
    {
        if (empty($historico)) {
            return 'sem_historico';
        }

        $hasResumo = collect($historico)->contains('role', 'system');
        
        if ($hasResumo) {
            return 'resumo_com_ultimas';
        }

        return count($historico) <= 5 ? 'todas_mensagens' : 'ultimas_mensagens';
    }

    /**
     * Obter estatísticas do sistema
     */
    public function obterEstatisticas(): array
    {
        $hoje = Carbon::today();
        $ontem = Carbon::yesterday();

        $conversasHoje = ConversaSuporte::whereDate('created_at', $hoje)->count();
        $conversasOntem = ConversaSuporte::whereDate('created_at', $ontem)->count();
        $conversasAtivas = ConversaSuporte::ativas()->count();

        $mensagensHoje = MensagemSuporte::whereDate('created_at', $hoje)->count();
        $tokensHoje = MensagemSuporte::whereDate('created_at', $hoje)->sum('tokens_total');
        $custoHoje = MensagemSuporte::whereDate('created_at', $hoje)->sum('custo_estimado');

        return [
            'conversas' => [
                'hoje' => $conversasHoje,
                'ontem' => $conversasOntem,
                'ativas' => $conversasAtivas,
                'total' => ConversaSuporte::count(),
            ],
            'mensagens' => [
                'hoje' => $mensagensHoje,
                'total' => MensagemSuporte::count(),
            ],
            'tokens' => [
                'hoje' => $tokensHoje,
                'total' => MensagemSuporte::sum('tokens_total'),
            ],
            'custos' => [
                'hoje' => round($custoHoje, 4),
                'total' => round(MensagemSuporte::sum('custo_estimado'), 4),
            ],
            'performance' => [
                'tempo_medio_resposta' => MensagemSuporte::assistant()
                    ->whereNotNull('metadata->processing_time_ms')
                    ->avg('metadata->processing_time_ms'),
                'taxa_sucesso' => MensagemSuporte::assistant()
                    ->where('tokens_total', '>', 0)
                    ->count() / max(MensagemSuporte::count(), 1) * 100,
            ]
        ];
    }
}
