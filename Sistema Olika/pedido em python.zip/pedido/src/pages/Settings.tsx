import { useState } from "react";
import { ArrowLeft, Plus, Trash2, Edit, Tag } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useMenu } from "@/contexts/MenuContext";
import { toast } from "sonner";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Product, Category, Coupon } from "@/types/menu";

interface SettingsProps {
  isDashboard?: boolean;
}

const Settings = ({ isDashboard = false }: SettingsProps) => {
  const { 
    config, 
    updateConfig, 
    products, 
    addProduct, 
    updateProduct, 
    deleteProduct, 
    categories, 
    addCategory, 
    deleteCategory,
    coupons,
    addCoupon,
    updateCoupon,
    deleteCoupon
  } = useMenu();
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [productDialogOpen, setProductDialogOpen] = useState(false);
  const [editingCoupon, setEditingCoupon] = useState<Coupon | null>(null);
  const [couponDialogOpen, setCouponDialogOpen] = useState(false);
  const [newCategory, setNewCategory] = useState("");

  const handleSaveConfig = (field: string, value: any) => {
    updateConfig({ [field]: value });
    toast.success("Configuração salva");
  };

  const handleProductSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    const product: Product = {
      id: editingProduct?.id || Date.now().toString(),
      name: formData.get("name") as string,
      description: formData.get("description") as string,
      price: parseFloat(formData.get("price") as string),
      image: formData.get("image") as string,
      category: formData.get("category") as string,
      available: true,
    };

    if (editingProduct) {
      updateProduct(product);
      toast.success("Produto atualizado");
    } else {
      addProduct(product);
      toast.success("Produto adicionado");
    }

    setProductDialogOpen(false);
    setEditingProduct(null);
  };

  const handleAddCategory = () => {
    if (!newCategory.trim()) return;
    
    const category: Category = {
      id: newCategory.toLowerCase().replace(/\s+/g, "-"),
      name: newCategory,
    };
    
    addCategory(category);
    setNewCategory("");
    toast.success("Categoria adicionada");
  };

  const handleCouponSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    const coupon: Coupon = {
      id: editingCoupon?.id || Date.now().toString(),
      code: (formData.get("code") as string).toUpperCase(),
      description: formData.get("description") as string,
      discountType: formData.get("discountType") as "percentage" | "fixed",
      discountValue: parseFloat(formData.get("discountValue") as string),
      isPublic: formData.get("isPublic") === "on",
      firstPurchaseOnly: formData.get("firstPurchaseOnly") === "on",
      minPurchaseValue: formData.get("minPurchaseValue") ? parseFloat(formData.get("minPurchaseValue") as string) : undefined,
      active: true,
    };

    if (editingCoupon) {
      updateCoupon(coupon);
      toast.success("Cupom atualizado");
    } else {
      addCoupon(coupon);
      toast.success("Cupom adicionado");
    }

    setCouponDialogOpen(false);
    setEditingCoupon(null);
  };

  return (
    <div className={isDashboard ? "" : "min-h-screen bg-background pb-8"}>
      {!isDashboard && (
        <header className="sticky top-0 z-50 bg-background border-b">
          <div className="container mx-auto px-4">
            <div className="flex items-center gap-4 h-16">
              <Button variant="ghost" size="icon" asChild>
                <Link to="/">
                  <ArrowLeft className="h-5 w-5" />
                </Link>
              </Button>
              <h1 className="text-xl font-bold">Configurações</h1>
            </div>
          </div>
        </header>
      )}

      <main className={isDashboard ? "" : "container mx-auto px-4 py-6 max-w-4xl"}>
        <Tabs defaultValue="general" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="general">Geral</TabsTrigger>
            <TabsTrigger value="products">Produtos</TabsTrigger>
            <TabsTrigger value="categories">Categorias</TabsTrigger>
            <TabsTrigger value="coupons">Cupons</TabsTrigger>
          </TabsList>

          <TabsContent value="general" className="space-y-4 mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Informações do Negócio</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="businessName">Nome do Negócio</Label>
                  <Input
                    id="businessName"
                    value={config.businessName}
                    onChange={(e) => handleSaveConfig("businessName", e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description">Descrição</Label>
                  <Textarea
                    id="description"
                    value={config.description || ""}
                    onChange={(e) => handleSaveConfig("description", e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">Telefone (WhatsApp)</Label>
                  <Input
                    id="phone"
                    value={config.phone || ""}
                    onChange={(e) => handleSaveConfig("phone", e.target.value)}
                    placeholder="(11) 99999-9999"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="deliveryInfo">Informações de Entrega</Label>
                  <Input
                    id="deliveryInfo"
                    value={config.deliveryInfo || ""}
                    onChange={(e) => handleSaveConfig("deliveryInfo", e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="minDeliveryValue">Valor Mínimo de Entrega (R$)</Label>
                  <Input
                    id="minDeliveryValue"
                    type="number"
                    step="0.01"
                    value={config.minDeliveryValue || ""}
                    onChange={(e) => handleSaveConfig("minDeliveryValue", parseFloat(e.target.value))}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="mercadoPagoAccessToken">Token de Acesso Mercado Pago</Label>
                  <Input
                    id="mercadoPagoAccessToken"
                    type="password"
                    value={config.mercadoPagoAccessToken || ""}
                    onChange={(e) => handleSaveConfig("mercadoPagoAccessToken", e.target.value)}
                    placeholder="APP_USR-..."
                  />
                  <p className="text-xs text-muted-foreground">
                    Configure seu token do Mercado Pago para aceitar pagamentos online
                  </p>
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="isOpen">Aberto para pedidos</Label>
                  <Switch
                    id="isOpen"
                    checked={config.isOpen}
                    onCheckedChange={(checked) => handleSaveConfig("isOpen", checked)}
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="products" className="space-y-4 mt-6">
            <div className="flex justify-between items-center">
              <h2 className="text-lg font-semibold">Gerenciar Produtos</h2>
              <Button
                onClick={() => {
                  setEditingProduct(null);
                  setProductDialogOpen(true);
                }}
              >
                <Plus className="h-4 w-4 mr-2" />
                Novo Produto
              </Button>
            </div>

            <div className="grid gap-4">
              {products.map((product) => (
                <Card key={product.id}>
                  <CardContent className="p-4">
                    <div className="flex gap-4">
                      <div className="w-20 h-20 rounded-lg overflow-hidden bg-muted shrink-0">
                        <img
                          src={product.image}
                          alt={product.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold">{product.name}</h3>
                        <p className="text-sm text-muted-foreground line-clamp-1">
                          {product.description}
                        </p>
                        <p className="text-sm font-bold text-primary mt-1">
                          R$ {product.price.toFixed(2).replace(".", ",")}
                        </p>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => {
                            setEditingProduct(product);
                            setProductDialogOpen(true);
                          }}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          size="icon"
                          variant="ghost"
                          className="text-destructive"
                          onClick={() => {
                            deleteProduct(product.id);
                            toast.success("Produto removido");
                          }}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="categories" className="space-y-4 mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Adicionar Categoria</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex gap-2">
                  <Input
                    placeholder="Nome da categoria"
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value)}
                  />
                  <Button onClick={handleAddCategory}>
                    <Plus className="h-4 w-4 mr-2" />
                    Adicionar
                  </Button>
                </div>
              </CardContent>
            </Card>

            <div className="grid gap-2">
              {categories.map((category) => (
                <Card key={category.id}>
                  <CardContent className="p-4 flex items-center justify-between">
                    <span className="font-medium">{category.name}</span>
                    <Button
                      size="icon"
                      variant="ghost"
                      className="text-destructive"
                      onClick={() => {
                        deleteCategory(category.id);
                        toast.success("Categoria removida");
                      }}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="coupons" className="space-y-4 mt-6">
            <div className="flex justify-between items-center">
              <h2 className="text-lg font-semibold">Gerenciar Cupons</h2>
              <Button
                onClick={() => {
                  setEditingCoupon(null);
                  setCouponDialogOpen(true);
                }}
              >
                <Plus className="h-4 w-4 mr-2" />
                Novo Cupom
              </Button>
            </div>

            <div className="grid gap-4">
              {coupons.map((coupon) => (
                <Card key={coupon.id}>
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <Tag className="h-4 w-4 text-primary" />
                          <h3 className="font-bold text-lg">{coupon.code}</h3>
                          {coupon.isPublic && (
                            <Badge variant="secondary">Público</Badge>
                          )}
                          {coupon.firstPurchaseOnly && (
                            <Badge variant="outline">1ª Compra</Badge>
                          )}
                          {!coupon.active && (
                            <Badge variant="destructive">Inativo</Badge>
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground mb-1">
                          {coupon.description}
                        </p>
                        <p className="text-sm font-semibold text-primary">
                          {coupon.discountType === 'percentage' 
                            ? `${coupon.discountValue}% de desconto` 
                            : `R$ ${coupon.discountValue.toFixed(2)} de desconto`
                          }
                        </p>
                        {coupon.minPurchaseValue && (
                          <p className="text-xs text-muted-foreground mt-1">
                            Mínimo: R$ {coupon.minPurchaseValue.toFixed(2)}
                          </p>
                        )}
                      </div>
                      <div className="flex gap-2">
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => {
                            setEditingCoupon(coupon);
                            setCouponDialogOpen(true);
                          }}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          size="icon"
                          variant="ghost"
                          className="text-destructive"
                          onClick={() => {
                            deleteCoupon(coupon.id);
                            toast.success("Cupom removido");
                          }}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </main>

      <Dialog open={productDialogOpen} onOpenChange={setProductDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>{editingProduct ? "Editar" : "Novo"} Produto</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleProductSubmit}>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Nome</Label>
                <Input
                  id="name"
                  name="name"
                  required
                  defaultValue={editingProduct?.name}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Descrição</Label>
                <Textarea
                  id="description"
                  name="description"
                  required
                  defaultValue={editingProduct?.description}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="price">Preço (R$)</Label>
                <Input
                  id="price"
                  name="price"
                  type="number"
                  step="0.01"
                  required
                  defaultValue={editingProduct?.price}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="image">URL da Imagem</Label>
                <Input
                  id="image"
                  name="image"
                  type="url"
                  required
                  defaultValue={editingProduct?.image}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="category">Categoria</Label>
                <select
                  id="category"
                  name="category"
                  className="w-full h-10 px-3 rounded-md border border-input bg-background"
                  required
                  defaultValue={editingProduct?.category}
                >
                  {categories.map((cat) => (
                    <option key={cat.id} value={cat.id}>
                      {cat.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            <DialogFooter className="mt-6">
              <Button type="button" variant="outline" onClick={() => setProductDialogOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit">Salvar</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={couponDialogOpen} onOpenChange={setCouponDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>{editingCoupon ? "Editar" : "Novo"} Cupom</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleCouponSubmit}>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="code">Código do Cupom</Label>
                <Input
                  id="code"
                  name="code"
                  required
                  placeholder="DESCONTO10"
                  defaultValue={editingCoupon?.code}
                  className="uppercase"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Descrição</Label>
                <Textarea
                  id="description"
                  name="description"
                  required
                  placeholder="10% de desconto na primeira compra"
                  defaultValue={editingCoupon?.description}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="discountType">Tipo de Desconto</Label>
                <select
                  id="discountType"
                  name="discountType"
                  className="w-full h-10 px-3 rounded-md border border-input bg-background"
                  required
                  defaultValue={editingCoupon?.discountType || "percentage"}
                >
                  <option value="percentage">Porcentagem (%)</option>
                  <option value="fixed">Valor Fixo (R$)</option>
                </select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="discountValue">Valor do Desconto</Label>
                <Input
                  id="discountValue"
                  name="discountValue"
                  type="number"
                  step="0.01"
                  required
                  placeholder="10"
                  defaultValue={editingCoupon?.discountValue}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="minPurchaseValue">Valor Mínimo de Compra (R$)</Label>
                <Input
                  id="minPurchaseValue"
                  name="minPurchaseValue"
                  type="number"
                  step="0.01"
                  placeholder="Opcional"
                  defaultValue={editingCoupon?.minPurchaseValue}
                />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="isPublic">Cupom Público</Label>
                <Switch
                  id="isPublic"
                  name="isPublic"
                  defaultChecked={editingCoupon?.isPublic}
                />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="firstPurchaseOnly">Apenas 1ª Compra</Label>
                <Switch
                  id="firstPurchaseOnly"
                  name="firstPurchaseOnly"
                  defaultChecked={editingCoupon?.firstPurchaseOnly}
                />
              </div>
            </div>
            <DialogFooter className="mt-6">
              <Button type="button" variant="outline" onClick={() => setCouponDialogOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit">Salvar</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Settings;
