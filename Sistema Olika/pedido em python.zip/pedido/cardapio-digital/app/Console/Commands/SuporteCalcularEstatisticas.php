<?php

namespace App\Console\Commands;

use App\Models\ConversaSuporte;
use App\Models\MensagemSuporte;
use Illuminate\Console\Command;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class SuporteCalcularEstatisticas extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'suporte:calcular-estatisticas {--periodo=hoje : Período para calcular (hoje, ontem, semana, mes)}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Calcula e exibe estatísticas do sistema de suporte IA';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $periodo = $this->option('periodo');
        
        $this->info("📊 Calculando estatísticas do sistema de suporte IA - Período: {$periodo}");
        $this->newLine();

        // Definir período
        $dataInicio = $this->obterDataInicio($periodo);
        $dataFim = Carbon::now();

        // Estatísticas gerais
        $this->exibirEstatisticasGerais($dataInicio, $dataFim);
        $this->newLine();

        // Estatísticas de conversas
        $this->exibirEstatisticasConversas($dataInicio, $dataFim);
        $this->newLine();

        // Estatísticas de tokens e custos
        $this->exibirEstatisticasTokens($dataInicio, $dataFim);
        $this->newLine();

        // Estatísticas de performance
        $this->exibirEstatisticasPerformance($dataInicio, $dataFim);
        $this->newLine();

        // Top assuntos
        $this->exibirTopAssuntos($dataInicio, $dataFim);
        $this->newLine();

        // Top intenções
        $this->exibirTopIntencoes($dataInicio, $dataFim);
    }

    private function obterDataInicio(string $periodo): Carbon
    {
        switch ($periodo) {
            case 'hoje':
                return Carbon::today();
            case 'ontem':
                return Carbon::yesterday();
            case 'semana':
                return Carbon::now()->subWeek();
            case 'mes':
                return Carbon::now()->subMonth();
            default:
                return Carbon::today();
        }
    }

    private function exibirEstatisticasGerais(Carbon $dataInicio, Carbon $dataFim): void
    {
        $this->info("📈 ESTATÍSTICAS GERAIS");
        $this->info("Período: {$dataInicio->format('d/m/Y H:i')} - {$dataFim->format('d/m/Y H:i')}");

        $conversas = ConversaSuporte::whereBetween('created_at', [$dataInicio, $dataFim])->count();
        $conversasAtivas = ConversaSuporte::whereBetween('created_at', [$dataInicio, $dataFim])
            ->where('status', 'ativa')
            ->count();
        
        $mensagens = MensagemSuporte::whereBetween('created_at', [$dataInicio, $dataFim])->count();
        $mensagensUsuario = MensagemSuporte::whereBetween('created_at', [$dataInicio, $dataFim])
            ->where('role', 'user')
            ->count();
        $mensagensAssistant = MensagemSuporte::whereBetween('created_at', [$dataInicio, $dataFim])
            ->where('role', 'assistant')
            ->count();

        $this->table(
            ['Métrica', 'Valor'],
            [
                ['Conversas criadas', $conversas],
                ['Conversas ativas', $conversasAtivas],
                ['Total de mensagens', $mensagens],
                ['Mensagens do usuário', $mensagensUsuario],
                ['Mensagens do assistant', $mensagensAssistant],
            ]
        );
    }

    private function exibirEstatisticasConversas(Carbon $dataInicio, Carbon $dataFim): void
    {
        $this->info("💬 ESTATÍSTICAS DE CONVERSAS");

        $conversasPorStatus = ConversaSuporte::whereBetween('created_at', [$dataInicio, $dataFim])
            ->selectRaw('status, COUNT(*) as total')
            ->groupBy('status')
            ->get()
            ->pluck('total', 'status')
            ->toArray();

        $conversasPorAssunto = ConversaSuporte::whereBetween('created_at', [$dataInicio, $dataFim])
            ->whereNotNull('assunto')
            ->selectRaw('assunto, COUNT(*) as total')
            ->groupBy('assunto')
            ->orderBy('total', 'desc')
            ->limit(5)
            ->get()
            ->pluck('total', 'assunto')
            ->toArray();

        $this->table(
            ['Status', 'Total'],
            collect($conversasPorStatus)->map(fn($total, $status) => [$status, $total])->toArray()
        );

        if (!empty($conversasPorAssunto)) {
            $this->newLine();
            $this->info("Top 5 Assuntos:");
            $this->table(
                ['Assunto', 'Total'],
                collect($conversasPorAssunto)->map(fn($total, $assunto) => [$assunto, $total])->toArray()
            );
        }
    }

    private function exibirEstatisticasTokens(Carbon $dataInicio, Carbon $dataFim): void
    {
        $this->info("💰 ESTATÍSTICAS DE TOKENS E CUSTOS");

        $tokens = MensagemSuporte::whereBetween('created_at', [$dataInicio, $dataFim])
            ->where('role', 'assistant')
            ->selectRaw('
                SUM(tokens_prompt) as total_prompt,
                SUM(tokens_completion) as total_completion,
                SUM(tokens_total) as total_tokens,
                SUM(custo_estimado) as custo_total,
                AVG(tokens_total) as media_tokens,
                AVG(custo_estimado) as media_custo
            ')
            ->first();

        $this->table(
            ['Métrica', 'Valor'],
            [
                ['Tokens Prompt', number_format($tokens->total_prompt ?? 0)],
                ['Tokens Completion', number_format($tokens->total_completion ?? 0)],
                ['Total de Tokens', number_format($tokens->total_tokens ?? 0)],
                ['Custo Total (USD)', '$' . number_format($tokens->custo_total ?? 0, 4)],
                ['Média Tokens/Mensagem', number_format($tokens->media_tokens ?? 0, 2)],
                ['Média Custo/Mensagem', '$' . number_format($tokens->media_custo ?? 0, 4)],
            ]
        );
    }

    private function exibirEstatisticasPerformance(Carbon $dataInicio, Carbon $dataFim): void
    {
        $this->info("⚡ ESTATÍSTICAS DE PERFORMANCE");

        $performance = MensagemSuporte::whereBetween('created_at', [$dataInicio, $dataFim])
            ->where('role', 'assistant')
            ->whereNotNull('classificacao')
            ->selectRaw('
                AVG(JSON_EXTRACT(classificacao, "$.confianca")) as media_confianca,
                COUNT(CASE WHEN JSON_EXTRACT(classificacao, "$.confianca") >= 0.8 THEN 1 END) as alta_confianca,
                COUNT(CASE WHEN JSON_EXTRACT(classificacao, "$.confianca") < 0.8 THEN 1 END) as baixa_confianca,
                COUNT(*) as total_mensagens
            ')
            ->first();

        $taxaSucesso = $performance->total_mensagens > 0 
            ? ($performance->alta_confianca / $performance->total_mensagens) * 100 
            : 0;

        $this->table(
            ['Métrica', 'Valor'],
            [
                ['Média de Confiança', number_format($performance->media_confianca ?? 0, 3)],
                ['Mensagens Alta Confiança', $performance->alta_confianca ?? 0],
                ['Mensagens Baixa Confiança', $performance->baixa_confianca ?? 0],
                ['Taxa de Sucesso', number_format($taxaSucesso, 2) . '%'],
            ]
        );
    }

    private function exibirTopAssuntos(Carbon $dataInicio, Carbon $dataFim): void
    {
        $this->info("📋 TOP 10 ASSUNTOS MAIS ABORDADOS");

        $assuntos = ConversaSuporte::whereBetween('created_at', [$dataInicio, $dataFim])
            ->whereNotNull('assunto')
            ->selectRaw('assunto, COUNT(*) as total')
            ->groupBy('assunto')
            ->orderBy('total', 'desc')
            ->limit(10)
            ->get();

        if ($assuntos->isEmpty()) {
            $this->warn('Nenhum assunto encontrado no período.');
            return;
        }

        $this->table(
            ['Posição', 'Assunto', 'Total'],
            $assuntos->map(function ($item, $index) {
                return [$index + 1, $item->assunto, $item->total];
            })->toArray()
        );
    }

    private function exibirTopIntencoes(Carbon $dataInicio, Carbon $dataFim): void
    {
        $this->info("🎯 TOP 10 INTENÇÕES MAIS RECONHECIDAS");

        $intencoes = MensagemSuporte::whereBetween('created_at', [$dataInicio, $dataFim])
            ->where('role', 'user')
            ->whereNotNull('classificacao')
            ->selectRaw('JSON_EXTRACT(classificacao, "$.intencao") as intencao, COUNT(*) as total')
            ->groupBy('intencao')
            ->orderBy('total', 'desc')
            ->limit(10)
            ->get();

        if ($intencoes->isEmpty()) {
            $this->warn('Nenhuma intenção encontrada no período.');
            return;
        }

        $this->table(
            ['Posição', 'Intenção', 'Total'],
            $intencoes->map(function ($item, $index) {
                return [$index + 1, $item->intencao, $item->total];
            })->toArray()
        );
    }
}
