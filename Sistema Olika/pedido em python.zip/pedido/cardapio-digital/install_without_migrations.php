<?php

/**
 * Script de Instalação sem Migrations
 * Cardápio Digital Olika
 */

echo "🚀 Instalando Cardápio Digital Olika...\n\n";

// Verificar se Laravel está configurado
if (!file_exists('.env')) {
    echo "❌ Arquivo .env não encontrado!\n";
    echo "📋 Copie o arquivo env.example para .env e configure:\n";
    echo "   cp env.example .env\n\n";
    exit(1);
}

// Verificar conexão com banco
try {
    $host = env('DB_HOST', '127.0.0.1');
    $port = env('DB_PORT', '3306');
    $database = env('DB_DATABASE', 'cardapio_digital');
    $username = env('DB_USERNAME', 'root');
    $password = env('DB_PASSWORD', '');
    
    echo "🔗 Testando conexão com banco de dados...\n";
    $pdo = new PDO("mysql:host=$host;port=$port;dbname=$database", $username, $password);
    echo "✅ Conexão com banco OK!\n\n";
    
} catch (PDOException $e) {
    echo "❌ Erro ao conectar com banco: " . $e->getMessage() . "\n";
    echo "📋 Verifique as configurações no arquivo .env\n\n";
    exit(1);
}

// Função para executar comandos artisan
function runArtisanCommand($command) {
    echo "⚙️  Executando: $command\n";
    $output = shell_exec("php artisan $command 2>&1");
    
    if (strpos($output, 'error') !== false || strpos($output, 'Error') !== false) {
        echo "⚠️  Aviso: $output\n";
    } else {
        echo "✅ Comando executado com sucesso!\n";
    }
    echo "\n";
}

// 1. Gerar chave da aplicação
echo "🔑 Gerando chave da aplicação...\n";
runArtisanCommand('key:generate');

// 2. Limpar cache de configuração
echo "🗄️  Limpando cache...\n";
runArtisanCommand('config:clear');
runArtisanCommand('cache:clear');
runArtisanCommand('route:clear');
runArtisanCommand('view:clear');

// 3. Configurar cache de produção
echo "⚡ Configurando cache de produção...\n";
runArtisanCommand('config:cache');
runArtisanCommand('route:cache');
runArtisanCommand('view:cache');

// 4. Criar link simbólico para storage
echo "🔗 Criando link simbólico para storage...\n";
runArtisanCommand('storage:link');

// 5. Verificar se banco tem dados
echo "🔍 Verificando estrutura do banco...\n";
try {
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM information_schema.tables WHERE table_schema = '$database'");
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($result['count'] == 0) {
        echo "❌ Banco de dados vazio!\n";
        echo "📋 Execute primeiro o script SQL:\n";
        echo "   mysql -u $username -p $database < database/cardapio_digital.sql\n\n";
        exit(1);
    } else {
        echo "✅ Banco de dados com $result[count] tabelas encontrado!\n";
    }
} catch (PDOException $e) {
    echo "❌ Erro ao verificar banco: " . $e->getMessage() . "\n";
    exit(1);
}

// 6. Verificar dados iniciais
echo "📊 Verificando dados iniciais...\n";
try {
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM categories");
    $categories = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
    
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM products");
    $products = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
    
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM settings");
    $settings = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
    
    echo "📈 Dados encontrados:\n";
    echo "   - Categorias: $categories\n";
    echo "   - Produtos: $products\n";
    echo "   - Configurações: $settings\n";
    
} catch (PDOException $e) {
    echo "⚠️  Erro ao verificar dados: " . $e->getMessage() . "\n";
}

// 7. Configurar permissões (apenas no Linux/Mac)
if (PHP_OS_FAMILY !== 'Windows') {
    echo "🔐 Configurando permissões...\n";
    exec('chmod -R 755 storage bootstrap/cache 2>/dev/null');
    echo "✅ Permissões configuradas!\n";
}

// 8. Verificar configuração final
echo "🔍 Verificando configuração final...\n";
runArtisanCommand('about');

echo "\n🎉 Instalação concluída com sucesso!\n\n";
echo "📋 Próximos passos:\n";
echo "1. Configure as integrações no arquivo .env:\n";
echo "   - MERCADOPAGO_ACCESS_TOKEN\n";
echo "   - WHATSAPP_API_URL\n";
echo "   - GOOGLE_MAPS_API_KEY\n\n";
echo "2. Execute o servidor:\n";
echo "   php artisan serve\n\n";
echo "3. Acesse:\n";
echo "   🌐 Frontend: http://localhost:8000\n";
echo "   🏢 Admin: http://localhost:8000/dashboard\n\n";
echo "📚 Documentação: INSTALACAO_BANCO.md\n";

// Função helper para ler variáveis do .env
function env($key, $default = null) {
    $envFile = file_get_contents('.env');
    $lines = explode("\n", $envFile);
    
    foreach ($lines as $line) {
        if (strpos($line, $key . '=') === 0) {
            return trim(substr($line, strlen($key) + 1));
        }
    }
    
    return $default;
}
