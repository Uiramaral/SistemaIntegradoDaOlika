<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Facades\Crypt;

class WhatsappSession extends Model
{
    use HasFactory;

    protected $fillable = [
        'loja_id',
        'phone',
        'adapter',
        'status',
        'instance_id',
        'auth_meta_json',
        'last_seen_at',
        'error_message',
    ];

    protected $casts = [
        'auth_meta_json' => 'array',
        'last_seen_at' => 'datetime',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    /**
     * Relacionamento com mensagens
     */
    public function messages(): HasMany
    {
        return $this->hasMany(WhatsappMessage::class, 'session_id');
    }

    /**
     * Criptografar auth_meta_json antes de salvar
     */
    public function setAuthMetaJsonAttribute($value)
    {
        if ($value) {
            $this->attributes['auth_meta_json'] = Crypt::encryptString(json_encode($value));
        }
    }

    /**
     * Descriptografar auth_meta_json ao recuperar
     */
    public function getAuthMetaJsonAttribute($value)
    {
        if ($value) {
            try {
                return json_decode(Crypt::decryptString($value), true);
            } catch (\Exception $e) {
                return null;
            }
        }
        return null;
    }

    /**
     * Verificar se a sessão está conectada
     */
    public function isConnected(): bool
    {
        return $this->status === 'connected';
    }

    /**
     * Verificar se a sessão está conectando
     */
    public function isConnecting(): bool
    {
        return $this->status === 'connecting';
    }

    /**
     * Verificar se a sessão está desconectada
     */
    public function isDisconnected(): bool
    {
        return $this->status === 'disconnected';
    }

    /**
     * Verificar se a sessão tem erro
     */
    public function hasError(): bool
    {
        return $this->status === 'error';
    }

    /**
     * Atualizar status da sessão
     */
    public function updateStatus(string $status, ?string $errorMessage = null): void
    {
        $this->update([
            'status' => $status,
            'error_message' => $errorMessage,
            'last_seen_at' => now(),
        ]);
    }

    /**
     * Scope para sessões conectadas
     */
    public function scopeConnected($query)
    {
        return $query->where('status', 'connected');
    }

    /**
     * Scope para um adapter específico
     */
    public function scopeAdapter($query, string $adapter)
    {
        return $query->where('adapter', $adapter);
    }

    /**
     * Scope para uma loja específica
     */
    public function scopeLoja($query, int $lojaId)
    {
        return $query->where('loja_id', $lojaId);
    }

    /**
     * Obter estatísticas da sessão
     */
    public function getStats(): array
    {
        $messages = $this->messages();
        
        return [
            'total_messages' => $messages->count(),
            'messages_in' => $messages->where('direction', 'IN')->count(),
            'messages_out' => $messages->where('direction', 'OUT')->count(),
            'last_message_at' => $messages->latest()->first()?->created_at,
            'success_rate' => $this->calculateSuccessRate(),
        ];
    }

    /**
     * Calcular taxa de sucesso das mensagens
     */
    private function calculateSuccessRate(): float
    {
        $total = $this->messages()->where('direction', 'OUT')->count();
        if ($total === 0) return 0.0;
        
        $successful = $this->messages()
            ->where('direction', 'OUT')
            ->whereIn('status', ['sent', 'delivered', 'read'])
            ->count();
            
        return round(($successful / $total) * 100, 2);
    }
}
