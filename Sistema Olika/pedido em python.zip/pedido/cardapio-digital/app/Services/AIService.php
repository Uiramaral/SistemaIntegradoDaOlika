<?php

namespace App\Services;

use App\Models\Product;
use App\Models\Category;
use App\Models\Customer;
use App\Models\Order;
use App\Models\Settings;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Cache;

class AIService
{
    private $intentRecognition;
    private $orderProcessor;
    private $responseGenerator;

    public function __construct()
    {
        $this->intentRecognition = new IntentRecognitionService();
        $this->orderProcessor = new AIOrderProcessor();
        $this->responseGenerator = new AIResponseGenerator();
    }

    /**
     * Processar mensagem do WhatsApp
     */
    public function processMessage(string $message, string $phone, array $context = []): array
    {
        try {
            // 1. Reconhecer intenção da mensagem
            $intent = $this->intentRecognition->recognize($message, $context);
            
            Log::info('IA - Intenção reconhecida', [
                'phone' => $phone,
                'message' => $message,
                'intent' => $intent
            ]);

            // 2. Processar baseado na intenção
            $response = $this->handleIntent($intent, $message, $phone, $context);

            return [
                'success' => true,
                'response' => $response['message'],
                'intent' => $intent,
                'actions' => $response['actions'] ?? [],
                'order_data' => $response['order_data'] ?? null,
                'context' => $response['context'] ?? []
            ];

        } catch (\Exception $e) {
            Log::error('Erro no processamento de IA', [
                'phone' => $phone,
                'message' => $message,
                'error' => $e->getMessage()
            ]);

            return [
                'success' => false,
                'response' => $this->getFallbackResponse(),
                'intent' => 'unknown',
                'actions' => [],
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * Processar intenção específica
     */
    private function handleIntent(array $intent, string $message, string $phone, array $context): array
    {
        switch ($intent['type']) {
            case 'greeting':
                return $this->handleGreeting($phone, $context);

            case 'menu_request':
                return $this->handleMenuRequest($intent, $context);

            case 'product_inquiry':
                return $this->handleProductInquiry($intent, $context);

            case 'order_start':
                return $this->handleOrderStart($phone, $context);

            case 'add_to_cart':
                return $this->handleAddToCart($intent, $phone, $context);

            case 'order_complete':
                return $this->handleOrderComplete($intent, $phone, $context);

            case 'order_status':
                return $this->handleOrderStatus($phone, $context);

            case 'delivery_info':
                return $this->handleDeliveryInfo($intent, $context);

            case 'payment_info':
                return $this->handlePaymentInfo($context);

            case 'complaint':
                return $this->handleComplaint($intent, $phone, $context);

            case 'compliment':
                return $this->handleCompliment($intent, $context);

            case 'help':
                return $this->handleHelp($context);

            default:
                return $this->handleUnknown($message, $context);
        }
    }

    /**
     * Lidar com cumprimentos
     */
    private function handleGreeting(string $phone, array $context): array
    {
        $customer = Customer::findByPhone($phone);
        $name = $customer ? $customer->name : 'Cliente';
        
        $greetings = [
            "Olá, $name! 👋 Bem-vindo ao Cardápio Digital Olika!",
            "Oi, $name! 😊 Como posso ajudar você hoje?",
            "Olá! $name, seja bem-vindo! 🎉",
        ];

        return [
            'message' => $greetings[array_rand($greetings)],
            'actions' => ['show_menu_options'],
            'context' => ['customer_identified' => $customer ? true : false]
        ];
    }

    /**
     * Lidar com solicitação de cardápio
     */
    private function handleMenuRequest(array $intent, array $context): array
    {
        $categories = Category::where('available', true)
            ->where('visible', true)
            ->orderBy('sort_order')
            ->get();

        $message = "📋 *NOSSO CARDÁPIO*\n\n";
        
        foreach ($categories as $category) {
            $message .= "🍽️ *{$category->name}*\n";
            
            $products = Product::where('category_id', $category->id)
                ->where('available', true)
                ->where('visible', true)
                ->limit(3)
                ->get();

            foreach ($products as $product) {
                $price = number_format($product->price, 2, ',', '.');
                $message .= "• {$product->name} - R$ {$price}\n";
            }
            
            $message .= "\n";
        }

        $message .= "💡 *Para fazer um pedido, digite:*\n";
        $message .= "• *\"Quero pedir\"* - Para começar um pedido\n";
        $message .= "• *\"Cardápio completo\"* - Ver todos os produtos\n";
        $message .= "• *\"Produto X\"* - Informações sobre um produto";

        return [
            'message' => $message,
            'actions' => ['show_full_menu'],
            'context' => ['categories_shown' => $categories->count()]
        ];
    }

    /**
     * Lidar com consulta de produto
     */
    private function handleProductInquiry(array $intent, array $context): array
    {
        $productName = $intent['entities']['product'] ?? '';
        
        $product = Product::where('name', 'like', "%{$productName}%")
            ->orWhere('description', 'like', "%{$productName}%")
            ->where('available', true)
            ->first();

        if (!$product) {
            return [
                'message' => "😔 Não encontrei o produto *{$productName}*. Que tal ver nosso cardápio completo?",
                'actions' => ['show_menu']
            ];
        }

        $price = number_format($product->price, 2, ',', '.');
        $message = "🍽️ *{$product->name}*\n\n";
        $message .= "💰 *Preço:* R$ {$price}\n";
        
        if ($product->description) {
            $message .= "📝 *Descrição:* {$product->description}\n";
        }
        
        if ($product->ingredients) {
            $message .= "🥘 *Ingredientes:* {$product->ingredients}\n";
        }
        
        if ($product->preparation_time) {
            $message .= "⏱️ *Tempo de preparo:* {$product->preparation_time} minutos\n";
        }

        $message .= "\n💡 *Para adicionar ao pedido, digite:*\n";
        $message .= "\"Quero {$product->name}\" ou \"Adicionar {$product->name}\"";

        return [
            'message' => $message,
            'actions' => ['add_to_cart', 'show_similar_products'],
            'context' => ['product_id' => $product->id]
        ];
    }

    /**
     * Lidar com início de pedido
     */
    private function handleOrderStart(string $phone, array $context): array
    {
        $customer = Customer::findByPhone($phone);
        
        if (!$customer) {
            return [
                'message' => "👋 Olá! Para fazer um pedido, preciso de algumas informações:\n\n" .
                           "📝 *Seu nome:* (digite seu nome completo)\n" .
                           "📱 *Seu telefone:* (já tenho: {$phone})\n" .
                           "🏠 *Endereço:* (CEP, rua, número, bairro)",
                'actions' => ['collect_customer_info'],
                'context' => ['order_started' => true, 'step' => 'collecting_info']
            ];
        }

        return [
            'message' => "🍽️ Ótimo, {$customer->name}! Vamos fazer seu pedido!\n\n" .
                        "📋 *Como funciona:*\n" .
                        "• Digite o nome do produto que deseja\n" .
                        "• Confirme a quantidade\n" .
                        "• Escolha a forma de pagamento\n\n" .
                        "💡 *Exemplo:* \"Quero 2 Prato do Dia\"",
            'actions' => ['start_order_session'],
            'context' => ['customer_id' => $customer->id, 'order_started' => true]
        ];
    }

    /**
     * Lidar com adição ao carrinho
     */
    private function handleAddToCart(array $intent, string $phone, array $context): array
    {
        $productName = $intent['entities']['product'] ?? '';
        $quantity = $intent['entities']['quantity'] ?? 1;

        $product = Product::where('name', 'like', "%{$productName}%")
            ->where('available', true)
            ->first();

        if (!$product) {
            return [
                'message' => "😔 Produto *{$productName}* não encontrado. Verifique o nome e tente novamente.",
                'actions' => ['show_similar_products']
            ];
        }

        // Processar adição ao carrinho via IA
        $result = $this->orderProcessor->addToCart($phone, $product->id, $quantity, $context);

        if ($result['success']) {
            $total = $result['cart_total'];
            $totalFormatted = number_format($total, 2, ',', '.');
            
            $message = "✅ *Adicionado ao pedido!*\n\n";
            $message .= "🍽️ *{$product->name}*\n";
            $message .= "📦 *Quantidade:* {$quantity}\n";
            $message .= "💰 *Valor:* R$ " . number_format($product->price * $quantity, 2, ',', '.') . "\n\n";
            $message .= "🛒 *Total do pedido:* R$ {$totalFormatted}\n\n";
            $message .= "💡 *Para continuar:*\n";
            $message .= "• Digite outro produto\n";
            $message .= "• \"Finalizar pedido\" - Para concluir\n";
            $message .= "• \"Ver pedido\" - Para revisar";

            return [
                'message' => $message,
                'actions' => ['continue_order', 'show_cart'],
                'context' => ['cart_updated' => true, 'cart_total' => $total]
            ];
        }

        return [
            'message' => "❌ Erro ao adicionar produto. Tente novamente ou entre em contato conosco.",
            'actions' => ['retry_add_to_cart']
        ];
    }

    /**
     * Lidar com finalização de pedido
     */
    private function handleOrderComplete(array $intent, string $phone, array $context): array
    {
        $result = $this->orderProcessor->completeOrder($phone, $intent, $context);

        if ($result['success']) {
            $order = $result['order'];
            $total = number_format($order->total, 2, ',', '.');
            
            $message = "🎉 *Pedido realizado com sucesso!*\n\n";
            $message .= "📋 *Pedido #{$order->order_number}*\n";
            $message .= "🛒 *Total:* R$ {$total}\n";
            $message .= "📅 *Entrega:* {$order->delivery_date} às {$order->delivery_time_slot}\n";
            $message .= "💳 *Pagamento:* " . ucfirst($order->payment_method) . "\n\n";
            $message .= "📱 *Acompanhe seu pedido:*\n";
            $message .= "• Status será enviado por aqui\n";
            $message .= "• Tempo estimado: " . ($order->delivery_fee > 0 ? '45-60 min' : '30-45 min') . "\n\n";
            $message .= "🙏 *Obrigado pela preferência!*";

            return [
                'message' => $message,
                'actions' => ['send_order_confirmation'],
                'order_data' => $order->toArray(),
                'context' => ['order_completed' => true, 'order_id' => $order->id]
            ];
        }

        return [
            'message' => "❌ Erro ao finalizar pedido: " . $result['message'],
            'actions' => ['retry_order_completion']
        ];
    }

    /**
     * Lidar com consulta de status do pedido
     */
    private function handleOrderStatus(string $phone, array $context): array
    {
        $customer = Customer::findByPhone($phone);
        
        if (!$customer) {
            return [
                'message' => "📱 Não encontrei pedidos para este número. Verifique o telefone ou faça um novo pedido."
            ];
        }

        $latestOrder = Order::where('customer_id', $customer->id)
            ->orderBy('created_at', 'desc')
            ->first();

        if (!$latestOrder) {
            return [
                'message' => "📋 Você ainda não fez nenhum pedido. Que tal conhecer nosso cardápio?",
                'actions' => ['show_menu']
            ];
        }

        $statusMessages = [
            'pending' => '⏳ Aguardando confirmação',
            'confirmed' => '✅ Pedido confirmado',
            'preparing' => '👨‍🍳 Preparando seu pedido',
            'ready' => '🍽️ Pedido pronto para entrega',
            'delivering' => '🚚 Saiu para entrega',
            'completed' => '🎉 Pedido entregue',
            'cancelled' => '❌ Pedido cancelado'
        ];

        $status = $statusMessages[$latestOrder->status] ?? $latestOrder->status;
        $total = number_format($latestOrder->total, 2, ',', '.');

        $message = "📋 *Último Pedido:*\n\n";
        $message .= "🆔 *Pedido #{$latestOrder->order_number}*\n";
        $message .= "📅 *Data:* " . $latestOrder->created_at->format('d/m/Y H:i') . "\n";
        $message .= "💰 *Total:* R$ {$total}\n";
        $message .= "📦 *Status:* {$status}\n";
        $message .= "🚚 *Entrega:* {$latestOrder->delivery_date} às {$latestOrder->delivery_time_slot}";

        return [
            'message' => $message,
            'actions' => ['show_order_details'],
            'context' => ['order_id' => $latestOrder->id]
        ];
    }

    /**
     * Lidar com informações de entrega
     */
    private function handleDeliveryInfo(array $intent, array $context): array
    {
        $settings = Settings::getSettings();
        
        $message = "🚚 *INFORMAÇÕES DE ENTREGA*\n\n";
        $message .= "📍 *Área de entrega:* " . ($settings->delivery_radius ?? 10) . "km\n";
        $message .= "💰 *Taxa de entrega:*\n";
        $message .= "• Centro: R$ 5,00\n";
        $message .= "• Zona Sul: R$ 8,00\n";
        $message .= "• Zona Norte: R$ 10,00\n";
        $message .= "• Zona Oeste: R$ 7,00\n\n";
        
        $freeDelivery = $settings->free_delivery_threshold ?? 50;
        $message .= "🎉 *Entrega grátis:* A partir de R$ " . number_format($freeDelivery, 2, ',', '.') . "\n\n";
        $message .= "⏱️ *Tempo de entrega:* 30-60 minutos\n";
        $message .= "📅 *Horário:* " . ($settings->business_hours_monday ?? '08:00-18:00');

        return [
            'message' => $message,
            'actions' => ['show_delivery_zones']
        ];
    }

    /**
     * Lidar com informações de pagamento
     */
    private function handlePaymentInfo(array $context): array
    {
        $settings = Settings::getSettings();
        
        $message = "💳 *FORMAS DE PAGAMENTO*\n\n";
        
        if ($settings->mercadopago_enabled ?? true) {
            $message .= "📱 *Mercado Pago:*\n";
            $message .= "• PIX\n";
            $message .= "• Cartão de crédito/débito\n";
            $message .= "• Boleto bancário\n\n";
        }
        
        if ($settings->whatsapp_payment_enabled ?? true) {
            $message .= "📲 *WhatsApp:*\n";
            $message .= "• Pix via WhatsApp\n";
            $message .= "• Transferência bancária\n\n";
        }
        
        $message .= "💰 *Dinheiro:* Aceito na entrega\n\n";
        $message .= "🔒 *Pagamento 100% seguro*";

        return [
            'message' => $message,
            'actions' => ['show_payment_methods']
        ];
    }

    /**
     * Lidar com reclamações
     */
    private function handleComplaint(array $intent, string $phone, array $context): array
    {
        $message = "😔 Lamento pelo inconveniente! Sua opinião é muito importante para nós.\n\n";
        $message .= "📞 *Vamos resolver isso juntos:*\n";
        $message .= "• Nossa equipe será notificada\n";
        $message .= "• Retornaremos em até 2 horas\n";
        $message .= "• Faremos o possível para resolver\n\n";
        $message .= "🙏 *Obrigado pela paciência!*";

        // TODO: Implementar sistema de tickets/reclamações
        Log::info('Reclamação recebida via IA', [
            'phone' => $phone,
            'complaint' => $intent['entities']['complaint'] ?? '',
            'context' => $context
        ]);

        return [
            'message' => $message,
            'actions' => ['create_complaint_ticket'],
            'context' => ['complaint_registered' => true]
        ];
    }

    /**
     * Lidar com elogios
     */
    private function handleCompliment(array $intent, array $context): array
    {
        $compliments = [
            "😊 Muito obrigado! Ficamos felizes em saber que você gostou!",
            "🙏 Obrigado pelo elogio! Isso nos motiva cada vez mais!",
            "🥰 Que bom saber que estamos no caminho certo! Muito obrigado!",
            "💖 Seu feedback é muito importante para nós! Obrigado!"
        ];

        return [
            'message' => $compliments[array_rand($compliments)],
            'actions' => ['save_compliment']
        ];
    }

    /**
     * Lidar com pedidos de ajuda
     */
    private function handleHelp(array $context): array
    {
        $message = "🆘 *COMO POSSO AJUDAR?*\n\n";
        $message .= "📋 *Cardápio:* Digite \"cardápio\"\n";
        $message .= "🍽️ *Fazer pedido:* Digite \"quero pedir\"\n";
        $message .= "📦 *Status do pedido:* Digite \"status do pedido\"\n";
        $message .= "🚚 *Entrega:* Digite \"entrega\"\n";
        $message .= "💳 *Pagamento:* Digite \"pagamento\"\n";
        $message .= "📞 *Falar com atendente:* Digite \"atendente\"\n\n";
        $message .= "💡 *Dica:* Seja específico na sua mensagem para melhor atendimento!";

        return [
            'message' => $message,
            'actions' => ['show_help_menu']
        ];
    }

    /**
     * Lidar com mensagens desconhecidas
     */
    private function handleUnknown(string $message, array $context): array
    {
        $suggestions = [
            "🤔 Não entendi bem sua mensagem. Que tal tentar:\n• \"Cardápio\"\n• \"Quero pedir\"\n• \"Ajuda\"",
            "😅 Desculpe, não consegui entender. Posso ajudar com:\n• Fazer um pedido\n• Ver o cardápio\n• Informações de entrega",
            "🤷‍♂️ Não entendi essa mensagem. Digite \"ajuda\" para ver todas as opções disponíveis!"
        ];

        return [
            'message' => $suggestions[array_rand($suggestions)],
            'actions' => ['show_suggestions']
        ];
    }

    /**
     * Resposta de fallback para erros
     */
    private function getFallbackResponse(): string
    {
        return "😔 Desculpe, estou com dificuldades técnicas no momento. " .
               "Por favor, tente novamente em alguns instantes ou entre em contato conosco pelo telefone.";
    }

    /**
     * Obter contexto da conversa
     */
    public function getConversationContext(string $phone): array
    {
        $cacheKey = "ai_context_{$phone}";
        return Cache::get($cacheKey, []);
    }

    /**
     * Salvar contexto da conversa
     */
    public function saveConversationContext(string $phone, array $context): void
    {
        $cacheKey = "ai_context_{$phone}";
        Cache::put($cacheKey, $context, 3600); // 1 hora
    }
}
