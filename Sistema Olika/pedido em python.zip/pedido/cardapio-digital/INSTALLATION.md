# Guia de Instalação - Sistema de Cardápio Digital Olika

## 📋 Pré-requisitos

Antes de começar, certifique-se de que você tem instalado:

- **PHP 8.1 ou superior**
- **Composer** (gerenciador de dependências PHP)
- **MySQL 5.7 ou superior** (ou MariaDB 10.3+)
- **Servidor web** (Apache, Nginx, ou usar o servidor built-in do PHP)

### Verificar Instalações

```bash
# Verificar PHP
php --version

# Verificar Composer
composer --version

# Verificar MySQL
mysql --version
```

## 🚀 Instalação Passo a Passo

### 1. Preparar o Ambiente

```bash
# Navegar para o diretório do projeto
cd cardapio-digital

# Instalar dependências do Composer
composer install
```

### 2. Configurar o Ambiente

```bash
# Copiar arquivo de configuração
cp .env.example .env

# Gerar chave da aplicação
php artisan key:generate
```

### 3. Configurar Banco de Dados

Edite o arquivo `.env` com suas configurações de banco:

```env
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=cardapio_digital
DB_USERNAME=seu_usuario
DB_PASSWORD=sua_senha
```

### 4. Criar Banco de Dados

```sql
-- Conectar ao MySQL e executar:
CREATE DATABASE cardapio_digital CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

### 5. Executar Migrations

```bash
# Executar as migrations para criar as tabelas
php artisan migrate
```

### 6. Configurar Integrações (Opcional)

Edite o arquivo `.env` com suas chaves de API:

```env
# Mercado Pago
MERCADOPAGO_ACCESS_TOKEN=seu_access_token_aqui
MERCADOPAGO_PUBLIC_KEY=sua_public_key_aqui
MERCADOPAGO_ENVIRONMENT=sandbox

# WhatsApp API
WHATSAPP_API_URL=https://sua-api-whatsapp.com
WHATSAPP_API_TOKEN=seu_token_aqui

# Google Maps
GOOGLE_MAPS_API_KEY=sua_api_key_aqui
```

### 7. Configurar Permissões

```bash
# Dar permissões para o diretório de storage
chmod -R 775 storage
chmod -R 775 bootstrap/cache

# Se estiver no Linux/Mac, definir o proprietário correto
chown -R www-data:www-data storage bootstrap/cache
```

### 8. Iniciar o Servidor

```bash
# Usar o servidor built-in do PHP (para desenvolvimento)
php artisan serve

# Ou configurar um servidor web (Apache/Nginx) para produção
```

## 🌐 Acessar o Sistema

Após a instalação, acesse:

- **API**: `http://localhost:8000/api`
- **Health Check**: `http://localhost:8000/api/health`
- **Configurações Públicas**: `http://localhost:8000/api/public/settings`

## 🔧 Configurações Iniciais

### 1. Configurar Sistema

Faça uma requisição PUT para `/api/settings`:

```bash
curl -X PUT http://localhost:8000/api/settings \
  -H "Content-Type: application/json" \
  -d '{
    "business_name": "Olika - Pães Artesanais",
    "primary_color": "#FF8C00",
    "description": "Pães e massas artesanais feitos com amor",
    "phone": "(11) 99999-9999",
    "is_open": true
  }'
```

### 2. Criar Categorias

```bash
curl -X POST http://localhost:8000/api/categories \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Pães Rústicos",
    "icon": "🥖",
    "sort_order": 1
  }'
```

### 3. Criar Produtos

```bash
curl -X POST http://localhost:8000/api/products \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Pão de Fermentação Natural",
    "description": "Pão rústico feito com fermentação natural de 24h",
    "price": 18.00,
    "image": "https://images.unsplash.com/photo-1509440159596-0249088772ff?w=800&q=80",
    "category_id": 1,
    "available": true,
    "featured": true,
    "visible": true
  }'
```

## 🧪 Testar o Sistema

### 1. Verificar Health Check

```bash
curl http://localhost:8000/api/health
```

Resposta esperada:
```json
{
  "status": "ok",
  "timestamp": "2024-01-01T00:00:00.000000Z",
  "version": "1.0.0"
}
```

### 2. Listar Produtos

```bash
curl http://localhost:8000/api/public/products
```

### 3. Listar Categorias

```bash
curl http://localhost:8000/api/public/categories
```

## 🔍 Troubleshooting

### Problema: Erro de Permissão

```bash
# Solução: Ajustar permissões
chmod -R 775 storage bootstrap/cache
chown -R www-data:www-data storage bootstrap/cache
```

### Problema: Erro de Banco de Dados

```bash
# Verificar se o banco existe
mysql -u root -p -e "SHOW DATABASES;"

# Recriar banco se necessário
mysql -u root -p -e "DROP DATABASE IF EXISTS cardapio_digital; CREATE DATABASE cardapio_digital CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"

# Executar migrations novamente
php artisan migrate:fresh
```

### Problema: Erro de Composer

```bash
# Limpar cache do Composer
composer clear-cache

# Reinstalar dependências
rm -rf vendor
composer install
```

### Problema: Chave da Aplicação

```bash
# Gerar nova chave
php artisan key:generate
```

## 📊 Verificar Instalação

### 1. Testar Endpoints Principais

```bash
# Health check
curl http://localhost:8000/api/health

# Configurações públicas
curl http://localhost:8000/api/public/settings

# Produtos públicos
curl http://localhost:8000/api/public/products

# Categorias públicas
curl http://localhost:8000/api/public/categories
```

### 2. Verificar Banco de Dados

```sql
-- Conectar ao MySQL e verificar tabelas
USE cardapio_digital;
SHOW TABLES;

-- Verificar se as tabelas foram criadas:
-- customers, categories, products, orders, order_items, coupons, 
-- loyalty_programs, referrals, delivery_fees, delivery_schedules, settings
```

## 🚀 Deploy para Produção

### 1. Configurar Ambiente de Produção

```bash
# Copiar .env para produção
cp .env .env.production

# Editar configurações de produção
nano .env.production
```

### 2. Configurações de Produção

```env
APP_ENV=production
APP_DEBUG=false
APP_URL=https://seu-dominio.com

# Banco de dados de produção
DB_HOST=seu-host-producao
DB_DATABASE=cardapio_digital_prod
DB_USERNAME=usuario_producao
DB_PASSWORD=senha_producao

# Mercado Pago de produção
MERCADOPAGO_ENVIRONMENT=production
MERCADOPAGO_ACCESS_TOKEN=seu_access_token_producao
```

### 3. Otimizar para Produção

```bash
# Instalar dependências otimizadas
composer install --optimize-autoloader --no-dev

# Cache de configuração
php artisan config:cache

# Cache de rotas
php artisan route:cache

# Cache de views
php artisan view:cache
```

## 📞 Suporte

Se encontrar problemas durante a instalação:

1. Verifique os logs em `storage/logs/laravel.log`
2. Verifique se todos os pré-requisitos estão instalados
3. Consulte a documentação da API em `/api`
4. Abra uma issue no repositório

## ✅ Checklist de Instalação

- [ ] PHP 8.1+ instalado
- [ ] Composer instalado
- [ ] MySQL instalado e configurado
- [ ] Dependências instaladas (`composer install`)
- [ ] Arquivo `.env` configurado
- [ ] Chave da aplicação gerada
- [ ] Banco de dados criado
- [ ] Migrations executadas
- [ ] Permissões configuradas
- [ ] Servidor iniciado
- [ ] Health check funcionando
- [ ] API respondendo corretamente

---

**🎉 Parabéns! Seu sistema está instalado e funcionando!**
