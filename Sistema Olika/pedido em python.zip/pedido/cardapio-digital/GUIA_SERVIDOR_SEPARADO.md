# 🖥️ **GUIA: SERVIDOR SEPARADO - CARDÁPIO DIGITAL**

## ✅ **SIM! É totalmente possível rodar a aplicação em um servidor e o banco em outro**

No Laravel, essa é uma prática muito comum e recomendada para produção. Aqui está o guia completo:

---

## 🏗️ **ARQUITETURAS POSSÍVEIS**

### **Opção 1: Servidor App + Banco Remoto**
```
┌─────────────────────┐    ┌─────────────────────┐
│   SERVIDOR APP      │    │   SERVIDOR BANCO    │
│                     │    │                     │
│  🌐 Nginx/Apache    │────│  🗄️  MySQL/Postgres │
│  📱 Laravel App     │    │  📊 phpMyAdmin      │
│  🎨 Assets          │    │  🔒 Firewall        │
└─────────────────────┘    └─────────────────────┘
```

### **Opção 2: Cloud Database**
```
┌─────────────────────┐    ┌─────────────────────┐
│   SERVIDOR APP      │    │   CLOUD DATABASE    │
│                     │    │                     │
│  🌐 DigitalOcean    │────│  ☁️  AWS RDS         │
│  📱 Laravel App     │    │  ☁️  Google Cloud    │
│  🎨 Assets          │    │  ☁️  Azure Database  │
└─────────────────────┘    └─────────────────────┘
```

### **Opção 3: Microserviços Completos**
```
┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐
│  SERVIDOR APP   │  │  SERVIDOR DB    │  │ SERVIDOR CACHE  │  │ SERVIDOR FILES  │
│                 │  │                 │  │                 │  │                 │
│  📱 Laravel     │──│  🗄️  MySQL      │  │  🚀 Redis       │  │  📁 S3/Minio    │
│  🌐 Nginx       │  │  📊 Adminer     │  │  ⚡ Cache       │  │  🖼️  Images     │
└─────────────────┘  └─────────────────┘  └─────────────────┘  └─────────────────┘
```

---

## ⚙️ **CONFIGURAÇÃO DO BANCO REMOTO**

### **1. Configurar o Servidor do Banco**

```bash
# No servidor do banco de dados (Ubuntu/Debian)
sudo apt update
sudo apt install mysql-server

# Configurar MySQL para aceitar conexões remotas
sudo nano /etc/mysql/mysql.conf.d/mysqld.cnf

# Alterar:
bind-address = 0.0.0.0  # Era 127.0.0.1

# Reiniciar MySQL
sudo systemctl restart mysql
sudo systemctl enable mysql
```

### **2. Criar Usuário e Banco**

```sql
-- Conectar no MySQL
mysql -u root -p

-- Criar banco
CREATE DATABASE cardapio_digital CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Criar usuário (substitua pelo IP do servidor da app)
CREATE USER 'cardapio_user'@'%' IDENTIFIED BY 'senha_super_segura_123!';
-- Para IP específico: CREATE USER 'cardapio_user'@'192.168.1.100' IDENTIFIED BY 'senha';

-- Dar permissões
GRANT ALL PRIVILEGES ON cardapio_digital.* TO 'cardapio_user'@'%';
FLUSH PRIVILEGES;

-- Verificar
SHOW GRANTS FOR 'cardapio_user'@'%';
```

### **3. Configurar Firewall**

```bash
# No servidor do banco
sudo ufw allow from IP_DO_SERVIDOR_APP to any port 3306
# Ou para qualquer IP (menos seguro):
sudo ufw allow 3306

# Verificar status
sudo ufw status
```

---

## 🔧 **CONFIGURAÇÃO DA APLICAÇÃO**

### **1. Arquivo .env da Aplicação**

```env
# ============================================
# APLICAÇÃO
# ============================================
APP_NAME="Cardápio Digital Olika"
APP_ENV=production
APP_DEBUG=false
APP_URL=https://seu-dominio.com

# ============================================
# BANCO REMOTO
# ============================================
DB_CONNECTION=mysql
DB_HOST=IP_DO_SERVIDOR_BANCO    # Ex: 192.168.1.200
DB_PORT=3306
DB_DATABASE=cardapio_digital
DB_USERNAME=cardapio_user
DB_PASSWORD=senha_super_segura_123!

# ============================================
# CACHE (OPCIONAL - SERVIDOR SEPARADO)
# ============================================
CACHE_DRIVER=redis
REDIS_HOST=IP_DO_SERVIDOR_REDIS
REDIS_PASSWORD=senha_redis
REDIS_PORT=6379

# ============================================
# SESSÕES
# ============================================
SESSION_DRIVER=redis  # ou database
SESSION_LIFETIME=120

# ============================================
# INTEGRAÇÕES
# ============================================
MERCADOPAGO_ACCESS_TOKEN=seu_token_producao
MERCADOPAGO_PUBLIC_KEY=sua_public_key_producao
WHATSAPP_API_URL=https://sua-api-whatsapp.com
GOOGLE_MAPS_API_KEY=sua_chave_google_maps
```

### **2. Testar Conexão**

```bash
# No servidor da aplicação
php artisan tinker

# Testar conexão
DB::connection()->getPdo();
echo "Conexão com banco OK!";

# Executar migrações
php artisan migrate
```

---

## 🚀 **DEPLOY EM PRODUÇÃO**

### **1. Servidor da Aplicação**

```bash
# Instalar dependências
composer install --no-dev --optimize-autoloader

# Configurar cache
php artisan config:cache
php artisan route:cache
php artisan view:cache

# Executar migrações
php artisan migrate --force

# Configurar permissões
chmod -R 755 storage bootstrap/cache
chown -R www-data:www-data storage bootstrap/cache
```

### **2. Configurar Nginx**

```nginx
# /etc/nginx/sites-available/cardapio-digital
server {
    listen 80;
    server_name seu-dominio.com www.seu-dominio.com;
    root /var/www/cardapio-digital/public;

    add_header X-Frame-Options "SAMEORIGIN";
    add_header X-Content-Type-Options "nosniff";

    index index.php;

    charset utf-8;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location = /favicon.ico { access_log off; log_not_found off; }
    location = /robots.txt  { access_log off; log_not_found off; }

    error_page 404 /index.php;

    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php8.1-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $realpath_root$fastcgi_script_name;
        include fastcgi_params;
    }

    location ~ /\.(?!well-known).* {
        deny all;
    }
}
```

---

## 🔒 **SEGURANÇA**

### **1. Conexão Segura**

```env
# Usar SSL para conexão com banco
DB_CONNECTION=mysql
DB_HOST=seu-servidor-banco.com
DB_PORT=3306
DB_DATABASE=cardapio_digital
DB_USERNAME=cardapio_user
DB_PASSWORD=senha_super_segura_123!
DB_SSL_CA=/path/to/ca-cert.pem  # Opcional
```

### **2. Firewall Restritivo**

```bash
# No servidor do banco - apenas IPs específicos
sudo ufw allow from 192.168.1.100 to any port 3306  # IP da app
sudo ufw allow from 192.168.1.101 to any port 3306  # IP de backup
sudo ufw deny 3306  # Bloquear todos os outros
```

### **3. Backup Automático**

```bash
#!/bin/bash
# backup-banco.sh
mysqldump -h IP_DO_BANCO -u cardapio_user -p cardapio_digital > backup_$(date +%Y%m%d_%H%M%S).sql
```

---

## ☁️ **OPÇÕES DE CLOUD**

### **AWS RDS**
```env
DB_CONNECTION=mysql
DB_HOST=cardapio-db.cluster-xxx.us-east-1.rds.amazonaws.com
DB_PORT=3306
DB_DATABASE=cardapio_digital
DB_USERNAME=admin
DB_PASSWORD=senha_aws
```

### **Google Cloud SQL**
```env
DB_CONNECTION=mysql
DB_HOST=IP_PUBLICO_GOOGLE_CLOUD
DB_PORT=3306
DB_DATABASE=cardapio_digital
DB_USERNAME=root
DB_PASSWORD=senha_google
```

### **DigitalOcean Managed Database**
```env
DB_CONNECTION=mysql
DB_HOST=db-postgresql-nyc1-12345-do-user-123456-0.db.ondigitalocean.com
DB_PORT=25060
DB_DATABASE=cardapio_digital
DB_USERNAME=doadmin
DB_PASSWORD=senha_digitalocean
```

---

## 📊 **MONITORAMENTO**

### **1. Verificar Conexões**

```bash
# No servidor do banco
mysql -u root -p
SHOW PROCESSLIST;
SHOW STATUS LIKE 'Connections';
```

### **2. Logs da Aplicação**

```bash
# Ver logs de conexão
tail -f storage/logs/laravel.log | grep "database"
```

### **3. Health Check**

```bash
# Script de monitoramento
#!/bin/bash
if php artisan tinker --execute="DB::connection()->getPdo();" > /dev/null 2>&1; then
    echo "✅ Banco conectado"
else
    echo "❌ Erro na conexão"
    # Enviar alerta
fi
```

---

## 🎯 **VANTAGENS DO SERVIDOR SEPARADO**

### ✅ **Performance**
- Banco dedicado com recursos otimizados
- Aplicação mais leve
- Escalabilidade independente

### ✅ **Segurança**
- Banco isolado em rede privada
- Backup centralizado
- Controle de acesso granular

### ✅ **Manutenção**
- Updates independentes
- Backup automático
- Monitoramento especializado

### ✅ **Custo**
- Servidores otimizados para cada função
- Recursos compartilhados
- Escalabilidade sob demanda

---

## 🚀 **RESUMO RÁPIDO**

1. **Configure o servidor do banco** com MySQL
2. **Crie usuário e banco** com permissões adequadas
3. **Configure firewall** para permitir conexões
4. **Atualize o .env** da aplicação com IP do banco
5. **Teste a conexão** com `php artisan tinker`
6. **Execute as migrações** com `php artisan migrate`
7. **Configure backup automático**
8. **Monitore as conexões**

**Pronto! Sua aplicação Laravel estará rodando em um servidor e o banco em outro! 🎉**
