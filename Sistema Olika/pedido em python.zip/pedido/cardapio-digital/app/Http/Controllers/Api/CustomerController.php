<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Models\Order;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Validator;

class CustomerController extends Controller
{
    /**
     * Listar clientes
     */
    public function index(Request $request): JsonResponse
    {
        $query = Customer::query();

        // Filtro por busca
        if ($search = $request->get('search')) {
            $query->where(function ($q) use ($search) {
                $q->where('name', 'LIKE', "%{$search}%")
                  ->orWhere('phone', 'LIKE', "%{$search}%")
                  ->orWhere('email', 'LIKE', "%{$search}%");
            });
        }

        // Ordenação
        $sortBy = $request->get('sort_by', 'created_at');
        $sortOrder = $request->get('sort_order', 'desc');
        $query->orderBy($sortBy, $sortOrder);

        $customers = $query->paginate(20);

        return response()->json([
            'success' => true,
            'data' => $customers
        ]);
    }

    /**
     * Obter cliente específico
     */
    public function show(Customer $customer): JsonResponse
    {
        $customer->load(['orders' => function ($query) {
            $query->orderBy('created_at', 'desc')->limit(10);
        }]);

        return response()->json([
            'success' => true,
            'data' => $customer
        ]);
    }

    /**
     * Criar novo cliente
     */
    public function store(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'phone' => 'required|string|max:20|unique:customers,phone',
            'email' => 'nullable|email|max:255',
            'birthday' => 'nullable|date',
            'cep' => 'required|string|max:10',
            'street' => 'required|string|max:255',
            'number' => 'required|string|max:20',
            'complement' => 'nullable|string|max:255',
            'neighborhood' => 'required|string|max:255',
            'city' => 'required|string|max:255',
            'state' => 'required|string|max:2',
            'reference' => 'nullable|string|max:255',
            'referred_by' => 'nullable|string|exists:customers,referral_code',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Dados inválidos',
                'errors' => $validator->errors()
            ], 422);
        }

        $data = $request->all();

        // Processar indicação se fornecida
        if (isset($data['referred_by'])) {
            $referrer = Customer::findByReferralCode($data['referred_by']);
            if ($referrer) {
                $data['referred_by'] = $referrer->id;
            }
        }

        $customer = Customer::create($data);
        $customer->load('orders');

        return response()->json([
            'success' => true,
            'message' => 'Cliente criado com sucesso',
            'data' => $customer
        ], 201);
    }

    /**
     * Atualizar cliente
     */
    public function update(Request $request, Customer $customer): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'name' => 'sometimes|required|string|max:255',
            'phone' => 'sometimes|required|string|max:20|unique:customers,phone,' . $customer->id,
            'email' => 'nullable|email|max:255',
            'birthday' => 'nullable|date',
            'cep' => 'sometimes|required|string|max:10',
            'street' => 'sometimes|required|string|max:255',
            'number' => 'sometimes|required|string|max:20',
            'complement' => 'nullable|string|max:255',
            'neighborhood' => 'sometimes|required|string|max:255',
            'city' => 'sometimes|required|string|max:255',
            'state' => 'sometimes|required|string|max:2',
            'reference' => 'nullable|string|max:255',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Dados inválidos',
                'errors' => $validator->errors()
            ], 422);
        }

        $customer->update($request->all());

        return response()->json([
            'success' => true,
            'message' => 'Cliente atualizado com sucesso',
            'data' => $customer
        ]);
    }

    /**
     * Deletar cliente
     */
    public function destroy(Customer $customer): JsonResponse
    {
        $customer->delete();

        return response()->json([
            'success' => true,
            'message' => 'Cliente deletado com sucesso'
        ]);
    }

    /**
     * Buscar cliente por telefone
     */
    public function findByPhone(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'phone' => 'required|string|max:20'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Telefone é obrigatório',
                'errors' => $validator->errors()
            ], 422);
        }

        $customer = Customer::findByPhone($request->phone);

        if (!$customer) {
            return response()->json([
                'success' => false,
                'message' => 'Cliente não encontrado'
            ], 404);
        }

        return response()->json([
            'success' => true,
            'data' => $customer
        ]);
    }

    /**
     * Buscar cliente por código de indicação
     */
    public function findByReferralCode(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'referral_code' => 'required|string|max:10'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Código de indicação é obrigatório',
                'errors' => $validator->errors()
            ], 422);
        }

        $customer = Customer::findByReferralCode($request->referral_code);

        if (!$customer) {
            return response()->json([
                'success' => false,
                'message' => 'Cliente não encontrado'
            ], 404);
        }

        return response()->json([
            'success' => true,
            'data' => $customer
        ]);
    }

    /**
     * Obter histórico de pedidos do cliente
     */
    public function orders(Customer $customer): JsonResponse
    {
        $orders = $customer->orders()
            ->with('items.product')
            ->orderBy('created_at', 'desc')
            ->paginate(20);

        return response()->json([
            'success' => true,
            'data' => $orders
        ]);
    }

    /**
     * Obter estatísticas do cliente
     */
    public function stats(Customer $customer): JsonResponse
    {
        $stats = [
            'total_orders' => $customer->order_count,
            'total_spent' => $customer->total_spent,
            'loyalty_points' => $customer->loyalty_points,
            'average_order_value' => $customer->order_count > 0 ? $customer->total_spent / $customer->order_count : 0,
            'referral_code' => $customer->referral_code,
            'referrals_count' => $customer->referrals()->count(),
            'completed_referrals_count' => $customer->referrals()->where('status', 'completed')->count(),
            'total_bonus_earned' => $customer->referrals()->where('status', 'completed')->sum('bonus_earned'),
        ];

        return response()->json([
            'success' => true,
            'data' => $stats
        ]);
    }

    /**
     * Adicionar pontos de fidelidade
     */
    public function addLoyaltyPoints(Request $request, Customer $customer): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'points' => 'required|integer|min:1'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Dados inválidos',
                'errors' => $validator->errors()
            ], 422);
        }

        $customer->addLoyaltyPoints($request->points);

        return response()->json([
            'success' => true,
            'message' => 'Pontos adicionados com sucesso',
            'data' => $customer
        ]);
    }

    /**
     * Remover pontos de fidelidade
     */
    public function removeLoyaltyPoints(Request $request, Customer $customer): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'points' => 'required|integer|min:1'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Dados inválidos',
                'errors' => $validator->errors()
            ], 422);
        }

        $success = $customer->removeLoyaltyPoints($request->points);

        if (!$success) {
            return response()->json([
                'success' => false,
                'message' => 'Pontos insuficientes'
            ], 422);
        }

        return response()->json([
            'success' => true,
            'message' => 'Pontos removidos com sucesso',
            'data' => $customer
        ]);
    }

    /**
     * Obter indicações do cliente
     */
    public function referrals(Customer $customer): JsonResponse
    {
        $referrals = $customer->referrals()
            ->with('referred')
            ->orderBy('created_at', 'desc')
            ->get();

        return response()->json([
            'success' => true,
            'data' => $referrals
        ]);
    }

    /**
     * Registrar novo cliente
     */
    public function register(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'phone' => 'required|string|max:20',
            'email' => 'nullable|email|max:255',
            'birthday' => 'nullable|date_format:d/m/Y',
            'password' => 'required|string|min:6',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Dados inválidos',
                'errors' => $validator->errors()
            ], 422);
        }

        // Verificar se cliente já existe
        $existingCustomer = Customer::findByPhone($request->phone);
        if ($existingCustomer) {
            return response()->json([
                'success' => false,
                'message' => 'Cliente já cadastrado com este telefone'
            ], 422);
        }

        try {
            $customerData = [
                'name' => $request->name,
                'phone' => preg_replace('/\D/', '', $request->phone),
                'email' => $request->email,
                'birthday' => $request->birthday ? \Carbon\Carbon::createFromFormat('d/m/Y', $request->birthday) : null,
                'password' => bcrypt($request->password),
                'loyalty_points' => 0,
                'order_count' => 0,
                'total_spent' => 0,
            ];

            $customer = Customer::create($customerData);

            // Gerar token de acesso
            $token = $customer->createToken('auth-token')->plainTextToken;

            return response()->json([
                'success' => true,
                'message' => 'Cliente cadastrado com sucesso',
                'data' => [
                    'customer' => $customer,
                    'token' => $token,
                    'is_new_customer' => true
                ]
            ], 201);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Erro ao cadastrar cliente: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Login do cliente
     */
    public function login(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'phone' => 'required|string',
            'password' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Telefone e senha são obrigatórios',
                'errors' => $validator->errors()
            ], 422);
        }

        $phone = preg_replace('/\D/', '', $request->phone);
        $customer = Customer::findByPhone($phone);

        if (!$customer || !password_verify($request->password, $customer->password)) {
            return response()->json([
                'success' => false,
                'message' => 'Telefone ou senha inválidos'
            ], 401);
        }

        // Gerar token de acesso
        $token = $customer->createToken('auth-token')->plainTextToken;

        return response()->json([
            'success' => true,
            'message' => 'Login realizado com sucesso',
            'data' => [
                'customer' => $customer,
                'token' => $token
            ]
        ]);
    }

    /**
     * Obter perfil do cliente autenticado
     */
    public function profile(Request $request): JsonResponse
    {
        $customer = $request->user();

        return response()->json([
            'success' => true,
            'data' => $customer
        ]);
    }

    /**
     * Atualizar perfil do cliente
     */
    public function updateProfile(Request $request): JsonResponse
    {
        $customer = $request->user();

        $validator = Validator::make($request->all(), [
            'name' => 'sometimes|required|string|max:255',
            'email' => 'sometimes|nullable|email|max:255|unique:customers,email,' . $customer->id,
            'birthday' => 'sometimes|nullable|date_format:d/m/Y',
            'cep' => 'sometimes|nullable|string|max:10',
            'street' => 'sometimes|nullable|string|max:255',
            'number' => 'sometimes|nullable|string|max:20',
            'complement' => 'sometimes|nullable|string|max:255',
            'neighborhood' => 'sometimes|nullable|string|max:255',
            'city' => 'sometimes|nullable|string|max:255',
            'state' => 'sometimes|nullable|string|max:2',
            'reference' => 'sometimes|nullable|string|max:255',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Dados inválidos',
                'errors' => $validator->errors()
            ], 422);
        }

        $updateData = $request->only([
            'name', 'email', 'cep', 'street', 'number', 'complement',
            'neighborhood', 'city', 'state', 'reference'
        ]);

        if ($request->has('birthday')) {
            $updateData['birthday'] = $request->birthday ? 
                \Carbon\Carbon::createFromFormat('d/m/Y', $request->birthday) : null;
        }

        $customer->update($updateData);

        return response()->json([
            'success' => true,
            'message' => 'Perfil atualizado com sucesso',
            'data' => $customer->fresh()
        ]);
    }

    /**
     * Obter pedidos do cliente
     */
    public function getOrders(Request $request): JsonResponse
    {
        $customer = $request->user();
        
        $orders = Order::where('customer_id', $customer->id)
            ->with(['items.product'])
            ->orderBy('created_at', 'desc')
            ->paginate(10);

        return response()->json([
            'success' => true,
            'data' => $orders
        ]);
    }

    /**
     * Obter pontos de fidelidade
     */
    public function getLoyaltyPoints(Request $request): JsonResponse
    {
        $customer = $request->user();
        
        return response()->json([
            'success' => true,
            'data' => [
                'loyalty_points' => $customer->loyalty_points,
                'order_count' => $customer->order_count,
                'total_spent' => $customer->total_spent,
                'next_reward' => $this->getNextReward($customer->loyalty_points)
            ]
        ]);
    }

    /**
     * Calcular próxima recompensa
     */
    private function getNextReward(int $currentPoints): array
    {
        $rewards = [
            50 => '5% de desconto',
            100 => '10% de desconto',
            200 => 'Produto grátis',
            500 => '15% de desconto permanente'
        ];

        foreach ($rewards as $points => $reward) {
            if ($currentPoints < $points) {
                return [
                    'points_needed' => $points - $currentPoints,
                    'reward' => $reward,
                    'total_points' => $points
                ];
            }
        }

        return [
            'points_needed' => 0,
            'reward' => 'Máximo atingido',
            'total_points' => $currentPoints
        ];
    }
}
