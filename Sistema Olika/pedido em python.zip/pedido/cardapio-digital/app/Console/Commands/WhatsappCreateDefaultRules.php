<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\WhatsappRule;
use App\Models\WhatsappTemplate;

class WhatsappCreateDefaultRules extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'whatsapp:create-default-rules {loja_id : ID da loja}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cria regras padrão do WhatsApp para uma loja';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $lojaId = $this->argument('loja_id');

        $this->info("Criando regras padrão do WhatsApp para loja {$lojaId}...");

        $rules = [
            [
                'event_key' => 'order_confirmed',
                'template_name' => 'order_confirmed',
                'template_body' => '🍞 Pedido {{pedido}} confirmado, {{nome}}! Previsão de entrega: {{previsao}}. Total: R$ {{total}}.',
                'template_vars' => ['pedido', 'nome', 'previsao', 'total'],
                'send_window' => '09:00-20:30',
                'adapter' => 'any'
            ],
            [
                'event_key' => 'out_for_delivery',
                'template_name' => 'out_for_delivery',
                'template_body' => '🚚 Seu pedido {{pedido}} saiu para entrega! Chegada estimada: {{previsao}}. Acompanhe pelo link: {{link_rastreio}}.',
                'template_vars' => ['pedido', 'previsao', 'link_rastreio'],
                'send_window' => '09:00-20:30',
                'adapter' => 'any'
            ],
            [
                'event_key' => 'delivered',
                'template_name' => 'delivered',
                'template_body' => '✅ Pedido {{pedido}} entregue! Obrigado pela preferência, {{nome}}! Deixe seu feedback: {{link_feedback}}.',
                'template_vars' => ['pedido', 'nome', 'link_feedback'],
                'send_window' => '09:00-20:30',
                'adapter' => 'any'
            ],
            [
                'event_key' => 'cancelled',
                'template_name' => 'cancelled',
                'template_body' => '❌ Pedido {{pedido}} cancelado. Motivo: {{motivo}}. Para mais informações: {{contato_suporte}}.',
                'template_vars' => ['pedido', 'motivo', 'contato_suporte'],
                'send_window' => '09:00-20:30',
                'adapter' => 'any'
            ],
            [
                'event_key' => 'winback_7d',
                'template_name' => 'winback_7d',
                'template_body' => '👋 Olá {{nome}}! Faz 7 dias que você não pede conosco. Que tal um {{produto_destaque}}? Use o cupom {{cupom}} e ganhe {{desconto}}% de desconto!',
                'template_vars' => ['nome', 'produto_destaque', 'cupom', 'desconto'],
                'send_window' => '09:00-20:30',
                'adapter' => 'any'
            ],
            [
                'event_key' => 'winback_30d',
                'template_name' => 'winback_30d',
                'template_body' => '🎉 {{nome}}, sentimos sua falta! Que tal voltar? Use o cupom {{cupom}} e ganhe {{desconto}}% de desconto em seu próximo pedido!',
                'template_vars' => ['nome', 'cupom', 'desconto'],
                'send_window' => '09:00-20:30',
                'adapter' => 'any'
            ],
            [
                'event_key' => 'birthday',
                'template_name' => 'birthday',
                'template_body' => '🎂 Feliz aniversário, {{nome}}! 🎉 Que tal comemorar com um {{produto_destaque}}? Use o cupom {{cupom}} e ganhe {{desconto}}% de desconto!',
                'template_vars' => ['nome', 'produto_destaque', 'cupom', 'desconto'],
                'send_window' => '09:00-20:30',
                'adapter' => 'any'
            ]
        ];

        $created = 0;
        $updated = 0;

        foreach ($rules as $ruleData) {
            $rule = WhatsappRule::updateOrCreate(
                [
                    'loja_id' => $lojaId,
                    'event_key' => $ruleData['event_key']
                ],
                array_merge($ruleData, [
                    'loja_id' => $lojaId,
                    'enabled' => true,
                    'created_at' => now(),
                    'updated_at' => now()
                ])
            );

            if ($rule->wasRecentlyCreated) {
                $created++;
                $this->line("✅ Regra criada: {$ruleData['event_key']}");
            } else {
                $updated++;
                $this->line("🔄 Regra atualizada: {$ruleData['event_key']}");
            }
        }

        $this->newLine();
        $this->info("Regras processadas:");
        $this->info("  - Criadas: {$created}");
        $this->info("  - Atualizadas: {$updated}");

        // Criar templates para Cloud API
        $this->createCloudTemplates($lojaId);

        $this->newLine();
        $this->info("✅ Regras padrão criadas com sucesso para loja {$lojaId}!");
    }

    /**
     * Criar templates para Cloud API
     */
    private function createCloudTemplates(int $lojaId): void
    {
        $this->info("Criando templates para Cloud API...");

        $templates = [
            [
                'name' => 'order_confirmed',
                'category' => 'utility',
                'body' => '🍞 Pedido {{1}} confirmado, {{2}}! Previsão de entrega: {{3}}. Total: R$ {{4}}.',
                'language' => 'pt_BR'
            ],
            [
                'name' => 'out_for_delivery',
                'category' => 'utility',
                'body' => '🚚 Seu pedido {{1}} saiu para entrega! Chegada estimada: {{2}}. Acompanhe pelo link: {{3}}.',
                'language' => 'pt_BR'
            ],
            [
                'name' => 'delivered',
                'category' => 'utility',
                'body' => '✅ Pedido {{1}} entregue! Obrigado pela preferência, {{2}}! Deixe seu feedback: {{3}}.',
                'language' => 'pt_BR'
            ],
            [
                'name' => 'cancelled',
                'category' => 'utility',
                'body' => '❌ Pedido {{1}} cancelado. Motivo: {{2}}. Para mais informações: {{3}}.',
                'language' => 'pt_BR'
            ],
            [
                'name' => 'winback_7d',
                'category' => 'marketing',
                'body' => '👋 Olá {{1}}! Faz 7 dias que você não pede conosco. Que tal um {{2}}? Use o cupom {{3}} e ganhe {{4}}% de desconto!',
                'language' => 'pt_BR'
            ],
            [
                'name' => 'winback_30d',
                'category' => 'marketing',
                'body' => '🎉 {{1}}, sentimos sua falta! Que tal voltar? Use o cupom {{2}} e ganhe {{3}}% de desconto em seu próximo pedido!',
                'language' => 'pt_BR'
            ],
            [
                'name' => 'birthday',
                'category' => 'marketing',
                'body' => '🎂 Feliz aniversário, {{1}}! 🎉 Que tal comemorar com um {{2}}? Use o cupom {{3}} e ganhe {{4}}% de desconto!',
                'language' => 'pt_BR'
            ]
        ];

        $created = 0;
        $updated = 0;

        foreach ($templates as $templateData) {
            $template = WhatsappTemplate::updateOrCreate(
                [
                    'loja_id' => $lojaId,
                    'name' => $templateData['name']
                ],
                array_merge($templateData, [
                    'loja_id' => $lojaId,
                    'status' => 'in_review',
                    'created_at' => now(),
                    'updated_at' => now()
                ])
            );

            if ($template->wasRecentlyCreated) {
                $created++;
                $this->line("✅ Template criado: {$templateData['name']}");
            } else {
                $updated++;
                $this->line("🔄 Template atualizado: {$templateData['name']}");
            }
        }

        $this->info("Templates Cloud API processados:");
        $this->info("  - Criados: {$created}");
        $this->info("  - Atualizados: {$updated}");
    }
}
