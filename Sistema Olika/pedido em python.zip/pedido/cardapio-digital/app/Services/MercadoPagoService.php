<?php

namespace App\Services;

use MercadoPago\SDK;
use MercadoPago\Preference;
use MercadoPago\Item;
use MercadoPago\Payer;
use App\Models\Order;
use App\Models\Settings;
use Illuminate\Support\Facades\Log;

class MercadoPagoService
{
    private $accessToken;
    private $publicKey;
    private $environment;

    public function __construct()
    {
        $settings = Settings::getSettings();
        
        $this->accessToken = $settings->mercado_pago_access_token;
        $this->publicKey = $settings->mercado_pago_public_key;
        $this->environment = $settings->mercado_pago_environment;

        if ($this->accessToken) {
            SDK::setAccessToken($this->accessToken);
        }
    }

    /**
     * Verificar se Mercado Pago está configurado
     */
    public function isConfigured(): bool
    {
        return !empty($this->accessToken) && !empty($this->publicKey);
    }

    /**
     * Criar preferência de pagamento
     */
    public function createPreference(Order $order): array
    {
        if (!$this->isConfigured()) {
            throw new \Exception('Mercado Pago não está configurado');
        }

        try {
            $preference = new Preference();

            // Criar itens
            $items = [];
            foreach ($order->items as $orderItem) {
                $item = new Item();
                $item->title = $orderItem->name;
                $item->quantity = $orderItem->quantity;
                $item->unit_price = $orderItem->price;
                $item->currency_id = 'BRL';
                $items[] = $item;
            }

            // Adicionar taxa de entrega se houver
            if ($order->delivery_fee > 0) {
                $deliveryItem = new Item();
                $deliveryItem->title = 'Taxa de Entrega';
                $deliveryItem->quantity = 1;
                $deliveryItem->unit_price = $order->delivery_fee;
                $deliveryItem->currency_id = 'BRL';
                $items[] = $deliveryItem;
            }

            $preference->items = $items;

            // Configurar pagador
            $payer = new Payer();
            $payer->name = $order->customer->name;
            $payer->email = $order->customer->email;
            $payer->phone = [
                'number' => $order->customer->phone
            ];
            $preference->payer = $payer;

            // Configurar URLs de retorno
            $settings = Settings::getSettings();
            $preference->back_urls = [
                'success' => $settings->mercado_pago_return_url . '?order_id=' . $order->id,
                'failure' => $settings->mercado_pago_return_url . '?order_id=' . $order->id . '&status=failure',
                'pending' => $settings->mercado_pago_return_url . '?order_id=' . $order->id . '&status=pending'
            ];

            // Configurar auto retorno
            $preference->auto_return = 'approved';

            // Configurar notificações
            $preference->notification_url = $settings->mercado_pago_webhook_url;

            // Configurar metadados
            $preference->metadata = [
                'order_id' => $order->id,
                'customer_id' => $order->customer_id
            ];

            // Configurar expiração (24 horas)
            $preference->expires = true;
            $preference->expiration_date_from = now()->toISOString();
            $preference->expiration_date_to = now()->addHours(24)->toISOString();

            $preference->save();

            return [
                'success' => true,
                'preference_id' => $preference->id,
                'init_point' => $preference->init_point,
                'sandbox_init_point' => $preference->sandbox_init_point,
                'public_key' => $this->publicKey
            ];

        } catch (\Exception $e) {
            Log::error('Erro ao criar preferência Mercado Pago: ' . $e->getMessage());
            
            return [
                'success' => false,
                'message' => 'Erro ao criar preferência de pagamento: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Verificar status do pagamento
     */
    public function getPaymentStatus(string $paymentId): array
    {
        if (!$this->isConfigured()) {
            throw new \Exception('Mercado Pago não está configurado');
        }

        try {
            $payment = \MercadoPago\Payment::find_by_id($paymentId);

            if (!$payment) {
                return [
                    'success' => false,
                    'message' => 'Pagamento não encontrado'
                ];
            }

            return [
                'success' => true,
                'status' => $payment->status,
                'status_detail' => $payment->status_detail,
                'amount' => $payment->transaction_amount,
                'currency' => $payment->currency_id,
                'payment_method' => $payment->payment_method_id,
                'installments' => $payment->installments,
                'date_approved' => $payment->date_approved,
                'date_created' => $payment->date_created
            ];

        } catch (\Exception $e) {
            Log::error('Erro ao verificar status do pagamento: ' . $e->getMessage());
            
            return [
                'success' => false,
                'message' => 'Erro ao verificar status do pagamento: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Processar webhook do Mercado Pago
     */
    public function processWebhook(array $data): array
    {
        if (!$this->isConfigured()) {
            throw new \Exception('Mercado Pago não está configurado');
        }

        try {
            $paymentId = $data['data']['id'] ?? null;
            
            if (!$paymentId) {
                return [
                    'success' => false,
                    'message' => 'ID do pagamento não encontrado'
                ];
            }

            $paymentStatus = $this->getPaymentStatus($paymentId);
            
            if (!$paymentStatus['success']) {
                return $paymentStatus;
            }

            // Buscar pedido pelo payment_id
            $order = Order::where('mercado_pago_payment_id', $paymentId)->first();
            
            if (!$order) {
                return [
                    'success' => false,
                    'message' => 'Pedido não encontrado'
                ];
            }

            // Atualizar status do pedido baseado no pagamento
            switch ($paymentStatus['status']) {
                case 'approved':
                    $order->updateStatus('confirmed');
                    break;
                case 'pending':
                    // Manter como pending
                    break;
                case 'rejected':
                case 'cancelled':
                    $order->updateStatus('cancelled');
                    break;
            }

            return [
                'success' => true,
                'message' => 'Webhook processado com sucesso',
                'order_id' => $order->id,
                'payment_status' => $paymentStatus['status']
            ];

        } catch (\Exception $e) {
            Log::error('Erro ao processar webhook Mercado Pago: ' . $e->getMessage());
            
            return [
                'success' => false,
                'message' => 'Erro ao processar webhook: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Obter métodos de pagamento disponíveis
     */
    public function getPaymentMethods(): array
    {
        if (!$this->isConfigured()) {
            return [
                'success' => false,
                'message' => 'Mercado Pago não está configurado'
            ];
        }

        try {
            $paymentMethods = \MercadoPago\PaymentMethod::all();
            
            return [
                'success' => true,
                'data' => $paymentMethods
            ];

        } catch (\Exception $e) {
            Log::error('Erro ao obter métodos de pagamento: ' . $e->getMessage());
            
            return [
                'success' => false,
                'message' => 'Erro ao obter métodos de pagamento: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Validar configuração
     */
    public function validateConfiguration(): array
    {
        if (!$this->isConfigured()) {
            return [
                'success' => false,
                'message' => 'Mercado Pago não está configurado'
            ];
        }

        try {
            // Testar acesso à API
            $paymentMethods = \MercadoPago\PaymentMethod::all();
            
            return [
                'success' => true,
                'message' => 'Configuração válida',
                'environment' => $this->environment
            ];

        } catch (\Exception $e) {
            Log::error('Erro ao validar configuração Mercado Pago: ' . $e->getMessage());
            
            return [
                'success' => false,
                'message' => 'Configuração inválida: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Obter configuração pública
     */
    public function getPublicConfig(): array
    {
        return [
            'public_key' => $this->publicKey,
            'environment' => $this->environment,
            'configured' => $this->isConfigured()
        ];
    }
}
