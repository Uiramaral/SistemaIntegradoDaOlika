<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Services\SuporteIAService;
use App\Models\ConversaSuporte;
use App\Models\MensagemSuporte;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class SuporteIAController extends Controller
{
    private $suporteIAService;

    public function __construct()
    {
        $this->suporteIAService = new SuporteIAService();
    }

    /**
     * Processar mensagem de suporte
     * POST /api/suporte/mensagem
     */
    public function processarMensagem(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'nome' => 'required|string|max:150',
            'telefone' => 'required|string|max:20',
            'mensagem' => 'required|string|max:2000',
            'subscriber_id' => 'nullable|string|max:50',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'error' => 'Dados inválidos',
                'details' => $validator->errors()
            ], 400);
        }

        try {
            $resultado = $this->suporteIAService->processarMensagem($request->all());

            return response()->json($resultado);

        } catch (\Exception $e) {
            Log::error('Erro no controller de suporte IA', [
                'error' => $e->getMessage(),
                'request' => $request->all()
            ]);

            return response()->json([
                'success' => false,
                'error' => 'Erro interno do servidor',
                'message' => 'Desculpe, ocorreu um erro. Tente novamente em alguns instantes.'
            ], 500);
        }
    }

    /**
     * Obter histórico por subscriber
     * GET /api/suporte/historico/subscriber/{id}
     */
    public function obterHistoricoPorSubscriber(string $subscriberId): JsonResponse
    {
        try {
            $conversa = ConversaSuporte::buscarAtivaPorSubscriber($subscriberId);
            
            if (!$conversa) {
                return response()->json([
                    'success' => false,
                    'message' => 'Nenhuma conversa encontrada para este subscriber'
                ], 404);
            }

            $mensagens = $conversa->mensagens()
                ->orderBy('created_at', 'asc')
                ->get()
                ->map(function ($msg) {
                    return [
                        'id' => $msg->id,
                        'role' => $msg->role,
                        'conteudo' => $msg->conteudo,
                        'classificacao' => $msg->classificacao,
                        'tokens_total' => $msg->tokens_total,
                        'custo_estimado' => $msg->custo_estimado,
                        'created_at' => $msg->created_at->toISOString(),
                    ];
                });

            return response()->json([
                'success' => true,
                'conversa' => [
                    'id' => $conversa->id,
                    'status' => $conversa->status,
                    'assunto' => $conversa->assunto,
                    'nome' => $conversa->nome,
                    'telefone' => $conversa->telefone,
                    'created_at' => $conversa->created_at->toISOString(),
                    'updated_at' => $conversa->updated_at->toISOString(),
                ],
                'mensagens' => $mensagens,
                'estatisticas' => $conversa->getEstatisticas()
            ]);

        } catch (\Exception $e) {
            Log::error('Erro ao obter histórico por subscriber', [
                'subscriber_id' => $subscriberId,
                'error' => $e->getMessage()
            ]);

            return response()->json([
                'success' => false,
                'error' => 'Erro interno do servidor'
            ], 500);
        }
    }

    /**
     * Obter estatísticas gerais
     * GET /api/suporte/estatisticas
     */
    public function obterEstatisticas(Request $request): JsonResponse
    {
        try {
            $periodo = $request->get('periodo', 'hoje'); // hoje, ontem, semana, mes
            $estatisticas = $this->suporteIAService->obterEstatisticas();

            // Adicionar estatísticas por período
            $estatisticas['periodo'] = $this->obterEstatisticasPorPeriodo($periodo);

            return response()->json([
                'success' => true,
                'estatisticas' => $estatisticas,
                'periodo' => $periodo,
                'timestamp' => now()->toISOString()
            ]);

        } catch (\Exception $e) {
            Log::error('Erro ao obter estatísticas', [
                'error' => $e->getMessage()
            ]);

            return response()->json([
                'success' => false,
                'error' => 'Erro interno do servidor'
            ], 500);
        }
    }

    /**
     * Obter conversas ativas
     * GET /api/suporte/conversas/ativas
     */
    public function obterConversasAtivas(Request $request): JsonResponse
    {
        try {
            $limit = $request->get('limit', 20);
            $offset = $request->get('offset', 0);

            $conversas = ConversaSuporte::ativas()
                ->with(['cliente', 'mensagens' => function($query) {
                    $query->orderBy('created_at', 'desc')->limit(1);
                }])
                ->orderBy('updated_at', 'desc')
                ->limit($limit)
                ->offset($offset)
                ->get()
                ->map(function ($conversa) {
                    $ultimaMensagem = $conversa->mensagens->first();
                    
                    return [
                        'id' => $conversa->id,
                        'nome' => $conversa->nome,
                        'telefone' => $conversa->telefone,
                        'subscriber_id' => $conversa->subscriber_id,
                        'status' => $conversa->status,
                        'assunto' => $conversa->assunto,
                        'total_mensagens' => $conversa->getTotalMensagens(),
                        'ultima_mensagem' => $ultimaMensagem ? [
                            'role' => $ultimaMensagem->role,
                            'conteudo' => $ultimaMensagem->conteudo,
                            'created_at' => $ultimaMensagem->created_at->toISOString(),
                        ] : null,
                        'created_at' => $conversa->created_at->toISOString(),
                        'updated_at' => $conversa->updated_at->toISOString(),
                    ];
                });

            return response()->json([
                'success' => true,
                'conversas' => $conversas,
                'total' => ConversaSuporte::ativas()->count(),
                'limit' => $limit,
                'offset' => $offset
            ]);

        } catch (\Exception $e) {
            Log::error('Erro ao obter conversas ativas', [
                'error' => $e->getMessage()
            ]);

            return response()->json([
                'success' => false,
                'error' => 'Erro interno do servidor'
            ], 500);
        }
    }

    /**
     * Encerrar conversa
     * POST /api/suporte/conversas/{id}/encerrar
     */
    public function encerrarConversa(int $conversaId): JsonResponse
    {
        try {
            $conversa = ConversaSuporte::find($conversaId);
            
            if (!$conversa) {
                return response()->json([
                    'success' => false,
                    'message' => 'Conversa não encontrada'
                ], 404);
            }

            $conversa->encerrar();

            Log::info('Conversa encerrada', [
                'conversa_id' => $conversaId,
                'subscriber_id' => $conversa->subscriber_id
            ]);

            return response()->json([
                'success' => true,
                'message' => 'Conversa encerrada com sucesso'
            ]);

        } catch (\Exception $e) {
            Log::error('Erro ao encerrar conversa', [
                'conversa_id' => $conversaId,
                'error' => $e->getMessage()
            ]);

            return response()->json([
                'success' => false,
                'error' => 'Erro interno do servidor'
            ], 500);
        }
    }

    /**
     * Obter detalhes de uma conversa
     * GET /api/suporte/conversas/{id}
     */
    public function obterDetalhesConversa(int $conversaId): JsonResponse
    {
        try {
            $conversa = ConversaSuporte::with(['cliente', 'mensagens'])
                ->find($conversaId);
            
            if (!$conversa) {
                return response()->json([
                    'success' => false,
                    'message' => 'Conversa não encontrada'
                ], 404);
            }

            $mensagens = $conversa->mensagens()
                ->orderBy('created_at', 'asc')
                ->get()
                ->map(function ($msg) {
                    return [
                        'id' => $msg->id,
                        'role' => $msg->role,
                        'conteudo' => $msg->conteudo,
                        'classificacao' => $msg->classificacao,
                        'tokens_total' => $msg->tokens_total,
                        'custo_estimado' => $msg->custo_estimado,
                        'model_usado' => $msg->model_usado,
                        'created_at' => $msg->created_at->toISOString(),
                    ];
                });

            return response()->json([
                'success' => true,
                'conversa' => [
                    'id' => $conversa->id,
                    'cliente_id' => $conversa->cliente_id,
                    'subscriber_id' => $conversa->subscriber_id,
                    'nome' => $conversa->nome,
                    'telefone' => $conversa->telefone,
                    'status' => $conversa->status,
                    'assunto' => $conversa->assunto,
                    'metadata' => $conversa->metadata,
                    'created_at' => $conversa->created_at->toISOString(),
                    'updated_at' => $conversa->updated_at->toISOString(),
                ],
                'cliente' => $conversa->cliente ? [
                    'id' => $conversa->cliente->id,
                    'name' => $conversa->cliente->name,
                    'email' => $conversa->cliente->email,
                    'loyalty_points' => $conversa->cliente->loyalty_points,
                    'order_count' => $conversa->cliente->order_count,
                ] : null,
                'mensagens' => $mensagens,
                'estatisticas' => $conversa->getEstatisticas()
            ]);

        } catch (\Exception $e) {
            Log::error('Erro ao obter detalhes da conversa', [
                'conversa_id' => $conversaId,
                'error' => $e->getMessage()
            ]);

            return response()->json([
                'success' => false,
                'error' => 'Erro interno do servidor'
            ], 500);
        }
    }

    /**
     * Obter estatísticas por período
     */
    private function obterEstatisticasPorPeriodo(string $periodo): array
    {
        $query = ConversaSuporte::query();
        $mensagensQuery = MensagemSuporte::query();

        switch ($periodo) {
            case 'hoje':
                $query->whereDate('created_at', today());
                $mensagensQuery->whereDate('created_at', today());
                break;
            case 'ontem':
                $query->whereDate('created_at', today()->subDay());
                $mensagensQuery->whereDate('created_at', today()->subDay());
                break;
            case 'semana':
                $query->where('created_at', '>=', today()->subWeek());
                $mensagensQuery->where('created_at', '>=', today()->subWeek());
                break;
            case 'mes':
                $query->where('created_at', '>=', today()->subMonth());
                $mensagensQuery->where('created_at', '>=', today()->subMonth());
                break;
        }

        $conversas = $query->get();
        $mensagens = $mensagensQuery->get();

        return [
            'conversas' => $conversas->count(),
            'mensagens' => $mensagens->count(),
            'tokens' => $mensagens->sum('tokens_total'),
            'custo' => round($mensagens->sum('custo_estimado'), 4),
            'assuntos' => $conversas->groupBy('assunto')->map->count(),
            'intencoes' => $mensagens->whereNotNull('classificacao->intencao')
                ->groupBy('classificacao->intencao')
                ->map->count(),
        ];
    }
}
