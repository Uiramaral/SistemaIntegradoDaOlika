<?php

namespace App\Services\Whatsapp;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use App\Models\WhatsappRule;
use App\Models\WhatsappTemplate;

class NonOfficialAdapter implements WhatsappAdapterInterface
{
    protected string $baseUrl;
    protected string $token;

    public function __construct()
    {
        $this->baseUrl = rtrim(config('services.whatsapp_gateway.base_url'), '/');
        $this->token = config('services.whatsapp_gateway.token');
        
        // Validar configurações obrigatórias
        if (empty($this->baseUrl)) {
            throw new \Exception('WHATS_GATEWAY_BASE_URL não configurado no .env');
        }
        
        if (empty($this->token)) {
            throw new \Exception('WHATS_GATEWAY_TOKEN não configurado no .env');
        }
    }

    public function connect(int $lojaId, string $phone): array
    {
        try {
            Log::info('Conectando sessão WhatsApp não-oficial', [
                'loja_id' => $lojaId,
                'phone' => $phone
            ]);

            $response = Http::withToken($this->token)
                ->timeout(30)
                ->post("{$this->baseUrl}/sessions", [
                    'phone' => $phone,
                    'mode' => 'pairing_code'
                ]);

            if (!$response->successful()) {
                throw new \Exception('Erro ao conectar: ' . $response->body());
            }

            $data = $response->json();

            return [
                'status' => $data['status'] ?? 'connecting',
                'pairing_code' => $data['pairing_code'] ?? null,
                'instance_id' => $data['instance_id'] ?? null,
                'auth_meta' => $data['auth_meta'] ?? null
            ];

        } catch (\Exception $e) {
            Log::error('Erro ao conectar sessão WhatsApp não-oficial', [
                'loja_id' => $lojaId,
                'phone' => $phone,
                'error' => $e->getMessage()
            ]);

            return [
                'status' => 'error',
                'pairing_code' => null,
                'instance_id' => null,
                'auth_meta' => null,
                'error' => $e->getMessage()
            ];
        }
    }

    public function status(int $sessionId): array
    {
        try {
            $response = Http::withToken($this->token)
                ->timeout(10)
                ->get("{$this->baseUrl}/sessions/{$sessionId}/status");

            if (!$response->successful()) {
                return ['status' => 'disconnected', 'instance_id' => null];
            }

            $data = $response->json();

            return [
                'status' => $data['status'] ?? 'disconnected',
                'instance_id' => $data['instance_id'] ?? null
            ];

        } catch (\Exception $e) {
            Log::error('Erro ao verificar status da sessão', [
                'session_id' => $sessionId,
                'error' => $e->getMessage()
            ]);

            return ['status' => 'disconnected', 'instance_id' => null];
        }
    }

    public function sendText(int $sessionId, string $to, string $text, array $meta = []): array
    {
        try {
            Log::info('Enviando mensagem de texto', [
                'session_id' => $sessionId,
                'to' => $to,
                'text_length' => strlen($text)
            ]);

            $response = Http::withToken($this->token)
                ->timeout(30)
                ->post("{$this->baseUrl}/messages", [
                    'session_id' => $sessionId,
                    'to' => $to,
                    'type' => 'text',
                    'text' => $text,
                    'meta' => $meta
                ]);

            if (!$response->successful()) {
                throw new \Exception('Erro ao enviar mensagem: ' . $response->body());
            }

            $data = $response->json();

            return [
                'provider_msg_id' => $data['id'] ?? null,
                'status' => $data['status'] ?? 'sent'
            ];

        } catch (\Exception $e) {
            Log::error('Erro ao enviar mensagem de texto', [
                'session_id' => $sessionId,
                'to' => $to,
                'error' => $e->getMessage()
            ]);

            return [
                'provider_msg_id' => null,
                'status' => 'failed',
                'error' => $e->getMessage()
            ];
        }
    }

    public function sendTemplate(int $sessionId, string $to, string $templateName, array $vars = []): array
    {
        try {
            // Buscar regra do template (adapter 'non_official' ou 'any')
            $rule = WhatsappRule::where('template_name', $templateName)
                ->where(function($q) {
                    $q->where('adapter', 'non_official')
                      ->orWhere('adapter', 'any');
                })
                ->where('enabled', true)
                ->first();

            if (!$rule) {
                throw new \Exception("Template '{$templateName}' não encontrado ou desabilitado");
            }

            // Renderizar template
            $text = $rule->renderTemplate($vars);

            Log::info('Enviando template', [
                'session_id' => $sessionId,
                'to' => $to,
                'template_name' => $templateName,
                'vars' => $vars
            ]);

            // Enviar como mensagem de texto
            return $this->sendText($sessionId, $to, $text, [
                'template_name' => $templateName,
                'template_vars' => $vars
            ]);

        } catch (\Exception $e) {
            Log::error('Erro ao enviar template', [
                'session_id' => $sessionId,
                'to' => $to,
                'template_name' => $templateName,
                'error' => $e->getMessage()
            ]);

            return [
                'provider_msg_id' => null,
                'status' => 'failed',
                'error' => $e->getMessage()
            ];
        }
    }

    public function sendMedia(int $sessionId, string $to, string $mediaUrl, string $type = 'image', string $caption = ''): array
    {
        try {
            Log::info('Enviando mídia', [
                'session_id' => $sessionId,
                'to' => $to,
                'type' => $type,
                'media_url' => $mediaUrl
            ]);

            $response = Http::withToken($this->token)
                ->timeout(30)
                ->post("{$this->baseUrl}/messages", [
                    'session_id' => $sessionId,
                    'to' => $to,
                    'type' => $type,
                    'media_url' => $mediaUrl,
                    'caption' => $caption
                ]);

            if (!$response->successful()) {
                throw new \Exception('Erro ao enviar mídia: ' . $response->body());
            }

            $data = $response->json();

            return [
                'provider_msg_id' => $data['id'] ?? null,
                'status' => $data['status'] ?? 'sent'
            ];

        } catch (\Exception $e) {
            Log::error('Erro ao enviar mídia', [
                'session_id' => $sessionId,
                'to' => $to,
                'type' => $type,
                'error' => $e->getMessage()
            ]);

            return [
                'provider_msg_id' => null,
                'status' => 'failed',
                'error' => $e->getMessage()
            ];
        }
    }

    public function isAvailable(): bool
    {
        try {
            $response = Http::withToken($this->token)
                ->timeout(5)
                ->get("{$this->baseUrl}/health");

            return $response->successful();
        } catch (\Exception $e) {
            return false;
        }
    }

    public function getInfo(): array
    {
        return [
            'name' => 'Non-Official WhatsApp Gateway',
            'type' => 'non_official',
            'base_url' => $this->baseUrl,
            'available' => $this->isAvailable()
        ];
    }
}
