@extends('dashboard.layout-complete')

@section('title', 'Configurações - Cardápio Digital Olika')
@section('page-title', 'Configurações do Sistema')

@section('content')
<div class="space-y-6">
    <!-- Header -->
    <div class="bg-white rounded-xl p-6 shadow-lg">
        <div class="flex items-center justify-between">
            <div>
                <h2 class="text-2xl font-bold text-gray-900">Configurações do Sistema</h2>
                <p class="text-gray-600">Gerencie as configurações gerais do seu restaurante</p>
            </div>
            <button id="save-all-settings" class="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition">
                Salvar Todas as Configurações
            </button>
        </div>
    </div>

    <!-- Configurações em Abas -->
    <div class="bg-white rounded-xl shadow-lg">
        <!-- Navegação das Abas -->
        <div class="border-b border-gray-200">
            <nav class="flex space-x-8 px-6" aria-label="Tabs">
                <button class="tab-button active py-4 px-1 border-b-2 border-blue-500 font-medium text-sm text-blue-600" data-tab="general">
                    Informações Gerais
                </button>
                <button class="tab-button py-4 px-1 border-b-2 border-transparent font-medium text-sm text-gray-500 hover:text-gray-700" data-tab="delivery">
                    Entrega
                </button>
                <button class="tab-button py-4 px-1 border-b-2 border-transparent font-medium text-sm text-gray-500 hover:text-gray-700" data-tab="payment">
                    Pagamento
                </button>
                <button class="tab-button py-4 px-1 border-b-2 border-transparent font-medium text-sm text-gray-500 hover:text-gray-700" data-tab="integrations">
                    Integrações
                </button>
                <button class="tab-button py-4 px-1 border-b-2 border-transparent font-medium text-sm text-gray-500 hover:text-gray-700" data-tab="notifications">
                    Notificações
                </button>
            </nav>
        </div>

        <!-- Conteúdo das Abas -->
        <div class="p-6">
            <!-- Aba: Informações Gerais -->
            <div id="tab-general" class="tab-content">
                <form class="space-y-6">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <!-- Nome do Restaurante -->
                        <div class="md:col-span-2">
                            <label class="block text-sm font-medium text-gray-700 mb-2">Nome do Restaurante *</label>
                            <input type="text" name="business_name" value="Olika" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>
                        
                        <!-- Descrição -->
                        <div class="md:col-span-2">
                            <label class="block text-sm font-medium text-gray-700 mb-2">Descrição do Negócio</label>
                            <textarea name="business_description" rows="3" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="Descreva seu restaurante...">Deliciosos pratos preparados com carinho e qualidade.</textarea>
                        </div>
                        
                        <!-- Telefone -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Telefone *</label>
                            <input type="tel" name="phone" value="(11) 99999-9999" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>
                        
                        <!-- E-mail -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">E-mail *</label>
                            <input type="email" name="email" value="contato@olika.com" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>
                        
                        <!-- Endereço -->
                        <div class="md:col-span-2">
                            <label class="block text-sm font-medium text-gray-700 mb-2">Endereço Completo</label>
                            <input type="text" name="address" value="Rua das Flores, 123 - Centro, São Paulo/SP" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>
                        
                        <!-- Horário de Funcionamento -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Horário de Abertura</label>
                            <input type="time" name="opening_time" value="08:00" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Horário de Fechamento</label>
                            <input type="time" name="closing_time" value="18:00" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>
                        
                        <!-- Logo -->
                        <div class="md:col-span-2">
                            <label class="block text-sm font-medium text-gray-700 mb-2">Logo do Restaurante</label>
                            <input type="file" name="logo" accept="image/*" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>
                    </div>
                </form>
            </div>

            <!-- Aba: Entrega -->
            <div id="tab-delivery" class="tab-content hidden">
                <form class="space-y-6">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <!-- Ativar Entrega -->
                        <div class="md:col-span-2">
                            <div class="flex items-center">
                                <input type="checkbox" name="delivery_enabled" id="delivery_enabled" class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500" checked>
                                <label for="delivery_enabled" class="ml-2 text-sm font-medium text-gray-700">Ativar serviço de entrega</label>
                            </div>
                        </div>
                        
                        <!-- Taxa de Entrega Padrão -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Taxa de Entrega Padrão (R$)</label>
                            <input type="number" name="default_delivery_fee" value="5.00" step="0.01" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>
                        
                        <!-- Valor Mínimo para Entrega -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Valor Mínimo para Entrega (R$)</label>
                            <input type="number" name="min_delivery_value" value="30.00" step="0.01" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>
                        
                        <!-- Tempo de Entrega -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Tempo de Entrega (minutos)</label>
                            <input type="number" name="delivery_time" value="45" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>
                        
                        <!-- Raio de Entrega -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Raio de Entrega (km)</label>
                            <input type="number" name="delivery_radius" value="10" step="0.1" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>
                        
                        <!-- Frete Grátis -->
                        <div class="md:col-span-2">
                            <div class="flex items-center">
                                <input type="checkbox" name="free_delivery_enabled" id="free_delivery_enabled" class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500" checked>
                                <label for="free_delivery_enabled" class="ml-2 text-sm font-medium text-gray-700">Oferecer frete grátis</label>
                            </div>
                        </div>
                        
                        <!-- Valor para Frete Grátis -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Valor para Frete Grátis (R$)</label>
                            <input type="number" name="free_delivery_value" value="50.00" step="0.01" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>
                    </div>
                </form>
            </div>

            <!-- Aba: Pagamento -->
            <div id="tab-payment" class="tab-content hidden">
                <form class="space-y-6">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <!-- Métodos de Pagamento -->
                        <div class="md:col-span-2">
                            <label class="block text-sm font-medium text-gray-700 mb-3">Métodos de Pagamento Aceitos</label>
                            <div class="space-y-3">
                                <div class="flex items-center">
                                    <input type="checkbox" name="payment_cash" id="payment_cash" class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500" checked>
                                    <label for="payment_cash" class="ml-2 text-sm font-medium text-gray-700">Dinheiro</label>
                                </div>
                                <div class="flex items-center">
                                    <input type="checkbox" name="payment_card" id="payment_card" class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500" checked>
                                    <label for="payment_card" class="ml-2 text-sm font-medium text-gray-700">Cartão (Débito/Crédito)</label>
                                </div>
                                <div class="flex items-center">
                                    <input type="checkbox" name="payment_pix" id="payment_pix" class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500" checked>
                                    <label for="payment_pix" class="ml-2 text-sm font-medium text-gray-700">PIX</label>
                                </div>
                                <div class="flex items-center">
                                    <input type="checkbox" name="payment_whatsapp" id="payment_whatsapp" class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500" checked>
                                    <label for="payment_whatsapp" class="ml-2 text-sm font-medium text-gray-700">WhatsApp</label>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Configurações do Mercado Pago -->
                        <div class="md:col-span-2">
                            <h3 class="text-lg font-semibold text-gray-900 mb-4">Mercado Pago</h3>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Access Token</label>
                            <input type="text" name="mercadopago_access_token" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="APP_USR-...">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Public Key</label>
                            <input type="text" name="mercadopago_public_key" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="APP_USR-...">
                        </div>
                        
                        <!-- Ambiente -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Ambiente</label>
                            <select name="mercadopago_environment" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                                <option value="sandbox">Sandbox (Teste)</option>
                                <option value="production">Produção</option>
                            </select>
                        </div>
                    </div>
                </form>
            </div>

            <!-- Aba: Integrações -->
            <div id="tab-integrations" class="tab-content hidden">
                <form class="space-y-6">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <!-- WhatsApp -->
                        <div class="md:col-span-2">
                            <h3 class="text-lg font-semibold text-gray-900 mb-4">WhatsApp</h3>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Número do WhatsApp</label>
                            <input type="tel" name="whatsapp_number" value="5511999999999" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Token da API</label>
                            <input type="text" name="whatsapp_token" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="Seu token do WhatsApp Business API">
                        </div>
                        
                        <!-- Google Maps -->
                        <div class="md:col-span-2">
                            <h3 class="text-lg font-semibold text-gray-900 mb-4">Google Maps</h3>
                        </div>
                        
                        <div class="md:col-span-2">
                            <label class="block text-sm font-medium text-gray-700 mb-2">API Key do Google Maps</label>
                            <input type="text" name="google_maps_api_key" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="AIza...">
                        </div>
                        
                        <!-- IA WhatsApp -->
                        <div class="md:col-span-2">
                            <h3 class="text-lg font-semibold text-gray-900 mb-4">IA WhatsApp</h3>
                        </div>
                        
                        <div class="md:col-span-2">
                            <div class="flex items-center">
                                <input type="checkbox" name="ai_whatsapp_enabled" id="ai_whatsapp_enabled" class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500" checked>
                                <label for="ai_whatsapp_enabled" class="ml-2 text-sm font-medium text-gray-700">Ativar IA para WhatsApp</label>
                            </div>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Modelo de IA</label>
                            <select name="ai_model" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                                <option value="gpt-3.5-turbo">GPT-3.5 Turbo</option>
                                <option value="gpt-5-nano">GPT-5 Nano</option>
                                <option value="claude-3">Claude 3</option>
                            </select>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">API Key da IA</label>
                            <input type="text" name="ai_api_key" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="Sua API key...">
                        </div>
                    </div>
                </form>
            </div>

            <!-- Aba: Notificações -->
            <div id="tab-notifications" class="tab-content hidden">
                <form class="space-y-6">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <!-- Notificações de Pedidos -->
                        <div class="md:col-span-2">
                            <h3 class="text-lg font-semibold text-gray-900 mb-4">Notificações de Pedidos</h3>
                        </div>
                        
                        <div class="md:col-span-2">
                            <div class="flex items-center">
                                <input type="checkbox" name="notify_new_orders" id="notify_new_orders" class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500" checked>
                                <label for="notify_new_orders" class="ml-2 text-sm font-medium text-gray-700">Notificar novos pedidos</label>
                            </div>
                        </div>
                        
                        <div class="md:col-span-2">
                            <div class="flex items-center">
                                <input type="checkbox" name="notify_order_updates" id="notify_order_updates" class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500" checked>
                                <label for="notify_order_updates" class="ml-2 text-sm font-medium text-gray-700">Notificar atualizações de pedidos</label>
                            </div>
                        </div>
                        
                        <!-- E-mail de Notificações -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">E-mail para Notificações</label>
                            <input type="email" name="notification_email" value="admin@olika.com" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>
                        
                        <!-- WhatsApp para Notificações -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">WhatsApp para Notificações</label>
                            <input type="tel" name="notification_whatsapp" value="5511999999999" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>
                        
                        <!-- Configurações de Horário -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Horário de Funcionamento para Notificações</label>
                            <input type="time" name="notification_start_time" value="08:00" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Até</label>
                            <input type="time" name="notification_end_time" value="22:00" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Navegação das abas
    const tabButtons = document.querySelectorAll('.tab-button');
    const tabContents = document.querySelectorAll('.tab-content');
    
    tabButtons.forEach(button => {
        button.addEventListener('click', function() {
            const targetTab = this.dataset.tab;
            
            // Remover classe ativa de todos os botões
            tabButtons.forEach(btn => {
                btn.classList.remove('active', 'border-blue-500', 'text-blue-600');
                btn.classList.add('border-transparent', 'text-gray-500');
            });
            
            // Adicionar classe ativa ao botão clicado
            this.classList.add('active', 'border-blue-500', 'text-blue-600');
            this.classList.remove('border-transparent', 'text-gray-500');
            
            // Ocultar todos os conteúdos
            tabContents.forEach(content => {
                content.classList.add('hidden');
            });
            
            // Mostrar conteúdo da aba selecionada
            document.getElementById(`tab-${targetTab}`).classList.remove('hidden');
        });
    });
    
    // Salvar configurações
    document.getElementById('save-all-settings').addEventListener('click', function() {
        const forms = document.querySelectorAll('form');
        const allData = {};
        
        forms.forEach(form => {
            const formData = new FormData(form);
            for (let [key, value] of formData.entries()) {
                allData[key] = value;
            }
        });
        
        // Simular salvamento
        showToast('Configurações salvas com sucesso!', 'success');
        
        // Aqui você faria a chamada para a API
        // saveSettings(allData);
    });
    
    // Validação em tempo real
    const requiredFields = document.querySelectorAll('input[required], select[required]');
    
    requiredFields.forEach(field => {
        field.addEventListener('blur', function() {
            if (!this.value.trim()) {
                this.classList.add('border-red-500');
                this.classList.remove('border-gray-300');
            } else {
                this.classList.remove('border-red-500');
                this.classList.add('border-gray-300');
            }
        });
    });
    
    // Formatação de telefone
    const phoneInputs = document.querySelectorAll('input[type="tel"]');
    
    phoneInputs.forEach(input => {
        input.addEventListener('input', function() {
            let value = this.value.replace(/\D/g, '');
            if (value.length > 0) {
                if (value.length <= 2) {
                    value = `(${value}`;
                } else if (value.length <= 7) {
                    value = `(${value.slice(0, 2)}) ${value.slice(2)}`;
                } else if (value.length <= 11) {
                    value = `(${value.slice(0, 2)}) ${value.slice(2, 7)}-${value.slice(7)}`;
                } else {
                    value = `(${value.slice(0, 2)}) ${value.slice(2, 7)}-${value.slice(7, 11)}`;
                }
            }
            this.value = value;
        });
    });
    
    // Formatação de CEP
    const cepInput = document.querySelector('input[name="cep"]');
    if (cepInput) {
        cepInput.addEventListener('input', function() {
            let value = this.value.replace(/\D/g, '');
            if (value.length > 0) {
                if (value.length <= 5) {
                    value = value;
                } else {
                    value = `${value.slice(0, 5)}-${value.slice(5, 8)}`;
                }
            }
            this.value = value;
        });
    }
    
    // Toggle de funcionalidades
    const toggles = document.querySelectorAll('input[type="checkbox"]');
    
    toggles.forEach(toggle => {
        toggle.addEventListener('change', function() {
            const dependentFields = this.closest('div').querySelectorAll('input, select');
            dependentFields.forEach(field => {
                if (field !== this) {
                    field.disabled = !this.checked;
                }
            });
        });
    });
});
</script>
@endpush
@endsection
