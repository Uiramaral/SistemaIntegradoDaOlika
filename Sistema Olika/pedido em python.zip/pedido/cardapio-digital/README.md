# Sistema de Cardápio Digital Olika

Sistema completo de cardápio digital desenvolvido em PHP/Laravel, convertido do sistema React original. Inclui todas as funcionalidades de gestão de produtos, pedidos, clientes, cupons, programa de fidelidade, PDV e integrações externas.

## 🚀 Funcionalidades Implementadas

### ✅ Sistema Completo de Gestão

1. **Gestão de Clientes**
   - Cadastro completo com dados pessoais e endereço
   - Sistema de aniversário para promoções
   - Histórico de pedidos e gastos
   - Programa de fidelidade integrado
   - Sistema de indicações

2. **Gestão de Produtos e Categorias**
   - Cadastro de produtos com imagens
   - Categorização de produtos
   - Controle de disponibilidade e visibilidade
   - Produtos em destaque
   - Busca e filtros avançados

3. **Sistema de Cupons e Promoções**
   - Cupons por porcentagem ou valor fixo
   - Cupons para primeira compra
   - Validação de valor mínimo
   - Controle de validade e limite de uso
   - Cupons públicos e privados

4. **Programa de Fidelidade**
   - Pontos por real gasto
   - Sistema de indicações
   - Bônus de aniversário
   - Resgate de pontos
   - Configuração flexível

5. **Gestão de Pedidos**
   - Controle de status em tempo real
   - Histórico completo de pedidos
   - Informações detalhadas do cliente
   - Resumo financeiro
   - Integração com programa de fidelidade

6. **Sistema PDV (Ponto de Venda)**
   - Interface de venda direta
   - Seleção de clientes
   - Processamento de pagamento
   - Finalização de pedidos
   - Integração com sistema de fidelidade

7. **Gestão de Taxas de Entrega**
   - Configuração por CEP
   - Zonas de entrega predefinidas
   - Cálculo automático de taxas
   - Entrega grátis configurável

8. **Integração Mercado Pago**
   - Configuração de access token
   - Criação de preferências de pagamento
   - Verificação de status de pagamento
   - Webhooks para confirmação
   - Ambiente sandbox e produção

9. **Integração WhatsApp**
   - Envio automático de pedidos
   - Notificações de status
   - Mensagens personalizadas
   - Teste de conexão

10. **Integração Google Maps**
    - Busca de endereços por CEP
    - Cálculo de distâncias
    - Verificação de área de entrega
    - Obtenção de coordenadas

11. **Dashboard com Estatísticas**
    - Métricas em tempo real
    - Top produtos
    - Receita total
    - Clientes ativos
    - Gráficos e relatórios

## 📁 Estrutura do Projeto

```
cardapio-digital/
├── app/
│   ├── Http/Controllers/Api/
│   │   ├── ProductController.php
│   │   ├── CategoryController.php
│   │   ├── CustomerController.php
│   │   ├── OrderController.php
│   │   ├── CouponController.php
│   │   ├── SettingsController.php
│   │   ├── DashboardController.php
│   │   ├── PDVController.php
│   │   ├── MercadoPagoController.php
│   │   └── WhatsAppController.php
│   ├── Models/
│   │   ├── Customer.php
│   │   ├── Product.php
│   │   ├── Category.php
│   │   ├── Order.php
│   │   ├── OrderItem.php
│   │   ├── Coupon.php
│   │   ├── LoyaltyProgram.php
│   │   ├── Referral.php
│   │   ├── DeliveryFee.php
│   │   ├── DeliverySchedule.php
│   │   └── Settings.php
│   └── Services/
│       ├── MercadoPagoService.php
│       ├── WhatsAppService.php
│       └── GoogleMapsService.php
├── database/
│   └── migrations/
│       ├── create_customers_table.php
│       ├── create_categories_table.php
│       ├── create_products_table.php
│       ├── create_orders_table.php
│       ├── create_order_items_table.php
│       ├── create_coupons_table.php
│       ├── create_loyalty_programs_table.php
│       ├── create_referrals_table.php
│       ├── create_delivery_fees_table.php
│       ├── create_delivery_schedules_table.php
│       └── create_settings_table.php
├── routes/
│   └── api.php
├── composer.json
└── README.md
```

## 🛠️ Instalação

### Pré-requisitos

- PHP 8.1 ou superior
- Composer
- MySQL 5.7 ou superior
- Laravel 10.x

### Passos de Instalação

1. **Clone o repositório**
   ```bash
   git clone <repository-url>
   cd cardapio-digital
   ```

2. **Instale as dependências**
   ```bash
   composer install
   ```

3. **Configure o ambiente**
   ```bash
   cp .env.example .env
   php artisan key:generate
   ```

4. **Configure o banco de dados**
   Edite o arquivo `.env` com suas configurações de banco:
   ```env
   DB_CONNECTION=mysql
   DB_HOST=127.0.0.1
   DB_PORT=3306
   DB_DATABASE=cardapio_digital
   DB_USERNAME=seu_usuario
   DB_PASSWORD=sua_senha
   ```

5. **Execute as migrations**
   ```bash
   php artisan migrate
   ```

6. **Execute os seeders (opcional)**
   ```bash
   php artisan db:seed
   ```

7. **Configure as integrações**
   Edite o arquivo `.env` com suas chaves de API:
   ```env
   # Mercado Pago
   MERCADOPAGO_ACCESS_TOKEN=seu_access_token
   MERCADOPAGO_PUBLIC_KEY=sua_public_key
   MERCADOPAGO_ENVIRONMENT=sandbox

   # WhatsApp API
   WHATSAPP_API_URL=sua_api_url
   WHATSAPP_API_TOKEN=seu_token

   # Google Maps
   GOOGLE_MAPS_API_KEY=sua_api_key
   ```

8. **Inicie o servidor**
   ```bash
   php artisan serve
   ```

## 🔧 Configuração

### Configurações do Sistema

Acesse `/api/settings` para configurar:

- Nome da empresa
- Cor primária
- Informações de contato
- Configurações de entrega
- Integrações externas

### Configuração do Mercado Pago

1. Acesse [Mercado Pago Developers](https://developers.mercadopago.com/)
2. Crie uma aplicação
3. Obtenha seu Access Token e Public Key
4. Configure no painel de administração

### Configuração do WhatsApp

1. Configure sua API do WhatsApp
2. Obtenha a URL e token de acesso
3. Configure no painel de administração

### Configuração do Google Maps

1. Acesse [Google Cloud Console](https://console.cloud.google.com/)
2. Ative a API do Google Maps
3. Obtenha sua API Key
4. Configure no painel de administração

## 📚 Documentação da API

### Endpoints Principais

#### Produtos
- `GET /api/products` - Listar produtos
- `POST /api/products` - Criar produto
- `GET /api/products/{id}` - Obter produto
- `PUT /api/products/{id}` - Atualizar produto
- `DELETE /api/products/{id}` - Deletar produto

#### Clientes
- `GET /api/customers` - Listar clientes
- `POST /api/customers` - Criar cliente
- `GET /api/customers/{id}` - Obter cliente
- `PUT /api/customers/{id}` - Atualizar cliente
- `DELETE /api/customers/{id}` - Deletar cliente

#### Pedidos
- `GET /api/orders` - Listar pedidos
- `POST /api/orders` - Criar pedido
- `GET /api/orders/{id}` - Obter pedido
- `POST /api/orders/{id}/status` - Atualizar status
- `POST /api/orders/{id}/complete` - Finalizar pedido

#### PDV
- `GET /api/pdv/products` - Produtos para PDV
- `GET /api/pdv/customers` - Clientes para PDV
- `POST /api/pdv/orders` - Criar venda no PDV

### Exemplos de Uso

#### Criar um pedido
```bash
curl -X POST http://localhost:8000/api/orders \
  -H "Content-Type: application/json" \
  -d '{
    "customer_id": 1,
    "items": [
      {
        "product_id": 1,
        "quantity": 2
      }
    ],
    "payment_method": "whatsapp"
  }'
```

#### Atualizar status do pedido
```bash
curl -X POST http://localhost:8000/api/orders/1/status \
  -H "Content-Type: application/json" \
  -d '{
    "status": "confirmed"
  }'
```

## 🎯 Funcionalidades do PDV

### Interface de Venda
- Seleção de produtos por categoria
- Busca de produtos
- Carrinho de compras
- Seleção de cliente
- Processamento de pagamento

### Tipos de Pagamento
- Dinheiro (com cálculo de troco)
- Cartão
- PIX

### Integração com Sistema
- Pontos de fidelidade automáticos
- Atualização de histórico do cliente
- Notificações WhatsApp

## 🔄 Integrações

### Mercado Pago
- Criação de preferências de pagamento
- Verificação de status
- Webhooks para confirmação
- Suporte a sandbox e produção

### WhatsApp
- Envio de pedidos
- Notificações de status
- Mensagens personalizadas
- Teste de conexão

### Google Maps
- Busca de endereços
- Cálculo de distâncias
- Verificação de área de entrega
- Coordenadas geográficas

## 📊 Dashboard e Relatórios

### Estatísticas
- Total de pedidos
- Receita total
- Número de clientes
- Valor médio do pedido
- Pedidos do dia
- Receita do dia

### Gráficos
- Evolução de pedidos
- Evolução de receita
- Top produtos
- Distribuição por status

## 🛡️ Segurança

- Validação de dados
- Sanitização de inputs
- Rate limiting
- CORS configurado
- Logs de auditoria

## 🚀 Deploy

### Produção
1. Configure o ambiente de produção
2. Execute `composer install --optimize-autoloader --no-dev`
3. Execute `php artisan config:cache`
4. Execute `php artisan route:cache`
5. Execute `php artisan view:cache`

### Docker (Opcional)
```dockerfile
FROM php:8.1-fpm
# Adicione suas configurações Docker aqui
```

## 🤝 Contribuição

1. Fork o projeto
2. Crie uma branch para sua feature
3. Commit suas mudanças
4. Push para a branch
5. Abra um Pull Request

## 📄 Licença

Este projeto está sob a licença MIT. Veja o arquivo [LICENSE](LICENSE) para mais detalhes.

## 📞 Suporte

Para dúvidas ou problemas:
- Abra uma issue no GitHub
- Entre em contato via email
- Consulte a documentação da API

## 🔄 Changelog

### v1.0.0
- Sistema completo de cardápio digital
- Todas as funcionalidades do sistema React original
- Integrações com Mercado Pago, WhatsApp e Google Maps
- Sistema PDV completo
- Dashboard com estatísticas
- API REST completa

---

**Desenvolvido com ❤️ para a Olika - Pães Artesanais**
