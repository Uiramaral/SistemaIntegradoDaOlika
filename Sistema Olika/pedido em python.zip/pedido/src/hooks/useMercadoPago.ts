import { useState } from 'react';
import { useMenu } from '@/contexts/MenuContext';
import { Order } from '@/types/menu';

interface MercadoPagoPreference {
  id: string;
  init_point: string;
}

export const useMercadoPago = () => {
  const { config } = useMenu();
  const [loading, setLoading] = useState(false);

  const createPreference = async (order: Order): Promise<MercadoPagoPreference | null> => {
    if (!config.mercadoPagoAccessToken) {
      console.error('Mercado Pago não configurado');
      return null;
    }

    setLoading(true);
    
    try {
      // Preparar items para o Mercado Pago
      const items = order.items.map(item => ({
        title: item.name,
        description: item.description,
        picture_url: item.image,
        quantity: item.quantity,
        unit_price: item.price,
        currency_id: 'BRL'
      }));

      // Adicionar taxa de entrega se houver
      if (order.deliveryFee > 0) {
        items.push({
          title: 'Taxa de Entrega',
          description: 'Taxa de entrega do pedido',
          picture_url: '',
          quantity: 1,
          unit_price: order.deliveryFee,
          currency_id: 'BRL'
        });
      }

      // Criar preferência
      const preference = {
        items,
        back_urls: {
          success: `${window.location.origin}/order-success?order_id=${order.id}`,
          failure: `${window.location.origin}/checkout`,
          pending: `${window.location.origin}/order-success?order_id=${order.id}&status=pending`
        },
        auto_return: 'approved' as const,
        external_reference: order.id,
        statement_descriptor: config.businessName,
        metadata: {
          order_id: order.id,
          customer_id: order.customerId
        }
      };

      // Simular criação de preferência (em produção, isso seria uma chamada ao backend)
      // Por enquanto, vamos simular com um ID fake
      const mockPreference: MercadoPagoPreference = {
        id: `PREF-${Date.now()}`,
        init_point: `https://www.mercadopago.com.br/checkout/v1/redirect?pref_id=PREF-${Date.now()}`
      };

      return mockPreference;
    } catch (error) {
      console.error('Erro ao criar preferência Mercado Pago:', error);
      return null;
    } finally {
      setLoading(false);
    }
  };

  const isConfigured = !!config.mercadoPagoAccessToken;

  return {
    createPreference,
    isConfigured,
    loading
  };
};
