<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\Customer;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\LoyaltyProgram;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

class PDVController extends Controller
{
    /**
     * Obter produtos para PDV
     */
    public function products(Request $request): JsonResponse
    {
        $search = $request->get('search');
        $categoryId = $request->get('category_id');

        $products = Product::search($search, $categoryId, true, false) // PDV mostra todos os produtos disponíveis
            ->with('category')
            ->orderBy('featured', 'desc')
            ->orderBy('name', 'asc')
            ->get();

        return response()->json([
            'success' => true,
            'data' => $products
        ]);
    }

    /**
     * Obter clientes para PDV
     */
    public function customers(Request $request): JsonResponse
    {
        $search = $request->get('search');

        $query = Customer::query();

        if ($search) {
            $query->where(function ($q) use ($search) {
                $q->where('name', 'LIKE', "%{$search}%")
                  ->orWhere('phone', 'LIKE', "%{$search}%")
                  ->orWhere('email', 'LIKE', "%{$search}%");
            });
        }

        $customers = $query->orderBy('name', 'asc')->limit(50)->get();

        return response()->json([
            'success' => true,
            'data' => $customers
        ]);
    }

    /**
     * Buscar clientes
     */
    public function searchCustomers(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'search' => 'required|string|min:2'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Termo de busca é obrigatório (mínimo 2 caracteres)',
                'errors' => $validator->errors()
            ], 422);
        }

        $search = $request->search;

        $customers = Customer::where(function ($query) use ($search) {
            $query->where('name', 'LIKE', "%{$search}%")
                  ->orWhere('phone', 'LIKE', "%{$search}%")
                  ->orWhere('email', 'LIKE', "%{$search}%")
                  ->orWhere('referral_code', 'LIKE', "%{$search}%");
        })
        ->orderBy('name', 'asc')
        ->limit(20)
        ->get();

        return response()->json([
            'success' => true,
            'data' => $customers
        ]);
    }

    /**
     * Criar venda no PDV
     */
    public function createOrder(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'customer_id' => 'required|exists:customers,id',
            'items' => 'required|array|min:1',
            'items.*.product_id' => 'required|exists:products,id',
            'items.*.quantity' => 'required|integer|min:1',
            'payment_method' => 'required|in:cash,card,pix',
            'cash_received' => 'required_if:payment_method,cash|numeric|min:0',
            'observations' => 'nullable|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Dados inválidos',
                'errors' => $validator->errors()
            ], 422);
        }

        DB::beginTransaction();

        try {
            // Calcular subtotal
            $subtotal = 0;
            $items = [];

            foreach ($request->items as $itemData) {
                $product = Product::find($itemData['product_id']);
                
                if (!$product->isAvailableForSale()) {
                    throw new \Exception("Produto {$product->name} não está disponível para venda");
                }

                $itemTotal = $product->price * $itemData['quantity'];
                $subtotal += $itemTotal;

                $items[] = OrderItem::fromProduct($product, $itemData['quantity']);
            }

            // Calcular totais (PDV não tem taxa de entrega)
            $deliveryFee = 0;
            $discount = 0;
            $total = $subtotal + $deliveryFee - $discount;

            // Verificar pagamento em dinheiro
            if ($request->payment_method === 'cash') {
                $cashReceived = $request->cash_received;
                if ($cashReceived < $total) {
                    throw new \Exception('Valor recebido insuficiente');
                }
            }

            // Criar pedido
            $order = Order::create([
                'customer_id' => $request->customer_id,
                'subtotal' => $subtotal,
                'delivery_fee' => $deliveryFee,
                'discount' => $discount,
                'total' => $total,
                'observations' => $request->observations ?: "Venda no PDV - {$request->payment_method}",
                'payment_method' => 'whatsapp', // PDV sempre usa WhatsApp
                'status' => 'completed', // PDV sempre finaliza o pedido
            ]);

            // Criar itens do pedido
            foreach ($items as $itemData) {
                $order->items()->create($itemData);
            }

            // Aplicar pontos de fidelidade e finalizar
            $loyaltyProgram = LoyaltyProgram::getDefault();
            $order->processCompletion($loyaltyProgram);

            DB::commit();

            $order->load(['customer', 'items.product']);

            // Calcular troco se pagamento em dinheiro
            $change = 0;
            if ($request->payment_method === 'cash') {
                $change = $request->cash_received - $total;
            }

            return response()->json([
                'success' => true,
                'message' => 'Venda processada com sucesso',
                'data' => [
                    'order' => $order,
                    'change' => $change,
                    'payment_method' => $request->payment_method,
                    'cash_received' => $request->cash_received ?? null,
                ]
            ], 201);

        } catch (\Exception $e) {
            DB::rollback();
            
            return response()->json([
                'success' => false,
                'message' => 'Erro ao processar venda: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Obter pedidos recentes do PDV
     */
    public function recentOrders(Request $request): JsonResponse
    {
        $limit = $request->get('limit', 10);

        $orders = Order::with(['customer', 'items.product'])
            ->where('observations', 'LIKE', '%PDV%')
            ->orderBy('created_at', 'desc')
            ->limit($limit)
            ->get();

        return response()->json([
            'success' => true,
            'data' => $orders
        ]);
    }

    /**
     * Obter estatísticas do PDV
     */
    public function stats(Request $request): JsonResponse
    {
        $today = now()->startOfDay();
        $yesterday = $today->copy()->subDay();

        $todayOrders = Order::where('observations', 'LIKE', '%PDV%')
            ->whereDate('created_at', $today)
            ->get();

        $yesterdayOrders = Order::where('observations', 'LIKE', '%PDV%')
            ->whereDate('created_at', $yesterday)
            ->get();

        $stats = [
            'today' => [
                'orders_count' => $todayOrders->count(),
                'total_revenue' => $todayOrders->sum('total'),
                'average_order_value' => $todayOrders->count() > 0 ? $todayOrders->sum('total') / $todayOrders->count() : 0,
            ],
            'yesterday' => [
                'orders_count' => $yesterdayOrders->count(),
                'total_revenue' => $yesterdayOrders->sum('total'),
                'average_order_value' => $yesterdayOrders->count() > 0 ? $yesterdayOrders->sum('total') / $yesterdayOrders->count() : 0,
            ],
            'growth' => [
                'orders_growth' => $this->calculateGrowth($yesterdayOrders->count(), $todayOrders->count()),
                'revenue_growth' => $this->calculateGrowth($yesterdayOrders->sum('total'), $todayOrders->sum('total')),
            ]
        ];

        return response()->json([
            'success' => true,
            'data' => $stats
        ]);
    }

    /**
     * Obter top produtos vendidos no PDV
     */
    public function topProducts(Request $request): JsonResponse
    {
        $days = $request->get('days', 7);
        $limit = $request->get('limit', 10);

        $startDate = now()->subDays($days)->startOfDay();

        $topProducts = DB::table('order_items')
            ->join('orders', 'order_items.order_id', '=', 'orders.id')
            ->join('products', 'order_items.product_id', '=', 'products.id')
            ->where('orders.observations', 'LIKE', '%PDV%')
            ->where('orders.created_at', '>=', $startDate)
            ->selectRaw('
                products.id,
                products.name,
                SUM(order_items.quantity) as total_quantity,
                SUM(order_items.quantity * order_items.price) as total_revenue
            ')
            ->groupBy('products.id', 'products.name')
            ->orderBy('total_revenue', 'desc')
            ->limit($limit)
            ->get();

        return response()->json([
            'success' => true,
            'data' => $topProducts
        ]);
    }

    /**
     * Calcular crescimento percentual
     */
    private function calculateGrowth(float $oldValue, float $newValue): float
    {
        if ($oldValue == 0) {
            return $newValue > 0 ? 100 : 0;
        }

        return (($newValue - $oldValue) / $oldValue) * 100;
    }

    /**
     * Obter produtos mais vendidos por categoria
     */
    public function topProductsByCategory(Request $request): JsonResponse
    {
        $days = $request->get('days', 7);
        $startDate = now()->subDays($days)->startOfDay();

        $topProductsByCategory = DB::table('order_items')
            ->join('orders', 'order_items.order_id', '=', 'orders.id')
            ->join('products', 'order_items.product_id', '=', 'products.id')
            ->join('categories', 'products.category_id', '=', 'categories.id')
            ->where('orders.observations', 'LIKE', '%PDV%')
            ->where('orders.created_at', '>=', $startDate)
            ->selectRaw('
                categories.id as category_id,
                categories.name as category_name,
                products.id as product_id,
                products.name as product_name,
                SUM(order_items.quantity) as total_quantity,
                SUM(order_items.quantity * order_items.price) as total_revenue
            ')
            ->groupBy('categories.id', 'categories.name', 'products.id', 'products.name')
            ->orderBy('categories.name')
            ->orderBy('total_revenue', 'desc')
            ->get()
            ->groupBy('category_name');

        return response()->json([
            'success' => true,
            'data' => $topProductsByCategory
        ]);
    }

    /**
     * Obter vendas por método de pagamento
     */
    public function salesByPaymentMethod(Request $request): JsonResponse
    {
        $days = $request->get('days', 7);
        $startDate = now()->subDays($days)->startOfDay();

        // Extrair método de pagamento das observações
        $cashOrders = Order::where('observations', 'LIKE', '%PDV%')
            ->where('observations', 'LIKE', '%cash%')
            ->where('created_at', '>=', $startDate)
            ->get();

        $cardOrders = Order::where('observations', 'LIKE', '%PDV%')
            ->where('observations', 'LIKE', '%card%')
            ->where('created_at', '>=', $startDate)
            ->get();

        $pixOrders = Order::where('observations', 'LIKE', '%PDV%')
            ->where('observations', 'LIKE', '%pix%')
            ->where('created_at', '>=', $startDate)
            ->get();

        $stats = [
            'cash' => [
                'count' => $cashOrders->count(),
                'total' => $cashOrders->sum('total'),
                'percentage' => 0
            ],
            'card' => [
                'count' => $cardOrders->count(),
                'total' => $cardOrders->sum('total'),
                'percentage' => 0
            ],
            'pix' => [
                'count' => $pixOrders->count(),
                'total' => $pixOrders->sum('total'),
                'percentage' => 0
            ]
        ];

        $totalRevenue = $cashOrders->sum('total') + $cardOrders->sum('total') + $pixOrders->sum('total');

        if ($totalRevenue > 0) {
            $stats['cash']['percentage'] = ($cashOrders->sum('total') / $totalRevenue) * 100;
            $stats['card']['percentage'] = ($cardOrders->sum('total') / $totalRevenue) * 100;
            $stats['pix']['percentage'] = ($pixOrders->sum('total') / $totalRevenue) * 100;
        }

        return response()->json([
            'success' => true,
            'data' => $stats
        ]);
    }
}
