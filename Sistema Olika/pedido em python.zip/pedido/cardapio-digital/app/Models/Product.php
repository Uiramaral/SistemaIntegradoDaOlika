<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Product extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'description',
        'price',
        'image',
        'category_id',
        'available',
        'featured',
        'visible',
    ];

    protected $casts = [
        'price' => 'decimal:2',
        'available' => 'boolean',
        'featured' => 'boolean',
        'visible' => 'boolean',
    ];

    protected $dates = [
        'created_at',
        'updated_at',
    ];

    /**
     * Relacionamento com categoria
     */
    public function category(): BelongsTo
    {
        return $this->belongsTo(Category::class);
    }

    /**
     * Relacionamento com itens de pedido
     */
    public function orderItems(): HasMany
    {
        return $this->hasMany(OrderItem::class);
    }

    /**
     * Scope para produtos disponíveis
     */
    public function scopeAvailable($query)
    {
        return $query->where('available', true);
    }

    /**
     * Scope para produtos visíveis
     */
    public function scopeVisible($query)
    {
        return $query->where('visible', true);
    }

    /**
     * Scope para produtos em destaque
     */
    public function scopeFeatured($query)
    {
        return $query->where('featured', true);
    }

    /**
     * Scope para produtos por categoria
     */
    public function scopeByCategory($query, $categoryId)
    {
        return $query->where('category_id', $categoryId);
    }

    /**
     * Buscar produtos com filtros
     */
    public static function search($search = null, $categoryId = null, $availableOnly = true, $visibleOnly = false)
    {
        $query = self::query();

        if ($search) {
            $query->where(function ($q) use ($search) {
                $q->where('name', 'LIKE', "%{$search}%")
                  ->orWhere('description', 'LIKE', "%{$search}%");
            });
        }

        if ($categoryId) {
            $query->where('category_id', $categoryId);
        }

        if ($availableOnly) {
            $query->available();
        }

        if ($visibleOnly) {
            $query->visible();
        }

        return $query->orderBy('featured', 'desc')
                    ->orderBy('name', 'asc');
    }

    /**
     * Obter URL da imagem ou placeholder
     */
    public function getImageUrlAttribute(): string
    {
        if ($this->image && filter_var($this->image, FILTER_VALIDATE_URL)) {
            return $this->image;
        }

        if ($this->image && file_exists(public_path('storage/' . $this->image))) {
            return asset('storage/' . $this->image);
        }

        return 'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=800&q=80';
    }

    /**
     * Formatar preço
     */
    public function getFormattedPriceAttribute(): string
    {
        return 'R$ ' . number_format($this->price, 2, ',', '.');
    }

    /**
     * Verificar se está disponível para venda
     */
    public function isAvailableForSale(): bool
    {
        return $this->available;
    }

    /**
     * Verificar se está visível no menu público
     */
    public function isVisibleInMenu(): bool
    {
        return $this->visible && $this->available;
    }

    /**
     * Atualizar disponibilidade
     */
    public function toggleAvailability(): void
    {
        $this->available = !$this->available;
        $this->save();
    }

    /**
     * Atualizar status de destaque
     */
    public function toggleFeatured(): void
    {
        $this->featured = !$this->featured;
        $this->save();
    }

    /**
     * Atualizar visibilidade
     */
    public function toggleVisibility(): void
    {
        $this->visible = !$this->visible;
        $this->save();
    }
}
