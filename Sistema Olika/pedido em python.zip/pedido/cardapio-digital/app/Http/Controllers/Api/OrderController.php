<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Customer;
use App\Models\Product;
use App\Models\LoyaltyProgram;
use App\Models\OrderItem;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

class OrderController extends Controller
{
    /**
     * Listar pedidos
     */
    public function index(Request $request): JsonResponse
    {
        $query = Order::with(['customer', 'items.product']);

        // Filtros
        if ($status = $request->get('status')) {
            $query->where('status', $status);
        }

        if ($customerId = $request->get('customer_id')) {
            $query->where('customer_id', $customerId);
        }

        if ($paymentMethod = $request->get('payment_method')) {
            $query->where('payment_method', $paymentMethod);
        }

        if ($dateFrom = $request->get('date_from')) {
            $query->whereDate('created_at', '>=', $dateFrom);
        }

        if ($dateTo = $request->get('date_to')) {
            $query->whereDate('created_at', '<=', $dateTo);
        }

        if ($search = $request->get('search')) {
            $query->where(function ($q) use ($search) {
                $q->where('id', 'LIKE', "%{$search}%")
                  ->orWhereHas('customer', function ($customerQuery) use ($search) {
                      $customerQuery->where('name', 'LIKE', "%{$search}%")
                                   ->orWhere('phone', 'LIKE', "%{$search}%");
                  });
            });
        }

        // Ordenação
        $sortBy = $request->get('sort_by', 'created_at');
        $sortOrder = $request->get('sort_order', 'desc');
        $query->orderBy($sortBy, $sortOrder);

        $orders = $query->paginate(20);

        return response()->json([
            'success' => true,
            'data' => $orders
        ]);
    }

    /**
     * Obter pedido específico
     */
    public function show(Order $order): JsonResponse
    {
        $order->load(['customer', 'items.product', 'coupon']);

        return response()->json([
            'success' => true,
            'data' => $order
        ]);
    }

    /**
     * Criar novo pedido
     */
    public function store(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'customer_id' => 'required|exists:customers,id',
            'items' => 'required|array|min:1',
            'items.*.product_id' => 'required|exists:products,id',
            'items.*.quantity' => 'required|integer|min:1',
            'delivery_fee' => 'numeric|min:0',
            'discount' => 'numeric|min:0',
            'coupon_code' => 'nullable|string|exists:coupons,code',
            'observations' => 'nullable|string',
            'payment_method' => 'required|in:whatsapp,mercadopago',
            'delivery_date' => 'nullable|date|after:today',
            'delivery_time_slot' => 'nullable|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Dados inválidos',
                'errors' => $validator->errors()
            ], 422);
        }

        DB::beginTransaction();

        try {
            // Calcular subtotal
            $subtotal = 0;
            $items = [];

            foreach ($request->items as $itemData) {
                $product = Product::find($itemData['product_id']);
                
                if (!$product->isAvailableForSale()) {
                    throw new \Exception("Produto {$product->name} não está disponível para venda");
                }

                $itemTotal = $product->price * $itemData['quantity'];
                $subtotal += $itemTotal;

                $items[] = OrderItem::fromProduct($product, $itemData['quantity']);
            }

            // Calcular totais
            $deliveryFee = $request->get('delivery_fee', 0);
            $discount = $request->get('discount', 0);
            $total = $subtotal + $deliveryFee - $discount;

            // Criar pedido
            $order = Order::create([
                'customer_id' => $request->customer_id,
                'subtotal' => $subtotal,
                'delivery_fee' => $deliveryFee,
                'discount' => $discount,
                'total' => $total,
                'coupon_code' => $request->coupon_code,
                'observations' => $request->observations,
                'payment_method' => $request->payment_method,
                'delivery_date' => $request->delivery_date,
                'delivery_time_slot' => $request->delivery_time_slot,
            ]);

            // Criar itens do pedido
            foreach ($items as $itemData) {
                $order->items()->create($itemData);
            }

            // Aplicar pontos de fidelidade
            $loyaltyProgram = LoyaltyProgram::getDefault();
            $order->applyLoyaltyPoints($loyaltyProgram);

            DB::commit();

            $order->load(['customer', 'items.product']);

            return response()->json([
                'success' => true,
                'message' => 'Pedido criado com sucesso',
                'data' => $order
            ], 201);

        } catch (\Exception $e) {
            DB::rollback();
            
            return response()->json([
                'success' => false,
                'message' => 'Erro ao criar pedido: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Atualizar status do pedido
     */
    public function updateStatus(Request $request, Order $order): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'status' => 'required|in:pending,confirmed,preparing,delivering,completed,cancelled'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Status inválido',
                'errors' => $validator->errors()
            ], 422);
        }

        $newStatus = $request->status;

        // Verificar se pode cancelar
        if ($newStatus === 'cancelled' && !$order->canBeCancelled()) {
            return response()->json([
                'success' => false,
                'message' => 'Pedido não pode ser cancelado neste status'
            ], 422);
        }

        $order->updateStatus($newStatus);

        // Se finalizado, processar completação
        if ($newStatus === 'completed') {
            $loyaltyProgram = LoyaltyProgram::getDefault();
            $order->processCompletion($loyaltyProgram);
        }

        return response()->json([
            'success' => true,
            'message' => 'Status do pedido atualizado',
            'data' => $order
        ]);
    }

    /**
     * Confirmar pedido
     */
    public function confirm(Order $order): JsonResponse
    {
        if (!$order->isPending()) {
            return response()->json([
                'success' => false,
                'message' => 'Apenas pedidos pendentes podem ser confirmados'
            ], 422);
        }

        $order->confirm();

        return response()->json([
            'success' => true,
            'message' => 'Pedido confirmado',
            'data' => $order
        ]);
    }

    /**
     * Marcar como em preparação
     */
    public function startPreparing(Order $order): JsonResponse
    {
        if (!$order->isConfirmed()) {
            return response()->json([
                'success' => false,
                'message' => 'Apenas pedidos confirmados podem iniciar preparação'
            ], 422);
        }

        $order->startPreparing();

        return response()->json([
            'success' => true,
            'message' => 'Pedido em preparação',
            'data' => $order
        ]);
    }

    /**
     * Marcar como em entrega
     */
    public function startDelivering(Order $order): JsonResponse
    {
        if (!$order->isPreparing()) {
            return response()->json([
                'success' => false,
                'message' => 'Apenas pedidos em preparação podem iniciar entrega'
            ], 422);
        }

        $order->startDelivering();

        return response()->json([
            'success' => true,
            'message' => 'Pedido em entrega',
            'data' => $order
        ]);
    }

    /**
     * Finalizar pedido
     */
    public function complete(Order $order): JsonResponse
    {
        if (!$order->isDelivering()) {
            return response()->json([
                'success' => false,
                'message' => 'Apenas pedidos em entrega podem ser finalizados'
            ], 422);
        }

        $loyaltyProgram = LoyaltyProgram::getDefault();
        $order->processCompletion($loyaltyProgram);

        return response()->json([
            'success' => true,
            'message' => 'Pedido finalizado',
            'data' => $order
        ]);
    }

    /**
     * Cancelar pedido
     */
    public function cancel(Order $order): JsonResponse
    {
        if (!$order->canBeCancelled()) {
            return response()->json([
                'success' => false,
                'message' => 'Pedido não pode ser cancelado'
            ], 422);
        }

        $order->cancel();

        return response()->json([
            'success' => true,
            'message' => 'Pedido cancelado',
            'data' => $order
        ]);
    }

    /**
     * Obter pedidos por status
     */
    public function byStatus(Request $request, string $status): JsonResponse
    {
        $orders = Order::with(['customer', 'items.product'])
            ->where('status', $status)
            ->orderBy('created_at', 'desc')
            ->paginate(20);

        return response()->json([
            'success' => true,
            'data' => $orders
        ]);
    }

    /**
     * Obter pedidos de hoje
     */
    public function today(): JsonResponse
    {
        $orders = Order::with(['customer', 'items.product'])
            ->today()
            ->orderBy('created_at', 'desc')
            ->get();

        return response()->json([
            'success' => true,
            'data' => $orders
        ]);
    }

    /**
     * Obter estatísticas de pedidos
     */
    public function stats(Request $request): JsonResponse
    {
        $dateFrom = $request->get('date_from', now()->startOfMonth());
        $dateTo = $request->get('date_to', now()->endOfMonth());

        $stats = [
            'total_orders' => Order::whereBetween('created_at', [$dateFrom, $dateTo])->count(),
            'total_revenue' => Order::whereBetween('created_at', [$dateFrom, $dateTo])->sum('total'),
            'average_order_value' => Order::whereBetween('created_at', [$dateFrom, $dateTo])->avg('total'),
            'orders_by_status' => Order::whereBetween('created_at', [$dateFrom, $dateTo])
                ->groupBy('status')
                ->selectRaw('status, count(*) as count')
                ->pluck('count', 'status'),
            'orders_today' => Order::today()->count(),
            'revenue_today' => Order::today()->sum('total'),
        ];

        return response()->json([
            'success' => true,
            'data' => $stats
        ]);
    }

    /**
     * Buscar pedidos
     */
    public function search(Request $request): JsonResponse
    {
        $search = $request->get('q');
        
        if (!$search) {
            return response()->json([
                'success' => false,
                'message' => 'Termo de busca é obrigatório'
            ], 422);
        }

        $orders = Order::with(['customer', 'items.product'])
            ->where(function ($query) use ($search) {
                $query->where('id', 'LIKE', "%{$search}%")
                      ->orWhereHas('customer', function ($customerQuery) use ($search) {
                          $customerQuery->where('name', 'LIKE', "%{$search}%")
                                       ->orWhere('phone', 'LIKE', "%{$search}%");
                      });
            })
            ->orderBy('created_at', 'desc')
            ->limit(50)
            ->get();

        return response()->json([
            'success' => true,
            'data' => $orders
        ]);
    }
}
