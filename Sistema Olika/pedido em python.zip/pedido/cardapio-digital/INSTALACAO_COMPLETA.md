# 🚀 **INSTALAÇÃO COMPLETA - CARDÁPIO DIGITAL OLIKA**

## 📋 **Guia Passo a Passo para Upload no Servidor**

### 🎯 **O que está incluído:**
- ✅ **Sistema Laravel completo** com IA para WhatsApp
- ✅ **Banco de dados unificado** (cardápio + IA)
- ✅ **15 produtos** de exemplo
- ✅ **4 categorias** configuradas
- ✅ **Sistema de IA** com 30+ exemplos de treinamento
- ✅ **Configurações** para Hostgator/produção

---

## 📁 **Arquivos para Upload**

### **1. Estrutura de Pastas:**
```
cardapio-digital/
├── app/                          # Código da aplicação
│   ├── Http/Controllers/         # Controllers
│   ├── Models/                   # Models
│   └── Services/                 # Serviços (IA, WhatsApp, etc.)
├── database/
│   └── CARDAPIO_DIGITAL_COMPLETO.sql  # Script SQL completo
├── routes/
│   ├── api.php                   # Rotas da API
│   └── web.php                   # Rotas web
├── config/
│   └── database.php              # Configuração do banco
├── bootstrap/
│   └── app.php                   # Bootstrap Laravel
├── public/
│   └── index.php                 # Ponto de entrada
├── composer.json                 # Dependências
├── artisan                      # CLI Laravel
├── env.production               # Configuração produção
└── README.md                    # Documentação
```

### **2. Arquivos Principais:**
- ✅ **`CARDAPIO_DIGITAL_COMPLETO.sql`** - Script SQL completo
- ✅ **`env.production`** - Configuração para produção
- ✅ **`composer.json`** - Dependências do Laravel
- ✅ **`artisan`** - CLI do Laravel
- ✅ **`public/index.php`** - Ponto de entrada

---

## 🗄️ **PASSO 1: CONFIGURAR BANCO DE DADOS**

### **1.1 Acessar phpMyAdmin:**
1. Entre no cPanel da Hostgator
2. Clique em **"phpMyAdmin"**
3. Selecione seu banco de dados

### **1.2 Importar Script SQL:**
1. Clique na aba **"Importar"**
2. Escolha o arquivo **`CARDAPIO_DIGITAL_COMPLETO.sql`**
3. Clique em **"Executar"**

### **1.3 Verificar Importação:**
```sql
-- Verificar se todas as tabelas foram criadas
SHOW TABLES;

-- Resultado esperado:
-- ai_conversations, ai_entity_patterns, ai_feedback, 
-- ai_intent_patterns, ai_performance_metrics, ai_training_data,
-- categories, coupons, customers, delivery_fees, delivery_schedules,
-- loyalty_programs, order_items, orders, personal_access_tokens,
-- products, referrals, settings
```

---

## 📁 **PASSO 2: UPLOAD DOS ARQUIVOS**

### **2.1 Via cPanel File Manager:**
1. Acesse **"Gerenciador de Arquivos"**
2. Vá para **`public_html`**
3. Crie pasta **`cardapio-digital`**
4. Faça upload de todos os arquivos

### **2.2 Via FTP:**
```bash
# Configurações FTP
Host: ftp.seudominio.com
Usuário: seu_usuario_ftp
Senha: sua_senha_ftp
Porta: 21

# Upload via FileZilla ou similar
```

### **2.3 Estrutura Final:**
```
public_html/
├── cardapio-digital/          # Seu projeto
│   ├── app/
│   ├── database/
│   ├── routes/
│   ├── config/
│   ├── public/
│   └── composer.json
└── outros_arquivos/
```

---

## ⚙️ **PASSO 3: CONFIGURAR APLICAÇÃO**

### **3.1 Renomear arquivo de configuração:**
```bash
# No servidor, renomeie:
env.production → .env
```

### **3.2 Editar configurações:**
```env
# Editar .env com seus dados
APP_URL=https://seudominio.com
DB_DATABASE=seu_usuario_cardapio_digital
DB_USERNAME=seu_usuario_mysql
DB_PASSWORD=sua_senha_mysql
```

### **3.3 Gerar chave da aplicação:**
```bash
# Via terminal (se disponível)
cd cardapio-digital
php artisan key:generate
```

### **3.4 Configurar permissões:**
```bash
# No cPanel File Manager
storage/ → 755
bootstrap/cache/ → 755
```

---

## 🌐 **PASSO 4: CONFIGURAR DOMÍNIO**

### **4.1 Opção A - Subdomínio:**
```
admin.seudominio.com → /public_html/cardapio-digital/public
```

### **4.2 Opção B - Pasta:**
```
seudominio.com/cardapio → /public_html/cardapio-digital/public
```

### **4.3 Opção C - Domínio Principal:**
```
seudominio.com → /public_html/cardapio-digital/public
```

---

## 🔧 **PASSO 5: CONFIGURAR INTEGRAÇÕES**

### **5.1 WhatsApp API:**
```env
WHATSAPP_API_URL=https://sua-api-whatsapp.com
WHATSAPP_API_TOKEN=seu_token
WHATSAPP_PHONE_NUMBER=5511999999999
```

### **5.2 Mercado Pago:**
```env
MERCADOPAGO_ACCESS_TOKEN=seu_token_producao
MERCADOPAGO_PUBLIC_KEY=sua_public_key_producao
```

### **5.3 Google Maps:**
```env
GOOGLE_MAPS_API_KEY=sua_chave_google_maps
```

---

## 🧪 **PASSO 6: TESTAR SISTEMA**

### **6.1 Testar Acesso:**
1. Acesse seu domínio
2. Deve aparecer o menu público
3. Teste navegação entre páginas

### **6.2 Testar API:**
```bash
# Testar endpoint da IA
POST https://seudominio.com/api/ai/test
{
    "message": "Olá, quero ver o cardápio",
    "phone": "5511999999999"
}
```

### **6.3 Testar Banco:**
```sql
-- Verificar dados iniciais
SELECT COUNT(*) FROM categories;     -- Deve retornar 4
SELECT COUNT(*) FROM products;       -- Deve retornar 15
SELECT COUNT(*) FROM settings;       -- Deve retornar 18
SELECT COUNT(*) FROM ai_training_data; -- Deve retornar 30
```

---

## 📊 **PASSO 7: CONFIGURAR WEBHOOK WHATSAPP**

### **7.1 URL do Webhook:**
```
https://seudominio.com/api/ai/whatsapp/webhook
```

### **7.2 Configuração no WhatsApp Business:**
1. Acesse configurações do WhatsApp Business
2. Adicione a URL do webhook
3. Configure eventos: `messages`
4. Teste com mensagem de exemplo

---

## 🎯 **FUNCIONALIDADES IMPLEMENTADAS**

### **🍽️ Cardápio Digital:**
- ✅ **Menu público** responsivo
- ✅ **Carrinho** de compras
- ✅ **Checkout** multi-etapas
- ✅ **Pagamento** via Mercado Pago
- ✅ **Entrega** com cálculo de frete
- ✅ **Cadastro** de clientes

### **🤖 IA WhatsApp:**
- ✅ **Reconhecimento** de intenções
- ✅ **Pedidos automáticos** via conversa
- ✅ **Carrinho inteligente**
- ✅ **Respostas personalizadas**
- ✅ **Integração** com sistema existente

### **📊 Dashboard Admin:**
- ✅ **Gestão** de produtos
- ✅ **Pedidos** em tempo real
- ✅ **Clientes** e fidelidade
- ✅ **Relatórios** de vendas
- ✅ **Configurações** do sistema

---

## 🔍 **VERIFICAÇÃO FINAL**

### **✅ Checklist de Instalação:**
- [ ] Banco de dados importado
- [ ] Arquivos enviados para servidor
- [ ] Configuração .env editada
- [ ] Permissões configuradas
- [ ] Domínio funcionando
- [ ] API respondendo
- [ ] WhatsApp webhook configurado
- [ ] Testes realizados

### **📱 Testes Recomendados:**
1. **Menu público** - Navegação e produtos
2. **Carrinho** - Adicionar/remover itens
3. **Checkout** - Processo completo
4. **WhatsApp IA** - Enviar mensagem de teste
5. **Dashboard** - Acessar área administrativa

---

## 🚨 **SOLUÇÃO DE PROBLEMAS**

### **❌ Erro 500:**
- Verificar permissões (storage: 755)
- Verificar logs em `storage/logs/`
- Verificar configuração .env

### **❌ Banco não conecta:**
- Verificar credenciais no .env
- Verificar se banco existe
- Verificar usuário tem permissões

### **❌ WhatsApp não responde:**
- Verificar webhook configurado
- Verificar logs da API
- Testar endpoint manualmente

### **❌ Página em branco:**
- Verificar se arquivos estão corretos
- Verificar permissões
- Verificar configuração do servidor

---

## 📞 **SUPORTE**

### **🔧 Comandos Úteis:**
```bash
# Limpar cache
php artisan cache:clear
php artisan config:clear
php artisan route:clear

# Verificar status
php artisan about

# Testar conexão
php artisan tinker
```

### **📊 Monitoramento:**
- **Logs:** `storage/logs/laravel.log`
- **Cache:** `storage/framework/cache/`
- **Sessões:** `storage/framework/sessions/`

---

## 🎉 **SISTEMA PRONTO!**

Após seguir todos os passos, você terá:

✅ **Cardápio Digital** funcionando  
✅ **IA WhatsApp** ativa  
✅ **Sistema de pedidos** integrado  
✅ **Pagamentos** via Mercado Pago  
✅ **Dashboard** administrativo  
✅ **Relatórios** e métricas  

**O sistema está 100% funcional e pronto para receber clientes! 🚀**
