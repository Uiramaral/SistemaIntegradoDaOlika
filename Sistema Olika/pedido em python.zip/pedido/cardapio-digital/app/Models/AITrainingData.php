<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AITrainingData extends Model
{
    use HasFactory;

    protected $fillable = [
        'intent_type',
        'message_example',
        'expected_intent',
        'entities_expected',
        'confidence_threshold',
        'is_verified',
        'verification_count',
        'success_rate',
    ];

    protected $casts = [
        'entities_expected' => 'array',
        'confidence_threshold' => 'decimal:4',
        'success_rate' => 'decimal:4',
        'is_verified' => 'boolean',
        'verification_count' => 'integer',
    ];

    /**
     * Scope para dados verificados
     */
    public function scopeVerified($query)
    {
        return $query->where('is_verified', true);
    }

    /**
     * Scope para um tipo de intenção
     */
    public function scopeForIntent($query, string $intent)
    {
        return $query->where('intent_type', $intent);
    }

    /**
     * Scope para alta taxa de sucesso
     */
    public function scopeHighSuccess($query, float $threshold = 0.8)
    {
        return $query->where('success_rate', '>=', $threshold);
    }

    /**
     * Obter dados de treinamento para um tipo de intenção
     */
    public static function getTrainingDataForIntent(string $intent, int $limit = 10): \Illuminate\Database\Eloquent\Collection
    {
        return static::forIntent($intent)
            ->verified()
            ->highSuccess()
            ->orderBy('success_rate', 'desc')
            ->limit($limit)
            ->get();
    }

    /**
     * Adicionar exemplo de treinamento
     */
    public static function addTrainingExample(
        string $intentType,
        string $messageExample,
        string $expectedIntent,
        array $entitiesExpected = [],
        float $confidenceThreshold = 0.8
    ): self {
        return static::create([
            'intent_type' => $intentType,
            'message_example' => $messageExample,
            'expected_intent' => $expectedIntent,
            'entities_expected' => $entitiesExpected,
            'confidence_threshold' => $confidenceThreshold,
            'is_verified' => false,
            'verification_count' => 0,
        ]);
    }

    /**
     * Verificar exemplo de treinamento
     */
    public function verify(bool $isCorrect, float $actualConfidence = null): void
    {
        $this->verification_count++;
        
        if ($isCorrect) {
            $this->is_verified = true;
        }

        // Calcular taxa de sucesso
        if ($actualConfidence !== null) {
            $this->success_rate = $actualConfidence;
        }

        $this->save();
    }

    /**
     * Obter estatísticas de treinamento
     */
    public static function getTrainingStats(): array
    {
        $total = static::count();
        $verified = static::verified()->count();
        $highSuccess = static::highSuccess()->count();

        $intentStats = static::selectRaw('intent_type, COUNT(*) as count, AVG(success_rate) as avg_success_rate')
            ->groupBy('intent_type')
            ->get()
            ->mapWithKeys(function ($item) {
                return [$item->intent_type => [
                    'count' => $item->count,
                    'avg_success_rate' => $item->avg_success_rate
                ]];
            });

        return [
            'total_examples' => $total,
            'verified_examples' => $verified,
            'high_success_examples' => $highSuccess,
            'verification_rate' => $total > 0 ? ($verified / $total) * 100 : 0,
            'intent_stats' => $intentStats,
        ];
    }

    /**
     * Exportar dados de treinamento
     */
    public static function exportTrainingData(string $format = 'json'): string
    {
        $data = static::all();

        switch ($format) {
            case 'json':
                return $data->toJson(JSON_PRETTY_PRINT);
            case 'csv':
                $csv = "intent_type,message_example,expected_intent,entities_expected,success_rate\n";
                foreach ($data as $item) {
                    $csv .= sprintf(
                        "%s,\"%s\",%s,\"%s\",%s\n",
                        $item->intent_type,
                        str_replace('"', '""', $item->message_example),
                        $item->expected_intent,
                        json_encode($item->entities_expected),
                        $item->success_rate ?? 'N/A'
                    );
                }
                return $csv;
            default:
                return $data->toJson(JSON_PRETTY_PRINT);
        }
    }

    /**
     * Importar dados de treinamento
     */
    public static function importTrainingData(array $data): array
    {
        $results = [
            'success' => 0,
            'errors' => 0,
            'errors_list' => []
        ];

        foreach ($data as $item) {
            try {
                static::create([
                    'intent_type' => $item['intent_type'] ?? 'unknown',
                    'message_example' => $item['message_example'] ?? '',
                    'expected_intent' => $item['expected_intent'] ?? 'unknown',
                    'entities_expected' => $item['entities_expected'] ?? [],
                    'confidence_threshold' => $item['confidence_threshold'] ?? 0.8,
                    'is_verified' => $item['is_verified'] ?? false,
                    'success_rate' => $item['success_rate'] ?? null,
                ]);
                $results['success']++;
            } catch (\Exception $e) {
                $results['errors']++;
                $results['errors_list'][] = $e->getMessage();
            }
        }

        return $results;
    }

    /**
     * Limpar dados de treinamento antigos
     */
    public static function cleanupOldData(int $days = 90): int
    {
        return static::where('created_at', '<', now()->subDays($days))
            ->where('is_verified', false)
            ->delete();
    }

    /**
     * Obter exemplos similares
     */
    public function getSimilarExamples(int $limit = 5): \Illuminate\Database\Eloquent\Collection
    {
        return static::where('intent_type', $this->intent_type)
            ->where('id', '!=', $this->id)
            ->verified()
            ->orderBy('success_rate', 'desc')
            ->limit($limit)
            ->get();
    }

    /**
     * Validar exemplo de treinamento
     */
    public static function validateTrainingExample(array $data): array
    {
        $errors = [];

        if (empty($data['intent_type'])) {
            $errors[] = 'Tipo de intenção é obrigatório';
        }

        if (empty($data['message_example'])) {
            $errors[] = 'Exemplo de mensagem é obrigatório';
        }

        if (empty($data['expected_intent'])) {
            $errors[] = 'Intenção esperada é obrigatória';
        }

        if (isset($data['confidence_threshold']) && 
            ($data['confidence_threshold'] < 0 || $data['confidence_threshold'] > 1)) {
            $errors[] = 'Limite de confiança deve estar entre 0 e 1';
        }

        return $errors;
    }
}
