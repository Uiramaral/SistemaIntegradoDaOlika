<?php

namespace App\Services\Whatsapp;

use App\Models\WhatsappSession;
use App\Models\WhatsappOptin;
use App\Models\WhatsappRule;
use Illuminate\Support\Facades\Log;

class WhatsappService
{
    /**
     * Criar adapter baseado no tipo
     */
    public static function makeAdapter(?string $adapter = null): WhatsappAdapterInterface
    {
        $adapter = $adapter ?: config('services.whatsapp.default_adapter', 'non_official');
        
        return $adapter === 'cloud_api'
            ? app(CloudApiAdapter::class)
            : app(NonOfficialAdapter::class);
    }

    /**
     * Criar adapter para uma sessão específica
     */
    public static function makeAdapterForSession(int $sessionId): WhatsappAdapterInterface
    {
        $session = WhatsappSession::findOrFail($sessionId);
        return self::makeAdapter($session->adapter);
    }

    /**
     * Conectar sessão WhatsApp
     */
    public function connect(int $lojaId, string $phone, string $adapter = 'non_official'): array
    {
        try {
            Log::info('Iniciando conexão WhatsApp', [
                'loja_id' => $lojaId,
                'phone' => $phone,
                'adapter' => $adapter
            ]);

            $adapterService = self::makeAdapter($adapter);
            $result = $adapterService->connect($lojaId, $phone);

            // Criar ou atualizar sessão
            $session = WhatsappSession::updateOrCreate(
                [
                    'loja_id' => $lojaId,
                    'adapter' => $adapter
                ],
                [
                    'phone' => $phone,
                    'status' => $result['status'],
                    'instance_id' => $result['instance_id'] ?? null,
                    'auth_meta_json' => $result['auth_meta'] ?? null,
                    'error_message' => $result['error'] ?? null,
                    'last_seen_at' => $result['status'] === 'connected' ? now() : null,
                ]
            );

            Log::info('Sessão WhatsApp criada/atualizada', [
                'session_id' => $session->id,
                'status' => $session->status
            ]);

            return [
                'success' => true,
                'session_id' => $session->id,
                'status' => $result['status'],
                'pairing_code' => $result['pairing_code'] ?? null,
                'adapter' => $adapter,
                'message' => $this->getConnectionMessage($result['status'])
            ];

        } catch (\Exception $e) {
            Log::error('Erro ao conectar WhatsApp', [
                'loja_id' => $lojaId,
                'phone' => $phone,
                'adapter' => $adapter,
                'error' => $e->getMessage()
            ]);

            return [
                'success' => false,
                'error' => 'Erro interno do servidor',
                'message' => 'Não foi possível conectar o WhatsApp. Tente novamente.'
            ];
        }
    }

    /**
     * Verificar status da sessão
     */
    public function getStatus(int $sessionId): array
    {
        try {
            $session = WhatsappSession::findOrFail($sessionId);
            $adapterService = self::makeAdapterForSession($sessionId);
            $result = $adapterService->status($sessionId);

            // Atualizar status se necessário
            if ($result['status'] !== $session->status) {
                $session->updateStatus($result['status']);
            }

            return [
                'success' => true,
                'status' => $result['status'],
                'instance_id' => $result['instance_id'] ?? null,
                'last_seen_at' => $session->last_seen_at,
                'stats' => $session->getStats()
            ];

        } catch (\Exception $e) {
            Log::error('Erro ao verificar status da sessão', [
                'session_id' => $sessionId,
                'error' => $e->getMessage()
            ]);

            return [
                'success' => false,
                'error' => 'Erro interno do servidor'
            ];
        }
    }

    /**
     * Enviar mensagem
     */
    public function sendMessage(int $sessionId, string $to, string $type, array $data = []): array
    {
        try {
            $session = WhatsappSession::findOrFail($sessionId);
            
            // Verificar se a sessão está conectada
            if (!$session->isConnected()) {
                return [
                    'success' => false,
                    'error' => 'Sessão não conectada',
                    'message' => 'O WhatsApp não está conectado. Conecte primeiro.'
                ];
            }

            // Verificar opt-in
            if (!$this->canSendMessage($session->loja_id, $to)) {
                return [
                    'success' => false,
                    'error' => 'Opt-in necessário',
                    'message' => 'O usuário não optou por receber mensagens.'
                ];
            }

            $adapterService = self::makeAdapterForSession($sessionId);
            $result = $this->sendByType($adapterService, $sessionId, $to, $type, $data);

            // Salvar mensagem no banco
            $this->saveMessage($session, $to, $type, $data, $result);

            return [
                'success' => true,
                'message_id' => $result['provider_msg_id'] ?? null,
                'status' => $result['status'],
                'message' => 'Mensagem enviada com sucesso'
            ];

        } catch (\Exception $e) {
            Log::error('Erro ao enviar mensagem', [
                'session_id' => $sessionId,
                'to' => $to,
                'type' => $type,
                'error' => $e->getMessage()
            ]);

            return [
                'success' => false,
                'error' => 'Erro interno do servidor',
                'message' => 'Não foi possível enviar a mensagem. Tente novamente.'
            ];
        }
    }

    /**
     * Enviar mensagem baseada no tipo
     */
    private function sendByType(WhatsappAdapterInterface $adapter, int $sessionId, string $to, string $type, array $data): array
    {
        switch ($type) {
            case 'text':
                return $adapter->sendText($sessionId, $to, $data['text'] ?? '', $data['meta'] ?? []);
            
            case 'template':
                return $adapter->sendTemplate($sessionId, $to, $data['template_name'] ?? '', $data['template_vars'] ?? []);
            
            case 'image':
            case 'file':
                return $adapter->sendMedia($sessionId, $to, $data['media_url'] ?? '', $type, $data['caption'] ?? '');
            
            default:
                throw new \Exception("Tipo de mensagem '{$type}' não suportado");
        }
    }

    /**
     * Salvar mensagem no banco
     */
    private function saveMessage(WhatsappSession $session, string $to, string $type, array $data, array $result): void
    {
        $session->messages()->create([
            'loja_id' => $session->loja_id,
            'direction' => 'OUT',
            'peer' => $to,
            'type' => $type,
            'body_text' => $data['text'] ?? null,
            'media_url' => $data['media_url'] ?? null,
            'template_name' => $data['template_name'] ?? null,
            'template_vars' => $data['template_vars'] ?? null,
            'status' => $result['status'],
            'provider_msg_id' => $result['provider_msg_id'] ?? null,
            'error_message' => $result['error'] ?? null,
        ]);
    }

    /**
     * Verificar se pode enviar mensagem
     */
    private function canSendMessage(int $lojaId, string $phone): bool
    {
        return WhatsappOptin::canReceiveMessages($lojaId, $phone);
    }

    /**
     * Registrar opt-in
     */
    public function optIn(int $lojaId, string $phone, string $source = 'manual', ?string $notes = null): array
    {
        try {
            $optin = WhatsappOptin::findOrCreate($lojaId, $phone, $source);
            $optin->optIn($source, $notes);

            Log::info('Opt-in registrado', [
                'loja_id' => $lojaId,
                'phone' => $phone,
                'source' => $source
            ]);

            return [
                'success' => true,
                'message' => 'Opt-in registrado com sucesso'
            ];

        } catch (\Exception $e) {
            Log::error('Erro ao registrar opt-in', [
                'loja_id' => $lojaId,
                'phone' => $phone,
                'error' => $e->getMessage()
            ]);

            return [
                'success' => false,
                'error' => 'Erro interno do servidor'
            ];
        }
    }

    /**
     * Registrar opt-out
     */
    public function optOut(int $lojaId, string $phone, ?string $notes = null): array
    {
        try {
            $optin = WhatsappOptin::where('loja_id', $lojaId)
                ->where('phone', $phone)
                ->first();

            if ($optin) {
                $optin->optOut($notes);
            }

            Log::info('Opt-out registrado', [
                'loja_id' => $lojaId,
                'phone' => $phone
            ]);

            return [
                'success' => true,
                'message' => 'Opt-out registrado com sucesso'
            ];

        } catch (\Exception $e) {
            Log::error('Erro ao registrar opt-out', [
                'loja_id' => $lojaId,
                'phone' => $phone,
                'error' => $e->getMessage()
            ]);

            return [
                'success' => false,
                'error' => 'Erro interno do servidor'
            ];
        }
    }

    /**
     * Processar evento de pedido
     */
    public function processOrderEvent(int $lojaId, string $eventKey, array $data = []): array
    {
        try {
            $rule = WhatsappRule::findActiveForEvent($lojaId, $eventKey);
            
            if (!$rule || !$rule->canSend()) {
                return [
                    'success' => false,
                    'message' => 'Nenhuma regra ativa encontrada para este evento'
                ];
            }

            // Buscar sessão ativa
            $session = WhatsappSession::where('loja_id', $lojaId)
                ->where('adapter', $rule->adapter === 'any' ? 'non_official' : $rule->adapter)
                ->connected()
                ->first();

            if (!$session) {
                return [
                    'success' => false,
                    'message' => 'Nenhuma sessão WhatsApp ativa encontrada'
                ];
            }

            // Enviar mensagem
            $result = $this->sendMessage($session->id, $data['phone'] ?? '', 'template', [
                'template_name' => $rule->template_name,
                'template_vars' => $data
            ]);

            return $result;

        } catch (\Exception $e) {
            Log::error('Erro ao processar evento de pedido', [
                'loja_id' => $lojaId,
                'event_key' => $eventKey,
                'error' => $e->getMessage()
            ]);

            return [
                'success' => false,
                'error' => 'Erro interno do servidor'
            ];
        }
    }

    /**
     * Obter mensagem de conexão
     */
    private function getConnectionMessage(string $status): string
    {
        switch ($status) {
            case 'connecting':
                return 'Conectando... Aguarde alguns instantes.';
            case 'connected':
                return 'WhatsApp conectado com sucesso!';
            case 'disconnected':
                return 'WhatsApp desconectado. Tente conectar novamente.';
            case 'error':
                return 'Erro ao conectar WhatsApp. Verifique as configurações.';
            default:
                return 'Status desconhecido.';
        }
    }

    /**
     * Obter estatísticas gerais
     */
    public function getStats(int $lojaId): array
    {
        $sessions = WhatsappSession::where('loja_id', $lojaId)->get();
        $messages = \App\Models\WhatsappMessage::where('loja_id', $lojaId)->get();
        $optins = WhatsappOptin::where('loja_id', $lojaId)->get();

        return [
            'sessions' => [
                'total' => $sessions->count(),
                'connected' => $sessions->where('status', 'connected')->count(),
                'disconnected' => $sessions->where('status', 'disconnected')->count(),
            ],
            'messages' => [
                'total' => $messages->count(),
                'sent' => $messages->where('status', 'sent')->count(),
                'delivered' => $messages->where('status', 'delivered')->count(),
                'failed' => $messages->where('status', 'failed')->count(),
            ],
            'optins' => WhatsappOptin::getStats($lojaId),
        ];
    }
}
