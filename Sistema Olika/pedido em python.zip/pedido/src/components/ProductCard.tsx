import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Product, DisplayMode } from "@/types/menu";
import { Plus, Star } from "lucide-react";
import { useMenu } from "@/contexts/MenuContext";
import { toast } from "sonner";

interface ProductCardProps {
  product: Product;
  onClick: () => void;
  displayMode?: DisplayMode;
}

const ProductCard = ({ product, onClick, displayMode = 'grid' }: ProductCardProps) => {
  const { addToCart } = useMenu();

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart(product);
    toast.success(`${product.name} adicionado ao carrinho`);
  };

  if (displayMode === 'list') {
    return (
      <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={onClick}>
        <CardContent className="p-4">
          <div className="flex gap-4">
            <div className="w-32 h-32 shrink-0 overflow-hidden rounded-lg bg-muted relative">
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-full object-cover"
              />
              {product.featured && (
                <Badge className="absolute top-2 left-2 bg-primary">
                  <Star className="h-3 w-3 mr-1 fill-current" />
                  Destaque
                </Badge>
              )}
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="font-semibold text-lg line-clamp-1">{product.name}</h3>
              <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                {product.description}
              </p>
              <div className="flex items-center justify-between mt-4">
                <span className="text-2xl font-bold text-primary">
                  R$ {product.price.toFixed(2).replace(".", ",")}
                </span>
                <Button size="icon" onClick={handleAddToCart} disabled={!product.available}>
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (displayMode === 'compact') {
    return (
      <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={onClick}>
        <CardContent className="p-0">
          <div className="aspect-square w-full overflow-hidden rounded-t-lg bg-muted relative">
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-full object-cover"
            />
            {product.featured && (
              <Badge className="absolute top-2 right-2 bg-primary">
                <Star className="h-3 w-3 fill-current" />
              </Badge>
            )}
            {!product.available && (
              <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                <span className="text-white font-semibold">Indisponível</span>
              </div>
            )}
          </div>
          <div className="p-3">
            <h3 className="font-semibold text-sm line-clamp-1">{product.name}</h3>
            <div className="flex items-center justify-between mt-2">
              <span className="text-lg font-bold text-primary">
                R$ {product.price.toFixed(2).replace(".", ",")}
              </span>
              <Button size="sm" onClick={handleAddToCart} disabled={!product.available}>
                <Plus className="h-3 w-3" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={onClick}>
      <CardContent className="p-0">
        <div className="aspect-video w-full overflow-hidden rounded-t-lg bg-muted relative">
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover"
          />
          {product.featured && (
            <Badge className="absolute top-2 right-2 bg-primary">
              <Star className="h-3 w-3 mr-1 fill-current" />
              Destaque
            </Badge>
          )}
          {!product.available && (
            <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
              <span className="text-white font-semibold">Indisponível</span>
            </div>
          )}
        </div>
        <div className="p-4">
          <h3 className="font-semibold text-lg line-clamp-1">{product.name}</h3>
          <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
            {product.description}
          </p>
          <div className="flex items-center justify-between mt-4">
            <span className="text-2xl font-bold text-primary">
              R$ {product.price.toFixed(2).replace(".", ",")}
            </span>
            <Button size="icon" onClick={handleAddToCart} disabled={!product.available}>
              <Plus className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ProductCard;