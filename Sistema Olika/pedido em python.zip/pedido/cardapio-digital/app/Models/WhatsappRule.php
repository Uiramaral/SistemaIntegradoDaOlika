<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WhatsappRule extends Model
{
    use HasFactory;

    protected $fillable = [
        'loja_id',
        'event_key',
        'enabled',
        'adapter',
        'template_name',
        'template_body',
        'template_vars',
        'send_window',
    ];

    protected $casts = [
        'enabled' => 'boolean',
        'template_vars' => 'array',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    /**
     * Verificar se a regra está habilitada
     */
    public function isEnabled(): bool
    {
        return $this->enabled;
    }

    /**
     * Verificar se a regra está desabilitada
     */
    public function isDisabled(): bool
    {
        return !$this->enabled;
    }

    /**
     * Verificar se a regra se aplica ao adapter
     */
    public function appliesToAdapter(string $adapter): bool
    {
        return $this->adapter === 'any' || $this->adapter === $adapter;
    }

    /**
     * Verificar se está dentro da janela de envio
     */
    public function isWithinSendWindow(): bool
    {
        if (!$this->send_window) {
            return true;
        }

        $window = explode('-', $this->send_window);
        if (count($window) !== 2) {
            return true;
        }

        $start = $window[0];
        $end = $window[1];
        
        // Usar timezone configurado no app (padrão: America/Sao_Paulo)
        $now = now()->timezone(config('app.timezone', 'America/Sao_Paulo'))->format('H:i');

        return $now >= $start && $now <= $end;
    }

    /**
     * Renderizar template com variáveis
     */
    public function renderTemplate(array $vars = []): string
    {
        $content = $this->template_body;
        
        foreach ($vars as $key => $value) {
            $content = str_replace("{{$key}}", $value, $content);
        }
        
        return $content;
    }

    /**
     * Verificar se pode enviar mensagem
     */
    public function canSend(): bool
    {
        return $this->isEnabled() && $this->isWithinSendWindow();
    }

    /**
     * Habilitar regra
     */
    public function enable(): void
    {
        $this->update(['enabled' => true]);
    }

    /**
     * Desabilitar regra
     */
    public function disable(): void
    {
        $this->update(['enabled' => false]);
    }

    /**
     * Scope para regras habilitadas
     */
    public function scopeEnabled($query)
    {
        return $query->where('enabled', true);
    }

    /**
     * Scope para regras desabilitadas
     */
    public function scopeDisabled($query)
    {
        return $query->where('enabled', false);
    }

    /**
     * Scope para um adapter específico
     */
    public function scopeAdapter($query, string $adapter)
    {
        return $query->where(function($q) use ($adapter) {
            $q->where('adapter', 'any')
              ->orWhere('adapter', $adapter);
        });
    }

    /**
     * Scope para uma loja específica
     */
    public function scopeLoja($query, int $lojaId)
    {
        return $query->where('loja_id', $lojaId);
    }

    /**
     * Scope para um evento específico
     */
    public function scopeEvent($query, string $eventKey)
    {
        return $query->where('event_key', $eventKey);
    }

    /**
     * Buscar regra ativa para um evento
     */
    public static function findActiveForEvent(int $lojaId, string $eventKey, string $adapter = 'any'): ?self
    {
        return static::loja($lojaId)
                    ->event($eventKey)
                    ->enabled()
                    ->adapter($adapter)
                    ->first();
    }

    /**
     * Obter estatísticas das regras
     */
    public static function getStats(int $lojaId): array
    {
        $total = static::where('loja_id', $lojaId)->count();
        $enabled = static::where('loja_id', $lojaId)->enabled()->count();
        $disabled = static::where('loja_id', $lojaId)->disabled()->count();
        
        return [
            'total' => $total,
            'enabled' => $enabled,
            'disabled' => $disabled,
            'enabled_rate' => $total > 0 ? round(($enabled / $total) * 100, 2) : 0,
        ];
    }
}
