<?php

namespace App\Services;

use App\Models\Product;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;

class AICartService
{
    /**
     * Adicionar item ao carrinho
     */
    public function addItem(string $phone, int $productId, int $quantity = 1): array
    {
        try {
            $product = Product::find($productId);
            
            if (!$product || !$product->available) {
                return [
                    'success' => false,
                    'message' => 'Produto não disponível'
                ];
            }

            $cartKey = "ai_cart_{$phone}";
            $cart = Cache::get($cartKey, []);

            $itemKey = $productId;
            
            if (isset($cart[$itemKey])) {
                $cart[$itemKey]['quantity'] += $quantity;
            } else {
                $cart[$itemKey] = [
                    'product_id' => $productId,
                    'product_name' => $product->name,
                    'product_price' => $product->price,
                    'product_description' => $product->description,
                    'product_image' => $product->image,
                    'quantity' => $quantity,
                    'added_at' => now()->toISOString()
                ];
            }

            Cache::put($cartKey, $cart, 3600); // 1 hora

            return [
                'success' => true,
                'cart' => $cart,
                'total' => $this->calculateTotal($cart),
                'item_count' => array_sum(array_column($cart, 'quantity'))
            ];

        } catch (\Exception $e) {
            Log::error('Erro ao adicionar item ao carrinho IA', [
                'phone' => $phone,
                'product_id' => $productId,
                'error' => $e->getMessage()
            ]);

            return [
                'success' => false,
                'message' => 'Erro ao adicionar produto ao carrinho'
            ];
        }
    }

    /**
     * Atualizar quantidade de item
     */
    public function updateQuantity(string $phone, int $productId, int $quantity): array
    {
        try {
            $cartKey = "ai_cart_{$phone}";
            $cart = Cache::get($cartKey, []);

            if (!isset($cart[$productId])) {
                return [
                    'success' => false,
                    'message' => 'Produto não encontrado no carrinho'
                ];
            }

            if ($quantity <= 0) {
                unset($cart[$productId]);
            } else {
                $cart[$productId]['quantity'] = $quantity;
            }

            Cache::put($cartKey, $cart, 3600);

            return [
                'success' => true,
                'cart' => $cart,
                'total' => $this->calculateTotal($cart),
                'item_count' => array_sum(array_column($cart, 'quantity'))
            ];

        } catch (\Exception $e) {
            Log::error('Erro ao atualizar quantidade no carrinho IA', [
                'phone' => $phone,
                'product_id' => $productId,
                'quantity' => $quantity,
                'error' => $e->getMessage()
            ]);

            return [
                'success' => false,
                'message' => 'Erro ao atualizar quantidade'
            ];
        }
    }

    /**
     * Remover item do carrinho
     */
    public function removeItem(string $phone, int $productId): array
    {
        try {
            $cartKey = "ai_cart_{$phone}";
            $cart = Cache::get($cartKey, []);

            if (!isset($cart[$productId])) {
                return [
                    'success' => false,
                    'message' => 'Produto não encontrado no carrinho'
                ];
            }

            unset($cart[$productId]);
            Cache::put($cartKey, $cart, 3600);

            return [
                'success' => true,
                'cart' => $cart,
                'total' => $this->calculateTotal($cart),
                'item_count' => array_sum(array_column($cart, 'quantity'))
            ];

        } catch (\Exception $e) {
            Log::error('Erro ao remover item do carrinho IA', [
                'phone' => $phone,
                'product_id' => $productId,
                'error' => $e->getMessage()
            ]);

            return [
                'success' => false,
                'message' => 'Erro ao remover produto do carrinho'
            ];
        }
    }

    /**
     * Limpar carrinho
     */
    public function clearCart(string $phone): array
    {
        try {
            $cartKey = "ai_cart_{$phone}";
            Cache::forget($cartKey);

            return [
                'success' => true,
                'message' => 'Carrinho limpo com sucesso'
            ];

        } catch (\Exception $e) {
            Log::error('Erro ao limpar carrinho IA', [
                'phone' => $phone,
                'error' => $e->getMessage()
            ]);

            return [
                'success' => false,
                'message' => 'Erro ao limpar carrinho'
            ];
        }
    }

    /**
     * Obter carrinho
     */
    public function getCart(string $phone): array
    {
        $cartKey = "ai_cart_{$phone}";
        $cart = Cache::get($cartKey, []);

        return [
            'items' => array_values($cart),
            'total' => $this->calculateTotal($cart),
            'item_count' => array_sum(array_column($cart, 'quantity')),
            'updated_at' => now()->toISOString()
        ];
    }

    /**
     * Calcular total do carrinho
     */
    private function calculateTotal(array $cart): float
    {
        $total = 0;
        foreach ($cart as $item) {
            $total += $item['product_price'] * $item['quantity'];
        }
        return $total;
    }

    /**
     * Validar carrinho
     */
    public function validateCart(string $phone): array
    {
        $cart = $this->getCart($phone);
        
        if (empty($cart['items'])) {
            return [
                'valid' => false,
                'message' => 'Carrinho vazio'
            ];
        }

        $errors = [];
        
        foreach ($cart['items'] as $item) {
            $product = Product::find($item['product_id']);
            
            if (!$product) {
                $errors[] = "Produto {$item['product_name']} não existe mais";
                continue;
            }
            
            if (!$product->available) {
                $errors[] = "Produto {$item['product_name']} não está disponível";
            }
        }

        if (!empty($errors)) {
            return [
                'valid' => false,
                'message' => implode(', ', $errors)
            ];
        }

        return [
            'valid' => true,
            'message' => 'Carrinho válido'
        ];
    }

    /**
     * Obter resumo do carrinho
     */
    public function getCartSummary(string $phone): array
    {
        $cart = $this->getCart($phone);
        
        $summary = [
            'items' => [],
            'subtotal' => 0,
            'item_count' => 0
        ];

        foreach ($cart['items'] as $item) {
            $itemTotal = $item['product_price'] * $item['quantity'];
            
            $summary['items'][] = [
                'product_name' => $item['product_name'],
                'quantity' => $item['quantity'],
                'unit_price' => $item['product_price'],
                'total_price' => $itemTotal
            ];
            
            $summary['subtotal'] += $itemTotal;
            $summary['item_count'] += $item['quantity'];
        }

        return $summary;
    }

    /**
     * Verificar se carrinho está vazio
     */
    public function isEmpty(string $phone): bool
    {
        $cart = $this->getCart($phone);
        return empty($cart['items']);
    }

    /**
     * Obter contagem de itens
     */
    public function getItemCount(string $phone): int
    {
        $cart = $this->getCart($phone);
        return $cart['item_count'];
    }

    /**
     * Verificar se produto está no carrinho
     */
    public function hasProduct(string $phone, int $productId): bool
    {
        $cartKey = "ai_cart_{$phone}";
        $cart = Cache::get($cartKey, []);
        
        return isset($cart[$productId]);
    }

    /**
     * Obter quantidade de produto específico
     */
    public function getProductQuantity(string $phone, int $productId): int
    {
        $cartKey = "ai_cart_{$phone}";
        $cart = Cache::get($cartKey, []);
        
        return $cart[$productId]['quantity'] ?? 0;
    }

    /**
     * Aplicar cupom de desconto
     */
    public function applyCoupon(string $phone, string $couponCode): array
    {
        // TODO: Implementar lógica de cupons
        return [
            'success' => false,
            'message' => 'Sistema de cupons em desenvolvimento'
        ];
    }

    /**
     * Remover cupom de desconto
     */
    public function removeCoupon(string $phone): array
    {
        // TODO: Implementar lógica de cupons
        return [
            'success' => true,
            'message' => 'Cupom removido'
        ];
    }
}
