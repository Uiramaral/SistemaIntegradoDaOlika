@props([
    'src' => null,
    'alt' => '',
    'fallback' => null,
])

<div {{ $attributes->merge(['class' => 'relative flex h-10 w-10 shrink-0 overflow-hidden rounded-full']) }}>
    @if($src)
        <img 
            src="{{ $src }}" 
            alt="{{ $alt }}"
            class="aspect-square h-full w-full object-cover"
        />
    @else
        <div class="flex h-full w-full items-center justify-center rounded-full bg-muted">
            <span class="text-sm font-medium">{{ $fallback ?? strtoupper(substr($alt, 0, 2)) }}</span>
        </div>
    @endif
</div>

