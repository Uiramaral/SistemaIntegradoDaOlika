@props([])

<div {{ $attributes->merge(['class' => 'animate-pulse rounded-md bg-muted']) }}>
    {{ $slot }}
</div>

