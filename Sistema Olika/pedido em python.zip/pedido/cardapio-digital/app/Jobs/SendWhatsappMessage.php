<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;
use App\Services\Whatsapp\WhatsappService;
use App\Models\WhatsappMessage;

class SendWhatsappMessage implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $tries = 3;
    public $timeout = 30;
    public $backoff = [5, 10, 30]; // Segundos entre tentativas

    private int $sessionId;
    private string $to;
    private string $type;
    private array $data;
    private int $lojaId;

    /**
     * Create a new job instance.
     */
    public function __construct(int $sessionId, string $to, string $type, array $data, int $lojaId)
    {
        $this->sessionId = $sessionId;
        $this->to = $to;
        $this->type = $type;
        $this->data = $data;
        $this->lojaId = $lojaId;
    }

    /**
     * Execute the job.
     */
    public function handle(): void
    {
        try {
            Log::info('Processando envio de mensagem WhatsApp', [
                'session_id' => $this->sessionId,
                'to' => $this->to,
                'type' => $this->type,
                'attempt' => $this->attempts()
            ]);

            $whatsappService = new WhatsappService();
            $result = $whatsappService->sendMessage($this->sessionId, $this->to, $this->type, $this->data);

            if (!$result['success']) {
                throw new \Exception($result['error'] ?? 'Erro desconhecido');
            }

            Log::info('Mensagem WhatsApp enviada com sucesso', [
                'session_id' => $this->sessionId,
                'to' => $this->to,
                'message_id' => $result['message_id'] ?? null
            ]);

        } catch (\Exception $e) {
            Log::error('Erro ao enviar mensagem WhatsApp', [
                'session_id' => $this->sessionId,
                'to' => $this->to,
                'type' => $this->type,
                'attempt' => $this->attempts(),
                'error' => $e->getMessage()
            ]);

            // Marcar mensagem como falhada
            $this->markMessageAsFailed($e->getMessage());

            // Re-throw para que o job seja marcado como falhado
            throw $e;
        }
    }

    /**
     * Marcar mensagem como falhada
     */
    private function markMessageAsFailed(string $errorMessage): void
    {
        try {
            $message = WhatsappMessage::where('session_id', $this->sessionId)
                ->where('peer', $this->to)
                ->where('direction', 'OUT')
                ->where('status', 'queued')
                ->latest()
                ->first();

            if ($message) {
                $message->updateStatus('failed', $errorMessage);
            }
        } catch (\Exception $e) {
            Log::error('Erro ao marcar mensagem como falhada', [
                'session_id' => $this->sessionId,
                'to' => $this->to,
                'error' => $e->getMessage()
            ]);
        }
    }

    /**
     * Handle a job failure.
     */
    public function failed(\Throwable $exception): void
    {
        Log::error('Job de envio de mensagem WhatsApp falhou definitivamente', [
            'session_id' => $this->sessionId,
            'to' => $this->to,
            'type' => $this->type,
            'attempts' => $this->attempts(),
            'error' => $exception->getMessage()
        ]);

        $this->markMessageAsFailed($exception->getMessage());
    }

    /**
     * Get the tags that should be assigned to the job.
     */
    public function tags(): array
    {
        return [
            'whatsapp',
            'session:' . $this->sessionId,
            'loja:' . $this->lojaId,
            'type:' . $this->type
        ];
    }
}
