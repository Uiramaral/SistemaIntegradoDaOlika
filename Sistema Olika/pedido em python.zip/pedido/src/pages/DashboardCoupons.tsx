import { useState } from "react";
import { useMenu } from "@/contexts/MenuContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Plus, Pencil, Trash2, Percent, DollarSign, Copy } from "lucide-react";
import { toast } from "sonner";
import type { Coupon } from "@/types/menu";

export default function DashboardCoupons() {
  const { coupons, addCoupon, updateCoupon, deleteCoupon } = useMenu();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingCoupon, setEditingCoupon] = useState<Coupon | null>(null);

  const [formData, setFormData] = useState({
    code: "",
    description: "",
    discountType: "percentage" as "percentage" | "fixed",
    discountValue: "",
    isPublic: true,
    firstPurchaseOnly: false,
    minPurchaseValue: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const couponData: Coupon = {
      id: editingCoupon?.id || Date.now().toString(),
      code: formData.code.toUpperCase(),
      description: formData.description,
      discountType: formData.discountType,
      discountValue: parseFloat(formData.discountValue),
      isPublic: formData.isPublic,
      firstPurchaseOnly: formData.firstPurchaseOnly,
      minPurchaseValue: formData.minPurchaseValue
        ? parseFloat(formData.minPurchaseValue)
        : undefined,
      active: true,
    };

    if (editingCoupon) {
      updateCoupon(couponData);
      toast.success("Cupom atualizado com sucesso!");
    } else {
      addCoupon(couponData);
      toast.success("Cupom criado com sucesso!");
    }

    handleCloseDialog();
  };

  const handleEdit = (coupon: Coupon) => {
    setEditingCoupon(coupon);
    setFormData({
      code: coupon.code,
      description: coupon.description,
      discountType: coupon.discountType,
      discountValue: coupon.discountValue.toString(),
      isPublic: coupon.isPublic,
      firstPurchaseOnly: coupon.firstPurchaseOnly,
      minPurchaseValue: coupon.minPurchaseValue?.toString() || "",
    });
    setDialogOpen(true);
  };

  const handleDelete = (id: string) => {
    if (confirm("Tem certeza que deseja excluir este cupom?")) {
      deleteCoupon(id);
      toast.success("Cupom excluído com sucesso!");
    }
  };

  const handleCloseDialog = () => {
    setDialogOpen(false);
    setEditingCoupon(null);
    setFormData({
      code: "",
      description: "",
      discountType: "percentage",
      discountValue: "",
      isPublic: true,
      firstPurchaseOnly: false,
      minPurchaseValue: "",
    });
  };

  const handleCopyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    toast.success("Código copiado!");
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Cupons de Desconto</h1>
          <p className="text-muted-foreground">Gerencie seus cupons promocionais</p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => setEditingCoupon(null)}>
              <Plus className="h-4 w-4 mr-2" />
              Novo Cupom
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>{editingCoupon ? "Editar Cupom" : "Novo Cupom"}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="code">Código do Cupom *</Label>
                <Input
                  id="code"
                  value={formData.code}
                  onChange={(e) =>
                    setFormData({ ...formData, code: e.target.value.toUpperCase() })
                  }
                  placeholder="EX: BEMVINDO10"
                  required
                />
              </div>

              <div>
                <Label htmlFor="description">Descrição</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Descrição do cupom..."
                  rows={2}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="discountType">Tipo de Desconto *</Label>
                  <Select
                    value={formData.discountType}
                    onValueChange={(value: "percentage" | "fixed") =>
                      setFormData({ ...formData, discountType: value })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="percentage">Percentual (%)</SelectItem>
                      <SelectItem value="fixed">Valor Fixo (R$)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="discountValue">
                    Valor do Desconto * {formData.discountType === "percentage" ? "(%)" : "(R$)"}
                  </Label>
                  <Input
                    id="discountValue"
                    type="number"
                    step="0.01"
                    value={formData.discountValue}
                    onChange={(e) => setFormData({ ...formData, discountValue: e.target.value })}
                    required
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="minPurchaseValue">Valor Mínimo de Compra (R$)</Label>
                <Input
                  id="minPurchaseValue"
                  type="number"
                  step="0.01"
                  value={formData.minPurchaseValue}
                  onChange={(e) =>
                    setFormData({ ...formData, minPurchaseValue: e.target.value })
                  }
                  placeholder="Opcional"
                />
              </div>

              <div className="space-y-4 pt-2">
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <Label htmlFor="isPublic">Cupom Público</Label>
                    <p className="text-xs text-muted-foreground">
                      Visível para todos os clientes no checkout
                    </p>
                  </div>
                  <Switch
                    id="isPublic"
                    checked={formData.isPublic}
                    onCheckedChange={(checked) => setFormData({ ...formData, isPublic: checked })}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <Label htmlFor="firstPurchaseOnly">Apenas Primeira Compra</Label>
                    <p className="text-xs text-muted-foreground">
                      Válido apenas para novos clientes
                    </p>
                  </div>
                  <Switch
                    id="firstPurchaseOnly"
                    checked={formData.firstPurchaseOnly}
                    onCheckedChange={(checked) =>
                      setFormData({ ...formData, firstPurchaseOnly: checked })
                    }
                  />
                </div>
              </div>

              <div className="flex gap-2 justify-end pt-4">
                <Button type="button" variant="outline" onClick={handleCloseDialog}>
                  Cancelar
                </Button>
                <Button type="submit">{editingCoupon ? "Atualizar" : "Criar Cupom"}</Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {coupons.length === 0 ? (
          <Card className="col-span-full">
            <CardContent className="py-8">
              <p className="text-center text-muted-foreground">
                Nenhum cupom criado ainda. Clique em "Novo Cupom" para começar.
              </p>
            </CardContent>
          </Card>
        ) : (
          coupons.map((coupon) => (
            <Card key={coupon.id}>
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2">
                    {coupon.discountType === "percentage" ? (
                      <Percent className="h-5 w-5 text-primary" />
                    ) : (
                      <DollarSign className="h-5 w-5 text-primary" />
                    )}
                    <CardTitle className="text-lg">{coupon.code}</CardTitle>
                  </div>
                  <div className="flex gap-1">
                    <Button size="icon" variant="ghost" onClick={() => handleEdit(coupon)}>
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button size="icon" variant="ghost" onClick={() => handleDelete(coupon.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                {coupon.description && (
                  <p className="text-sm text-muted-foreground">{coupon.description}</p>
                )}

                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Desconto:</span>
                    <span className="font-semibold">
                      {coupon.discountType === "percentage"
                        ? `${coupon.discountValue}%`
                        : `R$ ${coupon.discountValue.toFixed(2)}`}
                    </span>
                  </div>

                  {coupon.minPurchaseValue && (
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Compra mínima:</span>
                      <span>R$ {coupon.minPurchaseValue.toFixed(2)}</span>
                    </div>
                  )}
                </div>

                <div className="flex flex-wrap gap-2 pt-2">
                  {coupon.isPublic ? (
                    <span className="text-xs px-2 py-1 rounded-full bg-green-100 text-green-800">
                      Público
                    </span>
                  ) : (
                    <span className="text-xs px-2 py-1 rounded-full bg-gray-100 text-gray-800">
                      Privado
                    </span>
                  )}
                  {coupon.firstPurchaseOnly && (
                    <span className="text-xs px-2 py-1 rounded-full bg-blue-100 text-blue-800">
                      1ª Compra
                    </span>
                  )}
                </div>

                <Button
                  variant="outline"
                  size="sm"
                  className="w-full"
                  onClick={() => handleCopyCode(coupon.code)}
                >
                  <Copy className="h-3 w-3 mr-2" />
                  Copiar Código
                </Button>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
