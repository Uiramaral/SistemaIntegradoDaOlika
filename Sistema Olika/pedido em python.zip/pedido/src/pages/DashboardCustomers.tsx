import { useState } from "react";
import { useMenu } from "@/contexts/MenuContext";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Search, User } from "lucide-react";

export default function DashboardCustomers() {
  const { customers, orders } = useMenu();
  const [searchTerm, setSearchTerm] = useState("");

  const filteredCustomers = customers.filter(
    (customer) =>
      customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      customer.phone?.includes(searchTerm)
  );

  const getCustomerOrders = (customerId: string) => {
    return orders.filter((order) => order.customerId === customerId);
  };

  const getCustomerTotal = (customerId: string) => {
    return getCustomerOrders(customerId).reduce((sum, order) => sum + order.total, 0);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Clientes</h1>
        <p className="text-muted-foreground">Gerencie seus clientes cadastrados</p>
      </div>

      <Card>
        <CardHeader>
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Buscar clientes por nome ou telefone..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9"
            />
          </div>
        </CardHeader>
        <CardContent>
          {filteredCustomers.length === 0 ? (
            <p className="text-center py-8 text-muted-foreground">
              {searchTerm ? "Nenhum cliente encontrado" : "Nenhum cliente cadastrado ainda"}
            </p>
          ) : (
            <div className="space-y-4">
              {filteredCustomers.map((customer) => {
                const customerOrders = getCustomerOrders(customer.id);
                const totalSpent = getCustomerTotal(customer.id);

                return (
                  <Card key={customer.id}>
                    <CardContent className="p-4">
                      <div className="flex items-start gap-4">
                        <div className="p-3 bg-primary/10 rounded-full">
                          <User className="h-6 w-6 text-primary" />
                        </div>
                        <div className="flex-1 space-y-2">
                          <div>
                            <h3 className="font-semibold text-lg">{customer.name}</h3>
                            {customer.phone && (
                              <p className="text-sm text-muted-foreground">{customer.phone}</p>
                            )}
                          </div>

                          {customer.address && (
                            <p className="text-sm text-muted-foreground">{customer.address}</p>
                          )}

                          {customer.cep && (
                            <p className="text-sm text-muted-foreground">CEP: {customer.cep}</p>
                          )}

                          <div className="flex gap-6 pt-2 border-t">
                            <div>
                              <p className="text-xs text-muted-foreground">Total de Pedidos</p>
                              <p className="font-semibold">{customerOrders.length}</p>
                            </div>
                            <div>
                              <p className="text-xs text-muted-foreground">Total Gasto</p>
                              <p className="font-semibold">R$ {totalSpent.toFixed(2)}</p>
                            </div>
                            {customerOrders.length > 0 && (
                              <div>
                                <p className="text-xs text-muted-foreground">Ticket Médio</p>
                                <p className="font-semibold">
                                  R$ {(totalSpent / customerOrders.length).toFixed(2)}
                                </p>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
