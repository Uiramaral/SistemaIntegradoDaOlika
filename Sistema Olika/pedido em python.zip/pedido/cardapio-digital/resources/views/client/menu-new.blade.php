@extends('client.layout-new')

@section('title', 'Cardápio Digital Olika')

@section('content')
<div class="min-h-screen bg-gray-50">
    <!-- Header -->
    <header class="bg-white shadow-sm border-b sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-4">
                <div class="flex items-center">
                    <div class="flex items-center space-x-3">
                        <div class="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                            <span class="text-white font-bold text-lg">O</span>
                        </div>
                        <div>
                            <h1 class="text-xl font-bold text-gray-900">Olika</h1>
                            <p class="text-sm text-gray-500">Cardápio Digital</p>
                        </div>
                    </div>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="{{ route('search') }}" class="text-gray-600 hover:text-gray-900">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                        </svg>
                    </a>
                    <a href="{{ route('cart') }}" class="relative bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition flex items-center space-x-2">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4m0 0L7 13m0 0l-2.5 5M7 13l2.5 5m6-5v6a2 2 0 01-2 2H9a2 2 0 01-2-2v-6m8 0V9a2 2 0 00-2-2H9a2 2 0 00-2 2v4.01"></path>
                        </svg>
                        <span>Carrinho</span>
                        <span class="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center" id="cart-count">0</span>
                    </a>
                </div>
            </div>
        </div>
    </header>

    <!-- Banner Promocional -->
    <div class="bg-gradient-to-r from-blue-600 to-purple-600 text-white py-8">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 class="text-3xl font-bold mb-2">Bem-vindo ao Olika!</h2>
            <p class="text-lg opacity-90">Deliciosos pratos preparados com carinho</p>
            <div class="mt-4 flex justify-center space-x-4">
                <span class="bg-white bg-opacity-20 px-3 py-1 rounded-full text-sm">🚚 Entrega Grátis</span>
                <span class="bg-white bg-opacity-20 px-3 py-1 rounded-full text-sm">💳 Pague como quiser</span>
                <span class="bg-white bg-opacity-20 px-3 py-1 rounded-full text-sm">⭐ Qualidade garantida</span>
            </div>
        </div>
    </div>

    <!-- Categorias -->
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div class="mb-6">
            <h2 class="text-2xl font-bold text-gray-900 mb-4">Categorias</h2>
            <div class="flex space-x-3 overflow-x-auto pb-4 scrollbar-hide">
                <button class="category-tab bg-blue-600 text-white px-6 py-3 rounded-lg whitespace-nowrap font-medium shadow-md" data-category="all">
                    🍽️ Todos
                </button>
                @foreach($categories as $category)
                <button class="category-tab bg-white text-gray-700 px-6 py-3 rounded-lg whitespace-nowrap font-medium shadow-md hover:bg-gray-50 border" data-category="{{ $category->id }}">
                    @if($category->name === 'Pratos Principais') 🍽️
                    @elseif($category->name === 'Bebidas') 🥤
                    @elseif($category->name === 'Sobremesas') 🍰
                    @elseif($category->name === 'Aperitivos') 🍤
                    @else 🍽️
                    @endif
                    {{ $category->name }}
                </button>
                @endforeach
            </div>
        </div>

        <!-- Produtos em Destaque -->
        @if($featuredProducts->count() > 0)
        <div class="mb-8">
            <div class="flex items-center justify-between mb-4">
                <h2 class="text-2xl font-bold text-gray-900">⭐ Produtos em Destaque</h2>
                <span class="text-sm text-gray-500">{{ $featuredProducts->count() }} produtos</span>
            </div>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                @foreach($featuredProducts as $product)
                <div class="product-card bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 border border-gray-100" data-category="{{ $product->category_id }}">
                    <div class="relative">
                        <img src="{{ $product->image ?: '/placeholder.svg' }}" alt="{{ $product->name }}" class="w-full h-48 object-cover">
                        <div class="absolute top-3 left-3">
                            <span class="bg-yellow-400 text-yellow-900 px-2 py-1 rounded-full text-xs font-bold">⭐ DESTAQUE</span>
                        </div>
                        @if($product->preparation_time)
                        <div class="absolute top-3 right-3">
                            <span class="bg-gray-800 text-white px-2 py-1 rounded-full text-xs">⏱️ {{ $product->preparation_time }}min</span>
                        </div>
                        @endif
                    </div>
                    <div class="p-5">
                        <h3 class="font-bold text-gray-900 mb-2 text-lg">{{ $product->name }}</h3>
                        <p class="text-gray-600 text-sm mb-3 line-clamp-2">{{ $product->description }}</p>
                        @if($product->ingredients)
                        <p class="text-xs text-gray-500 mb-3">Ingredientes: {{ $product->ingredients }}</p>
                        @endif
                        <div class="flex justify-between items-center">
                            <div>
                                <span class="text-2xl font-bold text-green-600">R$ {{ number_format($product->price, 2, ',', '.') }}</span>
                                @if($product->preparation_time)
                                <p class="text-xs text-gray-500">Preparo: {{ $product->preparation_time }}min</p>
                                @endif
                            </div>
                            <button class="add-to-cart bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-all duration-200 font-medium shadow-md hover:shadow-lg" data-product-id="{{ $product->id }}">
                                <svg class="w-4 h-4 inline mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
                                </svg>
                                Adicionar
                            </button>
                        </div>
                    </div>
                </div>
                @endforeach
            </div>
        </div>
        @endif

        <!-- Todos os Produtos -->
        <div>
            <div class="flex items-center justify-between mb-4">
                <h2 class="text-2xl font-bold text-gray-900">🍽️ Cardápio Completo</h2>
                <span class="text-sm text-gray-500">{{ $products->count() }} produtos</span>
            </div>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6" id="products-grid">
                @foreach($products as $product)
                <div class="product-card bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 border border-gray-100" data-category="{{ $product->category_id }}">
                    <div class="relative">
                        <img src="{{ $product->image ?: '/placeholder.svg' }}" alt="{{ $product->name }}" class="w-full h-48 object-cover">
                        @if($product->preparation_time)
                        <div class="absolute top-3 right-3">
                            <span class="bg-gray-800 text-white px-2 py-1 rounded-full text-xs">⏱️ {{ $product->preparation_time }}min</span>
                        </div>
                        @endif
                    </div>
                    <div class="p-5">
                        <h3 class="font-bold text-gray-900 mb-2 text-lg">{{ $product->name }}</h3>
                        <p class="text-gray-600 text-sm mb-3 line-clamp-2">{{ $product->description }}</p>
                        @if($product->ingredients)
                        <p class="text-xs text-gray-500 mb-3">Ingredientes: {{ $product->ingredients }}</p>
                        @endif
                        <div class="flex justify-between items-center">
                            <div>
                                <span class="text-2xl font-bold text-green-600">R$ {{ number_format($product->price, 2, ',', '.') }}</span>
                                @if($product->preparation_time)
                                <p class="text-xs text-gray-500">Preparo: {{ $product->preparation_time }}min</p>
                                @endif
                            </div>
                            <button class="add-to-cart bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-all duration-200 font-medium shadow-md hover:shadow-lg" data-product-id="{{ $product->id }}">
                                <svg class="w-4 h-4 inline mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
                                </svg>
                                Adicionar
                            </button>
                        </div>
                    </div>
                </div>
                @endforeach
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-gray-900 text-white py-8 mt-12">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div>
                    <h3 class="text-lg font-bold mb-4">Olika</h3>
                    <p class="text-gray-400">Deliciosos pratos preparados com carinho e qualidade.</p>
                </div>
                <div>
                    <h3 class="text-lg font-bold mb-4">Contato</h3>
                    <p class="text-gray-400">📞 (11) 99999-9999</p>
                    <p class="text-gray-400">✉️ contato@olika.com</p>
                </div>
                <div>
                    <h3 class="text-lg font-bold mb-4">Horário</h3>
                    <p class="text-gray-400">Seg-Sex: 08:00-18:00</p>
                    <p class="text-gray-400">Sáb: 08:00-16:00</p>
                </div>
            </div>
        </div>
    </footer>
</div>

<!-- Toast Container -->
<div id="toast-container" class="fixed top-4 right-4 z-50"></div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Filtro por categoria
    const categoryTabs = document.querySelectorAll('.category-tab');
    const productCards = document.querySelectorAll('.product-card');

    categoryTabs.forEach(tab => {
        tab.addEventListener('click', function() {
            const category = this.dataset.category;
            
            // Atualizar tabs ativas
            categoryTabs.forEach(t => {
                t.classList.remove('bg-blue-600', 'text-white');
                t.classList.add('bg-white', 'text-gray-700');
            });
            this.classList.remove('bg-white', 'text-gray-700');
            this.classList.add('bg-blue-600', 'text-white');

            // Filtrar produtos
            productCards.forEach(card => {
                if (category === 'all' || card.dataset.category === category) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        });
    });

    // Adicionar ao carrinho
    document.querySelectorAll('.add-to-cart').forEach(button => {
        button.addEventListener('click', function() {
            const productId = this.dataset.productId;
            const originalText = this.innerHTML;
            
            // Feedback visual
            this.innerHTML = '<svg class="w-4 h-4 inline mr-1 animate-spin" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path></svg>Adicionando...';
            this.disabled = true;
            
            fetch('/api/cart/add', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                },
                body: JSON.stringify({
                    product_id: productId,
                    quantity: 1
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Atualizar contador do carrinho
                    document.getElementById('cart-count').textContent = data.cart_count;
                    
                    // Mostrar toast
                    showToast('Produto adicionado ao carrinho!', 'success');
                    
                    // Feedback visual
                    this.innerHTML = '<svg class="w-4 h-4 inline mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>Adicionado!';
                    this.classList.add('bg-green-600');
                    
                    setTimeout(() => {
                        this.innerHTML = originalText;
                        this.classList.remove('bg-green-600');
                        this.disabled = false;
                    }, 2000);
                } else {
                    showToast(data.message || 'Erro ao adicionar produto', 'error');
                    this.innerHTML = originalText;
                    this.disabled = false;
                }
            })
            .catch(error => {
                console.error('Erro:', error);
                showToast('Erro ao adicionar produto ao carrinho', 'error');
                this.innerHTML = originalText;
                this.disabled = false;
            });
        });
    });

    // Função para mostrar toast
    function showToast(message, type = 'info') {
        const toast = document.createElement('div');
        toast.className = `fixed top-4 right-4 z-50 p-4 rounded-lg shadow-lg text-white max-w-sm transform transition-all duration-300 ${
            type === 'success' ? 'bg-green-500' : 
            type === 'error' ? 'bg-red-500' : 
            'bg-blue-500'
        }`;
        toast.textContent = message;
        
        document.body.appendChild(toast);
        
        setTimeout(() => {
            toast.style.transform = 'translateX(100%)';
            setTimeout(() => {
                document.body.removeChild(toast);
            }, 300);
        }, 3000);
    }

    // Carregar contador do carrinho
    fetch('/api/cart/count')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                document.getElementById('cart-count').textContent = data.count;
            }
        })
        .catch(error => console.error('Erro ao carregar contador:', error));
});
</script>

<style>
.scrollbar-hide {
    -ms-overflow-style: none;
    scrollbar-width: none;
}
.scrollbar-hide::-webkit-scrollbar {
    display: none;
}
.line-clamp-2 {
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
}
</style>
@endsection
