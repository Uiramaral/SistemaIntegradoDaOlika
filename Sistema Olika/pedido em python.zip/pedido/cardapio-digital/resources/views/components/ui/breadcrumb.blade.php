@props([
    'items' => [],
])

<nav aria-label="breadcrumb" {{ $attributes->merge(['class' => '']) }}>
    <ol class="flex items-center space-x-2 text-sm text-muted-foreground">
        @foreach($items as $index => $item)
            <li class="flex items-center">
                @if($index > 0)
                    <svg class="h-4 w-4 mx-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                    </svg>
                @endif
                
                @if(isset($item['href']) && !$loop->last)
                    <a href="{{ $item['href'] }}" class="hover:text-foreground transition-colors">
                        {{ $item['label'] }}
                    </a>
                @else
                    <span class="font-medium text-foreground">{{ $item['label'] }}</span>
                @endif
            </li>
        @endforeach
    </ol>
</nav>

