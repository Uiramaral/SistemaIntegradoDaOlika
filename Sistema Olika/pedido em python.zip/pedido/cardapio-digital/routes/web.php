<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ClientController;
use App\Http\Controllers\Dashboard\WhatsappDashboardController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Rotas públicas do cliente
Route::get('/', [ClientController::class, 'menu'])->name('home');
Route::get('/menu', [ClientController::class, 'menu'])->name('menu');
Route::get('/cart', [ClientController::class, 'cart'])->name('cart');
Route::get('/checkout', [ClientController::class, 'checkout'])->name('checkout');
Route::get('/product/{id}', [ClientController::class, 'product'])->name('product');
Route::get('/search', [ClientController::class, 'search'])->name('search');
Route::get('/order-success/{orderId}', function($orderId) {
    return view('client.order-success', compact('orderId'));
})->name('order.success');

// Rotas administrativas
Route::get('/admin', function () {
    return redirect('/dashboard');
});

Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

// Rotas do Dashboard
Route::prefix('dashboard')->group(function () {
    // Dashboard principal
    Route::get('/', [DashboardController::class, 'index'])->name('dashboard');
    
    // PDV
    Route::get('/pos', function () {
        return view('dashboard.pdv');
    })->name('dashboard.pos');
    
    // Pedidos
    Route::get('/orders', function () {
        return view('dashboard.orders');
    })->name('dashboard.orders');
    
    // Produtos
    Route::get('/products', function () {
        return view('dashboard.products');
    })->name('dashboard.products');
    
    // Categorias
    Route::get('/categories', function () {
        return view('dashboard.categories');
    })->name('dashboard.categories');
    
    // Clientes
    Route::get('/customers', function () {
        return view('dashboard.customers');
    })->name('dashboard.customers');
    
    // Cupons
    Route::get('/coupons', function () {
        return view('dashboard.coupons');
    })->name('dashboard.coupons');
    
    // Configurações
    Route::get('/settings', function () {
        return view('dashboard.settings');
    })->name('dashboard.settings');
    
    // Relatórios
    Route::get('/reports', function () {
        return view('dashboard.reports');
    })->name('dashboard.reports');
    
    Route::get('/reports/sales', function () {
        return view('dashboard.reports-sales');
    })->name('dashboard.reports.sales');
    
    Route::get('/reports/customers', function () {
        return view('dashboard.reports-customers');
    })->name('dashboard.reports.customers');
    
    // WhatsApp
    Route::get('/whatsapp', [WhatsappDashboardController::class, 'index'])->name('whatsapp');
    Route::get('/whatsapp/messages', [WhatsappDashboardController::class, 'messages'])->name('whatsapp.messages');
    Route::get('/whatsapp/rules', [WhatsappDashboardController::class, 'rules'])->name('whatsapp.rules');
    Route::get('/whatsapp/optins', [WhatsappDashboardController::class, 'optins'])->name('whatsapp.optins');
    
    // Estatísticas do WhatsApp
    Route::get('/whatsapp/stats', [WhatsappDashboardController::class, 'getStats'])->name('whatsapp.stats');
    Route::get('/whatsapp/stats/messages', [WhatsappDashboardController::class, 'getMessagesStats'])->name('whatsapp.stats.messages');
    Route::get('/whatsapp/stats/optins', [WhatsappDashboardController::class, 'getOptinsStats'])->name('whatsapp.stats.optins');
    Route::get('/whatsapp/stats/rules', [WhatsappDashboardController::class, 'getRulesStats'])->name('whatsapp.stats.rules');
    Route::get('/whatsapp/stats/sessions', [WhatsappDashboardController::class, 'getSessionsStats'])->name('whatsapp.stats.sessions');
});
