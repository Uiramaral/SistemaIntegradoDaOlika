<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // 1. Sessões do WhatsApp (uma por loja/número)
        Schema::create('whatsapp_sessions', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('loja_id');
            $table->string('phone', 32);
            $table->enum('adapter', ['non_official', 'cloud_api'])->default('non_official');
            $table->enum('status', ['connecting', 'connected', 'disconnected', 'error'])->default('disconnected');
            $table->string('instance_id', 128)->nullable()->comment('id da sessão no gateway (não-oficial) ou phone_number_id (cloud)');
            $table->json('auth_meta_json')->nullable()->comment('cookies/keys criptografadas (não-oficial) ou metadados da Cloud API');
            $table->timestamp('last_seen_at')->nullable();
            $table->string('error_message', 255)->nullable();
            $table->timestamps();
            
            $table->unique(['loja_id', 'adapter'], 'uq_loja_adapter');
            $table->index('phone', 'idx_phone');
            $table->index('status', 'idx_status');
        });

        // 2. Mensagens
        Schema::create('whatsapp_messages', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('loja_id');
            $table->unsignedBigInteger('session_id');
            $table->enum('direction', ['IN', 'OUT']);
            $table->string('peer', 32)->comment('número do cliente');
            $table->enum('type', ['text', 'image', 'file', 'template'])->default('text');
            $table->longText('body_text')->nullable()->comment('texto puro');
            $table->text('media_url')->nullable()->comment('quando image/file');
            $table->string('template_name', 128)->nullable()->comment('quando template');
            $table->json('template_vars')->nullable()->comment('{"nome":"Uirá","pedido":"#123"}');
            $table->enum('status', ['queued', 'sent', 'delivered', 'read', 'failed'])->default('queued');
            $table->string('provider_msg_id', 128)->nullable()->comment('id da mensagem no provedor/gateway');
            $table->string('error_message', 255)->nullable();
            $table->timestamps();
            
            $table->foreign('session_id')->references('id')->on('whatsapp_sessions')->onDelete('cascade');
            $table->index(['loja_id', 'direction', 'created_at'], 'idx_loja_dir_created');
            $table->index(['peer', 'created_at'], 'idx_peer_created');
            $table->index('status', 'idx_status');
        });

        // 3. Opt-ins / Opt-outs
        Schema::create('whatsapp_optins', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('loja_id');
            $table->string('phone', 32);
            $table->timestamp('opted_in_at')->nullable();
            $table->timestamp('opted_out_at')->nullable();
            $table->string('source', 64)->nullable()->comment('checkout|form|whatsapp|manual');
            $table->string('notes', 255)->nullable();
            $table->timestamps();
            
            $table->unique(['loja_id', 'phone'], 'uq_loja_phone');
            $table->index('opted_in_at', 'idx_opted_in');
            $table->index('opted_out_at', 'idx_opted_out');
        });

        // 4. Regras → Evento de pedido => Template
        Schema::create('whatsapp_rules', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('loja_id');
            $table->string('event_key', 64)->comment('ex: order_confirmed|out_for_delivery|delivered|canceled|winback_30d');
            $table->boolean('enabled')->default(true);
            $table->enum('adapter', ['non_official', 'cloud_api', 'any'])->default('any');
            $table->string('template_name', 128);
            $table->longText('template_body')->comment('para não-oficial (texto livre com placeholders)');
            $table->json('template_vars')->nullable()->comment('lista de variáveis esperadas');
            $table->string('send_window', 32)->nullable()->comment('ex: "09:00-20:30" (horário local)');
            $table->timestamps();
            
            $table->index(['loja_id', 'event_key', 'enabled'], 'idx_loja_event');
        });

        // 5. Templates oficiais aprovados pela Meta
        Schema::create('whatsapp_templates', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('loja_id');
            $table->string('name', 128)->comment('ex: "order_update_v1"');
            $table->enum('category', ['marketing', 'utility', 'authentication', 'service'])->default('utility');
            $table->enum('status', ['approved', 'rejected', 'in_review'])->default('in_review');
            $table->string('language', 10)->default('pt_BR');
            $table->longText('body')->comment('conteúdo com {{1}}, {{2}}...');
            $table->timestamps();
            
            $table->unique(['loja_id', 'name'], 'uq_loja_name');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('whatsapp_templates');
        Schema::dropIfExists('whatsapp_rules');
        Schema::dropIfExists('whatsapp_optins');
        Schema::dropIfExists('whatsapp_messages');
        Schema::dropIfExists('whatsapp_sessions');
    }
};
