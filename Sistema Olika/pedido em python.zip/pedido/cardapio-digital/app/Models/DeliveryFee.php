<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DeliveryFee extends Model
{
    use HasFactory;

    protected $fillable = [
        'cep',
        'fee',
        'city',
        'state',
        'neighborhood',
    ];

    protected $casts = [
        'fee' => 'decimal:2',
    ];

    protected $dates = [
        'created_at',
        'updated_at',
    ];

    /**
     * Buscar taxa de entrega por CEP
     */
    public static function findByCep(string $cep): ?self
    {
        $cleanCep = preg_replace('/\D/', '', $cep);
        
        // Buscar por CEP exato
        $deliveryFee = self::where('cep', $cleanCep)->first();
        
        if ($deliveryFee) {
            return $deliveryFee;
        }

        // Buscar por CEP parcial (primeiros 5 dígitos)
        if (strlen($cleanCep) >= 5) {
            $partialCep = substr($cleanCep, 0, 5);
            $deliveryFee = self::where('cep', 'LIKE', $partialCep . '%')->first();
            
            if ($deliveryFee) {
                return $deliveryFee;
            }
        }

        // Buscar por cidade e estado
        if (strlen($cleanCep) >= 8) {
            // Aqui você poderia implementar uma busca por CEP usando uma API
            // Por enquanto, retornamos null para CEPs não encontrados
        }

        return null;
    }

    /**
     * Obter taxa de entrega por CEP
     */
    public static function getFeeByCep(string $cep): float
    {
        $deliveryFee = self::findByCep($cep);
        
        return $deliveryFee ? $deliveryFee->fee : 0.0;
    }

    /**
     * Verificar se há entrega grátis
     */
    public static function hasFreeDelivery(string $cep, float $orderValue, float $freeDeliveryThreshold = 100): bool
    {
        $fee = self::getFeeByCep($cep);
        
        return $fee > 0 && $orderValue >= $freeDeliveryThreshold;
    }

    /**
     * Calcular taxa de entrega final
     */
    public static function calculateDeliveryFee(string $cep, float $orderValue, float $freeDeliveryThreshold = 100): float
    {
        if (self::hasFreeDelivery($cep, $orderValue, $freeDeliveryThreshold)) {
            return 0.0;
        }

        return self::getFeeByCep($cep);
    }

    /**
     * Obter taxa formatada
     */
    public function getFormattedFeeAttribute(): string
    {
        if ($this->fee == 0) {
            return 'Grátis';
        }

        return 'R$ ' . number_format($this->fee, 2, ',', '.');
    }

    /**
     * Obter CEP formatado
     */
    public function getFormattedCepAttribute(): string
    {
        $cep = $this->cep;
        
        if (strlen($cep) == 8) {
            return substr($cep, 0, 5) . '-' . substr($cep, 5, 3);
        }

        return $cep;
    }

    /**
     * Obter endereço completo
     */
    public function getFullAddressAttribute(): string
    {
        $address = '';
        
        if ($this->neighborhood) {
            $address .= $this->neighborhood;
        }
        
        if ($this->city) {
            if ($address) {
                $address .= ', ';
            }
            $address .= $this->city;
        }
        
        if ($this->state) {
            if ($address) {
                $address .= '/';
            }
            $address .= $this->state;
        }
        
        if ($address) {
            $address .= ' - ';
        }
        
        $address .= $this->formatted_cep;
        
        return $address;
    }

    /**
     * Scope para buscar por cidade
     */
    public function scopeByCity($query, string $city)
    {
        return $query->where('city', 'LIKE', "%{$city}%");
    }

    /**
     * Scope para buscar por estado
     */
    public function scopeByState($query, string $state)
    {
        return $query->where('state', strtoupper($state));
    }

    /**
     * Scope para buscar por bairro
     */
    public function scopeByNeighborhood($query, string $neighborhood)
    {
        return $query->where('neighborhood', 'LIKE', "%{$neighborhood}%");
    }

    /**
     * Scope para taxas grátis
     */
    public function scopeFree($query)
    {
        return $query->where('fee', 0);
    }

    /**
     * Scope para taxas pagas
     */
    public function scopePaid($query)
    {
        return $query->where('fee', '>', 0);
    }

    /**
     * Validar CEP
     */
    public static function validateCep(string $cep): bool
    {
        $cleanCep = preg_replace('/\D/', '', $cep);
        return strlen($cleanCep) == 8 && is_numeric($cleanCep);
    }

    /**
     * Limpar CEP
     */
    public static function cleanCep(string $cep): string
    {
        return preg_replace('/\D/', '', $cep);
    }

    /**
     * Boot do modelo
     */
    protected static function boot()
    {
        parent::boot();

        static::creating(function ($deliveryFee) {
            $deliveryFee->cep = self::cleanCep($deliveryFee->cep);
        });

        static::updating(function ($deliveryFee) {
            if ($deliveryFee->isDirty('cep')) {
                $deliveryFee->cep = self::cleanCep($deliveryFee->cep);
            }
        });
    }
}
