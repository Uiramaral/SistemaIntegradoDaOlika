@extends('client.layout-new')

@section('title', 'Finalizar Pedido - Cardápio Digital Olika')

@section('content')
<div class="min-h-screen bg-gray-50">
    <!-- Header -->
    <header class="bg-white shadow-sm border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-4">
                <div class="flex items-center">
                    <a href="{{ route('cart') }}" class="flex items-center space-x-3">
                        <svg class="w-6 h-6 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path>
                        </svg>
                        <span class="text-gray-600">Voltar ao Carrinho</span>
                    </a>
                </div>
                <div class="flex items-center space-x-3">
                    <div class="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                        <span class="text-white font-bold text-lg">O</span>
                    </div>
                    <div>
                        <h1 class="text-xl font-bold text-gray-900">Olika</h1>
                        <p class="text-sm text-gray-500">Finalizar Pedido</p>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <!-- Progress Steps -->
        <div class="mb-8">
            <div class="flex items-center justify-center">
                <div class="flex items-center space-x-4">
                    <div class="flex items-center">
                        <div class="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-medium">1</div>
                        <span class="ml-2 text-sm font-medium text-blue-600">Contato</span>
                    </div>
                    <div class="w-16 h-1 bg-gray-300"></div>
                    <div class="flex items-center">
                        <div class="w-8 h-8 bg-gray-300 text-gray-600 rounded-full flex items-center justify-center text-sm font-medium">2</div>
                        <span class="ml-2 text-sm font-medium text-gray-600">Entrega</span>
                    </div>
                    <div class="w-16 h-1 bg-gray-300"></div>
                    <div class="flex items-center">
                        <div class="w-8 h-8 bg-gray-300 text-gray-600 rounded-full flex items-center justify-center text-sm font-medium">3</div>
                        <span class="ml-2 text-sm font-medium text-gray-600">Pagamento</span>
                    </div>
                    <div class="w-16 h-1 bg-gray-300"></div>
                    <div class="flex items-center">
                        <div class="w-8 h-8 bg-gray-300 text-gray-600 rounded-full flex items-center justify-center text-sm font-medium">4</div>
                        <span class="ml-2 text-sm font-medium text-gray-600">Confirmação</span>
                    </div>
                </div>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <!-- Formulário -->
            <div class="lg:col-span-2">
                <form id="checkout-form" class="space-y-8">
                    <!-- Passo 1: Contato -->
                    <div id="step-1" class="checkout-step">
                        <div class="bg-white rounded-xl shadow-lg p-6">
                            <h2 class="text-2xl font-bold text-gray-900 mb-6">📞 Informações de Contato</h2>
                            
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Nome Completo *</label>
                                    <input type="text" name="name" required class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                                </div>
                                
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Telefone *</label>
                                    <input type="tel" name="phone" required class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="(11) 99999-9999">
                                </div>
                                
                                <div class="md:col-span-2">
                                    <label class="block text-sm font-medium text-gray-700 mb-2">E-mail</label>
                                    <input type="email" name="email" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                                </div>
                            </div>
                            
                            <div class="mt-6">
                                <button type="button" class="next-step bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition">
                                    Continuar
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Passo 2: Entrega -->
                    <div id="step-2" class="checkout-step hidden">
                        <div class="bg-white rounded-xl shadow-lg p-6">
                            <h2 class="text-2xl font-bold text-gray-900 mb-6">🚚 Informações de Entrega</h2>
                            
                            <div class="space-y-6">
                                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-2">CEP *</label>
                                        <input type="text" name="cep" required class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="00000-000">
                                    </div>
                                    
                                    <div class="md:col-span-2">
                                        <label class="block text-sm font-medium text-gray-700 mb-2">Rua *</label>
                                        <input type="text" name="street" required class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                                    </div>
                                </div>
                                
                                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-2">Número *</label>
                                        <input type="text" name="number" required class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                                    </div>
                                    
                                    <div class="md:col-span-2">
                                        <label class="block text-sm font-medium text-gray-700 mb-2">Complemento</label>
                                        <input type="text" name="complement" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                                    </div>
                                </div>
                                
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-2">Bairro *</label>
                                        <input type="text" name="neighborhood" required class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                                    </div>
                                    
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-2">Cidade *</label>
                                        <input type="text" name="city" required class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                                    </div>
                                </div>
                                
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Ponto de Referência</label>
                                    <textarea name="reference" rows="3" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="Ex: Próximo ao shopping, em frente à escola..."></textarea>
                                </div>
                            </div>
                            
                            <div class="mt-6 flex space-x-4">
                                <button type="button" class="prev-step bg-gray-300 text-gray-700 px-6 py-3 rounded-lg hover:bg-gray-400 transition">
                                    Voltar
                                </button>
                                <button type="button" class="next-step bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition">
                                    Continuar
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Passo 3: Pagamento -->
                    <div id="step-3" class="checkout-step hidden">
                        <div class="bg-white rounded-xl shadow-lg p-6">
                            <h2 class="text-2xl font-bold text-gray-900 mb-6">💳 Forma de Pagamento</h2>
                            
                            <div class="space-y-4">
                                <div class="border border-gray-300 rounded-lg p-4 hover:border-blue-500 cursor-pointer payment-method" data-method="whatsapp">
                                    <div class="flex items-center">
                                        <input type="radio" name="payment_method" value="whatsapp" class="mr-3">
                                        <div class="flex-1">
                                            <h3 class="font-medium text-gray-900">💬 WhatsApp</h3>
                                            <p class="text-sm text-gray-600">Pague via WhatsApp com PIX ou transferência</p>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="border border-gray-300 rounded-lg p-4 hover:border-blue-500 cursor-pointer payment-method" data-method="mercadopago">
                                    <div class="flex items-center">
                                        <input type="radio" name="payment_method" value="mercadopago" class="mr-3">
                                        <div class="flex-1">
                                            <h3 class="font-medium text-gray-900">💳 Mercado Pago</h3>
                                            <p class="text-sm text-gray-600">PIX, cartão de crédito/débito ou boleto</p>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="border border-gray-300 rounded-lg p-4 hover:border-blue-500 cursor-pointer payment-method" data-method="cash">
                                    <div class="flex items-center">
                                        <input type="radio" name="payment_method" value="cash" class="mr-3">
                                        <div class="flex-1">
                                            <h3 class="font-medium text-gray-900">💰 Dinheiro</h3>
                                            <p class="text-sm text-gray-600">Pague na entrega com dinheiro</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mt-6 flex space-x-4">
                                <button type="button" class="prev-step bg-gray-300 text-gray-700 px-6 py-3 rounded-lg hover:bg-gray-400 transition">
                                    Voltar
                                </button>
                                <button type="button" class="next-step bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition">
                                    Continuar
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Passo 4: Confirmação -->
                    <div id="step-4" class="checkout-step hidden">
                        <div class="bg-white rounded-xl shadow-lg p-6">
                            <h2 class="text-2xl font-bold text-gray-900 mb-6">✅ Confirmação do Pedido</h2>
                            
                            <div class="space-y-6">
                                <div>
                                    <h3 class="font-medium text-gray-900 mb-3">📞 Dados de Contato</h3>
                                    <div id="contact-summary" class="text-gray-600"></div>
                                </div>
                                
                                <div>
                                    <h3 class="font-medium text-gray-900 mb-3">🚚 Endereço de Entrega</h3>
                                    <div id="address-summary" class="text-gray-600"></div>
                                </div>
                                
                                <div>
                                    <h3 class="font-medium text-gray-900 mb-3">💳 Forma de Pagamento</h3>
                                    <div id="payment-summary" class="text-gray-600"></div>
                                </div>
                                
                                <div>
                                    <h3 class="font-medium text-gray-900 mb-3">📦 Itens do Pedido</h3>
                                    <div id="items-summary" class="text-gray-600"></div>
                                </div>
                            </div>
                            
                            <div class="mt-6 flex space-x-4">
                                <button type="button" class="prev-step bg-gray-300 text-gray-700 px-6 py-3 rounded-lg hover:bg-gray-400 transition">
                                    Voltar
                                </button>
                                <button type="submit" class="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition">
                                    Finalizar Pedido
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>

            <!-- Resumo do Pedido -->
            <div class="lg:col-span-1">
                <div class="bg-white rounded-xl shadow-lg p-6 sticky top-4">
                    <h3 class="text-xl font-bold text-gray-900 mb-4">Resumo do Pedido</h3>
                    
                    <!-- Itens -->
                    <div id="order-items" class="space-y-3 mb-6">
                        <!-- Itens serão carregados via JavaScript -->
                    </div>
                    
                    <hr class="my-4">
                    
                    <!-- Totais -->
                    <div class="space-y-2">
                        <div class="flex justify-between">
                            <span class="text-gray-600">Subtotal</span>
                            <span id="subtotal">R$ 0,00</span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-600">Taxa de Entrega</span>
                            <span id="delivery-fee">R$ 0,00</span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-600">Desconto</span>
                            <span id="discount" class="text-green-600">-R$ 0,00</span>
                        </div>
                        <hr>
                        <div class="flex justify-between text-lg font-bold">
                            <span>Total</span>
                            <span id="total" class="text-green-600">R$ 0,00</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    let currentStep = 1;
    let cart = [];
    let formData = {};

    // Carregar carrinho
    loadCart();

    function loadCart() {
        fetch('/api/cart')
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    cart = data.items || [];
                    renderOrderSummary();
                }
            })
            .catch(error => {
                console.error('Erro ao carregar carrinho:', error);
            });
    }

    function renderOrderSummary() {
        const orderItems = document.getElementById('order-items');
        const subtotal = document.getElementById('subtotal');
        const deliveryFee = document.getElementById('delivery-fee');
        const total = document.getElementById('total');

        if (cart.length === 0) {
            orderItems.innerHTML = '<p class="text-gray-500">Carrinho vazio</p>';
            return;
        }

        // Renderizar itens
        orderItems.innerHTML = cart.map(item => `
            <div class="flex justify-between items-center">
                <div>
                    <p class="font-medium">${item.name}</p>
                    <p class="text-sm text-gray-500">Qtd: ${item.quantity}</p>
                </div>
                <span class="font-medium">R$ ${(item.price * item.quantity).toFixed(2).replace('.', ',')}</span>
            </div>
        `).join('');

        // Calcular totais
        const subtotalValue = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        const deliveryFeeValue = subtotalValue >= 50 ? 0 : 5;
        const totalValue = subtotalValue + deliveryFeeValue;

        subtotal.textContent = `R$ ${subtotalValue.toFixed(2).replace('.', ',')}`;
        deliveryFee.textContent = `R$ ${deliveryFeeValue.toFixed(2).replace('.', ',')}`;
        total.textContent = `R$ ${totalValue.toFixed(2).replace('.', ',')}`;
    }

    // Navegação entre passos
    document.querySelectorAll('.next-step').forEach(btn => {
        btn.addEventListener('click', function() {
            if (validateCurrentStep()) {
                currentStep++;
                showStep(currentStep);
            }
        });
    });

    document.querySelectorAll('.prev-step').forEach(btn => {
        btn.addEventListener('click', function() {
            currentStep--;
            showStep(currentStep);
        });
    });

    function showStep(step) {
        // Ocultar todos os passos
        document.querySelectorAll('.checkout-step').forEach(step => {
            step.classList.add('hidden');
        });

        // Mostrar passo atual
        document.getElementById(`step-${step}`).classList.remove('hidden');

        // Atualizar progresso
        updateProgress(step);

        // Se for o último passo, carregar resumo
        if (step === 4) {
            loadSummary();
        }
    }

    function updateProgress(step) {
        const steps = document.querySelectorAll('.w-8.h-8');
        const lines = document.querySelectorAll('.w-16.h-1');
        
        steps.forEach((stepEl, index) => {
            if (index < step) {
                stepEl.classList.add('bg-blue-600', 'text-white');
                stepEl.classList.remove('bg-gray-300', 'text-gray-600');
            } else {
                stepEl.classList.add('bg-gray-300', 'text-gray-600');
                stepEl.classList.remove('bg-blue-600', 'text-white');
            }
        });

        lines.forEach((line, index) => {
            if (index < step - 1) {
                line.classList.add('bg-blue-600');
                line.classList.remove('bg-gray-300');
            } else {
                line.classList.add('bg-gray-300');
                line.classList.remove('bg-blue-600');
            }
        });
    }

    function validateCurrentStep() {
        const currentStepEl = document.getElementById(`step-${currentStep}`);
        const requiredFields = currentStepEl.querySelectorAll('[required]');
        
        for (let field of requiredFields) {
            if (!field.value.trim()) {
                field.focus();
                alert('Por favor, preencha todos os campos obrigatórios.');
                return false;
            }
        }
        
        return true;
    }

    function loadSummary() {
        // Coletar dados do formulário
        const form = document.getElementById('checkout-form');
        const formDataObj = new FormData(form);
        
        // Resumo de contato
        document.getElementById('contact-summary').innerHTML = `
            <p><strong>Nome:</strong> ${formDataObj.get('name')}</p>
            <p><strong>Telefone:</strong> ${formDataObj.get('phone')}</p>
            <p><strong>E-mail:</strong> ${formDataObj.get('email') || 'Não informado'}</p>
        `;

        // Resumo de endereço
        document.getElementById('address-summary').innerHTML = `
            <p><strong>CEP:</strong> ${formDataObj.get('cep')}</p>
            <p><strong>Endereço:</strong> ${formDataObj.get('street')}, ${formDataObj.get('number')}</p>
            <p><strong>Bairro:</strong> ${formDataObj.get('neighborhood')}</p>
            <p><strong>Cidade:</strong> ${formDataObj.get('city')}</p>
            ${formDataObj.get('reference') ? `<p><strong>Referência:</strong> ${formDataObj.get('reference')}</p>` : ''}
        `;

        // Resumo de pagamento
        const paymentMethod = formDataObj.get('payment_method');
        const paymentText = {
            'whatsapp': '💬 WhatsApp (PIX/Transferência)',
            'mercadopago': '💳 Mercado Pago (PIX/Cartão/Boleto)',
            'cash': '💰 Dinheiro (Na entrega)'
        };
        document.getElementById('payment-summary').innerHTML = `<p><strong>Forma:</strong> ${paymentText[paymentMethod]}</p>`;

        // Resumo de itens
        document.getElementById('items-summary').innerHTML = cart.map(item => `
            <p><strong>${item.name}</strong> - Qtd: ${item.quantity} - R$ ${(item.price * item.quantity).toFixed(2).replace('.', ',')}</p>
        `).join('');
    }

    // Seleção de método de pagamento
    document.querySelectorAll('.payment-method').forEach(method => {
        method.addEventListener('click', function() {
            const radio = this.querySelector('input[type="radio"]');
            radio.checked = true;
            
            // Atualizar visual
            document.querySelectorAll('.payment-method').forEach(m => {
                m.classList.remove('border-blue-500', 'bg-blue-50');
                m.classList.add('border-gray-300');
            });
            this.classList.add('border-blue-500', 'bg-blue-50');
            this.classList.remove('border-gray-300');
        });
    });

    // Finalizar pedido
    document.getElementById('checkout-form').addEventListener('submit', function(e) {
        e.preventDefault();
        
        if (cart.length === 0) {
            alert('Carrinho vazio!');
            return;
        }

        const formDataObj = new FormData(this);
        const orderData = {
            contact: {
                name: formDataObj.get('name'),
                phone: formDataObj.get('phone'),
                email: formDataObj.get('email')
            },
            address: {
                cep: formDataObj.get('cep'),
                street: formDataObj.get('street'),
                number: formDataObj.get('number'),
                complement: formDataObj.get('complement'),
                neighborhood: formDataObj.get('neighborhood'),
                city: formDataObj.get('city'),
                reference: formDataObj.get('reference')
            },
            payment: {
                method: formDataObj.get('payment_method')
            },
            items: cart
        };

        // Enviar pedido
        fetch('/api/orders', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
            },
            body: JSON.stringify(orderData)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Limpar carrinho
                localStorage.removeItem('cart');
                
                // Redirecionar para página de sucesso
                window.location.href = `/order-success/${data.order_id}`;
            } else {
                alert(data.message || 'Erro ao finalizar pedido');
            }
        })
        .catch(error => {
            console.error('Erro:', error);
            alert('Erro ao finalizar pedido');
        });
    });
});
</script>
@endsection
