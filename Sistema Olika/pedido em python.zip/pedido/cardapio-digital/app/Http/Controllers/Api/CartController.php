<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Validator;

class CartController extends Controller
{
    /**
     * Adicionar item ao carrinho
     */
    public function addItem(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'product_id' => 'required|exists:products,id',
            'quantity' => 'required|integer|min:1',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Dados inválidos',
                'errors' => $validator->errors()
            ], 422);
        }

        $product = Product::find($request->product_id);

        if (!$product->isAvailableForSale()) {
            return response()->json([
                'success' => false,
                'message' => 'Produto não está disponível para venda'
            ], 422);
        }

        // Simular carrinho em sessão (em produção, usar Redis ou banco)
        $cart = session('cart', []);
        
        $itemKey = $product->id;
        
        if (isset($cart[$itemKey])) {
            $cart[$itemKey]['quantity'] += $request->quantity;
        } else {
            $cart[$itemKey] = [
                'id' => $product->id,
                'name' => $product->name,
                'description' => $product->description,
                'price' => $product->price,
                'image' => $product->image,
                'category' => $product->category->name ?? '',
                'quantity' => $request->quantity,
            ];
        }

        session(['cart' => $cart]);

        return response()->json([
            'success' => true,
            'message' => 'Produto adicionado ao carrinho',
            'data' => [
                'item' => $cart[$itemKey],
                'cart_count' => count($cart),
                'cart_total' => $this->calculateCartTotal($cart)
            ]
        ]);
    }

    /**
     * Remover item do carrinho
     */
    public function removeItem(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'product_id' => 'required|exists:products,id',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Produto inválido',
                'errors' => $validator->errors()
            ], 422);
        }

        $cart = session('cart', []);
        $productId = $request->product_id;

        if (isset($cart[$productId])) {
            unset($cart[$productId]);
            session(['cart' => $cart]);

            return response()->json([
                'success' => true,
                'message' => 'Produto removido do carrinho',
                'data' => [
                    'cart_count' => count($cart),
                    'cart_total' => $this->calculateCartTotal($cart)
                ]
            ]);
        }

        return response()->json([
            'success' => false,
            'message' => 'Produto não encontrado no carrinho'
        ], 404);
    }

    /**
     * Atualizar quantidade do item
     */
    public function updateQuantity(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'product_id' => 'required|exists:products,id',
            'quantity' => 'required|integer|min:0',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Dados inválidos',
                'errors' => $validator->errors()
            ], 422);
        }

        $cart = session('cart', []);
        $productId = $request->product_id;
        $quantity = $request->quantity;

        if (!isset($cart[$productId])) {
            return response()->json([
                'success' => false,
                'message' => 'Produto não encontrado no carrinho'
            ], 404);
        }

        if ($quantity <= 0) {
            unset($cart[$productId]);
        } else {
            $cart[$productId]['quantity'] = $quantity;
        }

        session(['cart' => $cart]);

        return response()->json([
            'success' => true,
            'message' => 'Quantidade atualizada',
            'data' => [
                'cart_count' => count($cart),
                'cart_total' => $this->calculateCartTotal($cart)
            ]
        ]);
    }

    /**
     * Limpar carrinho
     */
    public function clear(): JsonResponse
    {
        session(['cart' => []]);

        return response()->json([
            'success' => true,
            'message' => 'Carrinho limpo'
        ]);
    }

    /**
     * Obter carrinho
     */
    public function get(): JsonResponse
    {
        $cart = session('cart', []);
        $cartItems = array_values($cart);

        return response()->json([
            'success' => true,
            'data' => [
                'items' => $cartItems,
                'count' => count($cart),
                'subtotal' => $this->calculateCartTotal($cart),
                'formatted_subtotal' => 'R$ ' . number_format($this->calculateCartTotal($cart), 2, ',', '.')
            ]
        ]);
    }

    /**
     * Aplicar cupom
     */
    public function applyCoupon(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'coupon_code' => 'required|string|max:50',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Código do cupom é obrigatório',
                'errors' => $validator->errors()
            ], 422);
        }

        $cart = session('cart', []);
        $subtotal = $this->calculateCartTotal($cart);

        if (empty($cart)) {
            return response()->json([
                'success' => false,
                'message' => 'Carrinho vazio'
            ], 422);
        }

        $coupon = \App\Models\Coupon::findByCode($request->coupon_code);

        if (!$coupon) {
            return response()->json([
                'success' => false,
                'message' => 'Cupom não encontrado'
            ], 404);
        }

        // Verificar se cupom é válido
        if (!$coupon->isValid()) {
            return response()->json([
                'success' => false,
                'message' => 'Cupom não é válido ou expirou'
            ], 422);
        }

        // Verificar valor mínimo
        if ($coupon->min_purchase_value && $subtotal < $coupon->min_purchase_value) {
            return response()->json([
                'success' => false,
                'message' => 'Valor mínimo não atingido para este cupom'
            ], 422);
        }

        // Calcular desconto
        $discount = $coupon->calculateDiscount($subtotal);

        // Salvar cupom aplicado na sessão
        session([
            'applied_coupon' => [
                'coupon' => $coupon->toArray(),
                'discount' => $discount
            ]
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Cupom aplicado com sucesso',
            'data' => [
                'coupon' => $coupon,
                'discount' => $discount,
                'discount_formatted' => 'R$ ' . number_format($discount, 2, ',', '.'),
                'new_total' => $subtotal - $discount,
                'new_total_formatted' => 'R$ ' . number_format($subtotal - $discount, 2, ',', '.')
            ]
        ]);
    }

    /**
     * Remover cupom
     */
    public function removeCoupon(): JsonResponse
    {
        session()->forget('applied_coupon');

        $cart = session('cart', []);
        $subtotal = $this->calculateCartTotal($cart);

        return response()->json([
            'success' => true,
            'message' => 'Cupom removido',
            'data' => [
                'subtotal' => $subtotal,
                'subtotal_formatted' => 'R$ ' . number_format($subtotal, 2, ',', '.')
            ]
        ]);
    }

    /**
     * Obter resumo do carrinho
     */
    public function summary(): JsonResponse
    {
        $cart = session('cart', []);
        $appliedCoupon = session('applied_coupon');
        
        $subtotal = $this->calculateCartTotal($cart);
        $discount = $appliedCoupon['discount'] ?? 0;
        $total = $subtotal - $discount;

        return response()->json([
            'success' => true,
            'data' => [
                'items_count' => count($cart),
                'subtotal' => $subtotal,
                'discount' => $discount,
                'total' => $total,
                'formatted' => [
                    'subtotal' => 'R$ ' . number_format($subtotal, 2, ',', '.'),
                    'discount' => $discount > 0 ? '-R$ ' . number_format($discount, 2, ',', '.') : 'R$ 0,00',
                    'total' => 'R$ ' . number_format($total, 2, ',', '.')
                ],
                'applied_coupon' => $appliedCoupon['coupon'] ?? null
            ]
        ]);
    }

    /**
     * Calcular total do carrinho
     */
    private function calculateCartTotal(array $cart): float
    {
        $total = 0;
        
        foreach ($cart as $item) {
            $total += $item['price'] * $item['quantity'];
        }

        return $total;
    }

    /**
     * Validar carrinho
     */
    public function validate(): JsonResponse
    {
        $cart = session('cart', []);
        $errors = [];

        foreach ($cart as $productId => $item) {
            $product = Product::find($productId);
            
            if (!$product) {
                $errors[] = "Produto '{$item['name']}' não encontrado";
                continue;
            }

            if (!$product->isAvailableForSale()) {
                $errors[] = "Produto '{$item['name']}' não está disponível";
            }

            if ($product->price != $item['price']) {
                $errors[] = "Preço do produto '{$item['name']}' foi alterado";
            }
        }

        if (!empty($errors)) {
            return response()->json([
                'success' => false,
                'message' => 'Carrinho contém itens inválidos',
                'errors' => $errors
            ], 422);
        }

        return response()->json([
            'success' => true,
            'message' => 'Carrinho válido'
        ]);
    }
}
