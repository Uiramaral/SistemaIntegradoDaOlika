<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Category extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'icon',
        'visible',
        'available',
        'sort_order',
    ];

    protected $casts = [
        'visible' => 'boolean',
        'available' => 'boolean',
        'sort_order' => 'integer',
    ];

    protected $dates = [
        'created_at',
        'updated_at',
    ];

    /**
     * Relacionamento com produtos
     */
    public function products(): HasMany
    {
        return $this->hasMany(Product::class);
    }

    /**
     * Scope para categorias visíveis
     */
    public function scopeVisible($query)
    {
        return $query->where('visible', true);
    }

    /**
     * Scope para categorias disponíveis
     */
    public function scopeAvailable($query)
    {
        return $query->where('available', true);
    }

    /**
     * Scope para ordenar por ordem de exibição
     */
    public function scopeOrdered($query)
    {
        return $query->orderBy('sort_order', 'asc')->orderBy('name', 'asc');
    }

    /**
     * Obter produtos da categoria
     */
    public function getProducts($availableOnly = true, $visibleOnly = false)
    {
        $query = $this->products();

        if ($availableOnly) {
            $query->available();
        }

        if ($visibleOnly) {
            $query->visible();
        }

        return $query->orderBy('featured', 'desc')
                    ->orderBy('name', 'asc')
                    ->get();
    }

    /**
     * Contar produtos na categoria
     */
    public function getProductCount($availableOnly = true, $visibleOnly = false): int
    {
        $query = $this->products();

        if ($availableOnly) {
            $query->available();
        }

        if ($visibleOnly) {
            $query->visible();
        }

        return $query->count();
    }

    /**
     * Verificar se categoria tem produtos
     */
    public function hasProducts($availableOnly = true, $visibleOnly = false): bool
    {
        return $this->getProductCount($availableOnly, $visibleOnly) > 0;
    }

    /**
     * Atualizar visibilidade
     */
    public function toggleVisibility(): void
    {
        $this->visible = !$this->visible;
        $this->save();
    }

    /**
     * Atualizar disponibilidade
     */
    public function toggleAvailability(): void
    {
        $this->available = !$this->available;
        $this->save();
    }

    /**
     * Buscar categoria por nome
     */
    public static function findByName(string $name): ?self
    {
        return self::where('name', $name)->first();
    }

    /**
     * Obter categorias com produtos
     */
    public static function withProducts($availableOnly = true, $visibleOnly = false)
    {
        return self::ordered()
                   ->where(function ($query) use ($availableOnly, $visibleOnly) {
                       $query->whereHas('products', function ($productQuery) use ($availableOnly, $visibleOnly) {
                           if ($availableOnly) {
                               $productQuery->available();
                           }
                           if ($visibleOnly) {
                               $productQuery->visible();
                           }
                       });
                   })
                   ->get();
    }
}
