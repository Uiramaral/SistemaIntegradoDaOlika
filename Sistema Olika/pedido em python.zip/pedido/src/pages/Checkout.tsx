import { ArrowLeft, Tag } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useMenu } from "@/contexts/MenuContext";
import { toast } from "sonner";
import { useState } from "react";
import { Badge } from "@/components/ui/badge";

const Checkout = () => {
  const navigate = useNavigate();
  const {
    cart,
    config,
    appliedCoupon,
    applyCoupon,
    removeCoupon,
    coupons,
    addCustomer,
    setCurrentCustomer,
    getDeliveryFee,
    createOrder,
    clearCart,
    customers,
  } = useMenu();

  const [couponCode, setCouponCode] = useState("");
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    email: "",
    cep: "",
    address: "",
    city: "",
    state: "",
    complement: "",
    reference: "",
    observations: "",
  });

  const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const deliveryFee = formData.cep.length === 8 ? getDeliveryFee(formData.cep) : 0;
  
  let discount = 0;
  if (appliedCoupon) {
    discount = appliedCoupon.discountType === 'percentage'
      ? (subtotal * appliedCoupon.discountValue) / 100
      : appliedCoupon.discountValue;
  }
  
  const total = subtotal + deliveryFee - discount;

  const publicCoupons = coupons.filter(c => c.isPublic && c.active);

  const handleApplyCoupon = () => {
    if (!couponCode.trim()) {
      toast.error("Digite um código de cupom");
      return;
    }

    const existing = customers.find(c => c.phone === formData.phone);
    
    if (applyCoupon(couponCode)) {
      toast.success("Cupom aplicado com sucesso!");
      setCouponCode("");
    } else {
      const coupon = coupons.find(c => c.code.toUpperCase() === couponCode.toUpperCase());
      if (!coupon) {
        toast.error("Cupom inválido");
      } else if (coupon.firstPurchaseOnly && existing && existing.orderCount > 0) {
        toast.error("Este cupom é válido apenas para a primeira compra");
      } else if (coupon.minPurchaseValue && subtotal < coupon.minPurchaseValue) {
        toast.error(`Valor mínimo de compra: R$ ${coupon.minPurchaseValue.toFixed(2)}`);
      } else {
        toast.error("Não foi possível aplicar o cupom");
      }
    }
  };

  const handleSubmit = async (paymentMethod: 'whatsapp' | 'mercadopago') => {
    if (!formData.name || !formData.phone || !formData.cep || !formData.address) {
      toast.error("Preencha todos os campos obrigatórios");
      return;
    }

    let customer = customers.find(c => c.phone === formData.phone);
    
    if (!customer) {
      customer = addCustomer({
        name: formData.name,
        phone: formData.phone,
        email: formData.email,
        cep: formData.cep,
        address: formData.address,
        city: formData.city,
        state: formData.state,
        complement: formData.complement,
        reference: formData.reference,
      });
    }

    setCurrentCustomer(customer);

    const order = createOrder({
      customerId: customer.id,
      items: cart,
      subtotal,
      deliveryFee,
      discount,
      total,
      couponCode: appliedCoupon?.code,
      observations: formData.observations,
      paymentMethod,
      status: 'pending',
    });

    if (paymentMethod === 'whatsapp') {
      const message = `🛒 *Novo Pedido #${order.id}*\n\n` +
        `👤 *Cliente:* ${formData.name}\n` +
        `📱 *Telefone:* ${formData.phone}\n` +
        `📍 *Endereço:* ${formData.address}, ${formData.city}/${formData.state}\n` +
        `📮 *CEP:* ${formData.cep}\n` +
        `${formData.complement ? `🏠 *Complemento:* ${formData.complement}\n` : ''}` +
        `${formData.reference ? `📌 *Referência:* ${formData.reference}\n` : ''}` +
        `\n*Itens:*\n${cart.map(item => 
          `${item.quantity}x ${item.name} - R$ ${(item.price * item.quantity).toFixed(2)}`
        ).join('\n')}\n\n` +
        `💰 *Subtotal:* R$ ${subtotal.toFixed(2)}\n` +
        `🚚 *Taxa de Entrega:* R$ ${deliveryFee.toFixed(2)}\n` +
        `${discount > 0 ? `🎟️ *Desconto (${appliedCoupon?.code}):* -R$ ${discount.toFixed(2)}\n` : ''}` +
        `✅ *Total:* R$ ${total.toFixed(2)}\n` +
        `${formData.observations ? `\n📝 *Observações:* ${formData.observations}` : ''}`;

      const phone = config.phone?.replace(/\D/g, "") || "";
      const whatsappUrl = `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
      window.open(whatsappUrl, "_blank");
      
      clearCart();
      removeCoupon();
      toast.success("Pedido enviado com sucesso!");
      navigate("/order-success?order_id=" + order.id);
    } else {
      // Redirecionar para página de confirmação com Mercado Pago
      clearCart();
      removeCoupon();
      navigate("/order-success?order_id=" + order.id + "&payment=mercadopago");
    }
  };

  if (cart.length === 0) {
    navigate("/cart");
    return null;
  }

  return (
    <div className="min-h-screen bg-background pb-32">
      <header className="sticky top-0 z-50 bg-background border-b">
        <div className="container mx-auto px-4">
          <div className="flex items-center gap-4 h-16">
            <Button variant="ghost" size="icon" asChild>
              <Link to="/cart">
                <ArrowLeft className="h-5 w-5" />
              </Link>
            </Button>
            <h1 className="text-xl font-bold">Finalizar Pedido</h1>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        <div className="max-w-2xl mx-auto space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Dados de Entrega</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="name">Nome Completo *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Seu nome completo"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="phone">Telefone *</Label>
                  <Input
                    id="phone"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="(11) 99999-9999"
                  />
                </div>
                <div>
                  <Label htmlFor="email">E-mail</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="seu@email.com"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="cep">CEP *</Label>
                  <Input
                    id="cep"
                    value={formData.cep}
                    onChange={(e) => setFormData({ ...formData, cep: e.target.value.replace(/\D/g, '') })}
                    placeholder="00000-000"
                    maxLength={8}
                  />
                </div>
                <div>
                  <Label htmlFor="city">Cidade *</Label>
                  <Input
                    id="city"
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    placeholder="Cidade"
                  />
                </div>
                <div>
                  <Label htmlFor="state">Estado *</Label>
                  <Input
                    id="state"
                    value={formData.state}
                    onChange={(e) => setFormData({ ...formData, state: e.target.value })}
                    placeholder="SP"
                    maxLength={2}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="address">Endereço Completo *</Label>
                <Input
                  id="address"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  placeholder="Rua, número, bairro"
                />
              </div>

              <div>
                <Label htmlFor="complement">Complemento</Label>
                <Input
                  id="complement"
                  value={formData.complement}
                  onChange={(e) => setFormData({ ...formData, complement: e.target.value })}
                  placeholder="Apto, bloco, etc"
                />
              </div>

              <div>
                <Label htmlFor="reference">Ponto de Referência</Label>
                <Input
                  id="reference"
                  value={formData.reference}
                  onChange={(e) => setFormData({ ...formData, reference: e.target.value })}
                  placeholder="Próximo ao mercado, etc"
                />
              </div>

              <div>
                <Label htmlFor="observations">Observações</Label>
                <Textarea
                  id="observations"
                  value={formData.observations}
                  onChange={(e) => setFormData({ ...formData, observations: e.target.value })}
                  placeholder="Alguma observação sobre seu pedido?"
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>

          {publicCoupons.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Tag className="h-5 w-5" />
                  Cupons Disponíveis
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {publicCoupons.map((coupon) => (
                  <div
                    key={coupon.id}
                    className="flex items-center justify-between p-3 border rounded-lg cursor-pointer hover:bg-accent"
                    onClick={() => {
                      setCouponCode(coupon.code);
                      handleApplyCoupon();
                    }}
                  >
                    <div>
                      <div className="font-semibold flex items-center gap-2">
                        {coupon.code}
                        {coupon.firstPurchaseOnly && (
                          <Badge variant="secondary" className="text-xs">1ª Compra</Badge>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground">{coupon.description}</p>
                    </div>
                    <Button variant="outline" size="sm">Aplicar</Button>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          <Card>
            <CardHeader>
              <CardTitle>Cupom de Desconto</CardTitle>
            </CardHeader>
            <CardContent>
              {appliedCoupon ? (
                <div className="flex items-center justify-between p-3 border rounded-lg bg-success/10">
                  <div>
                    <div className="font-semibold text-success">{appliedCoupon.code}</div>
                    <p className="text-sm text-muted-foreground">{appliedCoupon.description}</p>
                  </div>
                  <Button variant="ghost" size="sm" onClick={removeCoupon}>
                    Remover
                  </Button>
                </div>
              ) : (
                <div className="flex gap-2">
                  <Input
                    value={couponCode}
                    onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
                    placeholder="Digite o código do cupom"
                  />
                  <Button onClick={handleApplyCoupon}>Aplicar</Button>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Resumo do Pedido</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {cart.map((item) => (
                <div key={item.id} className="flex justify-between text-sm">
                  <span>{item.quantity}x {item.name}</span>
                  <span>R$ {(item.price * item.quantity).toFixed(2)}</span>
                </div>
              ))}
              
              <div className="border-t pt-3 space-y-2">
                <div className="flex justify-between">
                  <span>Subtotal:</span>
                  <span>R$ {subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Taxa de Entrega:</span>
                  <span>R$ {deliveryFee.toFixed(2)}</span>
                </div>
                {discount > 0 && (
                  <div className="flex justify-between text-success">
                    <span>Desconto ({appliedCoupon?.code}):</span>
                    <span>-R$ {discount.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between text-lg font-bold border-t pt-2">
                  <span>Total:</span>
                  <span className="text-primary">R$ {total.toFixed(2)}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      <div className="fixed bottom-0 left-0 right-0 bg-background border-t p-4">
        <div className="container mx-auto max-w-2xl space-y-2">
          <Button
            className="w-full"
            size="lg"
            onClick={() => handleSubmit('whatsapp')}
          >
            Finalizar pelo WhatsApp
          </Button>
          {config.mercadoPagoAccessToken && (
            <Button
              className="w-full"
              size="lg"
              variant="outline"
              onClick={() => handleSubmit('mercadopago')}
            >
              Pagar com Mercado Pago
            </Button>
          )}
        </div>
      </div>
    </div>
  );
};

export default Checkout;