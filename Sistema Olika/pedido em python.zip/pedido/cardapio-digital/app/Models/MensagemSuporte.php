<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Carbon\Carbon;

class MensagemSuporte extends Model
{
    use HasFactory;

    protected $table = 'mensagens_suporte';
    
    protected $fillable = [
        'conversa_id',
        'subscriber_id',
        'role',
        'conteudo',
        'metadata',
        'processada',
        'classificacao',
        'tokens_prompt',
        'tokens_completion',
        'tokens_total',
        'model_usado',
        'custo_estimado',
    ];

    protected $casts = [
        'metadata' => 'array',
        'classificacao' => 'array',
        'processada' => 'boolean',
        'tokens_prompt' => 'integer',
        'tokens_completion' => 'integer',
        'tokens_total' => 'integer',
        'custo_estimado' => 'decimal:6',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    /**
     * Relacionamento com ConversaSuporte
     */
    public function conversa(): BelongsTo
    {
        return $this->belongsTo(ConversaSuporte::class, 'conversa_id');
    }

    /**
     * Criar mensagem do usuário
     */
    public static function criarMensagemUsuario(array $dados): self
    {
        return static::create([
            'conversa_id' => $dados['conversa_id'],
            'subscriber_id' => $dados['subscriber_id'] ?? null,
            'role' => 'user',
            'conteudo' => $dados['conteudo'],
            'metadata' => $dados['metadata'] ?? [],
            'processada' => false,
        ]);
    }

    /**
     * Criar mensagem do assistant
     */
    public static function criarMensagemAssistant(array $dados): self
    {
        return static::create([
            'conversa_id' => $dados['conversa_id'],
            'subscriber_id' => $dados['subscriber_id'] ?? null,
            'role' => 'assistant',
            'conteudo' => $dados['conteudo'],
            'metadata' => $dados['metadata'] ?? [],
            'processada' => true,
            'classificacao' => $dados['classificacao'] ?? null,
            'tokens_prompt' => $dados['tokens_prompt'] ?? 0,
            'tokens_completion' => $dados['tokens_completion'] ?? 0,
            'tokens_total' => $dados['tokens_total'] ?? 0,
            'model_usado' => $dados['model_usado'] ?? null,
            'custo_estimado' => $dados['custo_estimado'] ?? 0,
        ]);
    }

    /**
     * Criar mensagem do sistema
     */
    public static function criarMensagemSistema(array $dados): self
    {
        return static::create([
            'conversa_id' => $dados['conversa_id'],
            'subscriber_id' => $dados['subscriber_id'] ?? null,
            'role' => 'system',
            'conteudo' => $dados['conteudo'],
            'metadata' => $dados['metadata'] ?? [],
            'processada' => true,
        ]);
    }

    /**
     * Marcar como processada
     */
    public function marcarProcessada(): void
    {
        $this->update(['processada' => true]);
    }

    /**
     * Atualizar classificação
     */
    public function atualizarClassificacao(array $classificacao): void
    {
        $this->update(['classificacao' => $classificacao]);
    }

    /**
     * Atualizar tokens e custo
     */
    public function atualizarTokens(array $dados): void
    {
        $this->update([
            'tokens_prompt' => $dados['tokens_prompt'] ?? $this->tokens_prompt,
            'tokens_completion' => $dados['tokens_completion'] ?? $this->tokens_completion,
            'tokens_total' => $dados['tokens_total'] ?? $this->tokens_total,
            'model_usado' => $dados['model_usado'] ?? $this->model_usado,
            'custo_estimado' => $dados['custo_estimado'] ?? $this->custo_estimado,
        ]);
    }

    /**
     * Obter classificação de intenção
     */
    public function getIntencao(): ?string
    {
        return $this->classificacao['intencao'] ?? null;
    }

    /**
     * Obter sentimento
     */
    public function getSentimento(): ?string
    {
        return $this->classificacao['sentimento'] ?? null;
    }

    /**
     * Obter urgência
     */
    public function getUrgencia(): ?string
    {
        return $this->classificacao['urgencia'] ?? null;
    }

    /**
     * Obter confiança
     */
    public function getConfianca(): ?float
    {
        return $this->classificacao['confianca'] ?? null;
    }

    /**
     * Verificar se é mensagem do usuário
     */
    public function isUsuario(): bool
    {
        return $this->role === 'user';
    }

    /**
     * Verificar se é mensagem do assistant
     */
    public function isAssistant(): bool
    {
        return $this->role === 'assistant';
    }

    /**
     * Verificar se é mensagem do sistema
     */
    public function isSistema(): bool
    {
        return $this->role === 'system';
    }

    /**
     * Scope para mensagens do usuário
     */
    public function scopeUsuario($query)
    {
        return $query->where('role', 'user');
    }

    /**
     * Scope para mensagens do assistant
     */
    public function scopeAssistant($query)
    {
        return $query->where('role', 'assistant');
    }

    /**
     * Scope para mensagens do sistema
     */
    public function scopeSistema($query)
    {
        return $query->where('role', 'system');
    }

    /**
     * Scope para mensagens processadas
     */
    public function scopeProcessadas($query)
    {
        return $query->where('processada', true);
    }

    /**
     * Scope para mensagens não processadas
     */
    public function scopeNaoProcessadas($query)
    {
        return $query->where('processada', false);
    }

    /**
     * Scope para uma conversa específica
     */
    public function scopePorConversa($query, int $conversaId)
    {
        return $query->where('conversa_id', $conversaId);
    }

    /**
     * Scope para um subscriber específico
     */
    public function scopePorSubscriber($query, string $subscriberId)
    {
        return $query->where('subscriber_id', $subscriberId);
    }

    /**
     * Scope para mensagens recentes
     */
    public function scopeRecentes($query, int $dias = 7)
    {
        return $query->where('created_at', '>=', Carbon::now()->subDays($dias));
    }

    /**
     * Scope para mensagens de hoje
     */
    public function scopeHoje($query)
    {
        return $query->whereDate('created_at', Carbon::today());
    }

    /**
     * Scope para mensagens de ontem
     */
    public function scopeOntem($query)
    {
        return $query->whereDate('created_at', Carbon::yesterday());
    }
}
