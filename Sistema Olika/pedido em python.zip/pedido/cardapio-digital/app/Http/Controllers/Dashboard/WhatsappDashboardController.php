<?php

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class WhatsappDashboardController extends Controller
{
    /**
     * Página principal do WhatsApp
     */
    public function index()
    {
        return view('dashboard.whatsapp');
    }

    /**
     * Página de mensagens
     */
    public function messages()
    {
        return view('dashboard.whatsapp-messages');
    }

    /**
     * Página de regras
     */
    public function rules()
    {
        return view('dashboard.whatsapp-rules');
    }

    /**
     * Página de opt-ins
     */
    public function optins()
    {
        return view('dashboard.whatsapp-optins');
    }

    /**
     * Obter estatísticas gerais do WhatsApp
     */
    public function getStats(Request $request)
    {
        try {
            $lojaId = $request->input('loja_id', 1);

            // Estatísticas de sessões
            $sessionsStats = DB::table('whatsapp_sessions')
                ->where('loja_id', $lojaId)
                ->selectRaw('
                    COUNT(*) as total,
                    SUM(CASE WHEN status = "connected" THEN 1 ELSE 0 END) as connected,
                    SUM(CASE WHEN status = "connecting" THEN 1 ELSE 0 END) as connecting,
                    SUM(CASE WHEN status = "disconnected" THEN 1 ELSE 0 END) as disconnected
                ')
                ->first();

            // Estatísticas de mensagens
            $messagesStats = DB::table('whatsapp_messages')
                ->where('loja_id', $lojaId)
                ->selectRaw('
                    COUNT(*) as total,
                    SUM(CASE WHEN direction = "OUT" THEN 1 ELSE 0 END) as sent,
                    SUM(CASE WHEN direction = "IN" THEN 1 ELSE 0 END) as received,
                    SUM(CASE WHEN status = "queued" THEN 1 ELSE 0 END) as queued,
                    SUM(CASE WHEN status = "delivered" THEN 1 ELSE 0 END) as delivered,
                    SUM(CASE WHEN status = "failed" THEN 1 ELSE 0 END) as failed
                ')
                ->first();

            // Estatísticas de opt-ins
            $optinsStats = DB::table('whatsapp_optins')
                ->where('loja_id', $lojaId)
                ->selectRaw('
                    COUNT(*) as total,
                    SUM(CASE WHEN opted_in_at IS NOT NULL AND opted_out_at IS NULL THEN 1 ELSE 0 END) as opted_in,
                    SUM(CASE WHEN opted_out_at IS NOT NULL THEN 1 ELSE 0 END) as opted_out
                ')
                ->first();

            // Estatísticas de regras
            $rulesStats = DB::table('whatsapp_rules')
                ->where('loja_id', $lojaId)
                ->selectRaw('
                    COUNT(*) as total,
                    SUM(CASE WHEN enabled = 1 THEN 1 ELSE 0 END) as active
                ')
                ->first();

            return response()->json([
                'success' => true,
                'stats' => [
                    'sessions' => $sessionsStats,
                    'messages' => $messagesStats,
                    'optins' => $optinsStats,
                    'rules' => $rulesStats
                ]
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => 'Erro ao carregar estatísticas: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Obter estatísticas de mensagens por período
     */
    public function getMessagesStats(Request $request)
    {
        try {
            $lojaId = $request->input('loja_id', 1);
            $period = $request->input('period', 'today');

            $dateCondition = $this->getDateCondition($period);

            $stats = DB::table('whatsapp_messages')
                ->where('loja_id', $lojaId)
                ->when($dateCondition, function ($query) use ($dateCondition) {
                    return $query->whereRaw($dateCondition);
                })
                ->selectRaw('
                    COUNT(*) as total,
                    SUM(CASE WHEN direction = "OUT" THEN 1 ELSE 0 END) as sent,
                    SUM(CASE WHEN direction = "IN" THEN 1 ELSE 0 END) as received,
                    SUM(CASE WHEN status = "queued" THEN 1 ELSE 0 END) as queued,
                    SUM(CASE WHEN status = "delivered" THEN 1 ELSE 0 END) as delivered,
                    SUM(CASE WHEN status = "failed" THEN 1 ELSE 0 END) as failed,
                    SUM(CASE WHEN status = "read" THEN 1 ELSE 0 END) as read
                ')
                ->first();

            return response()->json([
                'success' => true,
                'stats' => $stats
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => 'Erro ao carregar estatísticas de mensagens: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Obter estatísticas de opt-ins por período
     */
    public function getOptinsStats(Request $request)
    {
        try {
            $lojaId = $request->input('loja_id', 1);
            $period = $request->input('period', 'today');

            $dateCondition = $this->getDateCondition($period);

            $stats = DB::table('whatsapp_optins')
                ->where('loja_id', $lojaId)
                ->when($dateCondition, function ($query) use ($dateCondition) {
                    return $query->whereRaw($dateCondition);
                })
                ->selectRaw('
                    COUNT(*) as total,
                    SUM(CASE WHEN opted_in_at IS NOT NULL AND opted_out_at IS NULL THEN 1 ELSE 0 END) as opted_in,
                    SUM(CASE WHEN opted_out_at IS NOT NULL THEN 1 ELSE 0 END) as opted_out
                ')
                ->first();

            return response()->json([
                'success' => true,
                'stats' => $stats
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => 'Erro ao carregar estatísticas de opt-ins: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Obter estatísticas de regras
     */
    public function getRulesStats(Request $request)
    {
        try {
            $lojaId = $request->input('loja_id', 1);

            $stats = DB::table('whatsapp_rules')
                ->where('loja_id', $lojaId)
                ->selectRaw('
                    COUNT(*) as total,
                    SUM(CASE WHEN enabled = 1 THEN 1 ELSE 0 END) as active,
                    SUM(CASE WHEN enabled = 0 THEN 1 ELSE 0 END) as inactive,
                    SUM(CASE WHEN adapter = "non_official" THEN 1 ELSE 0 END) as non_official,
                    SUM(CASE WHEN adapter = "cloud_api" THEN 1 ELSE 0 END) as cloud_api,
                    SUM(CASE WHEN adapter = "any" THEN 1 ELSE 0 END) as any
                ')
                ->first();

            return response()->json([
                'success' => true,
                'stats' => $stats
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => 'Erro ao carregar estatísticas de regras: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Obter estatísticas de sessões
     */
    public function getSessionsStats(Request $request)
    {
        try {
            $lojaId = $request->input('loja_id', 1);

            $stats = DB::table('whatsapp_sessions')
                ->where('loja_id', $lojaId)
                ->selectRaw('
                    COUNT(*) as total,
                    SUM(CASE WHEN status = "connected" THEN 1 ELSE 0 END) as connected,
                    SUM(CASE WHEN status = "connecting" THEN 1 ELSE 0 END) as connecting,
                    SUM(CASE WHEN status = "disconnected" THEN 1 ELSE 0 END) as disconnected,
                    SUM(CASE WHEN status = "error" THEN 1 ELSE 0 END) as error,
                    SUM(CASE WHEN adapter = "non_official" THEN 1 ELSE 0 END) as non_official,
                    SUM(CASE WHEN adapter = "cloud_api" THEN 1 ELSE 0 END) as cloud_api
                ')
                ->first();

            return response()->json([
                'success' => true,
                'stats' => $stats
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => 'Erro ao carregar estatísticas de sessões: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Obter condição de data baseada no período
     */
    private function getDateCondition($period)
    {
        switch ($period) {
            case 'today':
                return 'DATE(created_at) = CURDATE()';
            case 'week':
                return 'created_at >= DATE_SUB(NOW(), INTERVAL 1 WEEK)';
            case 'month':
                return 'created_at >= DATE_SUB(NOW(), INTERVAL 1 MONTH)';
            case 'year':
                return 'created_at >= DATE_SUB(NOW(), INTERVAL 1 YEAR)';
            default:
                return null;
        }
    }
}
