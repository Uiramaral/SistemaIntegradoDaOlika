<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class AIConversation extends Model
{
    use HasFactory;

    protected $fillable = [
        'phone',
        'customer_id',
        'message_type',
        'message_content',
        'intent_recognized',
        'intent_confidence',
        'entities_extracted',
        'context_data',
        'response_generated',
        'actions_triggered',
        'processing_time_ms',
    ];

    protected $casts = [
        'entities_extracted' => 'array',
        'context_data' => 'array',
        'actions_triggered' => 'array',
        'intent_confidence' => 'decimal:4',
        'processing_time_ms' => 'integer',
    ];

    /**
     * Relacionamento com Customer
     */
    public function customer(): BelongsTo
    {
        return $this->belongsTo(Customer::class);
    }

    /**
     * Relacionamento com AIFeedback
     */
    public function feedbacks(): HasMany
    {
        return $this->hasMany(AIFeedback::class, 'conversation_id');
    }

    /**
     * Scope para mensagens recebidas
     */
    public function scopeIncoming($query)
    {
        return $query->where('message_type', 'incoming');
    }

    /**
     * Scope para mensagens enviadas
     */
    public function scopeOutgoing($query)
    {
        return $query->where('message_type', 'outgoing');
    }

    /**
     * Scope para um telefone específico
     */
    public function scopeForPhone($query, string $phone)
    {
        return $query->where('phone', $phone);
    }

    /**
     * Scope para uma intenção específica
     */
    public function scopeWithIntent($query, string $intent)
    {
        return $query->where('intent_recognized', $intent);
    }

    /**
     * Scope para alta confiança
     */
    public function scopeHighConfidence($query, float $threshold = 0.8)
    {
        return $query->where('intent_confidence', '>=', $threshold);
    }

    /**
     * Obter conversas recentes
     */
    public static function getRecentConversations(string $phone, int $limit = 10): \Illuminate\Database\Eloquent\Collection
    {
        return static::forPhone($phone)
            ->orderBy('created_at', 'desc')
            ->limit($limit)
            ->get();
    }

    /**
     * Obter estatísticas de conversas
     */
    public static function getConversationStats(string $phone): array
    {
        $conversations = static::forPhone($phone)->get();
        
        return [
            'total_messages' => $conversations->count(),
            'incoming_messages' => $conversations->where('message_type', 'incoming')->count(),
            'outgoing_messages' => $conversations->where('message_type', 'outgoing')->count(),
            'unique_intents' => $conversations->pluck('intent_recognized')->unique()->count(),
            'average_confidence' => $conversations->avg('intent_confidence'),
            'average_processing_time' => $conversations->avg('processing_time_ms'),
            'last_conversation' => $conversations->sortByDesc('created_at')->first()?->created_at,
        ];
    }

    /**
     * Obter histórico de intenções
     */
    public static function getIntentHistory(string $phone, int $limit = 20): array
    {
        return static::forPhone($phone)
            ->incoming()
            ->whereNotNull('intent_recognized')
            ->orderBy('created_at', 'desc')
            ->limit($limit)
            ->get()
            ->map(function ($conversation) {
                return [
                    'intent' => $conversation->intent_recognized,
                    'confidence' => $conversation->intent_confidence,
                    'timestamp' => $conversation->created_at,
                    'message' => $conversation->message_content,
                ];
            })
            ->toArray();
    }

    /**
     * Verificar se há conversa recente
     */
    public static function hasRecentConversation(string $phone, int $minutes = 30): bool
    {
        return static::forPhone($phone)
            ->where('created_at', '>=', now()->subMinutes($minutes))
            ->exists();
    }

    /**
     * Obter contexto da conversa
     */
    public static function getConversationContext(string $phone): array
    {
        $recentConversation = static::forPhone($phone)
            ->orderBy('created_at', 'desc')
            ->first();

        return $recentConversation?->context_data ?? [];
    }

    /**
     * Salvar contexto da conversa
     */
    public static function saveConversationContext(string $phone, array $context): void
    {
        // Implementar lógica para salvar contexto
        // Pode usar cache ou tabela específica
    }

    /**
     * Limpar conversas antigas
     */
    public static function cleanupOldConversations(int $days = 30): int
    {
        return static::where('created_at', '<', now()->subDays($days))->delete();
    }

    /**
     * Obter métricas de performance
     */
    public static function getPerformanceMetrics(string $phone = null): array
    {
        $query = static::query();
        
        if ($phone) {
            $query->forPhone($phone);
        }

        $conversations = $query->get();

        return [
            'total_conversations' => $conversations->count(),
            'successful_recognitions' => $conversations->where('intent_confidence', '>=', 0.8)->count(),
            'failed_recognitions' => $conversations->where('intent_confidence', '<', 0.8)->count(),
            'average_confidence' => $conversations->avg('intent_confidence'),
            'average_processing_time' => $conversations->avg('processing_time_ms'),
            'most_common_intents' => $conversations
                ->whereNotNull('intent_recognized')
                ->groupBy('intent_recognized')
                ->map->count()
                ->sortDesc()
                ->take(5)
                ->toArray(),
        ];
    }
}
