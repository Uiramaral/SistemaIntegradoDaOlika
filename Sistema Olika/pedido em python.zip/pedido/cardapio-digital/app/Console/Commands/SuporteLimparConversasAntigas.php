<?php

namespace App\Console\Commands;

use App\Models\ConversaSuporte;
use App\Models\MensagemSuporte;
use Illuminate\Console\Command;
use Carbon\Carbon;

class SuporteLimparConversasAntigas extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'suporte:limpar-conversas-antigas {--dias=30 : Número de dias para considerar conversas antigas}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Limpa conversas de suporte antigas e não ativas';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $dias = $this->option('dias');
        $dataLimite = Carbon::now()->subDays($dias);

        $this->info("🧹 Iniciando limpeza de conversas antigas (mais de {$dias} dias)...");

        // Buscar conversas antigas e encerradas
        $conversasAntigas = ConversaSuporte::where('updated_at', '<', $dataLimite)
            ->where('status', '!=', 'ativa')
            ->get();

        $totalConversas = $conversasAntigas->count();
        
        if ($totalConversas === 0) {
            $this->info('✅ Nenhuma conversa antiga encontrada para limpeza.');
            return;
        }

        $this->info("📊 Encontradas {$totalConversas} conversas antigas para limpeza.");

        $bar = $this->output->createProgressBar($totalConversas);
        $bar->start();

        $conversasRemovidas = 0;
        $mensagensRemovidas = 0;

        foreach ($conversasAntigas as $conversa) {
            // Contar mensagens antes de remover
            $mensagensCount = $conversa->mensagens()->count();
            
            // Remover conversa (cascade remove as mensagens)
            $conversa->delete();
            
            $conversasRemovidas++;
            $mensagensRemovidas += $mensagensCount;
            
            $bar->advance();
        }

        $bar->finish();
        $this->newLine();

        $this->info("✅ Limpeza concluída:");
        $this->info("   - Conversas removidas: {$conversasRemovidas}");
        $this->info("   - Mensagens removidas: {$mensagensRemovidas}");
        $this->info("   - Data limite: {$dataLimite->format('d/m/Y H:i:s')}");

        // Estatísticas atuais
        $conversasAtivas = ConversaSuporte::ativas()->count();
        $totalMensagens = MensagemSuporte::count();

        $this->info("📊 Estatísticas atuais:");
        $this->info("   - Conversas ativas: {$conversasAtivas}");
        $this->info("   - Total de mensagens: {$totalMensagens}");
    }
}
