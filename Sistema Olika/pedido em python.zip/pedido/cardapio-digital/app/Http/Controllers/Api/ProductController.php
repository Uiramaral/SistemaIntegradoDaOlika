<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Validator;

class ProductController extends Controller
{
    /**
     * Listar produtos com filtros
     */
    public function index(Request $request): JsonResponse
    {
        $search = $request->get('search');
        $categoryId = $request->get('category_id');
        $availableOnly = $request->boolean('available_only', true);
        $visibleOnly = $request->boolean('visible_only', false);

        $products = Product::search($search, $categoryId, $availableOnly, $visibleOnly)
            ->with('category')
            ->paginate(20);

        return response()->json([
            'success' => true,
            'data' => $products
        ]);
    }

    /**
     * Obter produto específico
     */
    public function show(Product $product): JsonResponse
    {
        $product->load('category');

        return response()->json([
            'success' => true,
            'data' => $product
        ]);
    }

    /**
     * Criar novo produto
     */
    public function store(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'price' => 'required|numeric|min:0',
            'image' => 'nullable|string|max:500',
            'category_id' => 'required|exists:categories,id',
            'available' => 'boolean',
            'featured' => 'boolean',
            'visible' => 'boolean',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Dados inválidos',
                'errors' => $validator->errors()
            ], 422);
        }

        $product = Product::create($request->all());
        $product->load('category');

        return response()->json([
            'success' => true,
            'message' => 'Produto criado com sucesso',
            'data' => $product
        ], 201);
    }

    /**
     * Atualizar produto
     */
    public function update(Request $request, Product $product): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'name' => 'sometimes|required|string|max:255',
            'description' => 'nullable|string',
            'price' => 'sometimes|required|numeric|min:0',
            'image' => 'nullable|string|max:500',
            'category_id' => 'sometimes|required|exists:categories,id',
            'available' => 'boolean',
            'featured' => 'boolean',
            'visible' => 'boolean',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Dados inválidos',
                'errors' => $validator->errors()
            ], 422);
        }

        $product->update($request->all());
        $product->load('category');

        return response()->json([
            'success' => true,
            'message' => 'Produto atualizado com sucesso',
            'data' => $product
        ]);
    }

    /**
     * Deletar produto
     */
    public function destroy(Product $product): JsonResponse
    {
        $product->delete();

        return response()->json([
            'success' => true,
            'message' => 'Produto deletado com sucesso'
        ]);
    }

    /**
     * Toggle disponibilidade
     */
    public function toggleAvailability(Product $product): JsonResponse
    {
        $product->toggleAvailability();

        return response()->json([
            'success' => true,
            'message' => 'Disponibilidade atualizada',
            'data' => $product
        ]);
    }

    /**
     * Toggle destaque
     */
    public function toggleFeatured(Product $product): JsonResponse
    {
        $product->toggleFeatured();

        return response()->json([
            'success' => true,
            'message' => 'Status de destaque atualizado',
            'data' => $product
        ]);
    }

    /**
     * Toggle visibilidade
     */
    public function toggleVisibility(Product $product): JsonResponse
    {
        $product->toggleVisibility();

        return response()->json([
            'success' => true,
            'message' => 'Visibilidade atualizada',
            'data' => $product
        ]);
    }

    /**
     * Obter produtos por categoria
     */
    public function byCategory(Category $category): JsonResponse
    {
        $products = $category->getProducts();

        return response()->json([
            'success' => true,
            'data' => $products
        ]);
    }

    /**
     * Buscar produtos
     */
    public function search(Request $request): JsonResponse
    {
        $search = $request->get('q');
        $categoryId = $request->get('category_id');
        $availableOnly = $request->boolean('available_only', true);
        $visibleOnly = $request->boolean('visible_only', false);

        $products = Product::search($search, $categoryId, $availableOnly, $visibleOnly)
            ->with('category')
            ->limit(50)
            ->get();

        return response()->json([
            'success' => true,
            'data' => $products
        ]);
    }

    /**
     * Obter produtos em destaque
     */
    public function featured(): JsonResponse
    {
        $products = Product::featured()
            ->available()
            ->visible()
            ->with('category')
            ->get();

        return response()->json([
            'success' => true,
            'data' => $products
        ]);
    }
}
