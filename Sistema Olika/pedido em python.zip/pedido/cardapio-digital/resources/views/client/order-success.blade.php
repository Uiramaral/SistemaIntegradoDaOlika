@extends('client.layout-new')

@section('title', 'Pedido Realizado - Cardápio Digital Olika')

@section('content')
<div class="min-h-screen bg-gray-50 flex items-center justify-center">
    <div class="max-w-md w-full bg-white rounded-xl shadow-lg p-8 text-center">
        <!-- Ícone de Sucesso -->
        <div class="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <svg class="w-10 h-10 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
            </svg>
        </div>

        <!-- Título -->
        <h1 class="text-2xl font-bold text-gray-900 mb-2">Pedido Realizado!</h1>
        <p class="text-gray-600 mb-6">Seu pedido foi enviado com sucesso e está sendo processado.</p>

        <!-- Informações do Pedido -->
        <div class="bg-gray-50 rounded-lg p-4 mb-6">
            <div class="flex justify-between items-center mb-2">
                <span class="text-sm text-gray-600">Número do Pedido:</span>
                <span class="font-semibold text-gray-900">#{{ $orderId ?? '1234' }}</span>
            </div>
            <div class="flex justify-between items-center mb-2">
                <span class="text-sm text-gray-600">Total:</span>
                <span class="font-semibold text-green-600">R$ {{ number_format($total ?? 0, 2, ',', '.') }}</span>
            </div>
            <div class="flex justify-between items-center">
                <span class="text-sm text-gray-600">Status:</span>
                <span class="px-2 py-1 bg-yellow-100 text-yellow-800 text-xs rounded-full">Processando</span>
            </div>
        </div>

        <!-- Próximos Passos -->
        <div class="text-left mb-6">
            <h3 class="font-semibold text-gray-900 mb-3">Próximos Passos:</h3>
            <div class="space-y-2 text-sm text-gray-600">
                <div class="flex items-center">
                    <div class="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center mr-3">
                        <span class="text-xs font-bold text-blue-600">1</span>
                    </div>
                    <span>Confirmaremos seu pedido em até 5 minutos</span>
                </div>
                <div class="flex items-center">
                    <div class="w-6 h-6 bg-gray-100 rounded-full flex items-center justify-center mr-3">
                        <span class="text-xs font-bold text-gray-600">2</span>
                    </div>
                    <span>Prepararemos seu pedido com carinho</span>
                </div>
                <div class="flex items-center">
                    <div class="w-6 h-6 bg-gray-100 rounded-full flex items-center justify-center mr-3">
                        <span class="text-xs font-bold text-gray-600">3</span>
                    </div>
                    <span>Entregaremos no endereço informado</span>
                </div>
            </div>
        </div>

        <!-- Informações de Contato -->
        <div class="bg-blue-50 rounded-lg p-4 mb-6">
            <h3 class="font-semibold text-blue-900 mb-2">Precisa de ajuda?</h3>
            <p class="text-sm text-blue-700 mb-3">Entre em contato conosco:</p>
            <div class="space-y-1 text-sm text-blue-600">
                <p>📞 (11) 99999-9999</p>
                <p>✉️ contato@olika.com</p>
            </div>
        </div>

        <!-- Botões de Ação -->
        <div class="space-y-3">
            <a href="{{ route('menu') }}" class="w-full bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 transition font-medium block">
                Fazer Novo Pedido
            </a>
            <a href="https://wa.me/5511999999999?text=Olá! Gostaria de acompanhar meu pedido #{{ $orderId ?? '1234' }}" 
               target="_blank" 
               class="w-full bg-green-600 text-white py-3 px-4 rounded-lg hover:bg-green-700 transition font-medium block">
                Acompanhar no WhatsApp
            </a>
        </div>

        <!-- Tempo Estimado -->
        <div class="mt-6 pt-6 border-t border-gray-200">
            <p class="text-sm text-gray-500">
                ⏱️ Tempo estimado de entrega: <span class="font-semibold">30-45 minutos</span>
            </p>
        </div>
    </div>
</div>

<script>
// Auto-redirect após 30 segundos (opcional)
setTimeout(() => {
    if (confirm('Deseja fazer um novo pedido?')) {
        window.location.href = '{{ route("menu") }}';
    }
}, 30000);
</script>
@endsection
