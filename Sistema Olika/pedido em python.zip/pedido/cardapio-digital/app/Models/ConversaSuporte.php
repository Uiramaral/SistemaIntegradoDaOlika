<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Carbon\Carbon;

class ConversaSuporte extends Model
{
    use HasFactory;

    protected $table = 'conversas_suporte';
    
    protected $fillable = [
        'cliente_id',
        'subscriber_id',
        'telefone',
        'nome',
        'status',
        'assunto',
        'metadata',
    ];

    protected $casts = [
        'metadata' => 'array',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    /**
     * Relacionamento com Customer
     */
    public function cliente(): BelongsTo
    {
        return $this->belongsTo(Customer::class, 'cliente_id');
    }

    /**
     * Relacionamento com MensagemSuporte
     */
    public function mensagens(): HasMany
    {
        return $this->hasMany(MensagemSuporte::class, 'conversa_id');
    }

    /**
     * Buscar conversa ativa por subscriber_id
     */
    public static function buscarAtivaPorSubscriber(string $subscriberId): ?self
    {
        return static::where('subscriber_id', $subscriberId)
            ->where('status', 'ativa')
            ->orderBy('updated_at', 'desc')
            ->first();
    }

    /**
     * Buscar conversa ativa por telefone
     */
    public static function buscarAtivaPorTelefone(string $telefone): ?self
    {
        return static::where('telefone', $telefone)
            ->where('status', 'ativa')
            ->orderBy('updated_at', 'desc')
            ->first();
    }

    /**
     * Criar nova conversa
     */
    public static function criarConversa(array $dados): self
    {
        return static::create([
            'cliente_id' => $dados['cliente_id'] ?? null,
            'subscriber_id' => $dados['subscriber_id'] ?? null,
            'telefone' => $dados['telefone'],
            'nome' => $dados['nome'],
            'status' => 'ativa',
            'assunto' => $dados['assunto'] ?? null,
            'metadata' => $dados['metadata'] ?? [],
        ]);
    }

    /**
     * Atualizar subscriber_id se necessário
     */
    public function atualizarSubscriberId(string $subscriberId): void
    {
        if ($this->subscriber_id !== $subscriberId) {
            $this->update(['subscriber_id' => $subscriberId]);
        }
    }

    /**
     * Encerrar conversa
     */
    public function encerrar(): void
    {
        $this->update(['status' => 'encerrada']);
    }

    /**
     * Verificar se conversa é recente (hoje ou ontem)
     */
    public function isRecente(): bool
    {
        $hoje = Carbon::now()->startOfDay();
        $ontem = Carbon::now()->subDay()->startOfDay();
        
        return $this->created_at->gte($ontem);
    }

    /**
     * Obter dias desde última mensagem
     */
    public function getDiasDesdeUltimaMensagem(): int
    {
        $ultimaMensagem = $this->mensagens()
            ->orderBy('created_at', 'desc')
            ->first();
            
        if (!$ultimaMensagem) {
            return $this->created_at->diffInDays(Carbon::now());
        }
        
        return $ultimaMensagem->created_at->diffInDays(Carbon::now());
    }

    /**
     * Obter total de mensagens
     */
    public function getTotalMensagens(): int
    {
        return $this->mensagens()->count();
    }

    /**
     * Obter última mensagem
     */
    public function getUltimaMensagem(): ?MensagemSuporte
    {
        return $this->mensagens()
            ->orderBy('created_at', 'desc')
            ->first();
    }

    /**
     * Obter mensagens de hoje
     */
    public function getMensagensHoje(): \Illuminate\Database\Eloquent\Collection
    {
        return $this->mensagens()
            ->whereDate('created_at', Carbon::today())
            ->orderBy('created_at', 'asc')
            ->get();
    }

    /**
     * Obter mensagens de ontem
     */
    public function getMensagensOntem(): \Illuminate\Database\Eloquent\Collection
    {
        return $this->mensagens()
            ->whereDate('created_at', Carbon::yesterday())
            ->orderBy('created_at', 'asc')
            ->get();
    }

    /**
     * Obter mensagens recentes (hoje + ontem)
     */
    public function getMensagensRecentes(): \Illuminate\Database\Eloquent\Collection
    {
        $hoje = Carbon::today();
        $ontem = Carbon::yesterday();
        
        return $this->mensagens()
            ->where(function($query) use ($hoje, $ontem) {
                $query->whereDate('created_at', $hoje)
                      ->orWhereDate('created_at', $ontem);
            })
            ->orderBy('created_at', 'asc')
            ->get();
    }

    /**
     * Obter estatísticas da conversa
     */
    public function getEstatisticas(): array
    {
        $mensagens = $this->mensagens;
        
        return [
            'total_mensagens' => $mensagens->count(),
            'mensagens_usuario' => $mensagens->where('role', 'user')->count(),
            'mensagens_assistant' => $mensagens->where('role', 'assistant')->count(),
            'total_tokens' => $mensagens->sum('tokens_total'),
            'custo_total' => $mensagens->sum('custo_estimado'),
            'primeira_mensagem' => $mensagens->min('created_at'),
            'ultima_mensagem' => $mensagens->max('created_at'),
            'dias_ativo' => $this->created_at->diffInDays(Carbon::now()),
        ];
    }

    /**
     * Scope para conversas ativas
     */
    public function scopeAtivas($query)
    {
        return $query->where('status', 'ativa');
    }

    /**
     * Scope para conversas encerradas
     */
    public function scopeEncerradas($query)
    {
        return $query->where('status', 'encerrada');
    }

    /**
     * Scope para um assunto específico
     */
    public function scopePorAssunto($query, string $assunto)
    {
        return $query->where('assunto', $assunto);
    }

    /**
     * Scope para conversas recentes
     */
    public function scopeRecentes($query, int $dias = 7)
    {
        return $query->where('created_at', '>=', Carbon::now()->subDays($dias));
    }
}
