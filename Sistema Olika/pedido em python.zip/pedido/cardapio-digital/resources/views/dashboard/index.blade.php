@extends('layouts.app')

@section('title', 'Dashboard - Cardápio Digital Olika')

@section('content')
<div x-data="dashboardData()" x-init="init()" class="space-y-6">
    <!-- Welcome Message -->
    <div class="mb-6">
        <h1 class="text-2xl font-bold text-gray-900">
            Bem vindo, {{ $settings->business_name ?? 'Olika' }}
        </h1>
    </div>

    <!-- Community Card -->
    <div class="bg-gradient-to-r from-pink-50 to-pink-100 border border-pink-200 rounded-lg p-6">
        <div class="flex items-center gap-3 mb-3">
            <div class="w-10 h-10 bg-pink-500 rounded-lg flex items-center justify-center">
                <i data-lucide="megaphone" class="w-5 h-5 text-white"></i>
            </div>
            <div>
                <h2 class="text-lg font-semibold">Conheça a comunidade do Diggy</h2>
                <p class="text-sm text-gray-600">
                    Conecte-se com o Diggy, envie sugestões, acompanhe novidades e participe da comunidade
                </p>
            </div>
        </div>
        <button class="bg-pink-500 hover:bg-pink-600 text-white px-4 py-2 rounded-md text-sm font-medium flex items-center gap-2">
            Acessar
            <i data-lucide="arrow-right" class="w-4 h-4"></i>
        </button>
    </div>

    <!-- Performance Section -->
    <div class="space-y-4">
        <div class="flex items-center justify-between">
            <h2 class="text-xl font-semibold">Desempenho</h2>
            <div class="flex gap-2">
                <select x-model="performancePeriod" @change="updateStats()" class="text-sm border border-gray-300 rounded px-3 py-1">
                    <option value="7">Últimos 7 dias</option>
                    <option value="30">Últimos 30 dias</option>
                    <option value="90">Últimos 90 dias</option>
                </select>
                <select x-model="performanceMetric" @change="updateStats()" class="text-sm border border-gray-300 rounded px-3 py-1">
                    <option value="orders">Número de pedidos</option>
                    <option value="revenue">Valor das vendas</option>
                    <option value="customers">Clientes únicos</option>
                </select>
            </div>
        </div>
        
        <p class="text-sm text-gray-600">
            Você está vendo os pedidos recebidos na sua loja nos últimos <span x-text="performancePeriod"></span> dias
        </p>

        <!-- Stats Cards -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <!-- Menu Views -->
            <div class="bg-white rounded-lg shadow-sm border p-4">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm text-gray-600">acessos ao seu menu nos últimos <span x-text="performancePeriod"></span> dias</p>
                        <p class="text-2xl font-bold text-gray-900" x-text="stats.menuViews"></p>
                    </div>
                    <div class="flex gap-2">
                        <button class="p-2 hover:bg-gray-100 rounded-md">
                            <i data-lucide="eye" class="w-4 h-4"></i>
                        </button>
                        <button class="p-2 hover:bg-gray-100 rounded-md">
                            <i data-lucide="trending-up" class="w-4 h-4"></i>
                        </button>
                    </div>
                </div>
            </div>

            <!-- Orders -->
            <div class="bg-white rounded-lg shadow-sm border p-4">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm text-gray-600">vendas realizadas nos últimos <span x-text="performancePeriod"></span> dias</p>
                        <p class="text-2xl font-bold text-gray-900" x-text="stats.ordersCount"></p>
                    </div>
                    <div class="flex gap-2">
                        <button class="p-2 hover:bg-gray-100 rounded-md">
                            <i data-lucide="eye" class="w-4 h-4"></i>
                        </button>
                        <button class="p-2 hover:bg-gray-100 rounded-md">
                            <i data-lucide="calendar" class="w-4 h-4"></i>
                        </button>
                    </div>
                </div>
            </div>

            <!-- Revenue -->
            <div class="bg-white rounded-lg shadow-sm border p-4">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm text-gray-600">recebeu em vendas nos últimos <span x-text="performancePeriod"></span> dias</p>
                        <p class="text-2xl font-bold text-gray-900" x-text="formatCurrency(stats.revenue)"></p>
                    </div>
                    <div class="flex gap-2">
                        <button class="p-2 hover:bg-gray-100 rounded-md">
                            <i data-lucide="eye" class="w-4 h-4"></i>
                        </button>
                        <button class="p-2 hover:bg-gray-100 rounded-md">
                            <i data-lucide="dollar-sign" class="w-4 h-4"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Chart -->
        <div class="bg-white rounded-lg shadow-sm border p-6">
            <div class="h-64 flex items-center justify-center">
                <div class="text-center">
                    <i data-lucide="bar-chart-3" class="w-12 h-12 text-gray-400 mx-auto mb-2"></i>
                    <p class="text-gray-500">Gráfico de desempenho dos últimos <span x-text="performancePeriod"></span> dias</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Store Section -->
    <div class="space-y-4">
        <h2 class="text-xl font-semibold">Loja</h2>
        <div class="border border-orange-200 bg-orange-50 rounded-lg p-4">
            <div class="flex items-start gap-3">
                <div class="w-8 h-8 bg-orange-500 rounded flex items-center justify-center">
                    <i data-lucide="arrow-right" class="w-4 h-4 text-white"></i>
                </div>
                <div class="flex-1">
                    <div class="flex items-center gap-2 mb-1">
                        <span class="bg-orange-100 text-orange-800 px-2 py-1 rounded-full text-xs font-medium">
                            Atenção
                        </span>
                    </div>
                    <h3 class="font-semibold text-gray-900 mb-1">
                        Tem cardápio no iFood ou em outro sistema?
                    </h3>
                    <p class="text-sm text-gray-600 mb-3">
                        Economize tempo e importe agora seu cardápio para o Diggy!
                    </p>
                    <button class="border border-gray-300 hover:bg-gray-50 px-3 py-1 rounded-md text-sm">
                        Importar Cardápio
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Management Section -->
    <div class="space-y-4">
        <h2 class="text-xl font-semibold">Gestão</h2>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <!-- QR Code -->
            <div class="bg-white rounded-lg shadow-sm border p-4 card-hover">
                <div class="flex items-center gap-3 mb-3">
                    <div class="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                        <i data-lucide="qr-code" class="w-5 h-5 text-blue-600"></i>
                    </div>
                    <div>
                        <h3 class="font-semibold">Qr Code</h3>
                        <p class="text-sm text-gray-600">
                            Clique aqui para visualizar ou imprimir o QR CODE do seu menu
                        </p>
                    </div>
                </div>
                <button class="border border-gray-300 hover:bg-gray-50 px-3 py-1 rounded-md text-sm w-full">
                    Gerar QR Code
                </button>
            </div>

            <!-- Cashback -->
            <div class="bg-white rounded-lg shadow-sm border p-4 card-hover">
                <div class="flex items-center gap-3 mb-3">
                    <div class="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                        <i data-lucide="bar-chart-3" class="w-5 h-5 text-green-600"></i>
                    </div>
                    <div>
                        <h3 class="font-semibold flex items-center gap-2">
                            Cashback
                            <span class="bg-red-500 text-white text-xs px-2 py-1 rounded-full">Novo</span>
                        </h3>
                        <p class="text-sm text-gray-600">
                            Configure uma porcentagem de cashback para incentivar seus clientes
                        </p>
                    </div>
                </div>
                <button class="border border-gray-300 hover:bg-gray-50 px-3 py-1 rounded-md text-sm w-full">
                    Configurar
                </button>
            </div>

            <!-- Reviews -->
            <div class="bg-white rounded-lg shadow-sm border p-4 card-hover">
                <div class="flex items-center gap-3 mb-3">
                    <div class="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                        <i data-lucide="camera" class="w-5 h-5 text-purple-600"></i>
                    </div>
                    <div>
                        <h3 class="font-semibold">Avaliações</h3>
                        <p class="text-sm text-gray-600">
                            Veja o que seus clientes estão falando sobre sua loja
                        </p>
                    </div>
                </div>
                <button class="border border-gray-300 hover:bg-gray-50 px-3 py-1 rounded-md text-sm w-full">
                    Ver Avaliações
                </button>
            </div>

            <!-- Instagram -->
            <div class="bg-white rounded-lg shadow-sm border p-4 card-hover">
                <div class="flex items-center gap-3 mb-3">
                    <div class="w-10 h-10 bg-pink-100 rounded-lg flex items-center justify-center">
                        <i data-lucide="instagram" class="w-5 h-5 text-pink-600"></i>
                    </div>
                    <div>
                        <h3 class="font-semibold">Instagram</h3>
                        <p class="text-sm text-gray-600">
                            Siga o Diggy no Instagram para ficar por dentro das novidades
                        </p>
                    </div>
                </div>
                <button class="border border-gray-300 hover:bg-gray-50 px-3 py-1 rounded-md text-sm w-full">
                    Seguir
                </button>
            </div>

            <!-- Learn -->
            <div class="bg-white rounded-lg shadow-sm border p-4 card-hover">
                <div class="flex items-center gap-3 mb-3">
                    <div class="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
                        <i data-lucide="play" class="w-5 h-5 text-red-600"></i>
                    </div>
                    <div>
                        <h3 class="font-semibold">Aprenda a usar</h3>
                        <p class="text-sm text-gray-600">
                            Aprenda todas as funcionalidades do Diggy no nosso canal do Youtube
                        </p>
                    </div>
                </div>
                <button class="border border-gray-300 hover:bg-gray-50 px-3 py-1 rounded-md text-sm w-full">
                    Assistir
                </button>
            </div>

            <!-- Suggestions -->
            <div class="bg-white rounded-lg shadow-sm border p-4 card-hover">
                <div class="flex items-center gap-3 mb-3">
                    <div class="w-10 h-10 bg-yellow-100 rounded-lg flex items-center justify-center">
                        <i data-lucide="lightbulb" class="w-5 h-5 text-yellow-600"></i>
                    </div>
                    <div>
                        <h3 class="font-semibold">O que você quer ver no Diggy?</h3>
                        <p class="text-sm text-gray-600">
                            Conte nos o que você espera poder usar no Diggy
                        </p>
                    </div>
                </div>
                <button class="border border-gray-300 hover:bg-gray-50 px-3 py-1 rounded-md text-sm w-full">
                    Enviar Sugestão
                </button>
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script>
function dashboardData() {
    return {
        performancePeriod: 7,
        performanceMetric: 'orders',
        stats: {
            menuViews: 46,
            ordersCount: {{ $stats['orders_count'] ?? 0 }},
            revenue: {{ $stats['revenue'] ?? 0 }},
            customers: {{ $stats['customers_count'] ?? 0 }}
        },
        
        init() {
            this.loadStats();
            lucide.createIcons();
        },
        
        async loadStats() {
            try {
                const response = await axios.get('/api/dashboard/stats', {
                    params: {
                        period: this.performancePeriod,
                        metric: this.performanceMetric
                    }
                });
                
                if (response.data.success) {
                    this.stats = response.data.data;
                }
            } catch (error) {
                console.error('Erro ao carregar estatísticas:', error);
            }
        },
        
        updateStats() {
            this.loadStats();
        },
        
        formatCurrency(value) {
            return new Intl.NumberFormat('pt-BR', {
                style: 'currency',
                currency: 'BRL'
            }).format(value);
        }
    }
}
</script>
@endpush
@endsection
