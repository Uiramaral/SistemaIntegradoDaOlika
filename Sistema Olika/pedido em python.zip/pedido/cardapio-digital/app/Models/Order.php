<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Order extends Model
{
    use HasFactory;

    protected $fillable = [
        'customer_id',
        'subtotal',
        'delivery_fee',
        'discount',
        'total',
        'coupon_code',
        'observations',
        'payment_method',
        'status',
        'mercado_pago_payment_id',
        'loyalty_points_earned',
        'referral_bonus',
        'delivery_date',
        'delivery_time_slot',
    ];

    protected $casts = [
        'subtotal' => 'decimal:2',
        'delivery_fee' => 'decimal:2',
        'discount' => 'decimal:2',
        'total' => 'decimal:2',
        'loyalty_points_earned' => 'integer',
        'referral_bonus' => 'decimal:2',
        'delivery_date' => 'date',
    ];

    protected $dates = [
        'created_at',
        'updated_at',
        'delivery_date',
    ];

    const STATUS_PENDING = 'pending';
    const STATUS_CONFIRMED = 'confirmed';
    const STATUS_PREPARING = 'preparing';
    const STATUS_DELIVERING = 'delivering';
    const STATUS_COMPLETED = 'completed';
    const STATUS_CANCELLED = 'cancelled';

    const PAYMENT_WHATSAPP = 'whatsapp';
    const PAYMENT_MERCADOPAGO = 'mercadopago';

    /**
     * Relacionamento com cliente
     */
    public function customer(): BelongsTo
    {
        return $this->belongsTo(Customer::class);
    }

    /**
     * Relacionamento com itens do pedido
     */
    public function items(): HasMany
    {
        return $this->hasMany(OrderItem::class);
    }

    /**
     * Relacionamento com cupom
     */
    public function coupon(): BelongsTo
    {
        return $this->belongsTo(Coupon::class, 'coupon_code', 'code');
    }

    /**
     * Scope para pedidos por status
     */
    public function scopeByStatus($query, $status)
    {
        return $query->where('status', $status);
    }

    /**
     * Scope para pedidos de hoje
     */
    public function scopeToday($query)
    {
        return $query->whereDate('created_at', today());
    }

    /**
     * Scope para pedidos por período
     */
    public function scopeByDateRange($query, $startDate, $endDate)
    {
        return $query->whereBetween('created_at', [$startDate, $endDate]);
    }

    /**
     * Scope para pedidos por cliente
     */
    public function scopeByCustomer($query, $customerId)
    {
        return $query->where('customer_id', $customerId);
    }

    /**
     * Scope para pedidos pendentes
     */
    public function scopePending($query)
    {
        return $query->whereIn('status', [self::STATUS_PENDING, self::STATUS_CONFIRMED]);
    }

    /**
     * Scope para pedidos em andamento
     */
    public function scopeInProgress($query)
    {
        return $query->whereIn('status', [
            self::STATUS_CONFIRMED,
            self::STATUS_PREPARING,
            self::STATUS_DELIVERING
        ]);
    }

    /**
     * Scope para pedidos finalizados
     */
    public function scopeCompleted($query)
    {
        return $query->where('status', self::STATUS_COMPLETED);
    }

    /**
     * Atualizar status do pedido
     */
    public function updateStatus(string $status): bool
    {
        $this->status = $status;
        return $this->save();
    }

    /**
     * Confirmar pedido
     */
    public function confirm(): bool
    {
        return $this->updateStatus(self::STATUS_CONFIRMED);
    }

    /**
     * Marcar como em preparação
     */
    public function startPreparing(): bool
    {
        return $this->updateStatus(self::STATUS_PREPARING);
    }

    /**
     * Marcar como em entrega
     */
    public function startDelivering(): bool
    {
        return $this->updateStatus(self::STATUS_DELIVERING);
    }

    /**
     * Finalizar pedido
     */
    public function complete(): bool
    {
        return $this->updateStatus(self::STATUS_COMPLETED);
    }

    /**
     * Cancelar pedido
     */
    public function cancel(): bool
    {
        return $this->updateStatus(self::STATUS_CANCELLED);
    }

    /**
     * Verificar se pedido pode ser cancelado
     */
    public function canBeCancelled(): bool
    {
        return in_array($this->status, [
            self::STATUS_PENDING,
            self::STATUS_CONFIRMED,
            self::STATUS_PREPARING
        ]);
    }

    /**
     * Verificar se pedido está pendente
     */
    public function isPending(): bool
    {
        return $this->status === self::STATUS_PENDING;
    }

    /**
     * Verificar se pedido está confirmado
     */
    public function isConfirmed(): bool
    {
        return $this->status === self::STATUS_CONFIRMED;
    }

    /**
     * Verificar se pedido está em preparação
     */
    public function isPreparing(): bool
    {
        return $this->status === self::STATUS_PREPARING;
    }

    /**
     * Verificar se pedido está em entrega
     */
    public function isDelivering(): bool
    {
        return $this->status === self::STATUS_DELIVERING;
    }

    /**
     * Verificar se pedido está completo
     */
    public function isCompleted(): bool
    {
        return $this->status === self::STATUS_COMPLETED;
    }

    /**
     * Verificar se pedido está cancelado
     */
    public function isCancelled(): bool
    {
        return $this->status === self::STATUS_CANCELLED;
    }

    /**
     * Obter status formatado
     */
    public function getStatusLabelAttribute(): string
    {
        $statusLabels = [
            self::STATUS_PENDING => 'Pendente',
            self::STATUS_CONFIRMED => 'Confirmado',
            self::STATUS_PREPARING => 'Em Preparação',
            self::STATUS_DELIVERING => 'Em Entrega',
            self::STATUS_COMPLETED => 'Finalizado',
            self::STATUS_CANCELLED => 'Cancelado',
        ];

        return $statusLabels[$this->status] ?? 'Desconhecido';
    }

    /**
     * Obter método de pagamento formatado
     */
    public function getPaymentMethodLabelAttribute(): string
    {
        $paymentLabels = [
            self::PAYMENT_WHATSAPP => 'WhatsApp',
            self::PAYMENT_MERCADOPAGO => 'Mercado Pago',
        ];

        return $paymentLabels[$this->payment_method] ?? 'Desconhecido';
    }

    /**
     * Obter total formatado
     */
    public function getFormattedTotalAttribute(): string
    {
        return 'R$ ' . number_format($this->total, 2, ',', '.');
    }

    /**
     * Calcular pontos de fidelidade ganhos
     */
    public function calculateLoyaltyPoints(LoyaltyProgram $loyaltyProgram): int
    {
        return floor($this->total * $loyaltyProgram->points_per_real);
    }

    /**
     * Aplicar pontos de fidelidade ao pedido
     */
    public function applyLoyaltyPoints(LoyaltyProgram $loyaltyProgram): void
    {
        $this->loyalty_points_earned = $this->calculateLoyaltyPoints($loyaltyProgram);
        $this->save();
    }

    /**
     * Processar finalização do pedido
     */
    public function processCompletion(LoyaltyProgram $loyaltyProgram): void
    {
        // Aplicar pontos de fidelidade
        $this->applyLoyaltyPoints($loyaltyProgram);

        // Atualizar dados do cliente
        if ($this->customer) {
            $this->customer->incrementOrderCount();
            $this->customer->addToTotalSpent($this->total);
            $this->customer->addLoyaltyPoints($this->loyalty_points_earned);
        }

        // Finalizar pedido
        $this->complete();
    }
}
