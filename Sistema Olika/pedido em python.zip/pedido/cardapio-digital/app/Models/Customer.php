<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Customer extends Authenticatable
{
    use HasFactory, HasApiTokens;

    protected $fillable = [
        'name',
        'phone',
        'email',
        'password',
        'birthday',
        'cep',
        'street',
        'number',
        'complement',
        'neighborhood',
        'city',
        'state',
        'reference',
        'order_count',
        'loyalty_points',
        'total_spent',
        'referral_code',
        'referred_by',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
        'birthday' => 'date',
        'order_count' => 'integer',
        'loyalty_points' => 'integer',
        'total_spent' => 'decimal:2',
    ];

    protected $dates = [
        'created_at',
        'updated_at',
    ];

    /**
     * Relacionamento com pedidos
     */
    public function orders(): HasMany
    {
        return $this->hasMany(Order::class);
    }

    /**
     * Relacionamento com indicações feitas
     */
    public function referrals(): HasMany
    {
        return $this->hasMany(Referral::class, 'referrer_id');
    }

    /**
     * Relacionamento com indicações recebidas
     */
    public function referredBy(): HasMany
    {
        return $this->hasMany(Referral::class, 'referred_id');
    }

    /**
     * Gerar código de indicação único
     */
    public static function generateReferralCode(): string
    {
        $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $code = '';
        
        do {
            $code = '';
            for ($i = 0; $i < 6; $i++) {
                $code .= $chars[rand(0, strlen($chars) - 1)];
            }
        } while (self::where('referral_code', $code)->exists());
        
        return $code;
    }

    /**
     * Buscar cliente por telefone
     */
    public static function findByPhone(string $phone): ?self
    {
        return self::where('phone', $phone)->first();
    }

    /**
     * Buscar cliente por código de indicação
     */
    public static function findByReferralCode(string $code): ?self
    {
        return self::where('referral_code', $code)->first();
    }

    /**
     * Adicionar pontos de fidelidade
     */
    public function addLoyaltyPoints(int $points): void
    {
        $this->loyalty_points += $points;
        $this->save();
    }

    /**
     * Remover pontos de fidelidade
     */
    public function removeLoyaltyPoints(int $points): bool
    {
        if ($this->loyalty_points >= $points) {
            $this->loyalty_points -= $points;
            $this->save();
            return true;
        }
        return false;
    }

    /**
     * Incrementar contador de pedidos
     */
    public function incrementOrderCount(): void
    {
        $this->increment('order_count');
    }

    /**
     * Adicionar ao total gasto
     */
    public function addToTotalSpent(float $amount): void
    {
        $this->total_spent += $amount;
        $this->save();
    }

    /**
     * Verificar se é primeira compra
     */
    public function isFirstPurchase(): bool
    {
        return $this->order_count === 0;
    }

    /**
     * Obter endereço completo formatado
     */
    public function getFullAddressAttribute(): string
    {
        $address = "{$this->street}, {$this->number}";
        
        if ($this->complement) {
            $address .= ", {$this->complement}";
        }
        
        $address .= " - {$this->neighborhood}, {$this->city}/{$this->state}";
        
        if ($this->cep) {
            $address .= " - CEP: {$this->cep}";
        }
        
        return $address;
    }

    /**
     * Boot do modelo
     */
    protected static function boot()
    {
        parent::boot();

        static::creating(function ($customer) {
            if (empty($customer->referral_code)) {
                $customer->referral_code = self::generateReferralCode();
            }
        });
    }
}
