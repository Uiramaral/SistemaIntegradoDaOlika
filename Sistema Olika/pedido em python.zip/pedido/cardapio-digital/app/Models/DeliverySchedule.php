<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;

class DeliverySchedule extends Model
{
    use HasFactory;

    protected $fillable = [
        'day_of_week',
        'day_name',
        'time_slots',
        'is_active',
    ];

    protected $casts = [
        'day_of_week' => 'integer',
        'is_active' => 'boolean',
        'time_slots' => 'array',
    ];

    protected $dates = [
        'created_at',
        'updated_at',
    ];

    const DAYS_OF_WEEK = [
        0 => 'Domingo',
        1 => 'Segunda-feira',
        2 => 'Terça-feira',
        3 => 'Quarta-feira',
        4 => 'Quinta-feira',
        5 => 'Sexta-feira',
        6 => 'Sábado',
    ];

    /**
     * Scope para horários ativos
     */
    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    /**
     * Scope para buscar por dia da semana
     */
    public function scopeByDayOfWeek($query, int $dayOfWeek)
    {
        return $query->where('day_of_week', $dayOfWeek);
    }

    /**
     * Obter nome do dia da semana
     */
    public function getDayNameAttribute(): string
    {
        return self::DAYS_OF_WEEK[$this->day_of_week] ?? 'Desconhecido';
    }

    /**
     * Obter slots de horário disponíveis
     */
    public function getAvailableTimeSlots(): array
    {
        if (!$this->is_active) {
            return [];
        }

        return array_filter($this->time_slots, function ($slot) {
            return $slot['is_available'] && $slot['current_orders'] < $slot['max_orders'];
        });
    }

    /**
     * Obter slots de horário ocupados
     */
    public function getOccupiedTimeSlots(): array
    {
        if (!$this->is_active) {
            return [];
        }

        return array_filter($this->time_slots, function ($slot) {
            return !$slot['is_available'] || $slot['current_orders'] >= $slot['max_orders'];
        });
    }

    /**
     * Reservar slot de horário
     */
    public function bookTimeSlot(string $slotId): bool
    {
        if (!$this->is_active) {
            return false;
        }

        $timeSlots = $this->time_slots;
        
        foreach ($timeSlots as &$slot) {
            if ($slot['id'] === $slotId) {
                if ($slot['is_available'] && $slot['current_orders'] < $slot['max_orders']) {
                    $slot['current_orders']++;
                    
                    if ($slot['current_orders'] >= $slot['max_orders']) {
                        $slot['is_available'] = false;
                    }
                    
                    $this->time_slots = $timeSlots;
                    $this->save();
                    
                    return true;
                }
                return false;
            }
        }

        return false;
    }

    /**
     * Liberar slot de horário
     */
    public function releaseTimeSlot(string $slotId): bool
    {
        $timeSlots = $this->time_slots;
        
        foreach ($timeSlots as &$slot) {
            if ($slot['id'] === $slotId) {
                if ($slot['current_orders'] > 0) {
                    $slot['current_orders']--;
                    $slot['is_available'] = true;
                    
                    $this->time_slots = $timeSlots;
                    $this->save();
                    
                    return true;
                }
                return false;
            }
        }

        return false;
    }

    /**
     * Verificar se há slots disponíveis
     */
    public function hasAvailableSlots(): bool
    {
        return count($this->getAvailableTimeSlots()) > 0;
    }

    /**
     * Obter próximo slot disponível
     */
    public function getNextAvailableSlot(): ?array
    {
        $availableSlots = $this->getAvailableTimeSlots();
        
        if (empty($availableSlots)) {
            return null;
        }

        // Ordenar por horário e retornar o primeiro
        usort($availableSlots, function ($a, $b) {
            return strcmp($a['start_time'], $b['start_time']);
        });

        return $availableSlots[0];
    }

    /**
     * Verificar se horário está disponível para entrega
     */
    public function isTimeSlotAvailable(string $slotId): bool
    {
        if (!$this->is_active) {
            return false;
        }

        foreach ($this->time_slots as $slot) {
            if ($slot['id'] === $slotId) {
                return $slot['is_available'] && $slot['current_orders'] < $slot['max_orders'];
            }
        }

        return false;
    }

    /**
     * Obter horários de entrega disponíveis para uma data
     */
    public static function getAvailableSlotsForDate(Carbon $date): array
    {
        $dayOfWeek = $date->dayOfWeek;
        $schedule = self::active()->byDayOfWeek($dayOfWeek)->first();

        if (!$schedule) {
            return [];
        }

        return $schedule->getAvailableTimeSlots();
    }

    /**
     * Verificar se data tem entrega disponível
     */
    public static function hasDeliveryOnDate(Carbon $date): bool
    {
        $dayOfWeek = $date->dayOfWeek;
        $schedule = self::active()->byDayOfWeek($dayOfWeek)->first();

        return $schedule && $schedule->hasAvailableSlots();
    }

    /**
     * Obter próximas datas com entrega disponível
     */
    public static function getNextAvailableDates(int $days = 14): array
    {
        $dates = [];
        $today = Carbon::today();
        
        for ($i = 1; $i <= $days; $i++) {
            $date = $today->copy()->addDays($i);
            
            if (self::hasDeliveryOnDate($date)) {
                $dates[] = $date->format('Y-m-d');
            }
        }

        return $dates;
    }

    /**
     * Ativar horário de entrega
     */
    public function activate(): void
    {
        $this->is_active = true;
        $this->save();
    }

    /**
     * Desativar horário de entrega
     */
    public function deactivate(): void
    {
        $this->is_active = false;
        $this->save();
    }

    /**
     * Toggle status do horário
     */
    public function toggleStatus(): void
    {
        $this->is_active = !$this->is_active;
        $this->save();
    }

    /**
     * Resetar ocupação dos slots
     */
    public function resetSlotOccupation(): void
    {
        $timeSlots = $this->time_slots;
        
        foreach ($timeSlots as &$slot) {
            $slot['current_orders'] = 0;
            $slot['is_available'] = true;
        }
        
        $this->time_slots = $timeSlots;
        $this->save();
    }

    /**
     * Boot do modelo
     */
    protected static function boot()
    {
        parent::boot();

        static::creating(function ($schedule) {
            if (empty($schedule->day_name)) {
                $schedule->day_name = self::DAYS_OF_WEEK[$schedule->day_of_week] ?? 'Desconhecido';
            }
        });
    }
}
