import { useState } from "react";
import { useMenu } from "@/contexts/MenuContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Package, Clock, CheckCircle, XCircle } from "lucide-react";
import type { Order } from "@/types/menu";

type OrderStatus = "pending" | "confirmed" | "preparing" | "delivering" | "completed" | "cancelled";

export default function DashboardOrders() {
  const { orders, customers } = useMenu();
  const [selectedStatus, setSelectedStatus] = useState<OrderStatus | "all">("all");
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);

  const filteredOrders =
    selectedStatus === "all"
      ? orders
      : orders.filter((order) => order.status === selectedStatus);

  const stats = [
    {
      title: "Pendentes",
      value: orders.filter((o) => o.status === "pending").length,
      icon: Clock,
      color: "text-yellow-600",
      bg: "bg-yellow-50",
    },
    {
      title: "Preparando",
      value: orders.filter((o) => o.status === "preparing").length,
      icon: Package,
      color: "text-blue-600",
      bg: "bg-blue-50",
    },
    {
      title: "Concluídos",
      value: orders.filter((o) => o.status === "completed").length,
      icon: CheckCircle,
      color: "text-green-600",
      bg: "bg-green-50",
    },
    {
      title: "Cancelados",
      value: orders.filter((o) => o.status === "cancelled").length,
      icon: XCircle,
      color: "text-red-600",
      bg: "bg-red-50",
    },
  ];

  const getStatusBadge = (status: OrderStatus) => {
    const variants = {
      pending: { label: "Pendente", className: "bg-yellow-100 text-yellow-800" },
      confirmed: { label: "Confirmado", className: "bg-purple-100 text-purple-800" },
      preparing: { label: "Preparando", className: "bg-blue-100 text-blue-800" },
      delivering: { label: "Em Entrega", className: "bg-indigo-100 text-indigo-800" },
      completed: { label: "Concluído", className: "bg-green-100 text-green-800" },
      cancelled: { label: "Cancelado", className: "bg-red-100 text-red-800" },
    };
    return variants[status];
  };

  const handleViewOrder = (order: Order) => {
    setSelectedOrder(order);
    setDialogOpen(true);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Gestor de Pedidos</h1>
        <p className="text-muted-foreground">Gerencie todos os pedidos do seu restaurante</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => (
          <Card key={stat.title}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
              <div className={`p-2 rounded-lg ${stat.bg}`}>
                <stat.icon className={`h-4 w-4 ${stat.color}`} />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-wrap gap-2">
            <Button
              variant={selectedStatus === "all" ? "default" : "outline"}
              onClick={() => setSelectedStatus("all")}
            >
              Todos os pedidos
            </Button>
            <Button
              variant={selectedStatus === "pending" ? "default" : "outline"}
              onClick={() => setSelectedStatus("pending")}
            >
              Pendentes
            </Button>
            <Button
              variant={selectedStatus === "preparing" ? "default" : "outline"}
              onClick={() => setSelectedStatus("preparing")}
            >
              Preparando
            </Button>
            <Button
              variant={selectedStatus === "completed" ? "default" : "outline"}
              onClick={() => setSelectedStatus("completed")}
            >
              Concluídos
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {filteredOrders.length === 0 ? (
            <p className="text-center py-8 text-muted-foreground">
              Nenhum pedido encontrado
            </p>
          ) : (
            <div className="space-y-4">
              {filteredOrders.map((order) => {
                const statusInfo = getStatusBadge(order.status);
                return (
                  <Card key={order.id} className="cursor-pointer hover:shadow-md transition-shadow">
                    <CardContent className="p-4" onClick={() => handleViewOrder(order)}>
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <h3 className="font-semibold">Pedido #{order.id}</h3>
                          <p className="text-sm text-muted-foreground">
                            {new Date(order.createdAt).toLocaleString("pt-BR")}
                          </p>
                        </div>
                        <Badge className={statusInfo.className}>{statusInfo.label}</Badge>
                      </div>

                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Cliente:</span>
                          <span className="font-medium">
                            {customers.find(c => c.id === order.customerId)?.name || "Não informado"}
                          </span>
                        </div>
                        {customers.find(c => c.id === order.customerId)?.phone && (
                          <div className="flex justify-between text-sm">
                            <span className="text-muted-foreground">Telefone:</span>
                            <span>{customers.find(c => c.id === order.customerId)?.phone}</span>
                          </div>
                        )}
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Forma de pagamento:</span>
                          <span className="capitalize">{order.paymentMethod}</span>
                        </div>
                        <div className="flex justify-between text-sm font-bold border-t pt-2">
                          <span>Total:</span>
                          <span>R$ {order.total.toFixed(2)}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Detalhes do Pedido #{selectedOrder?.id}</DialogTitle>
          </DialogHeader>
          {selectedOrder && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Status:</span>
                <Badge className={getStatusBadge(selectedOrder.status).className}>
                  {getStatusBadge(selectedOrder.status).label}
                </Badge>
              </div>

              <div className="border-t pt-4">
                <h3 className="font-semibold mb-3">Informações do Cliente</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Nome:</span>
                    <span>{customers.find(c => c.id === selectedOrder.customerId)?.name || "Não informado"}</span>
                  </div>
                  {customers.find(c => c.id === selectedOrder.customerId)?.phone && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Telefone:</span>
                      <span>{customers.find(c => c.id === selectedOrder.customerId)?.phone}</span>
                    </div>
                  )}
                  {customers.find(c => c.id === selectedOrder.customerId)?.address && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Endereço:</span>
                      <span className="text-right max-w-[60%]">
                        {customers.find(c => c.id === selectedOrder.customerId)?.address}
                      </span>
                    </div>
                  )}
                </div>
              </div>

              <div className="border-t pt-4">
                <h3 className="font-semibold mb-3">Itens do Pedido</h3>
                <div className="space-y-3">
                  {selectedOrder.items.map((item, index) => (
                    <div key={index} className="flex justify-between items-start">
                      <div>
                        <p className="font-medium">{item.name}</p>
                        <p className="text-sm text-muted-foreground">
                          {item.quantity}x R$ {item.price.toFixed(2)}
                        </p>
                      </div>
                      <span className="font-medium">
                        R$ {(item.quantity * item.price).toFixed(2)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="border-t pt-4 space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Subtotal:</span>
                  <span>R$ {selectedOrder.subtotal.toFixed(2)}</span>
                </div>
                {selectedOrder.deliveryFee > 0 && (
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Taxa de entrega:</span>
                    <span>R$ {selectedOrder.deliveryFee.toFixed(2)}</span>
                  </div>
                )}
                {selectedOrder.discount > 0 && (
                  <div className="flex justify-between text-sm text-green-600">
                    <span>Desconto:</span>
                    <span>- R$ {selectedOrder.discount.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between font-bold text-lg border-t pt-2">
                  <span>Total:</span>
                  <span>R$ {selectedOrder.total.toFixed(2)}</span>
                </div>
              </div>

              <div className="border-t pt-4">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Forma de pagamento:</span>
                  <span className="capitalize font-medium">{selectedOrder.paymentMethod}</span>
                </div>
                <div className="flex justify-between text-sm mt-2">
                  <span className="text-muted-foreground">Data do pedido:</span>
                  <span>{new Date(selectedOrder.createdAt).toLocaleString("pt-BR")}</span>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
