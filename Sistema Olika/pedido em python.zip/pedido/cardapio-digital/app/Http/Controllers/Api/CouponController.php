<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Coupon;
use App\Models\Customer;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Validator;

class CouponController extends Controller
{
    /**
     * Listar cupons
     */
    public function index(Request $request): JsonResponse
    {
        $query = Coupon::query();

        // Filtros
        if ($active = $request->boolean('active_only')) {
            $query->active();
        }

        if ($public = $request->boolean('public_only')) {
            $query->public();
        }

        if ($available = $request->boolean('available_only')) {
            $query->available();
        }

        if ($search = $request->get('search')) {
            $query->where(function ($q) use ($search) {
                $q->where('code', 'LIKE', "%{$search}%")
                  ->orWhere('description', 'LIKE', "%{$search}%");
            });
        }

        $coupons = $query->orderBy('created_at', 'desc')->paginate(20);

        return response()->json([
            'success' => true,
            'data' => $coupons
        ]);
    }

    /**
     * Obter cupom específico
     */
    public function show(Coupon $coupon): JsonResponse
    {
        return response()->json([
            'success' => true,
            'data' => $coupon
        ]);
    }

    /**
     * Criar novo cupom
     */
    public function store(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'code' => 'required|string|max:50|unique:coupons,code',
            'description' => 'nullable|string',
            'discount_type' => 'required|in:percentage,fixed',
            'discount_value' => 'required|numeric|min:0',
            'is_public' => 'boolean',
            'first_purchase_only' => 'boolean',
            'valid_until' => 'nullable|date|after:today',
            'min_purchase_value' => 'nullable|numeric|min:0',
            'active' => 'boolean',
            'usage_limit' => 'nullable|integer|min:1',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Dados inválidos',
                'errors' => $validator->errors()
            ], 422);
        }

        $coupon = Coupon::create($request->all());

        return response()->json([
            'success' => true,
            'message' => 'Cupom criado com sucesso',
            'data' => $coupon
        ], 201);
    }

    /**
     * Atualizar cupom
     */
    public function update(Request $request, Coupon $coupon): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'code' => 'sometimes|required|string|max:50|unique:coupons,code,' . $coupon->id,
            'description' => 'nullable|string',
            'discount_type' => 'sometimes|required|in:percentage,fixed',
            'discount_value' => 'sometimes|required|numeric|min:0',
            'is_public' => 'boolean',
            'first_purchase_only' => 'boolean',
            'valid_until' => 'nullable|date|after:today',
            'min_purchase_value' => 'nullable|numeric|min:0',
            'active' => 'boolean',
            'usage_limit' => 'nullable|integer|min:1',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Dados inválidos',
                'errors' => $validator->errors()
            ], 422);
        }

        $coupon->update($request->all());

        return response()->json([
            'success' => true,
            'message' => 'Cupom atualizado com sucesso',
            'data' => $coupon
        ]);
    }

    /**
     * Deletar cupom
     */
    public function destroy(Coupon $coupon): JsonResponse
    {
        $coupon->delete();

        return response()->json([
            'success' => true,
            'message' => 'Cupom deletado com sucesso'
        ]);
    }

    /**
     * Toggle status do cupom
     */
    public function toggleStatus(Coupon $coupon): JsonResponse
    {
        $coupon->toggleStatus();

        return response()->json([
            'success' => true,
            'message' => 'Status do cupom atualizado',
            'data' => $coupon
        ]);
    }

    /**
     * Validar cupom
     */
    public function validate(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'code' => 'required|string|max:50',
            'subtotal' => 'required|numeric|min:0',
            'customer_id' => 'nullable|exists:customers,id'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Dados inválidos',
                'errors' => $validator->errors()
            ], 422);
        }

        $coupon = Coupon::findByCode($request->code);

        if (!$coupon) {
            return response()->json([
                'success' => false,
                'message' => 'Cupom não encontrado'
            ], 404);
        }

        $customer = null;
        if ($request->customer_id) {
            $customer = Customer::find($request->customer_id);
        }

        $isValid = $coupon->isValidForOrder($request->subtotal, $customer);

        if (!$isValid) {
            return response()->json([
                'success' => false,
                'message' => 'Cupom não é válido para este pedido'
            ], 422);
        }

        $discount = $coupon->calculateDiscount($request->subtotal);

        return response()->json([
            'success' => true,
            'data' => [
                'coupon' => $coupon,
                'discount' => $discount,
                'discount_formatted' => 'R$ ' . number_format($discount, 2, ',', '.')
            ]
        ]);
    }

    /**
     * Obter cupons públicos
     */
    public function public(): JsonResponse
    {
        $coupons = Coupon::public()
            ->active()
            ->available()
            ->get();

        return response()->json([
            'success' => true,
            'data' => $coupons
        ]);
    }

    /**
     * Buscar cupom por código
     */
    public function findByCode(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'code' => 'required|string|max:50'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Código é obrigatório',
                'errors' => $validator->errors()
            ], 422);
        }

        $coupon = Coupon::findByCode($request->code);

        if (!$coupon) {
            return response()->json([
                'success' => false,
                'message' => 'Cupom não encontrado'
            ], 404);
        }

        return response()->json([
            'success' => true,
            'data' => $coupon
        ]);
    }

    /**
     * Obter estatísticas do cupom
     */
    public function stats(Coupon $coupon): JsonResponse
    {
        $stats = [
            'usage_count' => $coupon->usage_count,
            'usage_limit' => $coupon->usage_limit,
            'usage_percentage' => $coupon->usage_limit ? ($coupon->usage_count / $coupon->usage_limit) * 100 : 0,
            'remaining_uses' => $coupon->usage_limit ? $coupon->usage_limit - $coupon->usage_count : null,
            'is_expired' => $coupon->isExpired(),
            'is_exhausted' => $coupon->isExhausted(),
            'can_be_used' => $coupon->canBeUsed(),
            'status' => $coupon->status
        ];

        return response()->json([
            'success' => true,
            'data' => $stats
        ]);
    }

    /**
     * Incrementar uso do cupom
     */
    public function incrementUsage(Coupon $coupon): JsonResponse
    {
        if (!$coupon->canBeUsed()) {
            return response()->json([
                'success' => false,
                'message' => 'Cupom não pode ser usado'
            ], 422);
        }

        $coupon->incrementUsage();

        return response()->json([
            'success' => true,
            'message' => 'Uso do cupom incrementado',
            'data' => $coupon
        ]);
    }
}
