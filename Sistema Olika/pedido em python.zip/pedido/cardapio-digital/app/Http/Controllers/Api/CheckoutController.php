<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\LoyaltyProgram;
use App\Models\Coupon;
use App\Models\DeliveryFee;
use App\Models\DeliverySchedule;
use App\Services\MercadoPagoService;
use App\Services\WhatsAppService;
use App\Services\GoogleMapsService;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class CheckoutController extends Controller
{
    /**
     * Iniciar processo de checkout
     */
    public function initialize(): JsonResponse
    {
        $cart = session('cart', []);
        
        if (empty($cart)) {
            return response()->json([
                'success' => false,
                'message' => 'Carrinho vazio'
            ], 422);
        }

        // Validar itens do carrinho
        foreach ($cart as $productId => $item) {
            $product = \App\Models\Product::find($productId);
            if (!$product || !$product->isAvailableForSale()) {
                return response()->json([
                    'success' => false,
                    'message' => "Produto '{$item['name']}' não está disponível"
                ], 422);
            }
        }

        return response()->json([
            'success' => true,
            'data' => [
                'cart' => array_values($cart),
                'steps' => [
                    ['id' => 'contact', 'title' => 'Contato', 'completed' => false],
                    ['id' => 'delivery', 'title' => 'Entrega', 'completed' => false],
                    ['id' => 'scheduling', 'title' => 'Agendamento', 'completed' => false],
                    ['id' => 'payment', 'title' => 'Pagamento', 'completed' => false],
                    ['id' => 'summary', 'title' => 'Resumo', 'completed' => false]
                ]
            ]
        ]);
    }

    /**
     * Validar dados de contato
     */
    public function validateContact(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'phone' => 'required|string|max:20',
            'email' => 'nullable|email|max:255',
            'birthday' => 'nullable|date_format:d/m/Y',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Dados inválidos',
                'errors' => $validator->errors()
            ], 422);
        }

        $phone = preg_replace('/\D/', '', $request->phone);
        
        if (strlen($phone) < 10) {
            return response()->json([
                'success' => false,
                'message' => 'Telefone deve ter pelo menos 10 dígitos'
            ], 422);
        }

        // Buscar cliente existente
        $customer = Customer::findByPhone($phone);
        
        if ($customer) {
            // Cliente existente - atualizar dados se necessário
            $customer->update([
                'name' => $request->name,
                'email' => $request->email,
                'birthday' => $request->birthday ? Carbon::createFromFormat('d/m/Y', $request->birthday) : null,
            ]);
            
            $isNewCustomer = false;
            $message = 'Cliente encontrado!';
        } else {
            // Novo cliente
            $customer = Customer::create([
                'name' => $request->name,
                'phone' => $phone,
                'email' => $request->email,
                'birthday' => $request->birthday ? Carbon::createFromFormat('d/m/Y', $request->birthday) : null,
                'cep' => '',
                'street' => '',
                'number' => '',
                'neighborhood' => '',
                'city' => '',
                'state' => '',
            ]);
            
            $isNewCustomer = true;
            $message = 'Cliente cadastrado com sucesso!';
        }

        // Salvar cliente na sessão
        session(['checkout_customer' => $customer]);

        return response()->json([
            'success' => true,
            'message' => $message,
            'data' => [
                'customer' => $customer,
                'is_new_customer' => $isNewCustomer,
                'has_first_purchase_coupons' => $isNewCustomer || $customer->isFirstPurchase()
            ]
        ]);
    }

    /**
     * Validar endereço de entrega
     */
    public function validateDelivery(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'cep' => 'required|string|max:10',
            'street' => 'required|string|max:255',
            'number' => 'required|string|max:20',
            'complement' => 'nullable|string|max:255',
            'neighborhood' => 'required|string|max:255',
            'city' => 'required|string|max:255',
            'state' => 'required|string|max:2',
            'reference' => 'nullable|string|max:255',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Dados inválidos',
                'errors' => $validator->errors()
            ], 422);
        }

        $customer = session('checkout_customer');
        
        if (!$customer) {
            return response()->json([
                'success' => false,
                'message' => 'Cliente não encontrado. Volte ao passo anterior.'
            ], 422);
        }

        // Atualizar endereço do cliente
        $customer->update([
            'cep' => $request->cep,
            'street' => $request->street,
            'number' => $request->number,
            'complement' => $request->complement,
            'neighborhood' => $request->neighborhood,
            'city' => $request->city,
            'state' => $request->state,
            'reference' => $request->reference,
        ]);

        // Calcular taxa de entrega
        $deliveryFee = DeliveryFee::getFeeByCep($request->cep);
        $cart = session('cart', []);
        $subtotal = $this->calculateCartTotal($cart);
        
        // Verificar entrega grátis
        $settings = \App\Models\Settings::getSettings();
        $freeDeliveryThreshold = $settings->free_delivery_threshold ?? 100;
        
        if ($subtotal >= $freeDeliveryThreshold) {
            $deliveryFee = 0;
        }

        // Salvar dados de entrega na sessão
        session([
            'checkout_delivery' => [
                'delivery_fee' => $deliveryFee,
                'free_delivery_threshold' => $freeDeliveryThreshold,
                'is_free_delivery' => $deliveryFee == 0
            ]
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Endereço validado',
            'data' => [
                'delivery_fee' => $deliveryFee,
                'formatted_delivery_fee' => $deliveryFee > 0 ? 'R$ ' . number_format($deliveryFee, 2, ',', '.') : 'Grátis',
                'free_delivery_threshold' => $freeDeliveryThreshold,
                'is_free_delivery' => $deliveryFee == 0,
                'subtotal' => $subtotal,
                'total_with_delivery' => $subtotal + $deliveryFee
            ]
        ]);
    }

    /**
     * Obter datas disponíveis para entrega
     */
    public function getAvailableDates(): JsonResponse
    {
        $availableDates = DeliverySchedule::getNextAvailableDates(14);

        return response()->json([
            'success' => true,
            'data' => $availableDates
        ]);
    }

    /**
     * Obter horários disponíveis para uma data
     */
    public function getAvailableTimeSlots(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'date' => 'required|date|after:today',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Data inválida',
                'errors' => $validator->errors()
            ], 422);
        }

        $date = Carbon::parse($request->date);
        $availableSlots = DeliverySchedule::getAvailableSlotsForDate($date);

        return response()->json([
            'success' => true,
            'data' => $availableSlots
        ]);
    }

    /**
     * Validar agendamento
     */
    public function validateScheduling(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'delivery_date' => 'required|date|after:today',
            'delivery_time_slot' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Dados inválidos',
                'errors' => $validator->errors()
            ], 422);
        }

        $date = Carbon::parse($request->delivery_date);
        
        // Verificar se a data tem entrega disponível
        if (!DeliverySchedule::hasDeliveryOnDate($date)) {
            return response()->json([
                'success' => false,
                'message' => 'Não há entrega disponível nesta data'
            ], 422);
        }

        // Salvar agendamento na sessão
        session([
            'checkout_scheduling' => [
                'delivery_date' => $request->delivery_date,
                'delivery_time_slot' => $request->delivery_time_slot
            ]
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Agendamento validado',
            'data' => [
                'delivery_date' => $request->delivery_date,
                'delivery_time_slot' => $request->delivery_time_slot
            ]
        ]);
    }

    /**
     * Processar pagamento
     */
    public function processPayment(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'payment_method' => 'required|in:whatsapp,mercadopago',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Método de pagamento inválido',
                'errors' => $validator->errors()
            ], 422);
        }

        $customer = session('checkout_customer');
        $deliveryData = session('checkout_delivery');
        $schedulingData = session('checkout_scheduling');
        $cart = session('cart', []);
        $appliedCoupon = session('applied_coupon');

        if (!$customer || !$deliveryData || !$schedulingData || empty($cart)) {
            return response()->json([
                'success' => false,
                'message' => 'Dados de checkout incompletos'
            ], 422);
        }

        DB::beginTransaction();

        try {
            // Calcular totais
            $subtotal = $this->calculateCartTotal($cart);
            $deliveryFee = $deliveryData['delivery_fee'];
            $discount = $appliedCoupon['discount'] ?? 0;
            $total = $subtotal + $deliveryFee - $discount;

            // Criar pedido
            $order = Order::create([
                'customer_id' => $customer->id,
                'subtotal' => $subtotal,
                'delivery_fee' => $deliveryFee,
                'discount' => $discount,
                'total' => $total,
                'coupon_code' => $appliedCoupon['coupon']['code'] ?? null,
                'payment_method' => $request->payment_method,
                'delivery_date' => $schedulingData['delivery_date'],
                'delivery_time_slot' => $schedulingData['delivery_time_slot'],
                'status' => 'pending',
            ]);

            // Criar itens do pedido
            foreach ($cart as $productId => $item) {
                $order->items()->create([
                    'product_id' => $productId,
                    'quantity' => $item['quantity'],
                    'price' => $item['price'],
                    'name' => $item['name'],
                    'description' => $item['description'],
                    'image' => $item['image'],
                ]);
            }

            // Processar pagamento
            $paymentData = null;
            
            if ($request->payment_method === 'mercadopago') {
                $mercadoPagoService = new MercadoPagoService();
                
                if ($mercadoPagoService->isConfigured()) {
                    $preference = $mercadoPagoService->createPreference($order);
                    
                    if ($preference['success']) {
                        $paymentData = $preference;
                        $order->update(['mercado_pago_payment_id' => $preference['preference_id']]);
                    } else {
                        throw new \Exception('Erro ao criar preferência de pagamento: ' . $preference['message']);
                    }
                } else {
                    throw new \Exception('Mercado Pago não está configurado');
                }
            }

            // Aplicar pontos de fidelidade
            $loyaltyProgram = LoyaltyProgram::getDefault();
            $order->applyLoyaltyPoints($loyaltyProgram);

            DB::commit();

            // Limpar sessões
            session()->forget(['cart', 'checkout_customer', 'checkout_delivery', 'checkout_scheduling', 'applied_coupon']);

            // Enviar notificação WhatsApp
            try {
                $whatsAppService = new WhatsAppService();
                if ($whatsAppService->isConfigured()) {
                    $whatsAppService->sendOrderMessage($order);
                }
            } catch (\Exception $e) {
                // Log error but don't fail the order
                \Log::error('Erro ao enviar WhatsApp: ' . $e->getMessage());
            }

            return response()->json([
                'success' => true,
                'message' => 'Pedido criado com sucesso',
                'data' => [
                    'order' => $order->load(['customer', 'items.product']),
                    'payment' => $paymentData,
                    'loyalty_points_earned' => $order->loyalty_points_earned
                ]
            ], 201);

        } catch (\Exception $e) {
            DB::rollback();
            
            return response()->json([
                'success' => false,
                'message' => 'Erro ao processar pedido: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Obter resumo do checkout
     */
    public function getSummary(): JsonResponse
    {
        $customer = session('checkout_customer');
        $deliveryData = session('checkout_delivery');
        $schedulingData = session('checkout_scheduling');
        $cart = session('cart', []);
        $appliedCoupon = session('applied_coupon');

        if (!$customer || !$deliveryData || !$schedulingData || empty($cart)) {
            return response()->json([
                'success' => false,
                'message' => 'Dados de checkout incompletos'
            ], 422);
        }

        $subtotal = $this->calculateCartTotal($cart);
        $deliveryFee = $deliveryData['delivery_fee'];
        $discount = $appliedCoupon['discount'] ?? 0;
        $total = $subtotal + $deliveryFee - $discount;

        return response()->json([
            'success' => true,
            'data' => [
                'customer' => $customer,
                'delivery' => $deliveryData,
                'scheduling' => $schedulingData,
                'cart' => array_values($cart),
                'totals' => [
                    'subtotal' => $subtotal,
                    'delivery_fee' => $deliveryFee,
                    'discount' => $discount,
                    'total' => $total,
                    'formatted' => [
                        'subtotal' => 'R$ ' . number_format($subtotal, 2, ',', '.'),
                        'delivery_fee' => $deliveryFee > 0 ? 'R$ ' . number_format($deliveryFee, 2, ',', '.') : 'Grátis',
                        'discount' => $discount > 0 ? '-R$ ' . number_format($discount, 2, ',', '.') : 'R$ 0,00',
                        'total' => 'R$ ' . number_format($total, 2, ',', '.')
                    ]
                ],
                'applied_coupon' => $appliedCoupon['coupon'] ?? null
            ]
        ]);
    }

    /**
     * Calcular total do carrinho
     */
    private function calculateCartTotal(array $cart): float
    {
        $total = 0;
        
        foreach ($cart as $item) {
            $total += $item['price'] * $item['quantity'];
        }

        return $total;
    }
}
