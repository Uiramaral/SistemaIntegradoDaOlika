<?php

namespace App\Services;

use App\Models\Order;
use App\Models\Settings;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class WhatsAppService
{
    private $apiUrl;
    private $apiToken;

    public function __construct()
    {
        $settings = Settings::getSettings();
        
        $this->apiUrl = $settings->whatsapp_api_url;
        $this->apiToken = $settings->whatsapp_api_token;
    }

    /**
     * Verificar se WhatsApp está configurado
     */
    public function isConfigured(): bool
    {
        return !empty($this->apiUrl) && !empty($this->apiToken);
    }

    /**
     * Enviar mensagem de pedido
     */
    public function sendOrderMessage(Order $order): array
    {
        if (!$this->isConfigured()) {
            throw new \Exception('WhatsApp não está configurado');
        }

        try {
            $message = $this->formatOrderMessage($order);
            
            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $this->apiToken,
                'Content-Type' => 'application/json'
            ])->post($this->apiUrl . '/send-message', [
                'phone' => $order->customer->phone,
                'message' => $message
            ]);

            if ($response->successful()) {
                Log::info('Mensagem WhatsApp enviada com sucesso', [
                    'order_id' => $order->id,
                    'customer_phone' => $order->customer->phone
                ]);

                return [
                    'success' => true,
                    'message' => 'Mensagem enviada com sucesso'
                ];
            }

            throw new \Exception('Erro na API do WhatsApp: ' . $response->body());

        } catch (\Exception $e) {
            Log::error('Erro ao enviar mensagem WhatsApp: ' . $e->getMessage());
            
            return [
                'success' => false,
                'message' => 'Erro ao enviar mensagem: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Enviar notificação de status
     */
    public function sendStatusNotification(Order $order): array
    {
        if (!$this->isConfigured()) {
            throw new \Exception('WhatsApp não está configurado');
        }

        try {
            $message = $this->formatStatusMessage($order);
            
            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $this->apiToken,
                'Content-Type' => 'application/json'
            ])->post($this->apiUrl . '/send-message', [
                'phone' => $order->customer->phone,
                'message' => $message
            ]);

            if ($response->successful()) {
                Log::info('Notificação de status WhatsApp enviada com sucesso', [
                    'order_id' => $order->id,
                    'status' => $order->status
                ]);

                return [
                    'success' => true,
                    'message' => 'Notificação enviada com sucesso'
                ];
            }

            throw new \Exception('Erro na API do WhatsApp: ' . $response->body());

        } catch (\Exception $e) {
            Log::error('Erro ao enviar notificação WhatsApp: ' . $e->getMessage());
            
            return [
                'success' => false,
                'message' => 'Erro ao enviar notificação: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Enviar mensagem personalizada
     */
    public function sendCustomMessage(string $phone, string $message): array
    {
        if (!$this->isConfigured()) {
            throw new \Exception('WhatsApp não está configurado');
        }

        try {
            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $this->apiToken,
                'Content-Type' => 'application/json'
            ])->post($this->apiUrl . '/send-message', [
                'phone' => $phone,
                'message' => $message
            ]);

            if ($response->successful()) {
                Log::info('Mensagem personalizada WhatsApp enviada com sucesso', [
                    'phone' => $phone
                ]);

                return [
                    'success' => true,
                    'message' => 'Mensagem enviada com sucesso'
                ];
            }

            throw new \Exception('Erro na API do WhatsApp: ' . $response->body());

        } catch (\Exception $e) {
            Log::error('Erro ao enviar mensagem personalizada WhatsApp: ' . $e->getMessage());
            
            return [
                'success' => false,
                'message' => 'Erro ao enviar mensagem: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Formatar mensagem do pedido
     */
    private function formatOrderMessage(Order $order): string
    {
        $settings = Settings::getSettings();
        
        $message = "🍞 *{$settings->business_name}*\n\n";
        $message .= "Olá {$order->customer->name}! 👋\n\n";
        $message .= "Seu pedido foi recebido:\n\n";
        
        $message .= "📋 *Pedido #{$order->id}*\n";
        $message .= "📅 Data: " . $order->created_at->format('d/m/Y H:i') . "\n\n";
        
        $message .= "🛒 *Itens:*\n";
        foreach ($order->items as $item) {
            $message .= "• {$item->name} (x{$item->quantity}) - R$ " . number_format($item->price * $item->quantity, 2, ',', '.') . "\n";
        }
        
        if ($order->delivery_fee > 0) {
            $message .= "• Taxa de Entrega - R$ " . number_format($order->delivery_fee, 2, ',', '.') . "\n";
        }
        
        if ($order->discount > 0) {
            $message .= "• Desconto - R$ " . number_format($order->discount, 2, ',', '.') . "\n";
        }
        
        $message .= "\n💰 *Total: R$ " . number_format($order->total, 2, ',', '.') . "*\n\n";
        
        $message .= "📍 *Endereço de entrega:*\n";
        $message .= "{$order->customer->full_address}\n\n";
        
        if ($order->observations) {
            $message .= "📝 *Observações:*\n";
            $message .= "{$order->observations}\n\n";
        }
        
        $message .= "⏰ *Status:* {$order->status_label}\n\n";
        
        $message .= "Acompanhe seu pedido em tempo real!\n";
        $message .= "Para dúvidas, entre em contato: {$settings->phone}\n\n";
        
        $message .= "Obrigado pela preferência! ❤️";

        return $message;
    }

    /**
     * Formatar mensagem de status
     */
    private function formatStatusMessage(Order $order): string
    {
        $settings = Settings::getSettings();
        
        $message = "🍞 *{$settings->business_name}*\n\n";
        $message .= "Olá {$order->customer->name}! 👋\n\n";
        $message .= "📋 *Pedido #{$order->id}*\n\n";
        
        $statusMessages = [
            'confirmed' => "✅ Seu pedido foi *confirmado* e está sendo preparado!",
            'preparing' => "👨‍🍳 Seu pedido está sendo *preparado* com muito carinho!",
            'delivering' => "🚚 Seu pedido está *saindo para entrega*!",
            'completed' => "🎉 Seu pedido foi *entregue* com sucesso!",
            'cancelled' => "❌ Seu pedido foi *cancelado*."
        ];
        
        $message .= $statusMessages[$order->status] ?? "Status: {$order->status_label}\n\n";
        
        if ($order->status === 'completed') {
            $message .= "\n💰 *Total pago: R$ " . number_format($order->total, 2, ',', '.') . "*\n\n";
            
            if ($order->loyalty_points_earned > 0) {
                $message .= "🎁 Você ganhou *{$order->loyalty_points_earned} pontos* de fidelidade!\n";
                $message .= "Seu saldo atual: *{$order->customer->loyalty_points} pontos*\n\n";
            }
            
            $message .= "Avalie sua experiência e nos ajude a melhorar! ⭐\n\n";
        }
        
        $message .= "Para dúvidas, entre em contato: {$settings->phone}\n\n";
        $message .= "Obrigado pela preferência! ❤️";

        return $message;
    }

    /**
     * Testar conexão
     */
    public function testConnection(): array
    {
        if (!$this->isConfigured()) {
            return [
                'success' => false,
                'message' => 'WhatsApp não está configurado'
            ];
        }

        try {
            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $this->apiToken,
                'Content-Type' => 'application/json'
            ])->get($this->apiUrl . '/status');

            if ($response->successful()) {
                return [
                    'success' => true,
                    'message' => 'Conexão com WhatsApp estabelecida com sucesso'
                ];
            }

            throw new \Exception('Erro na API do WhatsApp: ' . $response->body());

        } catch (\Exception $e) {
            Log::error('Erro ao testar conexão WhatsApp: ' . $e->getMessage());
            
            return [
                'success' => false,
                'message' => 'Erro ao testar conexão: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Validar configuração
     */
    public function validateConfiguration(): array
    {
        if (!$this->isConfigured()) {
            return [
                'success' => false,
                'message' => 'WhatsApp não está configurado'
            ];
        }

        return $this->testConnection();
    }

    /**
     * Obter configuração pública
     */
    public function getPublicConfig(): array
    {
        return [
            'configured' => $this->isConfigured(),
            'api_url' => $this->apiUrl ? parse_url($this->apiUrl, PHP_URL_HOST) : null
        ];
    }
}
