<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('settings', function (Blueprint $table) {
            $table->id();
            $table->string('business_name');
            $table->string('logo')->nullable();
            $table->string('header_image')->nullable();
            $table->string('primary_color', 7);
            $table->text('description')->nullable();
            $table->string('phone', 20)->nullable();
            $table->text('address')->nullable();
            $table->text('delivery_info')->nullable();
            $table->decimal('min_delivery_value', 10, 2)->nullable();
            $table->boolean('is_open')->default(true);
            $table->text('mercado_pago_access_token')->nullable();
            $table->string('mercado_pago_public_key')->nullable();
            $table->string('mercado_pago_return_url')->nullable();
            $table->string('mercado_pago_webhook_url')->nullable();
            $table->enum('mercado_pago_environment', ['sandbox', 'production'])->default('sandbox');
            $table->enum('display_mode', ['grid', 'list', 'compact'])->default('grid');
            $table->string('whatsapp_api_url')->nullable();
            $table->string('whatsapp_api_token')->nullable();
            $table->string('google_maps_api_key')->nullable();
            $table->decimal('free_delivery_threshold', 10, 2)->nullable();
            $table->time('order_cutoff_time')->nullable();
            $table->integer('advance_order_days')->default(1);
            $table->text('database_url')->nullable();
            $table->string('api_base_url')->nullable();
            $table->boolean('debug_mode')->default(false);
            $table->timestamps();

            $table->index('is_open');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('settings');
    }
};
