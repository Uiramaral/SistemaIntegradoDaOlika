export type DisplayMode = 'grid' | 'list' | 'compact';

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  category: string;
  available: boolean;
  featured?: boolean;
}

export interface CartItem extends Product {
  quantity: number;
}

export interface Category {
  id: string;
  name: string;
  icon?: string;
}

export interface MenuConfig {
  businessName: string;
  logo?: string;
  headerImage?: string;
  primaryColor: string;
  description?: string;
  phone?: string;
  address?: string;
  deliveryInfo?: string;
  minDeliveryValue?: number;
  isOpen: boolean;
  mercadoPagoAccessToken?: string;
  displayMode?: DisplayMode;
}

export interface Coupon {
  id: string;
  code: string;
  description: string;
  discountType: 'percentage' | 'fixed';
  discountValue: number;
  isPublic: boolean;
  firstPurchaseOnly: boolean;
  validUntil?: string;
  minPurchaseValue?: number;
  active: boolean;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  email?: string;
  address: string;
  cep: string;
  city: string;
  state: string;
  complement?: string;
  reference?: string;
  orderCount: number;
}

export interface DeliveryFee {
  cep: string;
  fee: number;
}

export interface Order {
  id: string;
  customerId: string;
  items: CartItem[];
  subtotal: number;
  deliveryFee: number;
  discount: number;
  total: number;
  couponCode?: string;
  observations?: string;
  paymentMethod: 'whatsapp' | 'mercadopago';
  status: 'pending' | 'confirmed' | 'preparing' | 'delivering' | 'completed' | 'cancelled';
  createdAt: string;
}
