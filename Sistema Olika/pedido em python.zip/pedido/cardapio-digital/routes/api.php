<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\ProductController;
use App\Http\Controllers\Api\CategoryController;
use App\Http\Controllers\Api\CustomerController;
use App\Http\Controllers\Api\OrderController;
use App\Http\Controllers\Api\CouponController;
use App\Http\Controllers\Api\SettingsController;
use App\Http\Controllers\Api\DashboardController;
use App\Http\Controllers\Api\PDVController;
use App\Http\Controllers\Api\MercadoPagoController;
use App\Http\Controllers\Api\CartController;
use App\Http\Controllers\Api\CheckoutController;
use App\Http\Controllers\Api\DeliveryController;
use App\Http\Controllers\Api\PaymentController;
use App\Http\Controllers\Api\WhatsAppAIController;
use App\Http\Controllers\Api\SuporteIAController;
use App\Http\Controllers\WhatsappController;
use App\Http\Controllers\WhatsappWebhookController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});


/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

// Rotas públicas
Route::get('/health', function () {
    return response()->json([
        'status' => 'ok',
        'timestamp' => now()->toISOString(),
        'version' => '1.0.0'
    ]);
});

// Configurações públicas
Route::get('/public/settings', [SettingsController::class, 'public']);
Route::get('/public/products', [ProductController::class, 'public']);
Route::get('/public/categories', [CategoryController::class, 'public']);
Route::get('/public/products/featured', [ProductController::class, 'featured']);

// Rotas públicas - Cliente
Route::prefix('client')->group(function () {
    // Carrinho
    Route::prefix('cart')->group(function () {
        Route::get('/', [CartController::class, 'get']);
        Route::post('/add', [CartController::class, 'addItem']);
        Route::put('/update', [CartController::class, 'updateQuantity']);
        Route::delete('/remove', [CartController::class, 'removeItem']);
        Route::delete('/clear', [CartController::class, 'clear']);
        Route::post('/apply-coupon', [CartController::class, 'applyCoupon']);
        Route::delete('/remove-coupon', [CartController::class, 'removeCoupon']);
        Route::get('/summary', [CartController::class, 'summary']);
        Route::get('/validate', [CartController::class, 'validate']);
    });
    
    // Checkout
    Route::prefix('checkout')->group(function () {
        Route::get('/initialize', [CheckoutController::class, 'initialize']);
        Route::post('/contact', [CheckoutController::class, 'validateContact']);
        Route::post('/delivery', [CheckoutController::class, 'validateDelivery']);
        Route::get('/available-dates', [CheckoutController::class, 'getAvailableDates']);
        Route::get('/time-slots', [CheckoutController::class, 'getAvailableTimeSlots']);
        Route::post('/scheduling', [CheckoutController::class, 'validateScheduling']);
        Route::post('/payment', [CheckoutController::class, 'processPayment']);
        Route::get('/summary', [CheckoutController::class, 'getSummary']);
    });
    
    // Entrega
    Route::prefix('delivery')->group(function () {
        Route::post('/calculate-fee', [DeliveryController::class, 'calculateFee']);
        Route::get('/address/{cep}', [DeliveryController::class, 'getAddressByCep']);
        Route::get('/available-dates', [DeliveryController::class, 'getAvailableDates']);
        Route::get('/time-slots', [DeliveryController::class, 'getAvailableTimeSlots']);
        Route::post('/check-availability', [DeliveryController::class, 'checkAvailability']);
        Route::get('/settings', [DeliveryController::class, 'getDeliverySettings']);
        Route::post('/calculate-time', [DeliveryController::class, 'calculateDeliveryTime']);
    });
    
    // Pagamento
    Route::prefix('payment')->group(function () {
        Route::post('/create-preference', [PaymentController::class, 'createPreference']);
        Route::post('/check-status', [PaymentController::class, 'checkPaymentStatus']);
        Route::post('/whatsapp', [PaymentController::class, 'processWhatsAppPayment']);
        Route::post('/confirm-manual', [PaymentController::class, 'confirmManualPayment']);
        Route::post('/cancel', [PaymentController::class, 'cancelPayment']);
        Route::get('/methods', [PaymentController::class, 'getPaymentMethods']);
    });
    
    // Cliente - Cadastro e Login
    Route::prefix('customer')->group(function () {
        Route::post('/register', [CustomerController::class, 'register']);
        Route::post('/login', [CustomerController::class, 'login']);
        Route::get('/profile', [CustomerController::class, 'profile'])->middleware('auth:sanctum');
        Route::put('/profile', [CustomerController::class, 'updateProfile'])->middleware('auth:sanctum');
        Route::get('/orders', [CustomerController::class, 'getOrders'])->middleware('auth:sanctum');
        Route::get('/loyalty-points', [CustomerController::class, 'getLoyaltyPoints'])->middleware('auth:sanctum');
    });
});

// ============================================
// ROTAS DA IA WHATSAPP
// ============================================
Route::prefix('ai')->group(function () {
    // Webhook WhatsApp IA
    Route::post('/whatsapp/webhook', [WhatsAppAIController::class, 'webhook']);
    
    // Teste da IA (desenvolvimento)
    Route::post('/test', [WhatsAppAIController::class, 'testAI']);
    
    // Estatísticas da IA
    Route::get('/stats', [WhatsAppAIController::class, 'getAIStats']);
    
    // TODO: Implementar controllers de IA quando necessário
    // AITrainingController, AIPatternController, AIConversationController
    // AIFeedbackController, AIMetricsController
});

// ============================================
// ROTAS DO SISTEMA DE SUPORTE IA
// ============================================
Route::prefix('suporte')->group(function () {
    // Processar mensagem de suporte
    Route::post('/mensagem', [SuporteIAController::class, 'processarMensagem']);
    
    // Histórico por subscriber
    Route::get('/historico/subscriber/{id}', [SuporteIAController::class, 'obterHistoricoPorSubscriber']);
    
    // Estatísticas gerais
    Route::get('/estatisticas', [SuporteIAController::class, 'obterEstatisticas']);
    
    // Conversas ativas
    Route::get('/conversas/ativas', [SuporteIAController::class, 'obterConversasAtivas']);
    
    // Detalhes de conversa
    Route::get('/conversas/{id}', [SuporteIAController::class, 'obterDetalhesConversa']);
    
    // Encerrar conversa
    Route::post('/conversas/{id}/encerrar', [SuporteIAController::class, 'encerrarConversa']);
});

// ============================================
// ROTAS DO SISTEMA WHATSAPP CHATBOT
// ============================================
Route::prefix('whatsapp')->middleware(['throttle:60,1'])->group(function () {
    // Conectar WhatsApp (rate limit mais restritivo)
    Route::post('/connect', [WhatsappController::class, 'connect'])->middleware('throttle:10,1');
    
    // Status da sessão
    Route::get('/session/status', [WhatsappController::class, 'status']);
    
    // Enviar mensagem (rate limit mais restritivo)
    Route::post('/send', [WhatsappController::class, 'send'])->middleware('throttle:30,1');
    
    // Opt-in/Opt-out
    Route::post('/opt-in', [WhatsappController::class, 'optIn']);
    Route::post('/opt-out', [WhatsappController::class, 'optOut']);
    
    // Gerenciar sessões
    Route::get('/sessions', [WhatsappController::class, 'sessions']);
    Route::get('/messages', [WhatsappController::class, 'messages']);
    Route::get('/stats', [WhatsappController::class, 'stats']);
    
    // Processar eventos de pedido
    Route::post('/process-event', [WhatsappController::class, 'processEvent']);
});

// Webhooks
Route::post('/webhooks/mercadopago', [MercadoPagoController::class, 'webhook']);
Route::post('/webhooks/payment', [PaymentController::class, 'webhook']);
Route::post('/webhooks/whatsapp-ai', [WhatsAppAIController::class, 'webhook']);

// Webhooks WhatsApp
Route::post('/whatsapp/webhook/gateway', [WhatsappWebhookController::class, 'gateway']);
Route::get('/whatsapp/webhook/cloud', [WhatsappWebhookController::class, 'cloudVerify']);
Route::post('/whatsapp/webhook/cloud', [WhatsappWebhookController::class, 'cloud']);

// Rotas da API (com autenticação básica ou sem autenticação para desenvolvimento)
Route::middleware('api')->group(function () {
    
    // Produtos
    Route::apiResource('products', ProductController::class);
    Route::post('products/{product}/toggle-availability', [ProductController::class, 'toggleAvailability']);
    Route::post('products/{product}/toggle-featured', [ProductController::class, 'toggleFeatured']);
    Route::post('products/{product}/toggle-visibility', [ProductController::class, 'toggleVisibility']);
    Route::get('products/search', [ProductController::class, 'search']);
    Route::get('products/category/{category}', [ProductController::class, 'byCategory']);

    // Categorias
    Route::apiResource('categories', CategoryController::class);
    Route::post('categories/{category}/toggle-visibility', [CategoryController::class, 'toggleVisibility']);
    Route::post('categories/{category}/toggle-availability', [CategoryController::class, 'toggleAvailability']);
    Route::get('categories/{category}/products', [CategoryController::class, 'products']);
    Route::get('categories-with-products', [CategoryController::class, 'withProducts']);
    Route::post('categories/reorder', [CategoryController::class, 'reorder']);

    // Clientes
    Route::apiResource('customers', CustomerController::class);
    Route::get('customers/search/phone', [CustomerController::class, 'findByPhone']);
    Route::get('customers/search/referral-code', [CustomerController::class, 'findByReferralCode']);
    Route::get('customers/{customer}/orders', [CustomerController::class, 'orders']);
    Route::get('customers/{customer}/stats', [CustomerController::class, 'stats']);
    Route::get('customers/{customer}/referrals', [CustomerController::class, 'referrals']);
    Route::post('customers/{customer}/add-loyalty-points', [CustomerController::class, 'addLoyaltyPoints']);
    Route::post('customers/{customer}/remove-loyalty-points', [CustomerController::class, 'removeLoyaltyPoints']);

    // Pedidos
    Route::apiResource('orders', OrderController::class);
    Route::post('orders/{order}/status', [OrderController::class, 'updateStatus']);
    Route::post('orders/{order}/confirm', [OrderController::class, 'confirm']);
    Route::post('orders/{order}/start-preparing', [OrderController::class, 'startPreparing']);
    Route::post('orders/{order}/start-delivering', [OrderController::class, 'startDelivering']);
    Route::post('orders/{order}/complete', [OrderController::class, 'complete']);
    Route::post('orders/{order}/cancel', [OrderController::class, 'cancel']);
    Route::get('orders/status/{status}', [OrderController::class, 'byStatus']);
    Route::get('orders/today', [OrderController::class, 'today']);
    Route::get('orders/stats', [OrderController::class, 'stats']);
    Route::get('orders/search', [OrderController::class, 'search']);

    // Cupons
    Route::apiResource('coupons', CouponController::class);
    Route::post('coupons/{coupon}/toggle-status', [CouponController::class, 'toggleStatus']);
    Route::get('coupons/validate/{code}', [CouponController::class, 'validate']);
    Route::get('coupons/public', [CouponController::class, 'public']);

    // Configurações
    Route::get('settings', [SettingsController::class, 'index']);
    Route::put('settings', [SettingsController::class, 'update']);
    Route::post('settings/toggle-status', [SettingsController::class, 'toggleStatus']);
    Route::get('settings/validate-mercadopago', [SettingsController::class, 'validateMercadoPago']);
    Route::get('settings/validate-whatsapp', [SettingsController::class, 'validateWhatsApp']);
    Route::get('settings/validate-googlemaps', [SettingsController::class, 'validateGoogleMaps']);

    // Dashboard
    Route::get('dashboard/stats', [DashboardController::class, 'stats']);
    Route::get('dashboard/recent-orders', [DashboardController::class, 'recentOrders']);
    Route::get('dashboard/top-products', [DashboardController::class, 'topProducts']);
    Route::get('dashboard/customers-stats', [DashboardController::class, 'customersStats']);
    Route::get('dashboard/orders-chart', [DashboardController::class, 'ordersChart']);
    Route::get('dashboard/revenue-chart', [DashboardController::class, 'revenueChart']);

    // PDV (Ponto de Venda)
    Route::prefix('pdv')->group(function () {
        Route::get('products', [PDVController::class, 'products']);
        Route::get('customers', [PDVController::class, 'customers']);
        Route::get('customers/search', [PDVController::class, 'searchCustomers']);
        Route::post('orders', [PDVController::class, 'createOrder']);
        Route::get('orders/recent', [PDVController::class, 'recentOrders']);
    });

    // Mercado Pago
    Route::prefix('mercadopago')->group(function () {
        Route::post('preference', [MercadoPagoController::class, 'createPreference']);
        Route::get('payment/{paymentId}', [MercadoPagoController::class, 'getPaymentStatus']);
        Route::get('payment-methods', [MercadoPagoController::class, 'getPaymentMethods']);
        Route::get('config', [MercadoPagoController::class, 'getConfig']);
        Route::post('validate', [MercadoPagoController::class, 'validateConfiguration']);
    });

    // WhatsApp legado removido - usar rotas do sistema novo em /api/whatsapp

    // Google Maps
    Route::prefix('maps')->group(function () {
        Route::get('address/cep/{cep}', [GoogleMapsController::class, 'getAddressByCep']);
        Route::get('cep/address', [GoogleMapsController::class, 'getCepByAddress']);
        Route::get('distance', [GoogleMapsController::class, 'calculateDistance']);
        Route::get('delivery-area/{cep}', [GoogleMapsController::class, 'isInDeliveryArea']);
        Route::get('coordinates', [GoogleMapsController::class, 'getCoordinates']);
        Route::get('config', [GoogleMapsController::class, 'getConfig']);
        Route::post('validate', [GoogleMapsController::class, 'validateConfiguration']);
    });

    // Taxas de entrega
    Route::apiResource('delivery-fees', DeliveryFeeController::class);
    Route::get('delivery-fees/cep/{cep}', [DeliveryFeeController::class, 'getByCep']);
    Route::post('delivery-fees/calculate', [DeliveryFeeController::class, 'calculate']);

    // Programa de fidelidade
    Route::apiResource('loyalty-program', LoyaltyProgramController::class);
    Route::post('loyalty-program/toggle-status', [LoyaltyProgramController::class, 'toggleStatus']);
    Route::get('loyalty-program/customers/{customer}/points', [LoyaltyProgramController::class, 'getCustomerPoints']);
    Route::post('loyalty-program/customers/{customer}/redeem', [LoyaltyProgramController::class, 'redeemPoints']);

    // Agendamento de entregas
    Route::apiResource('delivery-schedules', DeliveryScheduleController::class);
    Route::post('delivery-schedules/{schedule}/toggle-status', [DeliveryScheduleController::class, 'toggleStatus']);
    Route::get('delivery-schedules/available-dates', [DeliveryScheduleController::class, 'getAvailableDates']);
    Route::get('delivery-schedules/{date}/slots', [DeliveryScheduleController::class, 'getAvailableSlots']);
    Route::post('delivery-schedules/book-slot', [DeliveryScheduleController::class, 'bookSlot']);

    // Indicações
    Route::apiResource('referrals', ReferralController::class);
    Route::get('referrals/customer/{customer}', [ReferralController::class, 'getByCustomer']);
    Route::post('referrals/process/{referral}', [ReferralController::class, 'process']);
});
