# 🚀 GUIA DE UPLOAD SEGURO - HOSTGATOR

## ⚠️ **ATENÇÃO: NÃO COPIE TUDO DIRETAMENTE!**

Se você simplesmente copiar a pasta `cardapio-digital/` inteira para o HostGator, **TERÁ PROBLEMAS**!

---

## 🔴 **PRINCIPAIS DIFERENÇAS HOSTGATOR vs LOCAL**

### **1. Estrutura de Pastas**
- ❌ **Local:** Tudo junto na raiz
- ✅ **HostGator:** Separação específica

### **2. Banco de Dados**
- ❌ **Local:** `cardapio_digital`
- ✅ **HostGator:** `seuursuario_cardapio_digital` (prefixo do usuário)

### **3. Composer/Vendor**
- ❌ **Local:** `vendor/` gerado localmente
- ⚠️ **HostGator:** Pode não ter Composer ou versão diferente

### **4. Permissões**
- ❌ **Local:** Tudo 777/755
- ✅ **HostGator:** Permissões específicas obrigatórias

### **5. PHP Version**
- ❌ **Local:** 8.2+
- ⚠️ **HostGator:** Pode ser 7.4, 8.0, 8.1

### **6. Ambiente**
- ❌ **Local:** `.env` com `APP_DEBUG=true`
- ✅ **HostGator:** `.env` com `APP_DEBUG=false`

---

## ✅ **CHECKLIST ANTES DO UPLOAD**

### **Passo 1: Verificar Versão PHP no HostGator**
```bash
# No cPanel > Terminal ou SSH
php -v

# Deve ser PHP 8.0 ou superior
# Se for 7.4, configure para 8.0+ no cPanel
```

### **Passo 2: Preparar Arquivos Localmente**
```bash
# 1. Limpar cache local
php artisan cache:clear
php artisan config:clear
php artisan route:clear
php artisan view:clear

# 2. Remover arquivos desnecessários
# NÃO ENVIAR PARA O HOSTGATOR:
- node_modules/
- .git/
- .env (criar novo no servidor)
- storage/logs/*.log (logs locais)
- storage/framework/cache/*
- storage/framework/sessions/*
- storage/framework/views/*
- vendor/ (recriar no servidor)
```

### **Passo 3: Criar `.env` Específico para HostGator**
Crie um arquivo `.env.hostgator` com:

```env
# ============================================
# CONFIGURACAO HOSTGATOR - PRODUCAO
# ============================================
APP_NAME="Cardapio Digital Olika"
APP_ENV=production
APP_DEBUG=false
APP_KEY=base64:GERAR_NO_SERVIDOR
APP_URL=https://seudominio.com.br

# ============================================
# BANCO DE DADOS HOSTGATOR
# ============================================
DB_CONNECTION=mysql
DB_HOST=localhost
DB_PORT=3306
DB_DATABASE=seuursu_cardapio_digital
DB_USERNAME=seuursu_cardapio_user
DB_PASSWORD=SENHA_GERADA_NO_HOSTGATOR

# ============================================
# TIMEZONE (BAHIA)
# ============================================
APP_TIMEZONE=America/Bahia

# ============================================
# CACHE E SESSAO (HOSTGATOR)
# ============================================
CACHE_DRIVER=file
SESSION_DRIVER=file
QUEUE_CONNECTION=sync
LOG_CHANNEL=daily
LOG_LEVEL=error

# ============================================
# WHATSAPP (CONFIGURAR DEPOIS)
# ============================================
WHATS_ADAPTER_DEFAULT=non_official
WHATS_GATEWAY_BASE_URL=
WHATS_GATEWAY_TOKEN=
WHATS_WEBHOOK_SECRET=

# ============================================
# OPENAI (CONFIGURAR DEPOIS)
# ============================================
OPENAI_API_KEY=
OPENAI_MODEL=gpt-5-nano
OPENAI_MAX_TOKENS=1000
OPENAI_TEMPERATURE=0.7

# ============================================
# MERCADO PAGO (PRODUCAO)
# ============================================
MERCADOPAGO_ACCESS_TOKEN=
MERCADOPAGO_PUBLIC_KEY=

# ============================================
# GOOGLE MAPS
# ============================================
GOOGLE_MAPS_API_KEY=
```

---

## 📦 **O QUE ENVIAR PARA O HOSTGATOR**

### **✅ ENVIAR (Essencial):**
```
cardapio-digital/
├── app/                      ✅ Toda a pasta
├── bootstrap/                ✅ Toda a pasta
├── config/                   ✅ Toda a pasta
├── database/                 ✅ Apenas database/cardapio_digital.sql
├── public/                   ✅ Toda a pasta
├── resources/                ✅ Toda a pasta
├── routes/                   ✅ Toda a pasta
├── storage/                  ✅ Estrutura vazia (criar pastas)
├── artisan                   ✅ Arquivo
├── composer.json             ✅ Arquivo
├── composer.lock             ✅ Arquivo (se existir)
└── .htaccess                 ✅ Se tiver na raiz
```

### **❌ NÃO ENVIAR:**
```
❌ node_modules/             (não usar no Laravel)
❌ .git/                     (histórico Git)
❌ .env                      (criar novo no servidor)
❌ vendor/                   (recriar no servidor)
❌ storage/logs/*.log        (logs locais)
❌ storage/framework/cache/* (cache local)
❌ *.md                      (documentação)
❌ tests/                    (testes)
❌ .gitignore
❌ .editorconfig
```

### **⚠️ CRIAR NO SERVIDOR:**
```
⚠️ .env                      (baseado em .env.hostgator)
⚠️ storage/app/
⚠️ storage/framework/cache/
⚠️ storage/framework/sessions/
⚠️ storage/framework/views/
⚠️ storage/logs/
```

---

## 🎯 **PASSO A PASSO UPLOAD SEGURO**

### **MÉTODO 1: Upload via cPanel File Manager (RECOMENDADO)**

#### **1. Preparar Localmente:**
```bash
# Zipar apenas o necessário (Windows PowerShell)
Compress-Archive -Path cardapio-digital\app,cardapio-digital\bootstrap,cardapio-digital\config,cardapio-digital\public,cardapio-digital\resources,cardapio-digital\routes,cardapio-digital\storage,cardapio-digital\artisan,cardapio-digital\composer.json -DestinationPath cardapio-hostgator.zip

# OU criar manualmente:
# 1. Criar pasta "cardapio-hostgator"
# 2. Copiar apenas as pastas/arquivos da lista ✅
# 3. Zipar: cardapio-hostgator.zip
```

#### **2. No HostGator cPanel:**
```
1. Login no cPanel
2. Gerenciador de Arquivos
3. Navegar para: public_html/
4. Clicar em "Upload"
5. Selecionar: cardapio-hostgator.zip
6. Aguardar upload (pode demorar 5-10min)
7. Clicar com botão direito no .zip
8. "Extract" (Extrair)
9. Confirmar extração
10. Deletar o .zip após extrair
```

#### **3. Criar Estrutura storage/:**
```
No File Manager:
1. Navegar para: cardapio-digital/storage/
2. Criar pastas (se não existirem):
   - app/
   - app/public/
   - framework/
   - framework/cache/
   - framework/cache/data/
   - framework/sessions/
   - framework/views/
   - logs/
```

#### **4. Configurar Permissões:**
```
No File Manager:
1. Selecionar pasta "storage"
2. Botão direito > "Permissions"
3. Marcar: 755 (rwxr-xr-x)
4. Marcar: "Recursivamente"
5. "Change Permissions"

6. Repetir para "bootstrap/cache"
7. Permissão: 755
```

#### **5. Criar .env:**
```
No File Manager:
1. Navegar para: cardapio-digital/
2. Clicar em "+ Arquivo"
3. Nome: .env
4. Clicar com botão direito > "Edit"
5. Copiar conteúdo do .env.hostgator (preparado acima)
6. Salvar
```

#### **6. Gerar APP_KEY:**
```
# Via Terminal SSH (se disponível):
cd public_html/cardapio-digital
php artisan key:generate

# OU via cPanel Terminal:
1. cPanel > Terminal
2. cd public_html/cardapio-digital
3. php artisan key:generate
4. Copiar a key gerada
5. Editar .env e colar em APP_KEY

# OU Manualmente:
1. Gerar em: https://generate-random.org/laravel-key-generator
2. Copiar a key
3. Editar .env
4. APP_KEY=base64:SUA_KEY_AQUI
```

#### **7. Instalar Composer Dependencies:**
```bash
# Via Terminal SSH (PREFERENCIAL):
cd public_html/cardapio-digital
composer install --no-dev --optimize-autoloader

# Se NÃO TIVER Composer no HostGator:
# Opção A: Enviar vendor/ do local (NÃO RECOMENDADO)
# Opção B: Solicitar ao suporte instalar Composer
# Opção C: Usar Cloudflare Pages/Railway para Laravel
```

⚠️ **IMPORTANTE:** Se o HostGator não tiver Composer, você PRECISA:
1. Enviar a pasta `vendor/` junto (zipada separadamente)
2. OU solicitar ao suporte ativar Composer
3. OU migrar para serviço com Composer (Railway, Fly.io)

#### **8. Importar Banco de Dados:**
```
1. cPanel > phpMyAdmin
2. Criar banco: seuursu_cardapio_digital
3. Selecionar o banco
4. Aba "Importar"
5. Escolher: database/cardapio_digital.sql
6. "Executar"
7. Verificar: SHOW TABLES; (deve ter 20+ tabelas)
```

#### **9. Configurar Domínio:**
```
Opção A - Domínio Principal:
1. cPanel > "Domínios"
2. Domínio principal
3. "Gerenciar"
4. Raiz do Documento: /public_html/cardapio-digital/public

Opção B - Subdomínio:
1. cPanel > "Subdomínios"
2. Criar: admin.seudominio.com
3. Raiz: /public_html/cardapio-digital/public
4. Criar
```

#### **10. Testar:**
```
1. Acessar: https://seudominio.com.br
2. Deve carregar o menu
3. Verificar: https://seudominio.com.br/dashboard
4. Testar login admin
5. Verificar logs: storage/logs/laravel.log
```

---

## 🔧 **PROBLEMAS COMUNS E SOLUÇÕES**

### **1. Erro 500 - Internal Server Error**
```bash
# Causa: Permissões incorretas
# Solução:
chmod 755 storage -R
chmod 755 bootstrap/cache -R

# OU no cPanel File Manager:
# Permissões > 755 > Recursivo
```

### **2. Erro: "No application encryption key"**
```bash
# Causa: APP_KEY não configurada
# Solução:
php artisan key:generate

# OU manualmente:
# 1. Gerar key em https://generate-random.org/laravel-key-generator
# 2. Adicionar no .env: APP_KEY=base64:...
```

### **3. Erro: "SQLSTATE[HY000] [1045] Access denied"**
```env
# Causa: Credenciais banco incorretas
# Solução: Verificar .env
DB_DATABASE=seuursu_cardapio_digital  # COM prefixo do usuário!
DB_USERNAME=seuursu_cardapio_user
DB_PASSWORD=senha_correta
```

### **4. Erro: "Class 'Vendor\Package' not found"**
```bash
# Causa: vendor/ não foi instalado
# Solução:
composer install --no-dev --optimize-autoloader

# OU enviar vendor/ do local (última opção)
```

### **5. Página em branco**
```bash
# Causa: Erro no código
# Solução: Ver logs
cat storage/logs/laravel.log

# OU ativar debug temporariamente:
# .env: APP_DEBUG=true (NUNCA deixar true em produção!)
```

### **6. Erro: "The stream or file could not be opened"**
```bash
# Causa: Pasta storage sem permissão
# Solução:
chmod 755 storage -R
chmod 755 bootstrap/cache -R
```

---

## 📋 **CHECKLIST FINAL PÓS-UPLOAD**

### **Funcionalidades a Testar:**
- [ ] ✅ Menu público carrega
- [ ] ✅ Produtos aparecem com imagens
- [ ] ✅ Adicionar ao carrinho funciona
- [ ] ✅ Carrinho mostra itens
- [ ] ✅ Checkout abre
- [ ] ✅ Dashboard login funciona
- [ ] ✅ Dashboard mostra dados
- [ ] ✅ Criar/editar produtos
- [ ] ✅ Criar/editar pedidos
- [ ] ✅ WhatsApp (se configurado)
- [ ] ✅ MercadoPago (se configurado)

### **Segurança:**
- [ ] ✅ `APP_DEBUG=false` no .env
- [ ] ✅ `.env` com permissão 600
- [ ] ✅ `storage/` com permissão 755
- [ ] ✅ Senha banco forte
- [ ] ✅ APP_KEY gerada e única

### **Performance:**
- [ ] ✅ Cache config: `php artisan config:cache`
- [ ] ✅ Cache routes: `php artisan route:cache`
- [ ] ✅ Cache views: `php artisan view:cache`

---

## 🚨 **ERROS CRÍTICOS A EVITAR**

### **❌ NÃO FAÇA:**
1. ❌ Copiar `.env` do local para servidor
2. ❌ Enviar `vendor/` sem testar compatibilidade
3. ❌ Deixar `APP_DEBUG=true` em produção
4. ❌ Usar senha fraca no banco
5. ❌ Esquecer de criar estrutura `storage/`
6. ❌ Não configurar permissões
7. ❌ Enviar `node_modules/`
8. ❌ Enviar `.git/`
9. ❌ Não testar antes de apontar domínio

### **✅ SEMPRE FAÇA:**
1. ✅ Criar `.env` novo no servidor
2. ✅ Gerar `APP_KEY` nova
3. ✅ Configurar permissões corretas
4. ✅ Criar estrutura `storage/` completa
5. ✅ Instalar `vendor/` no servidor
6. ✅ Importar SQL no banco correto
7. ✅ Testar TUDO antes de abrir ao público
8. ✅ Fazer backup antes de qualquer mudança

---

## 🎯 **RESUMO EXECUTIVO**

### **Para Upload Seguro:**

```bash
# 1. PREPARAR LOCALMENTE (5min)
- Zipar apenas: app, bootstrap, config, public, resources, routes, storage, artisan, composer.json
- Criar .env.hostgator com configurações corretas

# 2. UPLOAD (10min)
- Enviar .zip via cPanel File Manager
- Extrair no servidor
- Criar estrutura storage/

# 3. CONFIGURAR (10min)
- Copiar .env.hostgator para .env
- php artisan key:generate
- Configurar permissões (755)
- composer install

# 4. BANCO (5min)
- Criar banco no cPanel
- Importar cardapio_digital.sql via phpMyAdmin
- Atualizar .env com credenciais

# 5. TESTAR (10min)
- Acessar domínio
- Testar todas funcionalidades
- Verificar logs

TEMPO TOTAL: ~40 minutos
```

---

## 📞 **SUPORTE**

Se tiver problemas:
1. Verificar `storage/logs/laravel.log`
2. Ativar temporariamente `APP_DEBUG=true`
3. Ver erro completo
4. Buscar solução acima
5. Contatar suporte HostGator se necessário

---

**✅ SEGUINDO ESTE GUIA, SEU UPLOAD SERÁ 100% SEGURO!**

**Data:** $(date +%Y-%m-%d)  
**Versão:** 1.0 - Upload Seguro HostGator

