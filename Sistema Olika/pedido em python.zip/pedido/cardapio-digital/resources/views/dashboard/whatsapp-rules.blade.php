@extends('dashboard.layout-complete')

@section('title', 'Regras WhatsApp - Cardápio Digital Olika')

@section('content')
<div class="min-h-screen bg-gray-50">
    <!-- Header -->
    <div class="bg-white shadow-sm border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-6">
                <div>
                    <h1 class="text-2xl font-bold text-gray-900">Regras WhatsApp</h1>
                    <p class="text-sm text-gray-600">Configure mensagens automáticas baseadas em eventos</p>
                </div>
                <div class="flex space-x-3">
                    <button id="addRuleBtn" class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                        <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
                        </svg>
                        Nova Regra
                    </button>
                </div>
            </div>
        </div>
    </div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <!-- Filtros -->
        <div class="bg-white rounded-lg shadow mb-6">
            <div class="px-6 py-4 border-b border-gray-200">
                <h3 class="text-lg font-medium text-gray-900">Filtros</h3>
            </div>
            <div class="p-6">
                <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Status</label>
                        <select id="statusFilter" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                            <option value="">Todos</option>
                            <option value="1">Ativas</option>
                            <option value="0">Inativas</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Adapter</label>
                        <select id="adapterFilter" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                            <option value="">Todos</option>
                            <option value="non_official">Não-oficial</option>
                            <option value="cloud_api">Cloud API</option>
                            <option value="any">Qualquer</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Evento</label>
                        <select id="eventFilter" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                            <option value="">Todos</option>
                            <option value="order_confirmed">Pedido Confirmado</option>
                            <option value="out_for_delivery">Saiu para Entrega</option>
                            <option value="delivered">Entregue</option>
                            <option value="canceled">Cancelado</option>
                            <option value="winback_7d">Winback 7 dias</option>
                            <option value="winback_30d">Winback 30 dias</option>
                            <option value="birthday">Aniversário</option>
                        </select>
                    </div>
                    <div class="flex items-end">
                        <button id="applyFilters" class="w-full inline-flex justify-center items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                            Aplicar Filtros
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Lista de Regras -->
        <div class="bg-white rounded-lg shadow">
            <div class="px-6 py-4 border-b border-gray-200">
                <div class="flex justify-between items-center">
                    <h3 class="text-lg font-medium text-gray-900">Regras Configuradas</h3>
                    <div class="flex items-center space-x-2">
                        <span id="rulesCount" class="text-sm text-gray-500">0 regras</span>
                        <button id="refreshRules" class="text-sm text-blue-600 hover:text-blue-500">
                            Atualizar
                        </button>
                    </div>
                </div>
            </div>
            <div class="divide-y divide-gray-200">
                <div id="rulesList">
                    <!-- Regras serão carregadas aqui -->
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal de Nova/Edição de Regra -->
<div id="ruleModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50" style="display: none;">
    <div class="relative top-20 mx-auto p-5 border w-full max-w-2xl shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <div class="flex items-center justify-between mb-4">
                <h3 id="ruleModalTitle" class="text-lg font-medium text-gray-900">Nova Regra</h3>
                <button id="closeRuleModal" class="text-gray-400 hover:text-gray-600">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                </button>
            </div>
            <form id="ruleForm">
                <input type="hidden" id="ruleId" value="">
                <div class="space-y-6">
                    <!-- Evento -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Evento *</label>
                        <select id="eventKey" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" required>
                            <option value="">Selecione um evento</option>
                            <option value="order_confirmed">Pedido Confirmado</option>
                            <option value="out_for_delivery">Saiu para Entrega</option>
                            <option value="delivered">Entregue</option>
                            <option value="canceled">Cancelado</option>
                            <option value="winback_7d">Winback 7 dias</option>
                            <option value="winback_30d">Winback 30 dias</option>
                            <option value="birthday">Aniversário</option>
                        </select>
                    </div>

                    <!-- Adapter -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Adapter *</label>
                        <select id="adapter" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" required>
                            <option value="any">Qualquer</option>
                            <option value="non_official">Não-oficial</option>
                            <option value="cloud_api">Cloud API</option>
                        </select>
                    </div>

                    <!-- Nome do Template -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Nome do Template *</label>
                        <input type="text" id="templateName" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" placeholder="Ex: order_confirmed_v1" required>
                    </div>

                    <!-- Conteúdo da Mensagem -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Conteúdo da Mensagem *</label>
                        <textarea id="templateBody" rows="4" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" placeholder="Digite a mensagem com variáveis como {{nome}}, {{pedido}}, etc." required></textarea>
                        <p class="mt-1 text-sm text-gray-500">
                            Variáveis disponíveis: {{nome}}, {{pedido}}, {{previsao}}, {{total}}, {{loja}}, {{data}}
                        </p>
                    </div>

                    <!-- Variáveis do Template -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Variáveis do Template (JSON)</label>
                        <textarea id="templateVars" rows="3" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" placeholder='["nome", "pedido", "previsao"]'></textarea>
                        <p class="mt-1 text-sm text-gray-500">
                            Lista de variáveis em formato JSON array
                        </p>
                    </div>

                    <!-- Janela de Envio -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Janela de Envio</label>
                        <div class="flex space-x-2">
                            <input type="time" id="sendWindowStart" class="flex-1 px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" value="09:00">
                            <span class="flex items-center text-gray-500">até</span>
                            <input type="time" id="sendWindowEnd" class="flex-1 px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" value="20:30">
                        </div>
                        <p class="mt-1 text-sm text-gray-500">
                            Horário em que as mensagens podem ser enviadas
                        </p>
                    </div>

                    <!-- Status -->
                    <div class="flex items-center">
                        <input type="checkbox" id="enabled" class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded" checked>
                        <label for="enabled" class="ml-2 block text-sm text-gray-900">
                            Regra ativa
                        </label>
                    </div>
                </div>

                <div class="flex justify-end space-x-3 mt-6">
                    <button type="button" id="saveRule" class="px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                        Salvar
                    </button>
                    <button type="button" id="cancelRule" class="px-4 py-2 bg-gray-300 text-gray-700 text-sm font-medium rounded-md hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500">
                        Cancelar
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal de Confirmação -->
<div id="confirmModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50" style="display: none;">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <div class="flex items-center justify-center w-12 h-12 mx-auto bg-red-100 rounded-full">
                <svg class="w-6 h-6 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z"></path>
                </svg>
            </div>
            <div class="mt-3 text-center">
                <h3 class="text-lg font-medium text-gray-900">Confirmar Exclusão</h3>
                <div class="mt-2">
                    <p class="text-sm text-gray-500" id="confirmMessage">
                        Tem certeza que deseja excluir esta regra?
                    </p>
                </div>
            </div>
            <div class="flex justify-center space-x-3 mt-6">
                <button id="confirmDelete" class="px-4 py-2 bg-red-600 text-white text-sm font-medium rounded-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500">
                    Excluir
                </button>
                <button id="cancelDelete" class="px-4 py-2 bg-gray-300 text-gray-700 text-sm font-medium rounded-md hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500">
                    Cancelar
                </button>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Elementos DOM
    const addRuleBtn = document.getElementById('addRuleBtn');
    const ruleModal = document.getElementById('ruleModal');
    const closeRuleModal = document.getElementById('closeRuleModal');
    const ruleForm = document.getElementById('ruleForm');
    const saveRule = document.getElementById('saveRule');
    const cancelRule = document.getElementById('cancelRule');
    const rulesList = document.getElementById('rulesList');
    const refreshRules = document.getElementById('refreshRules');
    const applyFilters = document.getElementById('applyFilters');
    const confirmModal = document.getElementById('confirmModal');
    const confirmDelete = document.getElementById('confirmDelete');
    const cancelDelete = document.getElementById('cancelDelete');

    // Variáveis
    let currentRuleId = null;
    let rules = [];

    // Inicializar
    loadRules();

    // Event Listeners
    addRuleBtn.addEventListener('click', () => openRuleModal());
    closeRuleModal.addEventListener('click', () => closeModal());
    saveRule.addEventListener('click', saveRuleData);
    cancelRule.addEventListener('click', closeModal);
    refreshRules.addEventListener('click', loadRules);
    applyFilters.addEventListener('click', applyFiltersToRules);
    confirmDelete.addEventListener('click', deleteRule);
    cancelDelete.addEventListener('click', () => confirmModal.style.display = 'none');

    // Fechar modais ao clicar fora
    window.addEventListener('click', function(event) {
        if (event.target === ruleModal) {
            closeModal();
        }
        if (event.target === confirmModal) {
            confirmModal.style.display = 'none';
        }
    });

    function openRuleModal(rule = null) {
        currentRuleId = rule ? rule.id : null;
        
        if (rule) {
            document.getElementById('ruleModalTitle').textContent = 'Editar Regra';
            document.getElementById('eventKey').value = rule.event_key;
            document.getElementById('adapter').value = rule.adapter;
            document.getElementById('templateName').value = rule.template_name;
            document.getElementById('templateBody').value = rule.template_body;
            document.getElementById('templateVars').value = rule.template_vars ? JSON.stringify(rule.template_vars) : '';
            document.getElementById('enabled').checked = rule.enabled;
            
            // Parse send window
            if (rule.send_window) {
                const [start, end] = rule.send_window.split('-');
                document.getElementById('sendWindowStart').value = start;
                document.getElementById('sendWindowEnd').value = end;
            }
        } else {
            document.getElementById('ruleModalTitle').textContent = 'Nova Regra';
            ruleForm.reset();
            document.getElementById('sendWindowStart').value = '09:00';
            document.getElementById('sendWindowEnd').value = '20:30';
            document.getElementById('enabled').checked = true;
        }
        
        ruleModal.style.display = 'block';
    }

    function closeModal() {
        ruleModal.style.display = 'none';
        ruleForm.reset();
        currentRuleId = null;
    }

    function saveRuleData() {
        const formData = {
            event_key: document.getElementById('eventKey').value,
            adapter: document.getElementById('adapter').value,
            template_name: document.getElementById('templateName').value,
            template_body: document.getElementById('templateBody').value,
            template_vars: document.getElementById('templateVars').value ? JSON.parse(document.getElementById('templateVars').value) : [],
            send_window: `${document.getElementById('sendWindowStart').value}-${document.getElementById('sendWindowEnd').value}`,
            enabled: document.getElementById('enabled').checked ? 1 : 0
        };

        if (!formData.event_key || !formData.template_name || !formData.template_body) {
            alert('Por favor, preencha todos os campos obrigatórios');
            return;
        }

        const url = currentRuleId ? `/api/whatsapp/rules/${currentRuleId}` : '/api/whatsapp/rules';
        const method = currentRuleId ? 'PUT' : 'POST';

        fetch(url, {
            method: method,
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
            },
            body: JSON.stringify(formData)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                closeModal();
                loadRules();
                showNotification('Regra salva com sucesso!', 'success');
            } else {
                alert('Erro ao salvar regra: ' + (data.message || data.error));
            }
        })
        .catch(error => {
            console.error('Erro:', error);
            alert('Erro ao salvar regra');
        });
    }

    function loadRules() {
        fetch('/api/whatsapp/rules?loja_id=1')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                rules = data.rules;
                displayRules(rules);
                updateRulesCount(rules.length);
            }
        })
        .catch(error => {
            console.error('Erro ao carregar regras:', error);
        });
    }

    function displayRules(rulesToShow) {
        if (rulesToShow.length === 0) {
            rulesList.innerHTML = `
                <div class="p-8 text-center">
                    <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                    </svg>
                    <h3 class="mt-2 text-sm font-medium text-gray-900">Nenhuma regra encontrada</h3>
                    <p class="mt-1 text-sm text-gray-500">Comece criando uma nova regra.</p>
                </div>
            `;
            return;
        }

        rulesList.innerHTML = rulesToShow.map(rule => `
            <div class="p-6 hover:bg-gray-50">
                <div class="flex items-start justify-between">
                    <div class="flex-1">
                        <div class="flex items-center space-x-3">
                            <h4 class="text-lg font-medium text-gray-900">${getEventDisplayName(rule.event_key)}</h4>
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${rule.enabled ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}">
                                ${rule.enabled ? 'Ativa' : 'Inativa'}
                            </span>
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getAdapterColor(rule.adapter)}">
                                ${getAdapterDisplayName(rule.adapter)}
                            </span>
                        </div>
                        <div class="mt-2">
                            <p class="text-sm text-gray-600">
                                <strong>Template:</strong> ${rule.template_name}
                            </p>
                            <p class="text-sm text-gray-600 mt-1">
                                <strong>Conteúdo:</strong> ${rule.template_body.substring(0, 100)}${rule.template_body.length > 100 ? '...' : ''}
                            </p>
                            <div class="mt-2 flex items-center space-x-4 text-xs text-gray-500">
                                <span>Janela: ${rule.send_window || 'Sempre'}</span>
                                <span>Criado: ${new Date(rule.created_at).toLocaleDateString()}</span>
                            </div>
                        </div>
                    </div>
                    <div class="flex items-center space-x-2">
                        <button onclick="editRule(${rule.id})" class="text-blue-600 hover:text-blue-900 text-sm font-medium">
                            Editar
                        </button>
                        <button onclick="toggleRule(${rule.id}, ${rule.enabled})" class="text-yellow-600 hover:text-yellow-900 text-sm font-medium">
                            ${rule.enabled ? 'Desativar' : 'Ativar'}
                        </button>
                        <button onclick="deleteRuleConfirm(${rule.id})" class="text-red-600 hover:text-red-900 text-sm font-medium">
                            Excluir
                        </button>
                    </div>
                </div>
            </div>
        `).join('');
    }

    function getEventDisplayName(eventKey) {
        const names = {
            'order_confirmed': 'Pedido Confirmado',
            'out_for_delivery': 'Saiu para Entrega',
            'delivered': 'Entregue',
            'canceled': 'Cancelado',
            'winback_7d': 'Winback 7 dias',
            'winback_30d': 'Winback 30 dias',
            'birthday': 'Aniversário'
        };
        return names[eventKey] || eventKey;
    }

    function getAdapterDisplayName(adapter) {
        const names = {
            'non_official': 'Não-oficial',
            'cloud_api': 'Cloud API',
            'any': 'Qualquer'
        };
        return names[adapter] || adapter;
    }

    function getAdapterColor(adapter) {
        const colors = {
            'non_official': 'bg-blue-100 text-blue-800',
            'cloud_api': 'bg-green-100 text-green-800',
            'any': 'bg-gray-100 text-gray-800'
        };
        return colors[adapter] || 'bg-gray-100 text-gray-800';
    }

    function updateRulesCount(count) {
        document.getElementById('rulesCount').textContent = `${count} regra${count !== 1 ? 's' : ''}`;
    }

    function applyFiltersToRules() {
        const statusFilter = document.getElementById('statusFilter').value;
        const adapterFilter = document.getElementById('adapterFilter').value;
        const eventFilter = document.getElementById('eventFilter').value;

        let filteredRules = rules;

        if (statusFilter !== '') {
            filteredRules = filteredRules.filter(rule => rule.enabled == statusFilter);
        }

        if (adapterFilter !== '') {
            filteredRules = filteredRules.filter(rule => rule.adapter === adapterFilter);
        }

        if (eventFilter !== '') {
            filteredRules = filteredRules.filter(rule => rule.event_key === eventFilter);
        }

        displayRules(filteredRules);
        updateRulesCount(filteredRules.length);
    }

    function editRule(ruleId) {
        const rule = rules.find(r => r.id === ruleId);
        if (rule) {
            openRuleModal(rule);
        }
    }

    function toggleRule(ruleId, currentStatus) {
        const newStatus = currentStatus ? 0 : 1;
        
        fetch(`/api/whatsapp/rules/${ruleId}`, {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
            },
            body: JSON.stringify({ enabled: newStatus })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                loadRules();
                showNotification(`Regra ${newStatus ? 'ativada' : 'desativada'} com sucesso!`, 'success');
            } else {
                alert('Erro ao alterar status da regra');
            }
        })
        .catch(error => {
            console.error('Erro:', error);
            alert('Erro ao alterar status da regra');
        });
    }

    function deleteRuleConfirm(ruleId) {
        currentRuleId = ruleId;
        confirmModal.style.display = 'block';
    }

    function deleteRule() {
        if (!currentRuleId) return;

        fetch(`/api/whatsapp/rules/${currentRuleId}`, {
            method: 'DELETE',
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                confirmModal.style.display = 'none';
                loadRules();
                showNotification('Regra excluída com sucesso!', 'success');
            } else {
                alert('Erro ao excluir regra');
            }
        })
        .catch(error => {
            console.error('Erro:', error);
            alert('Erro ao excluir regra');
        });
    }

    function showNotification(message, type = 'info') {
        // Implementar sistema de notificações
        alert(message);
    }

    // Tornar funções globais para uso nos botões
    window.editRule = editRule;
    window.toggleRule = toggleRule;
    window.deleteRuleConfirm = deleteRuleConfirm;
});
</script>
@endsection
