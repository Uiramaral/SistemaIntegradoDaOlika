# 🗄️ **INSTALAÇÃO DO BANCO DE DADOS - CARDÁPIO DIGITAL OLIKA**

## 🎯 **MariaDB/MySQL - Instalação Completa**

### **Opção 1: Instalação Rápida (Recomendada)**

```bash
# 1. Conectar no MariaDB/MySQL como root
mysql -u root -p

# 2. Executar o script de instalação
source /caminho/para/cardapio-digital/install_database.sql;
```

### **Opção 2: Instalação Manual**

```bash
# 1. Conectar no MariaDB/MySQL
mysql -u root -p

# 2. Executar o script completo
source /caminho/para/cardapio-digital/database/cardapio_digital.sql;
```

### **Opção 3: Via linha de comando**

```bash
# Executar diretamente via comando
mysql -u root -p < database/cardapio_digital.sql
```

---

## 📋 **O QUE É CRIADO**

### **🗂️ Tabelas (11 tabelas)**
1. **`customers`** - Clientes com autenticação
2. **`categories`** - Categorias de produtos
3. **`products`** - Produtos do cardápio
4. **`orders`** - Pedidos dos clientes
5. **`order_items`** - Itens dos pedidos
6. **`coupons`** - Cupons e promoções
7. **`loyalty_programs`** - Programa de fidelidade
8. **`referrals`** - Sistema de indicações
9. **`delivery_fees`** - Taxas de entrega por CEP
10. **`delivery_schedules`** - Agendamento de entregas
11. **`settings`** - Configurações do sistema
12. **`personal_access_tokens`** - Tokens de autenticação

### **📊 Views para Relatórios**
- **`v_sales_stats`** - Estatísticas de vendas
- **`v_top_products`** - Produtos mais vendidos
- **`v_top_customers`** - Clientes mais frequentes

### **⚡ Procedures Úteis**
- **`sp_calculate_delivery_fee`** - Calcular frete por CEP
- **`sp_get_available_slots`** - Horários disponíveis

### **🔧 Triggers Automáticos**
- **Geração automática de número do pedido**
- **Atualização de contadores do cliente**
- **Contador de uso de cupons**

### **📦 Dados Iniciais**
- ✅ 4 categorias padrão
- ✅ 6 produtos de exemplo
- ✅ Programa de fidelidade configurado
- ✅ 4 zonas de entrega
- ✅ 18 configurações padrão
- ✅ 3 cupons de exemplo

---

## 🔧 **CONFIGURAÇÃO PARA ACESSO REMOTO**

### **1. Configurar MariaDB para aceitar conexões remotas**

```bash
# Editar arquivo de configuração
sudo nano /etc/mysql/mariadb.conf.d/50-server.cnf

# Alterar a linha:
bind-address = 0.0.0.0  # Era 127.0.0.1

# Reiniciar MariaDB
sudo systemctl restart mariadb
```

### **2. Criar usuário para acesso remoto**

```sql
-- Conectar como root
mysql -u root -p

-- Criar usuário (substitua pelo IP do servidor da app)
CREATE USER 'cardapio_user'@'%' IDENTIFIED BY 'senha_super_segura_123!';
-- Para IP específico: CREATE USER 'cardapio_user'@'192.168.1.100' IDENTIFIED BY 'senha';

-- Dar permissões
GRANT ALL PRIVILEGES ON cardapio_digital.* TO 'cardapio_user'@'%';
FLUSH PRIVILEGES;
```

### **3. Configurar Firewall**

```bash
# Permitir conexões na porta 3306
sudo ufw allow 3306

# Ou apenas para IP específico (mais seguro)
sudo ufw allow from 192.168.1.100 to any port 3306
```

---

## ⚙️ **CONFIGURAÇÃO NO LARAVEL**

### **Arquivo `.env`**

```env
# Banco de dados
DB_CONNECTION=mysql
DB_HOST=IP_DO_SERVIDOR_BANCO    # Ex: 192.168.1.200
DB_PORT=3306
DB_DATABASE=cardapio_digital
DB_USERNAME=cardapio_user
DB_PASSWORD=senha_super_segura_123!
```

### **Testar Conexão**

```bash
# No servidor da aplicação Laravel
php artisan tinker

# Testar conexão
DB::connection()->getPdo();
echo "Conexão OK!";
```

---

## 🚀 **COMANDOS ÚTEIS**

### **Verificar Estrutura**

```sql
-- Ver todas as tabelas
SHOW TABLES;

-- Ver estrutura de uma tabela
DESCRIBE customers;

-- Ver dados de exemplo
SELECT * FROM categories;
SELECT * FROM products LIMIT 5;
```

### **Backup do Banco**

```bash
# Backup completo
mysqldump -u root -p cardapio_digital > backup_cardapio_$(date +%Y%m%d).sql

# Backup apenas estrutura
mysqldump -u root -p --no-data cardapio_digital > estrutura_cardapio.sql

# Backup apenas dados
mysqldump -u root -p --no-create-info cardapio_digital > dados_cardapio.sql
```

### **Restaurar Backup**

```bash
# Restaurar backup
mysql -u root -p cardapio_digital < backup_cardapio_20241201.sql
```

---

## 📊 **DADOS DE EXEMPLO INCLUÍDOS**

### **Categorias:**
- Pratos Principais
- Bebidas  
- Sobremesas
- Aperitivos

### **Produtos:**
- Prato do Dia (R$ 25,90)
- Frango Grelhado (R$ 22,50)
- Coca-Cola 350ml (R$ 4,50)
- Suco de Laranja (R$ 6,00)
- Pudim (R$ 8,50)
- Brigadeiro (R$ 3,50)

### **Cupons:**
- **PRIMEIRA10** - 10% primeira compra
- **FRETE20** - Frete grátis acima de R$ 20
- **DESC5** - Desconto fixo de R$ 5

### **Zonas de Entrega:**
- Centro: R$ 5,00 (30 min)
- Sul: R$ 8,00 (45 min)
- Norte: R$ 10,00 (60 min)
- Oeste: R$ 7,00 (40 min)

---

## 🔍 **VERIFICAÇÃO PÓS-INSTALAÇÃO**

```sql
-- Verificar se tudo foi criado
SELECT 
    'Tabelas' as tipo,
    COUNT(*) as quantidade 
FROM information_schema.tables 
WHERE table_schema = 'cardapio_digital'
UNION ALL
SELECT 
    'Views' as tipo,
    COUNT(*) as quantidade 
FROM information_schema.views 
WHERE table_schema = 'cardapio_digital'
UNION ALL
SELECT 
    'Procedures' as tipo,
    COUNT(*) as quantidade 
FROM information_schema.routines 
WHERE routine_schema = 'cardapio_digital';

-- Resultado esperado:
-- Tabelas: 12
-- Views: 3  
-- Procedures: 2
```

---

## 🎯 **PRÓXIMOS PASSOS**

1. ✅ Banco criado com sucesso
2. ⚙️ Configurar arquivo `.env` da aplicação
3. 🔗 Testar conexão com `php artisan tinker`
4. 🚀 Executar a aplicação Laravel
5. 🌐 Acessar o sistema

**Banco de dados pronto para uso! 🎉**
